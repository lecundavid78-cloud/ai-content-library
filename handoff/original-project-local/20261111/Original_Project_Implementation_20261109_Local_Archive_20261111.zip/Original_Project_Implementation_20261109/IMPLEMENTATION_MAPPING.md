# 当前已核实现对应

证据根目录：F:/novoR2/Research_Diagnosis_20261108/ThreeTarget_FourCell_Replication_20261108/R05_Code/v2。

- pilot/scorer.py：S在缓存h12上加入ContextAdapter(hidden,46维context)，再经冻结原head；全六成员合计597376可训参数。LoRA重算第12层Q/V，原rank32方案全六成员589824参数；其余主体与head冻结。两者都使用FullVRH/full19L。不是对最终单个分数缩放，也不是MiniLM最后两块。
- build_schedule.py：明确assert两来源，500步交替、每来源250批；需新单来源版本，不能删一半批仍称500步。
- pilot/engine.py：优化器lr来自常量、500末态保存，无完整AdamW/RNG/游标恢复；不能以旧pt宣称严格续训。
- 全量bank可采样不保证每条贡献梯度；覆盖必须由实际pair端点和更新账本计算。

详细新实现和测试待R05独立回执验收；未据以上静态核查运行模型。
