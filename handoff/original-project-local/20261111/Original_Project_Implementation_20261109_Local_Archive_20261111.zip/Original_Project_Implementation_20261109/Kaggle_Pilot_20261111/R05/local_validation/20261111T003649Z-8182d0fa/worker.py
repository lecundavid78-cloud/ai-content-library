
import argparse
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import time
import uuid

import torch


def write_json(path, data):
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(data, indent=2, allow_nan=False), encoding="utf-8")
    temp.replace(path)


def cuda_uuid():
    # Ask the driver for the physical identity of the only visible CUDA device.
    driver = ctypes.CDLL("libcuda.so.1")
    device = ctypes.c_int()
    raw = (ctypes.c_ubyte * 16)()
    get_uuid = getattr(driver, "cuDeviceGetUuid_v2", None) or driver.cuDeviceGetUuid
    if driver.cuInit(0) or driver.cuDeviceGet(ctypes.byref(device), 0) or get_uuid(ctypes.byref(raw), device):
        raise RuntimeError("CUDA driver UUID query failed")
    return "GPU-" + str(uuid.UUID(bytes=bytes(raw)))


def barrier(local, peer):
    local.touch()
    deadline = time.monotonic() + 30
    while not peer.is_file():
        if time.monotonic() >= deadline:
            raise TimeoutError(f"Rendezvous timed out: {peer.name}")
        time.sleep(0.01)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("rank", type=int, choices=[0, 1])
    parser.add_argument("mode", choices=["cuda", "cpu"])
    args = parser.parse_args()
    root, rank, mode = args.root, args.rank, args.mode
    output = root / f"worker_{rank}"
    torch.set_num_threads(1)
    torch.use_deterministic_algorithms(True)
    seed = 20261111 + rank
    torch.manual_seed(seed)
    device = torch.device("cuda:0" if mode == "cuda" else "cpu")
    gpu = mode == "cuda"
    visibility = os.environ["CUDA_VISIBLE_DEVICES"]
    visible_count = torch.cuda.device_count()
    device_info = None
    if gpu:
        if visible_count != 1:
            raise RuntimeError(f"Expected one visible device; got {visible_count}")
        properties = torch.cuda.get_device_properties(device)
        actual_uuid = cuda_uuid()
        if actual_uuid.lower() != visibility.lower() or "T4" not in properties.name.split():
            raise RuntimeError(f"Unexpected GPU: {properties.name} {actual_uuid}")
        torch.cuda.manual_seed(seed)
        device_info = {"uuid": actual_uuid, "name": properties.name,
                       "total_memory_bytes": properties.total_memory,
                       "capability": [properties.major, properties.minor]}
    elif visible_count != 0:
        raise RuntimeError("CPU verification must have zero visible CUDA devices")

    def sync():
        if gpu:
            torch.cuda.synchronize(device)

    width, batch = (512, 128) if gpu else (16, 8)
    steps = 12 if gpu else 4

    def new_model():
        model = torch.nn.Sequential(torch.nn.Linear(width, width), torch.nn.ReLU(),
                                    torch.nn.Linear(width, width)).to(device)
        return model, torch.optim.Adam(model.parameters(), lr=0.001, foreach=False)

    def step(model, optimizer):
        sync()
        start = time.monotonic_ns()
        optimizer.zero_grad(set_to_none=True)
        x = torch.randn(batch, width, device=device)
        y = torch.randn(batch, width, device=device)
        loss = torch.nn.functional.mse_loss(model(x), y)
        loss.backward()
        optimizer.step()
        sync()
        end = time.monotonic_ns()
        value = loss.item()
        if not math.isfinite(value):
            raise RuntimeError("Non-finite loss")
        return {"start_ns": start, "end_ns": end, "milliseconds": (end - start) / 1e6, "loss": value}

    model, optimizer = new_model()
    sync()
    if gpu:
        torch.cuda.reset_peak_memory_stats(device)
    print(f"worker {rank}, pid {os.getpid()}, mode {mode}, device {device_info}", flush=True)
    barrier(output / "ready", root / f"worker_{1-rank}" / "ready")
    timings = [step(model, optimizer)]
    # Each worker completes a real step before either proceeds to its remaining steps.
    barrier(output / "first_step_done", root / f"worker_{1-rank}" / "first_step_done")
    timings.extend(step(model, optimizer) for _ in range(steps - 1))
    checkpoint = output / "checkpoint.pt"
    torch.save({"model": model.state_dict(), "optimizer": optimizer.state_dict(), "steps": steps,
                "cpu_rng": torch.get_rng_state(),
                "cuda_rng": torch.cuda.get_rng_state(device) if gpu else None}, checkpoint)
    reference = step(model, optimizer)

    restored, restored_optimizer = new_model()
    state = torch.load(checkpoint, map_location="cpu", weights_only=True)
    restored.load_state_dict(state["model"])
    restored_optimizer.load_state_dict(state["optimizer"])
    torch.set_rng_state(state["cpu_rng"])
    if gpu:
        torch.cuda.set_rng_state(state["cuda_rng"], device)
    resumed = step(restored, restored_optimizer)

    for name, parameter in model.state_dict().items():
        torch.testing.assert_close(restored.state_dict()[name], parameter, rtol=0, atol=0)
    for index, entry in optimizer.state_dict()["state"].items():
        for name, value in entry.items():
            torch.testing.assert_close(restored_optimizer.state_dict()["state"][index][name],
                                       value, rtol=0, atol=0)
    if state["steps"] != steps or resumed["loss"] != reference["loss"]:
        raise RuntimeError("Restored next step differs")

    write_json(output / "report.json", {
        "status": "PASS", "task_id": f"{root.name}-worker-{rank}", "rank": rank,
        "pid": os.getpid(), "seed": seed, "mode": mode, "visible_device_count": visible_count,
        "cuda_visible_devices": visibility, "device": device_info,
        "torch": str(torch.__version__), "cuda_build": torch.version.cuda,
        "steps": timings, "timed_training_start_ns": timings[0]["start_ns"],
        "timed_training_end_ns": timings[-1]["end_ns"],
        "peak_allocated_bytes": torch.cuda.max_memory_allocated(device) if gpu else None,
        "peak_reserved_bytes": torch.cuda.max_memory_reserved(device) if gpu else None,
        "checkpoint": {"path": f"worker_{rank}/checkpoint.pt", "steps": steps,
                       "sha256": hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
                       "bytes": checkpoint.stat().st_size},
        "resume": {"exact": True, "reference_next_loss": reference["loss"],
                   "restored_next_loss": resumed["loss"]}
    })


if __name__ == "__main__":
    main()
