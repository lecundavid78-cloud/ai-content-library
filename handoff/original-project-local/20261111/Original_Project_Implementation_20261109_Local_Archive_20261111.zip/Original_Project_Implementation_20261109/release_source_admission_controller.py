"""Audit the fixed CPU payload and bind a single delegated execution release."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
OWNER = ROOT / 'R02/source_bundle_admission_v1'
OUT = ROOT / 'controller_source_admission_release_v1'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()

def main():
    manifest = json.loads((OWNER / 'CPU_PACKAGE_MANIFEST.json').read_bytes())
    archive = Path(manifest['archive']['path'])
    assert sha(archive.read_bytes()) == manifest['archive']['sha256']
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == set(manifest['files'])
        files = {n: z.read(n) for n in z.namelist()}
    assert all(sha(b) == manifest['files'][n] for n,b in files.items())
    assert files['control/derive_sources_cpu.py'] == (OWNER/'derive_sources_cpu.py').read_bytes()
    assert not any(n.endswith(('.pt', '.tsv')) or 'pairs_2000' in n for n in files)
    plan = json.loads(files['control/CONTRACT.json'])
    release = json.loads((OWNER / 'RELEASE_NOT_RELEASED.json').read_bytes())
    assert release['status'] == 'NOT_RELEASED'
    assert release['contract_sha256'] == sha(files['control/CONTRACT.json'])
    assert release['script_sha256'] == sha(files['control/derive_sources_cpu.py'])
    assert plan['controller_admission']['sha256'] == sha(files['control/CONTROLLER_SOURCE_ADMISSION.json'])
    assert len(plan['rows']) == 6
    for n,b in files.items():
        if n.startswith('code/'):
            original = ROOT/'R05/runtime_v1'/n.removeprefix('code/')
            assert original.is_file() and original.read_bytes() == b, n
    # Leave numeric and scientific code unchanged. Give verification sufficient wall time.
    batch = files['source_admission.sbatch'].decode()
    assert batch.count('#SBATCH --time=00:15:00') == 1
    assert batch.count('timeout --signal=TERM --kill-after=15 800 ') == 1
    batch = batch.replace('#SBATCH --time=00:15:00', '#SBATCH --time=00:30:00')
    batch = batch.replace('timeout --signal=TERM --kill-after=15 800 ',
                          'timeout --signal=TERM --kill-after=15 1700 ')
    files['source_admission.sbatch'] = batch.encode()
    release['status'] = 'RELEASED'
    files['control/EXECUTION_RELEASE.json'] = encoded(release)
    OUT.mkdir(exist_ok=True)
    for name in ('source_admission.sbatch',):
        (OUT/name).write_bytes(files[name])
    subprocess.run(['F:/programming language/Git/bin/bash.exe', '-n', str(OUT/'source_admission.sbatch')], check=True)
    (OUT/'EXECUTION_RELEASE.json').write_bytes(files['control/EXECUTION_RELEASE.json'])
    signed = OUT/'SOURCE_ADMISSION_CPU_SIGNED.zip'
    with zipfile.ZipFile(signed, 'w') as z:
        for n,b in sorted(files.items()):
            z.writestr(zipfile.ZipInfo(n,(2026,11,10,0,0,0)),b,compress_type=zipfile.ZIP_DEFLATED)
    acceptance = {
        'schema':'PHASE1_SOURCE_ADMISSION_CPU_CONTROLLER_RELEASE_V1', 'status':'RELEASED',
        'controller':'01a1c09c-f9e6-70f1-b9e8-b988b89c755f',
        'utc':datetime.now(timezone.utc).isoformat(),
        'archive':{'path':str(signed),'sha256':sha(signed.read_bytes()),'bytes':signed.stat().st_size},
        'inner_release':{'path':str(OUT/'EXECUTION_RELEASE.json'),'sha256':sha(files['control/EXECUTION_RELEASE.json'])},
        'files':{n:sha(b) for n,b in sorted(files.items())},
        'remote_root':manifest['new_remote_root'], 'max_new_submissions':1,
        'resources':{'CPU':4,'memory_GiB':32,'Slurm_seconds':1800,'internal_seconds':1700,'GPU':0},
        'scope':'Three immutable SOURCE_POOL parents to exact authorized SOURCE derivatives; three existing TARGET exact full-WT admissions.',
        'checks':{'zip_crc':True,'all_payload_hashes':True,'all_scientific_code_exact':True,
                  'root_replayed_owner_tests':5,'batch_syntax':True,'no_numeric_training_tables':True},
        'changes_from_candidate':['Slurm wall time 900 to 1800 seconds','internal timeout 800 to 1700 seconds','explicit signed release'],
        'preserve': ['all historical caches','all tensors/natural inputs/native scores','existing clean initializations'],
        'formal_training_release':False, 'functional_labels_allowed':False,
        'next':'After actual derived hashes and six admissions, compile exact 12 production training configurations; no new qualifications or initializations.'
    }
    path=ROOT/'CONTROLLER_PHASE1_SOURCE_ADMISSION_CPU_EXECUTION_RELEASE.json'
    path.write_bytes(encoded(acceptance))
    print(json.dumps({'release':str(path),'sha256':sha(path.read_bytes()),'signed_archive_sha256':acceptance['archive']['sha256'],
                      'inner_release_sha256':acceptance['inner_release']['sha256'],'files':len(files)}))

if __name__ == '__main__':
    main()
