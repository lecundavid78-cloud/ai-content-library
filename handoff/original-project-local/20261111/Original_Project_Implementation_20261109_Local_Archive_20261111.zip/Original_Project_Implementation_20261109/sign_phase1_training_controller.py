"""Bind the reviewed twelve real jobs to one finite single-GPU execution release."""
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import zipfile

D=Path(__file__).resolve().parent
P=D/'R02/production_training_deployment_v1'
OUT=D/'controller_phase1_training_signed_v1'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(o):return (json.dumps(o,indent=2)+'\n').encode()
def read(p):return json.loads(p.read_bytes())

def main():
    template=read(P/'TRAINING_RELEASE_NOT_RELEASED.json')
    candidates=read(D/'R05/phase1_v2/actual_train_candidates/CANDIDATES.json')
    acceptance=read(D/'CONTROLLER_PHASE1_V2_REAL_TRAIN_CANDIDATES_ACCEPTANCE.json')
    assert template['candidate_manifest_sha256']==acceptance['candidates']['sha256']
    assert template['status']=='NOT_RELEASED' and len(template['nodes'])==12
    assert template['max_submissions']==12 and template['simultaneous_gpu_max']==1
    assert template['max_train_gpu_seconds']==21600 and template['formal_total_gpu_cap_seconds']==59400
    assert template['automatic_retry'] is False and template['target_labels'] is False
    code=read(D/'R05/runtime_v1/RUNTIME_CODE_SHA256.json')
    release=template|{'status':'RELEASED','nodes':[]}
    OUT.mkdir(exist_ok=True)
    for node in template['nodes']:
        tid=node['track_id'];p=Path(node['archive']['path'])
        assert sha(p.read_bytes())==node['archive']['sha256']
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None and set(z.namelist())==set(node['unsigned_files'])
            files={n:z.read(n) for n in z.namelist()}
        assert {n:sha(b) for n,b in files.items()}==node['unsigned_files']
        job=json.loads(files['JOB.json']);manifest=json.loads(files['MANIFEST.json'])
        assert job==candidates['jobs'][tid]['job']
        assert job['runtime_code_sha256']==code and len(job['cases'])==1
        assert manifest['mounts']=={k:v for k,v in manifest['mounts'].items()}
        assert node['remote_root']==manifest['remote_root'] and node['allocated_gpu_seconds']==1800
        assert node['job_sha256']==sha(files['JOB.json'])
        config_ref=job['cases'][0]['config']
        assert sha(files[config_ref['path'].lstrip('/')])==config_ref['sha256']
        assert manifest['scope']['output']==job['output']
        assert not any('/TARGET/' in path for path in manifest['mounts'])
        inner=json.loads(files['INNER_NOT_RELEASED.json'])|{'status':'RELEASED'}
        files['ROOT_RELEASE.json']=enc(inner)
        outer=json.loads(files['OUTER_NOT_RELEASED.json'])|{'status':'RELEASED','inner_sha256':sha(files['ROOT_RELEASE.json'])}
        assert inner['stage']=='train' and inner['max_updates_per_case']==2000 and inner['wall_seconds']==1500
        assert outer['slurm_seconds']==1800 and outer['gpu']==1 and outer['updates']==2000
        files['OUTER_RELEASE.json']=enc(outer)
        directory=OUT/tid;directory.mkdir(exist_ok=True)
        signed=directory/'TRAIN_SIGNED.zip'
        with zipfile.ZipFile(signed,'w') as z:
            for n,b in sorted(files.items()):
                z.writestr(zipfile.ZipInfo(n,(2026,11,10,0,0,0)),b,compress_type=zipfile.ZIP_DEFLATED)
        release['nodes'].append(node|{'signed_archive':{'path':str(signed),'sha256':sha(signed.read_bytes()),'bytes':signed.stat().st_size},
                                      'inner_sha256':sha(files['ROOT_RELEASE.json']),'outer_sha256':sha(files['OUTER_RELEASE.json'])})
    helpers=['serial_driver.py','serial_remote.py','training_launcher.py','prepare_production.py','test_local.py']
    release['reviewed_helper_files']={str(P/name):sha((P/name).read_bytes()) for name in helpers}
    release['controller_acceptance_sha256']=sha((D/'CONTROLLER_PHASE1_V2_REAL_TRAIN_CANDIDATES_ACCEPTANCE.json').read_bytes())
    path=D/'CONTROLLER_PHASE1_TWELVE_TRAIN_EXECUTION_RELEASE.json'
    path.write_bytes(enc(release))
    result=subprocess.run(['C:/Users/10606/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe',
                           '-X','utf8','-B',str(P/'serial_driver.py'),'check','--release',str(path),'--release-sha256',sha(path.read_bytes())],capture_output=True,text=True)
    assert result.returncode==0,result.stderr
    record={'status':'TWELVE_FORMAL_TRAIN_EXECUTION_RELEASED','utc':datetime.now(timezone.utc).isoformat(),
            'release':{'path':str(path),'sha256':sha(path.read_bytes())},'tracks':12,'max_submissions':12,
            'single_gpu_serial':True,'max_train_gpu_seconds':21600,'formal_total_gpu_seconds':59400,
            'root_replayed_local_package_tests':3,'root_replayed_compiler_tests':8,
            'signed_packages_check':result.stdout.strip(),'old_scientific_runtime_unchanged':True,
            'functional_target_labels_allowed':False,'jobs_submitted_observed':0,
            'review_notes':['Only RUN assignment changed from INIT template; all immutable host mount paths preserved.',
                            'Each generated config is an explicit file mount; exact source-only files, no TARGET mounts.',
                            'Previous training must complete 2000 updates and all three checkpoints before next submission.']}
    (D/'CONTROLLER_PHASE1_TRAIN_DEPLOYMENT_ACCEPTANCE.json').write_bytes(enc(record))
    print(json.dumps({'release_sha256':record['release']['sha256'],'tracks':12,'signed_check':result.stdout.strip()}))

if __name__=='__main__':main()
