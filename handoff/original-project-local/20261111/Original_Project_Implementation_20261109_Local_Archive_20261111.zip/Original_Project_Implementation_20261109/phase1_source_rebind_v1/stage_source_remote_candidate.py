"""Stage only the released training subset bytes supplied in PLAN and ARCHIVE_B64."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import pwd
import zipfile


EXPECTED_ROOT = "/public/home/s20223010065/RFduffision/Original_Project_Implementation_20261109/production_phase1_sources_v1"
EXPECTED_RELEASE = "e363b2014c8c72e32072e03ffb3e2da540a4b35143b6993e0dfc02366429b5ff"
FILENAMES = {"TRAINONLY_ADMISSION.json", "train_bank.tsv", "BANK_INDEX.json", "pairs_2000.json"}
ROUTES = {
    "RCRO_LAMBD_Tsuboyama_2023_1ORC": "TnpB",
    "CAS9_STRP1_Spencer_2017_positive": "AsCas12f",
    "HSP82_YEAST_Flynn_2019": "SpCas9",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def verify_files(root, expected):
    observed = set()
    for path in root.rglob("*"):
        require(not path.is_symlink(), "symlink in source staging root")
        if path.is_file():
            observed.add(path.relative_to(root).as_posix())
    require(observed == set(expected) | {".deploy_claim.json"}, "unexpected or incomplete staging inventory")
    for relative, row in expected.items():
        raw = (root / relative).read_bytes()
        require(len(raw) == row["bytes"] and digest(raw) == row["ref"]["sha256"], "staged file identity differs")


def main(plan, archive_b64):
    require(pwd.getpwuid(os.geteuid()).pw_name == "s20223010065", "unexpected server account")
    require(plan["root"] == EXPECTED_ROOT and plan["release_sha256"] == EXPECTED_RELEASE, "exact staging release required")
    rows = plan["files"]
    groups = {}
    for relative, row in rows.items():
        path = PurePosixPath(relative)
        require(len(path.parts) == 3 and ".." not in path.parts and "\\" not in relative, "invalid relative path")
        source, bank_rule, filename = path.parts
        require(source in ROUTES and bank_rule in {"small594", "full_train"} and filename in FILENAMES, "outside released source subset")
        require(row["source_id"] == source and row["bank_rule"] == bank_rule and row["target_route"] == ROUTES[source], "source route differs")
        require(row["host_path"] == EXPECTED_ROOT + "/" + relative, "host file path differs")
        require(row["ref"]["path"] == "/inputs/sources/" + relative and row["kind"] == "regular_file", "container path differs")
        groups.setdefault((source, bank_rule), set()).add(filename)
    require(len(rows) == 24 and len(groups) == 6 and all(names == FILENAMES for names in groups.values()), "exact six banks required")
    blob = base64.b64decode(archive_b64, validate=True)
    require(digest(blob) == plan["zip_sha256"], "transport archive differs")
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)) == 24 and set(names) == set(rows) and archive.testzip() is None, "archive inventory differs")
        for name, row in rows.items():
            raw = archive.read(name)
            require(len(raw) == row["bytes"] and digest(raw) == row["ref"]["sha256"], "transport file differs")
        root = Path(EXPECTED_ROOT)
        require(root.parent.is_dir() and not root.is_symlink(), "existing project parent required")
        claim = {"release_sha256": EXPECTED_RELEASE, "zip_sha256": plan["zip_sha256"]}
        if root.exists():
            require(json.loads((root / ".deploy_claim.json").read_bytes()) == claim, "existing deployment requires reconciliation")
            verify_files(root, rows)
        else:
            os.umask(0o077)
            root.mkdir(exist_ok=False)
            with (root / ".deploy_claim.json").open("x", encoding="utf-8") as stream:
                json.dump(claim, stream)
            for name in names:
                destination = root / name
                destination.parent.mkdir(parents=True, exist_ok=True)
                with destination.open("xb") as stream:
                    stream.write(archive.read(name))
                destination.chmod(0o444)
            verify_files(root, rows)
    print(json.dumps({"status": "STAGED_24_HASH_VERIFIED", "root": EXPECTED_ROOT,
                      "release_sha256": EXPECTED_RELEASE, "zip_sha256": plan["zip_sha256"],
                      "files": list(rows.values()), "new_sbatch": 0, "gpu": 0}), flush=True)


if __name__ == "__main__":
    main(PLAN, ARCHIVE_B64)
