"""Finite single-source continuity ledger, metadata only, no label-table IO."""
from pathlib import Path
import csv,json,hashlib
R=Path(__file__).resolve().parent
E=Path('F:/novoR2/Research_Diagnosis_20261108/ThreeTarget_FourCell_Replication_20261108')
Q=Path('F:/novoR2/Research_Diagnosis_20261106/FourCell_Pilot_20261106')
P=Path('F:/novoR2/Research_Diagnosis_20261107/ProteinGym217_SourcePool_Audit_20261107')
ACCESS=[]
def ref(p):return {'path':Path(p).as_posix(),'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest(),'bytes':Path(p).stat().st_size}
def read(p):ACCESS.append(ref(p));return json.loads(Path(p).read_text(encoding='utf-8'))
def need(ok,m):
 if not ok:raise ValueError(m)
def dump(n,x):(R/n).write_text(json.dumps(x,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def table(n,rs):
 with (R/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
def metadata_bound(b):
 p=Path(b['path']);need(ref(p)['sha256']==b['sha256'],'bound metadata changed');return read(p)
def main():
 lock=read(E/'R01_Inputs/SOURCE_SELECTION_LOCK.json');numeric=read(E/'R01_Inputs/source_support_v2/SOURCE_NUMERIC_READY.json')
 validation=read(E/'R01_Inputs/NUMERIC_V2_VALIDATION.json');prior=read(Path('F:/novoR2/Research_Diagnosis_20261109/Framework_Convergence_Review_20261109/Execution_Design_SingleSource_v2_20261109/TOP1_METADATA_EVIDENCE.json'))
 top=[]
 for tid,sel in lock['targets'].items():
  x=sel['retrieved']['ESM2_650M']['selected'][0];sid=x['representative_assay'];n=numeric['sources'][sid];a=metadata_bound(n['numeric_admission']);split=metadata_bound(a['split']);v=validation['sources'][sid]
  old=next(x for x in prior['records'] if x['target']==tid)
  need(old['single_representative_assay']==sid and old['all_eligible_train_site_variants']==a['train_before_budget_rows'],'prior TOP1/count identity')
  need(len(split['selected_training_indices'])==594 and a['unique_valid_single']==a['train_before_budget_rows']+a['heldout_rows'],'count reconciliation')
  payload={k:dict(n[k],verification='RECORDED_BYTE_BINDING_FROM_ADMITTED_METADATA_NOT_FUNCTIONAL_FILE_REOPEN') for k in ['train_only_support','pair_batches','source_fields']}
  top.append({'target':tid,'retrieval_rank':1,'source_assay':sid,'ranked_assay_display':x['ranked_assay'],'representative_rule':'max qualified single count then assay-ID tie break; score is WT-level not assay-specific evidence','WT_sha256':a['WT_sha256'],'reference_length':a['length'],'cosine':x['cosine'],'full_unique_single_count':a['unique_valid_single'],'all_train_only_count':a['train_before_budget_rows'],'heldout_count':a['heldout_rows'],'existing_support_count':594,'additional_train_rows_not_in_support':a['train_before_budget_rows']-594,'train_sites':a['train_sites'],'existing_support_sites':v['support_sites'],'source_admission':n['numeric_admission'],'split_metadata':a['split'],'existing_train_payload':payload,'existing_source_batches':250,'pairs_per_class_per_batch':128,'all_train_only_bank_status':'Count/positions admitted; complete all-train table NOT_GENERATED in E; cannot pretend existing594 support is all train data','single_source_500_step_schedule':'NOT_GENERATED_BY_R01; old250 batch stream is source-level asset, not a frozen new500 schedule','new_training_source_admission':'PENDING_DEVELOPMENT_FINAL_ROLE_LOCK; historical TOP1 not unconditional new admission'})
 dump('TOP1_SOURCE_LEDGER.json',{'records':top,'functional_values_read':False})
 table('TOP1_COUNTS.csv',[{k:x[k] for k in ['target','source_assay','ranked_assay_display','WT_sha256','reference_length','full_unique_single_count','all_train_only_count','heldout_count','existing_support_count','additional_train_rows_not_in_support','train_sites','existing_support_sites']} for x in top])
 # Reuse metadata-only existing exposure declarations; no fresh pool audit.
 qsource=read(Q/'R01_Inputs/SOURCE_NUMERIC_INPUTS_READY.json')
 known_source=set(lock['selected_assays'])|set(qsource['source_admissions'])
 targetmeta=read(E/'R01_Inputs/target_bindings_v1/TARGET_LABEL_METADATA_CANDIDATES.json')
 finalsupport=read(E/'R03_Evaluation/final_cpu_run/collected_5200164/evaluation-5200164/receipts/LABEL_SUPPORT_RECEIPT.json')
 amap=read(P/'All217_Retrieval_v1/R01_Inputs/ASSAY_MAP.json')['assays']
 biology_path=P/'R04_Biology/BIOLOGY_AUDIT.csv'
 ACCESS.append(ref(biology_path))
 with biology_path.open(encoding='utf-8-sig',newline='') as f:biology={x['DMS_id']:x for x in csv.DictReader(f)}
 source_WT={x['wt_sha256'] for x in amap if x['assay_id'] in known_source};source_uni={x['UniProt_ID'] for x in amap if x['assay_id'] in known_source}
 pool=[]
 for x in amap:
  sid=x['assay_id'];trained=sid in known_source;sameparent=x['wt_sha256'] in source_WT or x['UniProt_ID'] in source_uni
  pool.append({'assay_id':sid,'WT_sha256':x['wt_sha256'],'UniProt_ID':x['UniProt_ID'],'known_source_in_finite_E_or_Q':trained,'same_parent_or_UniProt_as_known_source':sameparent,'new_independent_final_status':'NOT_NEW_TEST_PREVIOUS_SOURCE_OR_SAME_PARENT' if sameparent else 'UNRESOLVED_HISTORY_NOT_CLEAN_CERTIFIED','exposure_evidence':'existing frozen source lock/admission' if trained else 'same exact WT or existing UniProt parent proxy' if sameparent else 'not selected in these two runs is not proof labels/model tuning never used','study_group':biology[sid]['study_group'],'shared_library_status':biology[sid]['shared_library_status'],'development_final_assignment':'NOT_ASSIGNED; prelock role and dependence before score access'})
 table('EXISTING_EXPOSURE_ROLE_LEDGER_217.csv',pool)
 dev=[{'target':tid,'role':'EXPOSED_DEVELOPMENT_ONLY_NOT_NEW_FINAL_TEST','evaluation_N':finalsupport['measured_supports'][tid]['N'],'historical_exposure':True,'own_target_training_labels_used':False,'other_target_source_role':tid=='SpCas9','constraint':'SpCas9 SOURCE to AsCas12f is historical admitted cross-target use; exclude whole parent from any independent final set; no target-label-based source reselection','evidence':ref(E/'R03_Evaluation/final_cpu_run/collected_5200164/evaluation-5200164/receipts/LABEL_SUPPORT_RECEIPT.json')} for tid in ['TnpB','AsCas12f','SpCas9']]
 dump('DEVELOPMENT_FINAL_BOUNDARY.json',{'exposed_development_targets':dev,'known_source_assays_in_E18_and_Q4':sorted(known_source),'metadata_grouping_only':'exactWT plus existing UniProt proxy; existing certified shared-library links if present; same DOI alone is not proof of same library','independent_development_list':None,'independent_final_list':None,'reason':'No newly approved identity-and-exposure role manifest in current protocol. Do not invent a clean list from absence in two source locks.','mechanical_order':['Freeze explicit history/role manifest for each assay and parent before new scoring','Keep all known source parents disjoint from new independent development/final targets','Group confirmed shared-library records; disclose unknown dependence instead of certifying independence','Choose development/final assignment with predeclared metadata-only deterministic rule and preserve label access boundary','After role lock filter admissible ESM2 ranking; current3 historical Top1 mappings may need exclusion, never target-effect-based replacement'],'clean_new_final_count':'UNKNOWN','known_source_or_parent_records':sum(x['same_parent_or_UniProt_as_known_source'] for x in pool),'other_records_without_clean_history_certification':sum(not x['same_parent_or_UniProt_as_known_source'] for x in pool)})
 gaps=[{'id':'G1','gap':'Independent development/final assay-and-parent list plus prior training/tuning/exposure manifest not frozen','impact':'cannot certify new independent final evidence or final source eligibility','owner':'controller/R03 role contract','data_collection_required':False},{'id':'G2','gap':'594 support files exist; complete all-train source bank for948/6496/10619 rows not generated in this scope','impact':'cannot claim all train-only variants consumed; numeric counts alone are not full bank byte identity','owner':'R01 only after exact bank/usage specification and label-role authorization','data_collection_required':False},{'id':'G3','gap':'Existing250 source batches do not define new single-source500 update schedule or normalization/selection recipe','impact':'must freeze new schedule identity; no ad hoc doubling claimed approved','owner':'R05/controller','data_collection_required':False}]
 dump('MINIMAL_GAPS.json',gaps)
 (R/'说明.md').write_text('''# 单来源实施输入接续

现有ESM2 Top1：TnpB→RCRO_LAMBD_Tsuboyama_2023_1ORC；AsCas12f→CAS9_STRP1_Spencer_2017_positive；SpCas9→HSP82_YEAST_Flynn_2019。HSP82旧排名展示的是Cote-Hammarlof 2020 assay，同WT实际代表按预锁单点数量规则为Flynn2019，不能换成另一个实验。Top1只是历史资格池结果，新开发/最终角色排除后需重绑定，不重算检索。

每源旧支持594条。全部train-only可用数量依次948、6496、10619；留出依次247、1621、2675。支持与pair文件沿原准入metadata指针，不打开功能值、不新生成pair。旧250批次不是新的单来源500步完整日程；完整train-only bank也没有在本轮生成，不能以计数充字节验收。

TnpB、AsCas12f、SpCas9成绩均已曝光，应作为开发对象，不是新的最终独立测试。E18源及Q4源并集、相同WT/现有UniProt母本代理需排除为新最终对象。其余记录仅标历史未闭合，不能凭未出现在这两个source lock就认证干净；同论文不自动当共享库。独立开发名单和最终名单当前没有明确新批准清单，账本保留null/未知，待总控按metadata-only规则冻结。

本次仅元数据接线，未重新217审查，未打开功能表，未运行模型/SSH/sbatch。新单来源设置保留Original、S/LoRA方向；未移植MiniLM或恢复历史实验。详JSON、CSV及缺口表。
''',encoding='utf-8')
 dump('ACCESS_LOG.json',{'metadata_files':ACCESS,'functional_tables_accessed':[],'support_TSV_or_raw_csv_or_pair_generation':False})
 dump('VALIDATION.json',{'status':'PASS_METADATA_IDENTITY_AND_COUNTS','targets':3,'source_support594_all3':True,'full_equals_train_plus_heldout':True,'prior_single_source_evidence_matched':True,'no_new_functional_values':True})
 dump('STATUS.json',{'status':'FINITE_METADATA_LEDGER_COMPLETE_INDEPENDENT_ROLE_LOCK_AND_ALL_TRAIN_BANK_PENDING','controller':'01a1c09c-f9e6-70f1-b9e8-b988b89c755f','scope':'R01_only_current_original_project_preparation','top1_source_count':3,'independent_development_and_final_lists':'NOT_APPROVED_OR_IDENTIFIED_IN_CURRENT_PROTOCOL','exact_gaps':ref(R/'MINIMAL_GAPS.json'),'source_ledger':ref(R/'TOP1_SOURCE_LEDGER.json'),'development_final_boundary':ref(R/'DEVELOPMENT_FINAL_BOUNDARY.json'),'new_functional_reads_models_training_SSH_sbatch':0})
 dump('MANIFEST.json',{'files':[ref(p) for p in sorted(R.iterdir()) if p.is_file() and p.name!='MANIFEST.json']})
 print(json.dumps({'status':ref(R/'STATUS.json'),'known_source_assays':len(known_source),'source_or_parent217':sum(x['same_parent_or_UniProt_as_known_source'] for x in pool),'top1_counts':[(x['target'],x['source_assay'],x['all_train_only_count']) for x in top]}))
if __name__=='__main__':main()
