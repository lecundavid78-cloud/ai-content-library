# 三来源真实 TRAIN-only bank 与2000步配对流

本目录仅用于当前原项目开发阶段：RCRO→TnpB、Spencer positive→AsCas12f、Flynn2019→SpCas9；每个模型单一来源。每源small594精确复制旧支持文件，full_train包含原已锁训练位点的全部合格单替换，分别为948、6496、10619条。不得把Spencer SOURCE挂到SpCas9自己的目标模型。

每bank独立PCG64(seed11)，沿旧采样定义：每步先128同位点、再128跨位点，源内原score高者在前，精确同分拒绝，固定上限无重抽种子；真实生成2000步，不拼接或重复旧250批。两架构引用同一bank和流。配对是重复出现，不是独立新增实验；计划端点覆盖也不等于实际完成更新覆盖。本次实际训练更新为0。

隔离边界：原全池CSV不可避免逐物理行读取并流式哈希。先仅拆出第一个mutant token，由原split路由；源留出行剩余字节和多突变行不解码、不CSV解析、不转换score、不写出。只有TRAIN行到达数值解析。ACCESS_BOUNDARY逐源公开该限制，不声称从未读过含留出值的磁盘字节。隔离测试放置无法UTF-8解码的留出score字段仍成功，证明它未到数值解析；禁止多行quoted CSV，一旦schema/行数不符硬停。未打开任何heldout.tsv或目标评价输入。这里SpCas9物理全表仅在已授权SOURCE专用上下文投影其TRAIN行，不能将该许可扩展到目标评估。

R05_INTERFACE_BINDINGS给原canonical19L索引、heldout位置、bank文件hash和JSON schedule列表及Q compact digest，未伪造bundle/init/runtime/native或代码hash。实际生产配置和资格依当前总控验收及精确release；本数据交付不是训练提交。

读取权限：bank TSV含私有训练数值，不给总控展示；执行端只挂exact bank/pairs/index，不挂整个目录或原全池文件。总控可读READY/STATUS/VALIDATION/身份索引/ACCESS_BOUNDARY。脚本只输出数量，不输出分数。

复现：新空目录运行build_training_banks.py，然后verify_production_banks.py；构建不覆盖既有产物。TEST_EXECUTION保留5项正反例实际运行日志。
