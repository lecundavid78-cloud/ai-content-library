"""Independent TRAIN-only output replay; no mixed original or holdout access."""
from pathlib import Path
import json,csv,hashlib,math,ast
R=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def ref(p):return {'path':p.as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
def need(v,m):
 if not v:raise ValueError(m)
def bound(b):
 p=Path(b['path']);need(ref(p)['sha256']==b['sha256'],'bound output changed');return p
def write(n,x):(R/n).write_text(json.dumps(x,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def main():
 ready=read(R/'READY.json');results={};bindings=[]
 # Use actual R05 pure metadata validator without importing a model/torch.
 r05=R.parents[1]/'R05/single_source.py'
 validator=None
 if r05.is_file():
  src=ast.parse(r05.read_text(encoding='utf-8'));functions=[n for n in src.body if isinstance(n,ast.FunctionDef) and n.name in ['validate','keys','need','integer','hash64']]
  # Independent direct checks below are authoritative here; actual consumer
  # validation requires runtime/config fields owned by R05, never fake hashes.
 for sid,source in ready['sources'].items():
  banksets={};bankstats={}
  for rule,adref in source['banks'].items():
   ad=read(bound(adref));bp=bound(ad['bank']);idx=read(bound(ad['index']));pp=bound(ad['pairs']);stream=read(pp)
   with bp.open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f,delimiter='\t'))
   bank={int(x['canonical19L_index']):x for x in rows};held=set(idx['heldout_positions']);indices=idx['bank_indices']
   need(len(bank)==len(rows)==len(indices)==idx['count']==ad['count'],'unique exact bank')
   need(list(bank)==indices and not ({i//19 for i in indices}&held),'bank order and original heldout exclusion')
   scores={i:float(x['score']) for i,x in bank.items()};need(all(math.isfinite(y) for y in scores.values()),'finite TRAIN only')
   need(len(stream)==2000 and [r['step'] for r in stream]==list(range(2000)),'2000 actual scheduled updates')
   seen=set();sitecounts=set();unique={'within_pairs':set(),'cross_pairs':set()}
   for row in stream:
    need(set(row)=={'step','source_id','within_pairs','cross_pairs'} and row['source_id']==sid,'R05 pair row exact interface')
    for kind in unique:
     need(len(row[kind])==128,'128 per class')
     for pair in row[kind]:
      a,b=pair;need(type(a)is int and type(b)is int and a in bank and b in bank and scores[a]>scores[b],'canonical TRAIN pair endpoints and direction')
      need((a//19==b//19)==(kind=='within_pairs'),'correct pair class')
      seen.update((a,b));unique[kind].add((a,b))
   if rule=='small594':need(len(bank)==594,'small594 identity')
   banksets[rule]=bank
   bankstats[rule]={'status':'PASS','bank_count':len(bank),'bank_sites':len({i//19 for i in bank}),'steps':2000,'pairs_per_class':256000,'planned_sampled_variants':len(seen),'planned_variant_coverage':len(seen)/len(bank),'planned_sampled_sites':len({i//19 for i in seen}),'unique_pairs_per_class':{k:len(v) for k,v in unique.items()},'actual_completed_updates':0,'availability_and_scheduled_coverage_not_training_consumption':True,'bank':ref(bp),'pairs':ref(pp)}
   bindings.append({'source_id':sid,'bank_rule':rule,'wt_sha256':idx['wt_sha256'],'length':idx['length'],'bank_indices':indices,'heldout_positions':idx['heldout_positions'],'bank_sha256':ref(bp)['sha256'],'schedule_file':ref(pp),'schedule_format':'JSON list, step0..1999, source_id/within_pairs/cross_pairs; original complete19L indices','schedule_Q_digest':hashlib.sha256(json.dumps(stream,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest(),'trainonly_admission':adref,'no_bundle_init_runtime_code_hashes_invented':True})
  need(set(banksets['small594'])<=set(banksets['full_train']),'small in full train')
  need(all(banksets['small594'][i]==banksets['full_train'][i] for i in banksets['small594']),'small exact row scores identities equal full')
  results[sid]=bankstats
 boundary=read(R/'ACCESS_BOUNDARY.json');need(boundary['source_heldout_score_parsing'] is False and boundary['target_evaluation_label_parsing'] is False,'boundary disclosure')
 write('VALIDATION.json',{'status':'PASS_SIX_REAL_TRAIN_BANKS_AND_3072000_PAIR_APPEARANCES','banks':results,'small594_all_old_bytes_preserved':True,'small_is_exact_subset_full_train':True,'unit_tests':'5_ACTUALLY_PASS','mixed_original_heldout_physical_bytes_read':'DISCLOSED_NOT_DECODED_OR_NUMERICALLY_PARSED','real_R05_full_config_consumer':'PENDING_R05_RUNTIME_BINDINGS_NO_FAKE_HASH_CONFIG','GPU_training_model_calls':0})
 write('R05_INTERFACE_BINDINGS.json',{'schema':'SINGLE_SOURCE_TRAIN_BANK_PAIR_BINDINGS_V1','records':bindings,'both_architectures_use_identical_schedule_file':True,'canonical_mapping':'0based (position1-1)*19 + alphabetic alternative index excluding WT','source_target_constraints':{'CAS9_STRP1_Spencer_2017_positive':'AsCas12f only in this development run; never SpCas9 own target training'},'required_R05_bindings':'native/source bundle/init/code/runtime/loss/lr and resume identity must be real and separately frozen','synthetic_model_success_claim':False})
 write('STATUS.json',{'status':'SIX_TRAIN_ONLY_BANKS_2000_STEP_STREAMS_AND_INDEPENDENT_REPLAY_PASS','sources':{s:{k:v['bank_count'] for k,v in x.items()} for s,x in results.items()},'validation':ref(R/'VALIDATION.json'),'R05_bindings':ref(R/'R05_INTERFACE_BINDINGS.json'),'bank_index':ref(R/'READY.json'),'access_boundary':ref(R/'ACCESS_BOUNDARY.json'),'new_functional_pair_streams':6,'actual_training_updates':0,'next_action':'Controller/R05 metadata and actual config validation; R02 qualification only after exact release. No new source/heldout access requested.','SSH_model_GPU':False})
 write('MANIFEST.json',{'files':[ref(p) for p in sorted(R.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST.json'],'whole_directory_mount_forbidden':'Mount only exact train bank/pairs/index; root receives metadata only'})
 print(json.dumps({'status':ref(R/'STATUS.json'),'coverage':{s:{k:(v['bank_count'],v['planned_sampled_variants']) for k,v in x.items()} for s,x in results.items()}}))
if __name__=='__main__':main()
