"""Exact authorized three-source TRAIN projection; no heldout score decoding.

Physical mixed-file bytes must be read for identity and line routing. Only the
first CSV mutation token is decoded before split routing. A heldout line's
remaining bytes are never CSV-parsed/decoded/converted to scores or exported.
Fail closed for embedded-newline CSV or a header not beginning with mutant.
"""
from pathlib import Path
from collections import defaultdict,Counter
import csv,io,json,hashlib,math,re,time
import numpy as np
R=Path(__file__).resolve().parent
E=Path('F:/novoR2/Research_Diagnosis_20261108/ThreeTarget_FourCell_Replication_20261108/R01_Inputs')
META=Path('F:/novoR2/DMS_Panel_Assets_20261028/provenance/OFFICIAL_DMS_substitutions.csv')
SOURCES={'RCRO_LAMBD_Tsuboyama_2023_1ORC':'TnpB','CAS9_STRP1_Spencer_2017_positive':'AsCas12f','HSP82_YEAST_Flynn_2019':'SpCas9'}
AA='ACDEFGHIKLMNPQRSTVWY';TOKEN=re.compile(rb'"?([ACDEFGHIKLMNPQRSTVWY])(\d+)([ACDEFGHIKLMNPQRSTVWY])"?$')
FIELDS=['source_id','variant','pos1','wt','alt','canonical19L_index','score','original_csv_row1']
def need(v,m):
 if not v:raise ValueError(m)
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return {'path':Path(p).as_posix(),'sha256':sha(p),'bytes':Path(p).stat().st_size}
def write(p,d):
 with p.open('x',encoding='utf-8') as f:json.dump(d,f,sort_keys=True,separators=(',',':'),allow_nan=False);f.write('\n')
def table(p,rows):
 with p.open('x',encoding='utf-8',newline='') as f:
  w=csv.DictWriter(f,fieldnames=FIELDS,delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)
def route(raw,train,held,wt):
 token=raw.split(b',',1)[0];m=TOKEN.fullmatch(token)
 if m is None and b':' in token:
  parts=token.strip(b'"').split(b':')
  need(all(TOKEN.fullmatch(x) for x in parts),'invalid multivariant token')
  return None,None # Previously admitted mixed table: multis never enter single bank.
 need(m is not None,'non-single/multiline mutation token: refuse mixed-file projection')
 a,p,b=m.groups();p=int(p)
 need(1<=p<=len(wt) and wt[p-1]==a.decode() and a!=b,'mutation identity')
 need((p in train) != (p in held),'split membership ambiguous')
 return p in train,p
def project(path,expected,split,wt,sid):
 train=set(split['train_positions1']);held=set(split['heldout_positions1']);need(not train&held,'split overlap')
 hasher=hashlib.sha256();out=[];routed=Counter();seen=set();skipped_ids=[]
 with path.open('rb') as f:
  header=f.readline();hasher.update(header);fields=next(csv.reader([header.decode('utf-8-sig')]))
  need(fields[0]=='mutant' and {'mutant','mutated_sequence','DMS_score'}<=set(fields),'locked plain PG schema')
  for rowno,line in enumerate(f,2):
   hasher.update(line);inside,pos=route(line,train,held,wt)
   if inside is None:routed['multi_variant_physical_lines_skipped_before_score_decode']+=1;continue
   if not inside:routed['heldout_physical_lines_skipped_before_score_decode']+=1;skipped_ids.append(line.split(b',',1)[0]);continue
   # Only already-routed TRAIN lines reach CSV decoding or numerical parsing.
   parsed=list(csv.reader([line.decode('utf-8')]))
   need(len(parsed)==1 and len(parsed[0])==len(fields),'multiline/width mismatch')
   x=dict(zip(fields,parsed[0]));v=x['mutant'];alt=v[-1];y=float(x['DMS_score'])
   need(math.isfinite(y) and v not in seen,'finite unique TRAIN rows');seen.add(v)
   need(x['mutated_sequence']==wt[:pos-1]+alt+wt[pos:],'full TRAIN mutation sequence')
   index=(pos-1)*19+[a for a in AA if a!=wt[pos-1]].index(alt)
   out.append(dict(source_id=sid,variant=v,pos1=pos,wt=wt[pos-1],alt=alt,canonical19L_index=index,score=x['DMS_score'],original_csv_row1=rowno));routed['train_lines_score_decoded']+=1
 need(hasher.hexdigest()==expected['sha256'] and path.stat().st_size==expected['bytes'],'full original bytes identity')
 out.sort(key=lambda x:x['canonical19L_index'])
 return out,dict(routed)
def pair_stream(sid,rows,steps=2000,seed=11,per_class=128):
 by=defaultdict(list)
 for x in rows:by[x['pos1']].append(x)
 sites=sorted(by);within=[p for p in sites if len(by[p])>=2]
 need(len(sites)>=2 and any(len({float(x['score']) for x in by[p]})>=2 for p in within),'non-tied within feasibility')
 need(len({float(x['score']) for x in rows})>=2,'nonconstant bank')
 rng=np.random.Generator(np.random.PCG64(seed));tot=Counter();usage=Counter();pairusage={'within':Counter(),'cross':Counter()};schedule=[]
 for step in range(steps):
  batch={'step':step,'source_id':sid,'within_pairs':[],'cross_pairs':[]}
  for kind in ['within','cross']:
   attempts=0
   while len(batch[kind+'_pairs'])<per_class:
    attempts+=1;need(attempts<=1000000,'bounded tie rejection exhausted; no reseed')
    if kind=='within':
     p=int(rng.choice(within));ij=rng.choice(len(by[p]),size=2,replace=False);a,b=by[p][int(ij[0])],by[p][int(ij[1])]
    else:
     pp=rng.choice(sites,size=2,replace=False);p,q=map(int,pp);a=by[p][int(rng.integers(len(by[p])))];b=by[q][int(rng.integers(len(by[q])))]
    ya,yb=float(a['score']),float(b['score'])
    if ya==yb:tot[kind+'_ties_rejected']+=1;continue
    pair=[a['canonical19L_index'],b['canonical19L_index']] if ya>yb else [b['canonical19L_index'],a['canonical19L_index']]
    batch[kind+'_pairs'].append(pair);usage.update(pair);pairusage[kind].update([tuple(pair)])
   tot[kind+'_attempts']+=attempts
  schedule.append(batch)
 return schedule,{'seed':seed,'rng':'PCG64','steps':steps,'class_order':'within then cross per step; one uninterrupted RNG stream per bank','attempts_and_ties':dict(tot),'pair_counts':{k:{'appearances':sum(v.values()),'unique':len(v),'repeated_appearances':sum(v.values())-len(v)} for k,v in pairusage.items()},'planned_prefix_coverage':{str(T):coverage(schedule[:T],rows) for T in [500,1000,2000] if T<=steps},'actual_completed_training_updates':0,'bank_available_is_not_actual_training_consumption':True}
def coverage(schedule,rows):
 endpoints={i for b in schedule for k in ['within_pairs','cross_pairs'] for pair in b[k] for i in pair};bank={r['canonical19L_index'] for r in rows};sites={i//19 for i in endpoints}
 return {'planned_updates':len(schedule),'bank_variants':len(bank),'sampled_endpoint_variants':len(endpoints),'planned_variant_coverage':len(endpoints)/len(bank),'bank_sites':len({i//19 for i in bank}),'sampled_sites':len(sites),'unseen_bank_indices':sorted(bank-endpoints),'not_actual_completed_updates':True}
def main():
 need(not (R/'READY.json').exists(),'no automatic regeneration')
 with META.open(encoding='utf-8-sig') as f:md={x['DMS_id']:x for x in csv.DictReader(f)}
 ready=read(E/'source_support_v2/SOURCE_NUMERIC_READY.json');ledger={};access=[];started=time.time()
 for sid,target in SOURCES.items():
  entry=ready['sources'][sid];adfile=Path(entry['numeric_admission']['path']);need(sha(adfile)==entry['numeric_admission']['sha256'],'old admission')
  ad=read(adfile);sp=Path(ad['split']['path']);need(sha(sp)==ad['split']['sha256'],'old split hash');split=read(sp)
  path=Path(ad['input']['path']);wt=md[sid]['target_seq'];full,boundary=project(path,ad['input'],split,wt,sid)
  need(len(full)==ad['train_before_budget_rows'] and boundary.get('heldout_physical_lines_skipped_before_score_decode',0)==ad['heldout_rows'],'original admitted partition counts')
  smallpath=Path(entry['train_only_support']['path']);need(sha(smallpath)==entry['train_only_support']['sha256'],'exact old support bytes')
  with smallpath.open(encoding='utf-8',newline='') as f:small=list(csv.DictReader(f,delimiter='\t'))
  index={r['variant']:r for r in full}
  for row in small:
   original=index[row['variant']]
   need(all(str(original[k])==str(row[k]) for k in FIELDS),'exact small594 subset row')
  need(len(small)==594 and [int(x['canonical19L_index']) for x in small]==split['selected_training_indices'],'exact old selected order')
  # Numeric fields decoded only from the authorized existing train-only support.
  for x in small:
   for k in ['pos1','canonical19L_index','original_csv_row1']:x[k]=int(x[k])
  d=R/sid;d.mkdir();banks={}
  for rule,rows in [('small594',small),('full_train',full)]:
   bankdir=d/rule;bankdir.mkdir();bankfile=bankdir/'train_bank.tsv'
   if rule=='small594':bankfile.write_bytes(smallpath.read_bytes())
   else:table(bankfile,rows)
   if rule=='small594':need(sha(bankfile)==entry['train_only_support']['sha256'],'small byte copy')
   stream,stats=pair_stream(sid,rows);pairfile=bankdir/'pairs_2000.json';write(pairfile,stream)
   indices=[int(x['canonical19L_index']) for x in rows];supportfile=bankdir/'BANK_INDEX.json'
   write(supportfile,{'source_id':sid,'bank_rule':rule,'wt_sha256':ad['WT_sha256'],'length':ad['length'],'bank_indices':indices,'heldout_positions':split['heldout_positions0'],'count':len(rows),'sites':len({x['pos1'] for x in rows}),'bank_file':ref(bankfile),'score_column':'score','direction':'higher_is_better','canonical_index':'0-based complete19L; position0=index//19; alternate alphabetical AA20 excluding WT'})
   write(bankdir/'SAMPLING_COVERAGE.json',stats)
   manifest={'source_id':sid,'target_development_use':target,'bank_rule':rule,'role':'SOURCE_TRAIN_ONLY','count':len(rows),'bank':ref(bankfile),'index':ref(supportfile),'pairs':ref(pairfile),'sampling':ref(bankdir/'SAMPLING_COVERAGE.json'),'original_admission':ref(adfile),'original_split':ref(sp),'seed':11,'steps':2000,'pairs_each_class_per_step':128,'same_bank_and_stream_for_S_and_LoRA':True,'new_training_release':False}
   write(bankdir/'TRAINONLY_ADMISSION.json',manifest);banks[rule]=ref(bankdir/'TRAINONLY_ADMISSION.json')
   print('PREPARED '+sid+' '+rule+' N='+str(len(rows)),flush=True)
  access.append({'source':sid,'original_file_metadata':ad['input'],'boundary':boundary,'physical_read':'mixed original CSV full bytes read for hashing/line routing; first mutation token only before split; heldout remainder never decoded/parsed/numerically processed or exported','heldout_file_opened':False,'target_evaluation_role_file_opened':False,'authorized_SOURCE_context':target,'SpCas9_SOURCE_exception':sid.startswith('CAS9_')})
  ledger[sid]={'target':target,'banks':banks,'full_train_count':len(full),'small594_original_byte_hash_preserved':True}
 write(R/'ACCESS_BOUNDARY.json',{'sources':access,'source_heldout_score_parsing':False,'target_evaluation_label_parsing':False,'unavoidable_physical_mixed_file_bytes_read_disclosed':True})
 write(R/'READY.json',{'status':'SIX_TRAINONLY_BANKS_AND_SIX_REAL_2000_STEP_STREAMS_CREATED_PENDING_INDEPENDENT_VALIDATION','sources':ledger,'seeds':[11],'bank_rules':['small594','full_train'],'new_model_SSH_GPU':False,'actual_training_completed_updates':0,'wall_seconds':time.time()-started,'implementation':ref(Path(__file__)),'numpy_version':np.__version__,'loss_contract':'source-internal within and cross class means then equal weighting; unchanged objective; data only here'})
 print(json.dumps({'sources':len(ledger),'banks':6,'steps_each':2000,'wall_seconds':time.time()-started}))
if __name__=='__main__':main()
