from pathlib import Path
import tempfile,hashlib,unittest
from build_training_banks import project,pair_stream,route
class Tests(unittest.TestCase):
 def test_heldout_poison_score_is_not_decoded(self):
  b=b'mutant,mutated_sequence,DMS_score\nA1C,CCD,1\nD3E,ACE,\xffNOT_A_SCORE\n'
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'synthetic.csv';p.write_bytes(b)
   rows,c=project(p,{'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)},{'train_positions1':[1],'heldout_positions1':[3]},'ACD','synthetic')
   self.assertEqual(len(rows),1);self.assertEqual(c['heldout_physical_lines_skipped_before_score_decode'],1)
 def test_overlap_or_unknown_position_rejected(self):
  for train,held in [({1},{1}),(set(),set())]:
   with self.assertRaises(ValueError):route(b'A1C,CCD,1\n',train,held,'ACD')
 def test_multi_skipped_before_score(self):
  self.assertEqual(route(b'A1C:D3E,CCE,not-score\n',{1},{3},'ACD'),(None,None))
 def bank(self):return [{'pos1':p,'canonical19L_index':19*(p-1)+a,'score':str(p+a)} for p in [1,2] for a in [0,1,2]]
 def test_real_stream_repeatability_and_direction(self):
  rows=self.bank();a,stats=pair_stream('x',rows,steps=5,per_class=4);b,_=pair_stream('x',rows,steps=5,per_class=4)
  self.assertEqual(a,b);scores={x['canonical19L_index']:float(x['score']) for x in rows}
  for rec in a:
   for key in ['within_pairs','cross_pairs']:
    for i,j in rec[key]:self.assertGreater(scores[i],scores[j]);self.assertEqual(i//19==j//19,key=='within_pairs')
 def test_constant_and_no_within_rejected(self):
  rows=self.bank()
  for x in rows:x['score']='1'
  with self.assertRaises(ValueError):pair_stream('x',rows,steps=1)
  with self.assertRaises(ValueError):pair_stream('x',[{'pos1':1,'canonical19L_index':0,'score':'1'},{'pos1':2,'canonical19L_index':19,'score':'2'}],steps=1)
if __name__=='__main__':unittest.main(verbosity=2)
