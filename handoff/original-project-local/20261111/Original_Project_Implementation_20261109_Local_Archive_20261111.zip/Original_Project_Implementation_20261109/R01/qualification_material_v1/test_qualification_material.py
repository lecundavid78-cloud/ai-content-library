import copy,unittest
from pathlib import Path
from build_qualification_material import R,PRODUCTION,read,bound,validate,ALLOWED
class Checks(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  ready=read(PRODUCTION/'READY.json');cls.fixtures={}
  built=read(R/'READY.json')
  for sid in ALLOWED:
   ad=read(bound(ready['sources'][sid]['banks']['small594']));ap=bound(ad['original_admission'])
   w=read(bound(built['sources'][sid]['wrapper']))
   cls.fixtures[sid]=(read(bound(w['original_natural'])),read(ap),read(bound(ad['index'])),read(bound(ad['original_split'])),read(ap.parent/'SOURCE_ADMISSION_FIELDS.json'),read(bound(ad['pairs'])))
 def test_all_three_exact(self):
  for sid,fixture in self.fixtures.items():self.assertTrue(validate(sid,*fixture))
 def test_target_role_rejected(self):
  sid=next(iter(self.fixtures));f=copy.deepcopy(self.fixtures[sid]);f[0]['role']='TARGET'
  with self.assertRaises(ValueError):validate(sid,*f)
 def test_WT_identity_rejected(self):
  sid=next(iter(self.fixtures));f=copy.deepcopy(self.fixtures[sid]);f[0]['wt_sha256']='0'*64
  with self.assertRaises(ValueError):validate(sid,*f)
 def test_heldout_and_pair_injection_rejected(self):
  sid=next(iter(self.fixtures));f=copy.deepcopy(self.fixtures[sid]);f[2]['heldout_positions'].append(f[2]['bank_indices'][0]//19)
  with self.assertRaises(ValueError):validate(sid,*f)
  f=copy.deepcopy(self.fixtures[sid]);f[5][0]['within_pairs'][0][0]=-1
  with self.assertRaises(ValueError):validate(sid,*f)
 def test_other_source_or_reordered_batch_rejected(self):
  sid=next(iter(self.fixtures));f=copy.deepcopy(self.fixtures[sid])
  with self.assertRaises(ValueError):validate('unknown',*f)
  f[5][0]['step']=1
  with self.assertRaises(ValueError):validate(sid,*f)
 def test_slices_and_fields_exact(self):
  for sid,f in self.fixtures.items():
   out=R/sid;self.assertEqual(read(out/'pair_slice.json'),f[5][:2]);self.assertEqual(read(out/'derived_admission.json'),f[4])
if __name__=='__main__':unittest.main(verbosity=2)
