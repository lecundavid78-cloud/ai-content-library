"""Explicit source-role bridge. Reads JSON metadata/pair indices only."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parent;E=R.parents[1]
PRODUCTION=R.parent/'production_inputs_v1'
OLD=Path('F:/novoR2/Research_Diagnosis_20261108/ThreeTarget_FourCell_Replication_20261108/R01_Inputs')
CONTROLLER='01a1c09c-f9e6-70f1-b9e8-b988b89c755f'
ALLOWED={'RCRO_LAMBD_Tsuboyama_2023_1ORC':'TnpB','CAS9_STRP1_Spencer_2017_positive':'AsCas12f','HSP82_YEAST_Flynn_2019':'SpCas9'}
ACCESS=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return {'path':Path(p).as_posix(),'sha256':sha(p)}
def read(p):
 ACCESS.append(ref(p));return json.loads(Path(p).read_text(encoding='utf-8'))
def need(v,m):
 if not bool(v):raise ValueError(m)
def bound(b):
 p=Path(b['path']);need(sha(p)==b['sha256'],'changed bound metadata '+str(p));return p
def write(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,sort_keys=True,indent=2,allow_nan=False);f.write('\n')
def validate(sid,natural,admission,index,split,original_fields,pairs):
 need(sid in ALLOWED,'not one of three authorized sources')
 need(natural['schema']=='FOURCELL_NATURAL_V1' and natural['role'] in ['SOURCE_POOL','SOURCE'] and natural['functional_labels_included'] is False,'only explicit existing source natural; TARGET forbidden')
 need(natural['asset_id']==admission['source_id']==index['source_id']==split['source_id']==sid,'source identity')
 need(natural['wt_sha256']==admission['WT_sha256']==index['wt_sha256']==split['WT_sha256']==original_fields['wt_sha256'],'source WT equality')
 need(hashlib.sha256(natural['wt_sequence'].encode()).hexdigest()==natural['wt_sha256'],'full natural WT digest')
 need(index['bank_rule']=='small594' and index['count']==len(index['bank_indices'])==594 and len(set(index['bank_indices']))==594,'exact small594')
 need(index['bank_indices']==split['selected_training_indices']==original_fields['training_indices'],'original support order unchanged')
 need(index['heldout_positions']==split['heldout_positions0']==original_fields['heldout_positions'],'original heldout positions')
 need(original_fields['role']=='SOURCE','original numeric source role')
 bank=set(index['bank_indices']);L=len(natural['wt_sequence'])
 need(all(type(i)is int and 0<=i<19*L for i in bank),'canonical19L bank')
 need(not ({i//19 for i in bank}&set(index['heldout_positions'])),'no heldout support')
 need(len(pairs)==2000,'real parent2000 stream')
 for step,row in enumerate(pairs[:2]):
  need(set(row)=={'step','source_id','within_pairs','cross_pairs'} and row['source_id']==sid and row['step']==step,'exact first two rows')
  for kind in ['within_pairs','cross_pairs']:
   need(len(row[kind])==128,'both128 pair classes')
   for pair in row[kind]:
    need(len(pair)==2 and all(type(i)is int and i in bank for i in pair) and pair[0]!=pair[1],'pair TRAIN bank only')
    need((pair[0]//19==pair[1]//19)==(kind=='within_pairs'),'pair site class')
 return True
def main():
 contract=E/'QUALIFICATION_SOURCE_ROLE_CONTRACT.md';need(contract.is_file(),'controller contract missing')
 ready=read(PRODUCTION/'READY.json');naturalindex=read(OLD/'SOURCE_NATURAL_READY.json')
 need(set(ready['sources'])==set(ALLOWED),'exact current sources')
 sources={};mount=[];originalHashes={}
 for sid in ALLOWED:
  trainad=read(bound(ready['sources'][sid]['banks']['small594']))
  adp=bound(trainad['original_admission']);ad=read(adp);sp=read(bound(trainad['original_split']))
  idxp=bound(trainad['index']);idx=read(idxp);pairp=bound(trainad['pairs']);pairs=read(pairp)
  np=bound(naturalindex['sources'][sid]['natural']);natural=read(np);originalHashes[np]=sha(np)
  fieldp=adp.parent/'SOURCE_ADMISSION_FIELDS.json';fields=read(fieldp)
  need(fields['admission_sha256']==sha(adp),'original fields to numeric admission')
  need(idx['bank_file']['sha256']==trainad['bank']['sha256']==ad['training_table']['sha256'],'metadata-only exact small bank identity')
  validate(sid,natural,ad,idx,sp,fields,pairs)
  out=R/sid;out.mkdir()
  derived={k:fields[k] for k in ['role','wt_sha256','training_indices','heldout_positions','admission_sha256']}
  write(out/'derived_admission.json',derived)
  write(out/'pair_slice.json',pairs[:2])
  wrapper={'schema':'SINGLE_SOURCE_QUALIFICATION_MATERIAL_V1','controller':CONTROLLER,'stage':'CPU_QUALIFICATION_ONLY','role':'ADMITTED_SOURCE','source_id':sid,'wt_sha256':natural['wt_sha256'],'original_natural':ref(np),'original_numeric_admission':ref(adp),'bank_index':ref(idxp),'derived_admission':ref(out/'derived_admission.json'),'pair_slice':ref(out/'pair_slice.json'),'parent_pair_stream_sha256':sha(pairp),'parent_pair_count':2000,'slice_steps':[0,1]}
  wp=out/'SOURCE_QUALIFICATION_WRAPPER.json';write(wp,wrapper)
  arrays=np.parent/natural['arrays']['path']
  # Existing NPZ identity is recorded, not re-read/recomputed; consumer owns load.
  sources[sid]={'wrapper':ref(wp),'natural_original_role':natural['role'],'target_development_context_only':ALLOWED[sid],'bank_indices_count':594,'pair_slice_steps':2,'ordered_pair_appearances':512,'derived_admission':ref(out/'derived_admission.json'),'pair_slice':ref(out/'pair_slice.json'),'parent_pair_stream':ref(pairp),'original_natural':ref(np),'original_numeric_admission':ref(adp),'bank_index':ref(idxp),'natural_arrays_binding':{'path':arrays.as_posix(),'sha256':natural['arrays']['sha256']},'no_source_scores_present':True,'no_original_role_overwrite':True}
  mount.extend([ref(wp),ref(np),ref(adp),ref(idxp),ref(out/'derived_admission.json'),ref(out/'pair_slice.json'),{'path':arrays.as_posix(),'sha256':natural['arrays']['sha256']}])
 for p,h in originalHashes.items():need(sha(p)==h,'historical natural changed')
 write(R/'READY.json',{'schema':'QUALIFICATION_SOURCE_MATERIAL_READY_V1','status':'THREE_SMALL594_SOURCE_WRAPPERS_AND_TWO_BATCH_SLICES_READY_NOT_MODEL_RELEASE','controller_contract':ref(contract),'sources':sources,'unchanged_original_natural_roles':True,'qualification_role_only':True,'model_GPU_SSH':False})
 write(R/'PAYLOAD_ALLOWLIST.json',{'files':mount,'do_not_mount':['train_bank.tsv','train_support.tsv','raw functional CSV','full pairs_2000.json','target evaluation or heldout directories'],'scope':'qualified source CPU interface only; no model execution release','SpCas9_SOURCE_rule':'Only AsCas12f source context; cannot open SpCas9 target evaluation labels'})
 write(R/'ACCESS_LOG.json',{'JSON_inputs_and_pair_identity_only':ACCESS,'TSV_or_raw_functional_table_opened':False,'new_pairs_sampled':False,'old_natural_roles_changed':False})
 write(R/'STATUS.json',{'status':'QUALIFICATION_METADATA_READY_PENDING_R05_CONSUMER','ready':ref(R/'READY.json'),'payload':ref(R/'PAYLOAD_ALLOWLIST.json'),'source_count':3,'no_numeric_scores_or_TSV_output':True,'next_action':'R05 validates explicit wrapper parent identity and original natural source role; R02 binds exact material only after root release.','GPU_SSH_target_labels_or_new_search':False})
 print(json.dumps({'ready':ref(R/'READY.json'),'wrappers':{s:x['wrapper'] for s,x in sources.items()},'status':ref(R/'STATUS.json')}))
if __name__=='__main__':main()
