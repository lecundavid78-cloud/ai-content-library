# 单来源实施映射（2026-11-09）

**最终状态：接口 + 新生产控制循环接线及CPU toy回归通过；真实ProSST/CUDA/服务器资格未验证，整轮不标READY。** 当前总控01a1c09c-f9e6-70f1-b9e8-b988b89c755f，依据本轮CONTROL_PROTOCOL。此目录无真实模型调用、标签解析、训练、SSH或sbatch。历史11/08 v2及科学底座不改，不恢复旧双来源图或MiniLM设置。

## 现有真实插入点与精确预算

旧源码基准目录为 `F:/novoR2/Research_Diagnosis_20261108/ThreeTarget_FourCell_Replication_20261108/R05_Code/v2`，文件SHA/行号见MAPPING_EVIDENCE.json。

|路径/行|原版或适配位置|可训与冻结|
|---|---|---|
|pilot/provider.py:90 capture_member；pilot/scorer.py:81 admit|原WT完整前向抓末块输入h11、结构hidden、mask/relative位置；另留h12与原AA25|h11/h12、天然输入、MSA、结构码均detached。缓存与六成员native/WT/天然/结构身份相符才复用，检索向量不是h11。|
|pilot/scorer.py:93 fields|Original使用原head输出及原VRH；S使用h12 + ContextAdapter(h12,46维context,canonical mask,member)，再走原cls|S bottleneck64，共22张量597376可训参数。共享adapter结构含成员条件；六底座和完整head冻结，保留head输入autograd。|
|r05_internal/lora.py:10 PATHS；pilot/scorer.py:100|六成员encoder.layer[11].attention.self.query/value，h11重放末块，再原cls|12个Q/V投影，A/B共24张量589824参数；rank32/alpha32、未合并，原Q/V及其他底座/head冻结。|
|pilot/scorer.py:116 score；r05_internal/suffix.py:44|原AA25→FullVRH完整19L、full统计梯度；loss为within/cross各自mean softplus(-(preferred-other))再各半平均|本接口不改任何科学公式；当前仅这个既有loss可用。前列目标/阈值仍待负责人决定，不暗加新目标。|
|pilot/scorer.py:73 guard及139 verify_frozen|运行中tensor stamp、末态完整冻结byte/head哈希检查|新接口不代替原guard，frozen_sha必须来自实际原scorer.verify_frozen，而非随意常量。|

旧engine.py:38 train硬锁双源、500步、step0初始化；旧checkpoint只有adapter张量，没有AdamW/RNG。本轮不向它塞一个假第二来源，也不把旧FINAL_500转换成完整恢复文件。Original仍单列，只预测不训练；不能以原版历史指标替代精确实物身份核验。

## 基础接口（已实现）

- `single_source.validate(config,schedule)`：精确单来源schema，不接受sources第二字段、列表来源、其他source_id或旧schema；train bank必须唯一合法19L索引且不含heldout整位点。steps/lr/checkpoints/pairs_per_class显式输入；无512下限、4遍、594、500或种子11硬锁。末步必须在checkpoint列表中。科学优化器其余字段按原FP32 AdamW冻结，scheduler/scaler显式None，不支持混精或未声明调度器。
- `assemble`：消费已锁有序pairs，深复制成单源日程，不读标签、不再抽样、不自动循环不足的batches。输入多少批须等于steps；每类数量和端点/位点类型严格验收。pair方向由R01上游准入负责，本函数无法凭元数据判断真实优劣，不能冒称已验证标签。
- `training_identity`：来源代表/WT、完整bank索引与上游bank SHA、bundle身份、完整pairs日程、架构/seed/init、loss/lr/steps/checkpoints、native/code/runtime均入SHA；不含目标数据。bank_SHA是上游文件身份，另生成规范化索引摘要；需要生产绑定器实际核对文件SHA，接口不会读取源数值表。改变配置不得误复用旧训练模型。
- `coverage`：只累计成功更新前缀，分attempts与completed；报告可用/实际变体、位点覆盖、未见索引、两类pair出现次数/独立pair/重复。全bank可采样不等于全bank已被监督，也不等于完整19L有标签。
- `resume_state.capture/restore`：单来源专用schema，存trainable whitelist+完整AdamW step/一二阶矩、固定schedule身份/下一游标、attempt/completed/coverage、Python/NumPy/Torch CPU RNG及**已经初始化时**的CUDA RNG、环境版本、冻结底座身份、内容摘要。未初始化CUDA时不启动GPU。当前完整性仅覆盖既有FP32/无scheduler/无scaler训练；若未来引入新随机生成器/调度器/混精，应版本化扩字段，不能宣称此接口自动覆盖。
- capture要求无残留grad的更新边界。每个参数必须有等于completed的AdamW counter和有限矩；缺失状态/旧双源或adapter-only checkpoint/错误模型配置/游标/shape被拒绝。restore先验所有内容与RNG可加载性，再改张量、optimizer、RNG。底座值由原loader+冻结哈希重建，不复制进文件；跨设备/驱动的位级续训一致性尚未实测。
- `save_new`采用同目录唯一`.incomplete`临时文件→torch.save→flush+fsync→`os.link`原子不覆盖发布→清理临时文件。发布不支持硬链接时直接失败，无copy/replace降级；并发已有最终路径不覆盖。POSIX另fsync目录；Windows返回directory_fsync=false，不夸称已验证断电目录持久性。正式校内文件系统的hardlink/目录fsync/中断恢复必须资格核验。SIGKILL可遗留临时文件，临时文件从不视为完成；最终文件只在完整字节写完后可见。若发布后目录fsync报错，可能已有完整最终文件，应核对后对账，不能盲重投。

## 最初接线审查与最终完成范围

以下为最初接口交付时的接线清单，现第2–5项中的循环/optimizer/节点保存与恢复/节点推理已在production_loop.py实现；生产外围gate、真实native初始化与校内资格仍待完成。优先以文末“最终生产接线”及STATUS分层为准。

1. **版本化入口与gate**：新运行目录绑定本轮config、R01单源admission/bank/pairs/bundle与来源隔离；配置完整前不启动。只接受一个bundle，保留native/缓存全长资格及原guard。原v2的exact-key gate/源码manifest不能直接接受新入口，需总控验新manifest/release与预算。ESM2只复用既有排名；目标/同母本隔离由源选择和预测边再核，本元数据模块不取代该门禁。
2. **保留Scorer科学实现**：S/LoRA构造、参数白名单和精确计数、原head/FullVRH不变。旧Scorer只接受11/23/47，若正式固定seed在这三者外需新目录窄改seed检查，初始化算法不动；旧state/restore格式不得承担新resume。新resume直接接`scorer.params`与原optimizer，实际scorer.guard()/verify_frozen()前后调用。
3. **替换旧train控制流**（原engine:38–76）：删除双源validate/交替250及FINAL_500硬编码；配置驱动单源日程。fresh从精确原init恢复step0；resume仅接新schema并跳到next_schedule_index，绝不重置AdamW后称无缝续训。每次attempt前递增并计账；仅optimizer update成功且guard通过后递增completed。若optimizer/guard中途失败，不从不确定内存继续；回到最近完整checkpoint并单独计失败工作量。
4. **checkpoint调用点**：原update函数保留原loss/梯度/clip/AdamW算术；成功后显式`optimizer.zero_grad(set_to_none=True)`，guard+verify_frozen，再按配置节点capture/save_new。落盘后绑定字节SHA及content hash并记录完成回执；更新边界清grad不改变下一步本就zero_grad的科学算术。旧engine无此hook，接口单独通过不代表接线完成。
5. **续训与覆盖验收**：生产端比较连续运行与中断恢复在同runtime/设备上的后续参数、AdamW状态、RNG、日程端点/覆盖完全一致；错误源/heldout/旧双源checkpoint必须独立拒绝。未做实际前向/优化器step，这项仍未验证。CUDA RNG/device映射与restore中途异常须fail-closed，不在半恢复内存继续。不得改steps或lr后复用“精确resume”身份；若延长训练需先锁完整总预算/前缀，另版本化实验身份，不混称旧实验续跑。
6. **边界**：没有新损失、验证早停、来源代表、step/lr候选值或正式seed的科学裁决；没有实际生产CLI、GPUrelease/训练许可、完整engine/导出接线。Original及正式评价仍用独立精确身份，先由总控与R03锁开发/最终数据边界。本轮交付是`INTERFACES_TESTED_ENGINE_WIRING_PENDING`，不是训练就绪。

## 测试证据与限制

初始11项接口CPU合成正反例见TEST_RUN.json，仅2元素Parameter和手工矩，不执行backward/step。后续新循环另用两参数toy scorer实际autograd/AdamW证明恢复，不加载蛋白模型，合并最终16项见FINAL_TEST_RUN.json。检查：不固定教学预算、第二源/heldout/错pair类拒绝、完整身份敏感性、实际覆盖、完整state/RNG/cursor读写、旧schema/缺矩/损坏游标/脏grad拒绝、写入中断无最终文件、发布竞争不覆盖。最初9项接口测试通过；随后总控指出直接写最终路径的持久化缺口，已在同一未封开发目录修复为原子发布并加2测试，INITIAL_REVIEW_HISTORY.json保留该事实，不制造失败测试或声称旧版已原子。


## 最终生产接线（本次续接已实现）

`production_loop.py`是新循环，未替换旧engine文件。生产函数式入口`run_bound(config,schedule,init_path,bundle_spec,output,legacy_root,scorer_factory,resume_path=None,prior_attempts=None)`：精确单源bundle路径/SHA，先CPU反序列化并硬验原role==SOURCE；TARGET和SOURCE_POOL均拒绝，绝不改标。身份通过才移往CUDA。`scorer_factory(architecture,seed)`由外层资格环境构造原Scorer；生产wrapper硬验原类型及参数总数。没有服务器提交器/真实加载CLI，本轮未调用该CUDA边界。

`original_kernels`绑定原v2 manifest SHA4b0afe0a…，核全部py文件SHA，并在导入前/后检查sys.modules中所有pilot/r05_internal实际__file__都来自锁定目录且内容相符；锁原engine.update/export、scorer/storage，不运行provider的加载函数。测试借用此原update，包括原pair loss/backward/clip，但注入两参数toy scorer。科学源文件无修改或复制后变更。

新train循环确实从config.lr构造AdamW、遍历config.steps份单源日程，使用原update；从新INIT_V1或完整resume起步，恢复后从next_schedule_index继续。零残留grad的预锁节点调用原冻结byte检查、新capture/save_new，重新读取并验content摘要，记录文件SHA/publication证据。attempt先加、仅成功update及guard后completed加；失败只写FAILURE而无TRAIN_RECEIPT，不在不确定内存继续。恢复必须显式给prior_attempts≥snapshot attempts，来自此前attempt日志/FAILURE账本；它记录包括失败尝试的累计真实工作量，与成功前缀覆盖分开。断点以来重放的旧更新属于额外attempt，不能将其漏掉；外层合并多进程/Slurm账本仍必需。

预测`predict_node`验实际checkpoint completed节点属于预锁checkpoints，并恢复其完整状态再评分，不使用500常量；生产`predict_bound`核target文件/role/native且调用原export RAW/19L。来源/目标ID与WT重合拒绝，group/共享文库关系及精确目标release仍由外门禁验收。Original保持原独立无适配路径，此模块不重算它。任意steps/lr修改都会改变身份，不能作为精确resume混用。

真实native provenance键已核：原v2 run_replication.py:55和batch_qualification.py:41（实际行号以MAPPING_EVIDENCE为准）将`b['provenance']['native_lock_sha256']`写入bundle；原storage.dump_bundle保存provenance；run_replication.admit_bundle原样检查该键。现成真实资格SOURCE_00回执也包含同native lock身份。没有因toy而发明新键。新入口要求生产传入SOURCE实物；旧SOURCE_POOL缓存不能在这里自动晋级，需上游明确单来源准入产物及新文件身份，不能改TARGET冒充来源。

最小科学接线diff见MINIMAL_IMPLEMENTATION.diff（新目录全部执行模块/测试新增，旧科学模块零改动）。恢复合成证明是同一原update+toy环境中的参数/AdamW/RNG/output逐值一致；GPU RNG和真实六成员S/LoRA、Original实物复用、真实head/full19L/导出、校内hardlink/fsync/断电持久性、生产源准入/外层release尚未测试，不能称生产资格通过。若恢复过程底层load_state_dict或设备转换出现异常，一律中止；不承诺异常发生后的内存事务回滚。
