"""Actual CPU autograd on injected two-parameter toy only; no protein model."""
import copy
import random
import tempfile
from pathlib import Path
from types import SimpleNamespace
import unittest
import numpy as np
import torch
from test_single_source import fixture
from resume_state import load,content_hash
from production_loop import train,predict_node,original_kernels,file_sha

LEGACY=Path('F:/novoR2/Research_Diagnosis_20261108/ThreeTarget_FourCell_Replication_20261108/R05_Code/v2')


class ToyScorer:
    def __init__(self,architecture,seed):
        self.params={'p':torch.nn.Parameter(torch.tensor([.1,.2]))};self.base_hash='4'*64
    def guard(self):pass
    def verify_frozen(self):return {'frozen_bytes_unchanged':True,'frozen_current_sha256':self.base_hash}
    def score(self,bundle):
        p=self.params['p'];x=torch.arange(76,dtype=torch.float32)
        # All supported global RNG streams affect this injected scorer, exposing bad restoration.
        noise=random.random()+float(np.random.rand())+float(torch.rand(()))
        scores=p[0]*x/76+p[1]*torch.sin(x+noise)
        return None,SimpleNamespace(score_all19l=scores)


def setup(root,steps=6,lr=1e-4):
    c,s=fixture(steps);c['checkpoints']=[2,steps] if steps>2 else [steps];c['lr']=lr
    init=root/'init.pt'
    if not init.exists():torch.save({'schema':'SINGLE_SOURCE_INIT_V1','architecture':'S','seed':c['seed'],
        'native_sha256':c['native_sha256'],'frozen_sha256':'4'*64,'parameters':{'p':torch.tensor([.1,.2])}},init)
    c['init_sha256']=file_sha(init)
    bundle={'asset_role':'SOURCE','natural':SimpleNamespace(protein_id=c['source']['id'],wt_sha256=c['source']['wt_sha256'],wt_sequence='AAAA')}
    return c,s,init,{c['source']['id']:bundle}


def reset():random.seed(17);np.random.seed(18);torch.manual_seed(19)


class LoopTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        update,export=original_kernels(LEGACY)
        cls.update=staticmethod(update);cls.export=staticmethod(export)

    def test_continuous_vs_new_instance_resume_parameters_moments_rng_output(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);c,s,init,b=setup(p)
            reset();full=train(c,s,init,b,p/'full',scorer_factory=ToyScorer,update_fn=self.update)
            reset();calls=[]
            def fail_after2(*args):
                calls.append(1)
                if len(calls)==3:raise RuntimeError('synthetic interrupted attempt')
                return self.update(*args)
            with self.assertRaises(RuntimeError):train(c,s,init,b,p/'cut',scorer_factory=ToyScorer,update_fn=fail_after2)
            self.assertFalse((p/'cut/TRAIN_RECEIPT.json').exists())
            resumed=train(c,s,init,b,p/'resume',scorer_factory=ToyScorer,update_fn=self.update,resume_path=p/'cut/STEP_2.pt',prior_attempts=3)
            a=load(p/'full/STEP_6.pt');z=load(p/'resume/STEP_6.pt')
            for key in ('parameters','optimizer','rng'):
                self.assertEqual(content_hash(a[key]),content_hash(z[key]),key)
            self.assertEqual(resumed['completed_updates'],6)
            self.assertEqual(resumed['attempts'],7)
            self.assertEqual(a['coverage']['pair_counts'],z['coverage']['pair_counts'])
            def exporter(out,b,fields,result,meta):
                torch.save(result.score_all19l,out/'toy_output.pt');return meta
            target={'asset_role':'TARGET','natural':SimpleNamespace(protein_id='target',wt_sha256='5'*64)}
            ma=predict_node(c,s,p/'full/STEP_6.pt',target,p/'pred1',scorer_factory=ToyScorer,export_fn=exporter)
            mz=predict_node(c,s,p/'resume/STEP_6.pt',target,p/'pred2',scorer_factory=ToyScorer,export_fn=exporter)
            self.assertTrue(torch.equal(load(p/'pred1/toy_output.pt'),load(p/'pred2/toy_output.pt')))
            self.assertEqual(ma['steps_completed'],6);self.assertEqual(mz['steps_completed'],6)

    def test_lr_and_steps_really_affect_behavior_and_reject_resume_changes(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);c,s,init,b=setup(p)
            reset();train(c,s,init,b,p/'lr1',scorer_factory=ToyScorer,update_fn=self.update)
            changed=copy.deepcopy(c);changed['lr']=.01
            reset();train(changed,s,init,b,p/'lr2',scorer_factory=ToyScorer,update_fn=self.update)
            self.assertFalse(torch.equal(load(p/'lr1/STEP_6.pt')['parameters']['p'],load(p/'lr2/STEP_6.pt')['parameters']['p']))
            with self.assertRaises(ValueError):train(changed,s,init,b,p/'bad_resume',scorer_factory=ToyScorer,update_fn=self.update,resume_path=p/'lr1/STEP_2.pt')
            short,ss,ii,bb=setup(p,steps=2)
            reset();r=train(short,ss,ii,bb,p/'short',scorer_factory=ToyScorer,update_fn=self.update)
            self.assertEqual(r['completed_updates'],2);self.assertFalse((p/'short/STEP_6.pt').exists())
            with self.assertRaises(ValueError):train(short,ss,ii,bb,p/'bad_steps',scorer_factory=ToyScorer,update_fn=self.update,resume_path=p/'lr1/STEP_2.pt')

    def test_legacy_checkpoint_and_failed_update_no_false_completion(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);c,s,init,b=setup(p)
            torch.save({'schema':'FOURCELL_ADAPTER_V1','step':500,'tensors':{}},p/'old.pt')
            with self.assertRaises(ValueError):train(c,s,init,b,p/'legacy',scorer_factory=ToyScorer,update_fn=self.update,resume_path=p/'old.pt')
            def bad(*args):raise RuntimeError('synthetic optimizer failure')
            with self.assertRaises(RuntimeError):train(c,s,init,b,p/'failed',scorer_factory=ToyScorer,update_fn=bad)
            import json
            r=json.loads((p/'failed/FAILURE.json').read_text())
            self.assertEqual((r['attempts'],r['completed_updates']),(1,0));self.assertFalse((p/'failed/TRAIN_RECEIPT.json').exists())
            self.assertEqual(list((p/'failed').glob('STEP_*.pt')),[])

    def test_bound_entry_rejects_target_without_role_rewrite(self):
        from unittest.mock import patch
        from production_loop import run_bound
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);c,s,init,b=setup(p);f=p/'bundle.pt';f.write_bytes(b'synthetic binding')
            c['source']['bundle_sha256']=file_sha(f)
            target={'asset_role':'TARGET'}
            with patch('pilot.storage.load_bundle',return_value=target):
                with self.assertRaisesRegex(ValueError,'original loaded role must be SOURCE'):
                    run_bound(c,s,init,{'path':str(f),'sha256':file_sha(f)},p/'bad_target',legacy_root=LEGACY,scorer_factory=ToyScorer)
            self.assertEqual(target['asset_role'],'TARGET');self.assertFalse((p/'bad_target').exists())

    def test_existing_shadow_module_rejected_without_model_import(self):
        import sys
        from unittest.mock import patch
        with patch.dict(sys.modules,{'pilot.untrusted':SimpleNamespace(__file__=str(Path(__file__).resolve()))}):
            with self.assertRaisesRegex(ValueError,'module import shadow'):original_kernels(LEGACY)


if __name__=='__main__':unittest.main()
