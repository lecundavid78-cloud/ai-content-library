# 阶段一正式作业接线

R02 使用本工具从已观测文件及实际回执生成精确作业候选。固定 RCRO→TnpB、Spencer→AsCas12f、HSP82→SpCas9。S 和 LoRA 各生成一份新的 seed11 干净初态。同架构的三源两池共用该 INIT SHA。RCRO 是 init JOB 的许可哨位。该节点只用原生模型构造 Scorer，不挂来源 bundle 或 bank。12 条轨迹各 2000 步，lr 1e-4，每类 128 pairs，在 500／1000／2000 各输出一次预测。三个 Original 从已验收字节复用。实际账本按 2 个 init 和 48 个 train/predict 合计 50 个分配核算。R03 的成功作业集合仅含后 48 个。R02 草案 59400 秒按两 init 计算。以总控锁定预算和实际账本为准。

## 命令和输出

```text
python -B build_phase1.py init    --bindings BINDINGS.json --bindings-sha256 <实际SHA> --out OUT_INIT
python -B build_phase1.py train   --bindings BINDINGS.json --bindings-sha256 <更新后实际SHA> --out OUT_TRAIN
python -B build_phase1.py predict --bindings BINDINGS.json --bindings-sha256 <更新后实际SHA> --out OUT_PREDICT
```

从本目录执行，保留相邻已验 `runtime_v1` 和项目根预锁文件。输出每作业 JOB、训练时生成对应 config、以及 `CANDIDATES.json` 中的精确作业 SHA、逐文件只读挂载、内部 wall、分配上限、来源重绑证据和 R03 轨迹收集字段。训练 config 先用清单中 JOB 的 config.path 做逐文件部署，再复核同一 SHA。当前工具不签 release。R02 对最终容器文件运行 `runtime_cli.py preflight --job JOB.json --report INPUT_PREFLIGHT.json`，总控再按实际 job SHA 和上限签单作业 release。

## R02 输入合同

顶层使用 `schema=PHASE1_R02_VERIFIED_BINDINGS_V1`、`inventory_sha256`、`files`、`runtime`、`budget` 和 `slots`。之后按阶段补 `initializations`、`sources`、`targets` 及 `completed_tracks`。文件引用均为 `{path,sha256}`，path 是容器内 POSIX 绝对文件路径。文件 SHA 必须来自实际文件核验。行内 host_path 是 R02 实际观测到的学校主机路径。SHA 不代替准入或角色验证。

| 字段 | 内容 |
|---|---|
| files | 每条 `{ref,kind:"regular_file",bytes,host_path,local_copy?}`，按 ref.path 唯一。需要解析的 JSON 必须提供同字节 local_copy。运行库等容器内部的只读文件也须观测，已在锁定镜像内的文件可由 R02 保留为内建文件，逐件对账。 |
| runtime | `{native_lock,import_lock,code_root,code_inventory_local,code_inventory_sha256}`。绑定全部 runtime_v1 Python 和 legacy manifest、native lock 所列的全部成员文件、import lock 四库实际文件。镜像／解释器／挂载等外围身份仍由 R02 部署收据绑定。 |
| budget | 总控正式 `PHASE1_BUDGET_LOCKED` 文件引用，包含 controller、inventory_sha256、max_gpu_seconds。估算稿不能当锁。 |
| slots | `init/train/predict` 三个映射。键分别为 `S`、`L`（init）、预锁 track_id、`target::config_id`。每项 `{output,wall_seconds,allocated_gpu_seconds}`。每作业独立新输出，内部 wall 小于实际单卡分配上限，并包含留给前置核验和收尾的差额。 |
| initializations | 按 S、L 两个键，`{init,receipt,job,release,runtime_receipt,inspection}`。原生锁、实际代码、import 锁、架构和 seed11 均核同一执行链。inspection 是实际 step0 文件只读验收 JSON，schema=PHASE1_INIT_INSPECTION_V1，包含 init_sha256、checkpoint_schema=SINGLE_SOURCE_INIT_V1、architecture、seed、native_sha256、frozen_sha256、qualified_frozen_sha256、trainable_parameters、trainable_tensor_count、exact_original_whitelist_verified。冻结摘要须与相同原生身份和架构的资格证据一致。资格 INIT、旧训练权重及旧双来源恢复文件均不作为正式初态。 |
| sources | source_id → `{wt_sha256,bundle,evidence,banks}`。banks 含 small594/full_train，每项 `{original_admission_local,admission,config_root}`。部署 admission 仅重绑 bank/index/pairs 三条实际路径，叶 SHA 与所有其余内容保持一致。index/pairs 只读无值元数据。 |
| targets | target → `{wt_sha256,forbidden_source_ids,core,natural,bundle,evidence,original}`，original 含 `acceptance,record,raw,csv`。目标 core 需同 WT/ID，forbidden 列表由总控绑定已知同母本及共享文库。Original 的四份文件只进入收集证据，不进入训练或预测作业。 |
| completed_tracks | 预测阶段按 12 个 track_id，`{job,release,runtime_receipt,train_receipt,identity,checkpoints}`。checkpoint 以字符串步数 500/1000/2000 为键。可用 predict --track <预锁track_id> 只生成已完成轨迹的 3 份预测，此时 completed_tracks 只需该轨迹。完整预算与 50 个预锁 slot 仍需绑定。需要原本从零完成的训练回执，实际 checkpoint SHA 必须同回执节点。 |

缓存 evidence 是 R02／总控在实际 bytes-only 与 bundle CPU 审查后产生的 `EXACT_FULLWT_BUNDLE_ADMITTED` JSON。需包含 id、role、bundle_sha256、wt_sha256、native_lock_sha256、natural_input_sha256、structure_asset_sha256、member_identity_sha256、cache_schema=`FOURCELL_PREPARED_V1`、prefix_layer=11、window_rule=`single-full-WT-forward-no-window`、full_wt_h11_h12_validated=true、all_six_member_identities_match=true、functional_values_present=false。全长 AA 映射、结构码和量化器、MSA／天然输入、h11 mask／相对位置、h12 和六成员原 head 均须对上对应资格身份。SHA 观测不等同此收据。SOURCE 实际角色必须为 SOURCE。历史 SOURCE_POOL 需有正式准入产物，不能重写历史文件或使用资格 wrapper 冒充正式准入。TARGET 缓存仅可供该路线的预测。预测不挂载来源 h11。SpCas9 的预测路线只接 HSP82。

## 当前兼容性差异

- **R03 原 admission SHA 门禁。** 原文件嵌入 Windows 路径，runtime_v1 的 `bound` 在 Linux 要求实际绝对路径并核文件 SHA。逐字段保留内容的路径重绑也会改变 admission SHA。当前 R03 `track_gate` 把预锁原 SHA 同时用于部署 JOB 和 seal，因此会拒绝正确部署后的文件。最小兼容改法在 R03 侧。seal 另绑定原 admission，引入原件 SHA／部署件 SHA 的双链，并验证两 JSON 只允许 bank/index/pairs 的 path 变化。保留 index／pairs／bank 的原叶 SHA 与 JOB 对应检查。R05 候选清单已给 lineage 字段。测试用真实原 admission 纯路径重绑成功，同时拒绝变更 bank/hash/索引或缺原件。此问题影响最终评价，不要求修改科学 runtime。总控与 R03 完成该准入前，不能宣称 39 预测已可封存评价。
- **正式预测需挂一个获准来源 bank 文件。** 已验 runtime 的 r01_admission 在 train/predict 都按文件哈希复核 bank；没有打开解析 TSV 的路径。挂载仅对应来源 train-only TSV 的单个只读文件，无目标评估表、源 heldout、原始 DMS 混合文件或目录。若总控另定预测进程完全不挂来源值文件，应另审精确最小入口差异。可让预测验证此前已验 train receipt 与 bank SHA 的绑定，保留 config/schedule/init/target/checkpoint 验证，并增缺少训练绑定即拒绝的回归。此处保留当前 runtime 行为。

本包测试使用真实预锁 admission 的无值 JSON 与小型合成边界。最终远端观察、部署后路径／文件身份、真实 init、实际 GPU 预算与正式 release 由当前总控和 R02 交接。
