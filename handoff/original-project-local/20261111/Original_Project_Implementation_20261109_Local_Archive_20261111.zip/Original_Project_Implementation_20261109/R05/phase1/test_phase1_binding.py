import copy
import json
import unittest
from unittest.mock import patch
from build_phase1 import PROJECT, ROOT, CONTROLLER, INVENTORY_SHA, TARGETS, INIT_SENTINEL, compile_jobs, admission_rebind, check_cache, load, sha


class BindingTests(unittest.TestCase):
    def test_real_prelock_inventory_and_rebind_only(self):
        inventory = load(PROJECT/'DEVELOPMENT_PHASE1_INVENTORY.json', INVENTORY_SHA)
        self.assertEqual({r['target']:r['source_id'] for r in inventory['development_routes']}, TARGETS)
        for r in inventory['training_trajectories']:
            path = PROJECT/'R01/production_inputs_v1'/r['source_id']/r['bank_rule']/'TRAINONLY_ADMISSION.json'
            original = load(path, r['source_admission_sha256'])
            rebased = copy.deepcopy(original)
            for key in ('bank','index','pairs'):
                rebased[key]['path'] = '/data/'+key
            admission_rebind(original, rebased)
            rebased['pairs']['sha256'] = '0'*64
            with self.assertRaises(ValueError): admission_rebind(original, rebased)

    def test_cache_role_and_h11_evidence_required(self):
        ref={'path':'/bundle.pt','sha256':'1'*64}
        runtime={'native_lock':{'sha256':'2'*64}}
        row={'status':'EXACT_FULLWT_BUNDLE_ADMITTED','bundle_sha256':ref['sha256'],'id':'source','role':'SOURCE',
             'wt_sha256':'3'*64,'native_lock_sha256':'2'*64,'full_wt_h11_h12_validated':True,
             'functional_values_present':False,'cache_schema':'FOURCELL_PREPARED_V1','prefix_layer':11,
             'window_rule':'single-full-WT-forward-no-window','all_six_member_identities_match':True,
             'natural_input_sha256':'4'*64,'structure_asset_sha256':'5'*64,'member_identity_sha256':'6'*64}
        check_cache(row,ref,'source','SOURCE','3'*64,runtime)
        for key,val in [('role','SOURCE_POOL'),('prefix_layer',12),('functional_values_present',True)]:
            with self.assertRaises(ValueError):check_cache(dict(row,**{key:val}),ref,'source','SOURCE','3'*64,runtime)

    def test_missing_observation_fails_without_output(self):
        with self.assertRaisesRegex(ValueError,'missing actual R02 remote'):
            compile_jobs('init',{'schema':'PHASE1_R02_VERIFIED_BINDINGS_V1','inventory_sha256':INVENTORY_SHA,
                'files':[],'runtime':{'native_lock':{'path':'/native.json','sha256':'a'*64}}})

    def test_two_clean_init_jobs_only_and_budget_scope(self):
        inventory=load(PROJECT/'DEVELOPMENT_PHASE1_INVENTORY.json',INVENTORY_SHA)
        ci=ROOT.parent/'runtime_v1/RUNTIME_CODE_SHA256.json'
        h=sha(ci.read_bytes());code=load(ci,h);files=[];docs={}
        def register(path,h='a'*64,document=None):
            r={'path':path,'sha256':h}
            files.append({'ref':r,'host_path':'/host'+path,'kind':'regular_file','bytes':1,'local_copy':path})
            if document is not None:docs[path]=document
            return r
        versions={k:'fixture' for k in ('torch_version','transformers_version','numpy_version')}
        native=register('/native.json',document=dict(versions,schema='FOURCELL_NATIVE_MEMBERS_V1',
            members=[{'K':k,'root':'/model/'+str(k),'files_sha256':{}} for k in (20,128,512,1024,2048,4096)]))
        imp=register('/import.json',document=dict(versions,files={k:register('/lib/'+k) for k in
            ('torch','numpy','transformers','transformers.dynamic_module_utils')}))
        for name,digest in code.items():register('/code/'+name,digest)
        register('/code/legacy_v2/CODE_MANIFEST.json',sha((ROOT.parent/'runtime_v1/legacy_v2/CODE_MANIFEST.json').read_bytes()))
        budget=register('/budget.json',document={'status':'PHASE1_BUDGET_LOCKED','controller':CONTROLLER,
            'inventory_sha256':INVENTORY_SHA,'max_gpu_seconds':100})
        keys={'init':['S','L'],'train':[x['track_id'] for x in inventory['training_trajectories']],
            'predict':[x['target']+'::'+x['config_id'] for x in inventory['checkpoint_predictions']]}
        slots={kind:{k:{'output':'/out/'+kind+'/'+k,'wall_seconds':1,'allocated_gpu_seconds':2} for k in ids}
            for kind,ids in keys.items()}
        bindings={'schema':'PHASE1_R02_VERIFIED_BINDINGS_V1','inventory_sha256':INVENTORY_SHA,'files':files,
            'runtime':{'native_lock':native,'import_lock':imp,'code_root':'/code','code_inventory_local':str(ci),
                       'code_inventory_sha256':h},'budget':budget,'slots':slots}
        with patch('build_phase1.load',side_effect=lambda p,h:docs[str(p)] if str(p) in docs else load(p,h)):
            jobs,configs,plan=compile_jobs('init',bindings)
            self.assertEqual(set(jobs),{'S','L'});self.assertEqual(configs,{})
            self.assertEqual(plan['planned_gpu_seconds_all_50'],100)
            for arch,row in jobs.items():
                self.assertEqual(row['job']['cases'],[{'source_id':INIT_SENTINEL,'architecture':arch,'seed':11}])
                self.assertTrue(all(path.startswith(('/code/','/lib/')) or path in ('/native.json','/import.json')
                                    for path in row['read_only_file_mounts']))
            with self.assertRaisesRegex(ValueError,'predict-only'):compile_jobs('init',bindings,keys['train'][0])
            docs['/budget.json']['max_gpu_seconds']=99
            with self.assertRaisesRegex(ValueError,'exceed locked budget'):compile_jobs('init',bindings)


if __name__=='__main__':unittest.main()
