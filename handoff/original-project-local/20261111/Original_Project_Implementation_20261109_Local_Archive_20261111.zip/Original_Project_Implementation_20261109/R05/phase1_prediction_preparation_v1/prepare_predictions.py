"""Bridge observed R02 terminal metadata into the frozen phase1_v2 compiler."""
import argparse
import json
from pathlib import Path, PurePosixPath
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent/'phase1_v2'))
from build_phase1 import (PROJECT, INVENTORY_SHA, NODES, absolute, compile_jobs,
                          encode, hash64, load, need, sha)

BINDINGS = PROJECT/'R02/source_bundle_admission_v1/training_candidates_v1/BINDINGS.json'
BINDINGS_SHA = '79e01f8bffb852d453b6013450096008e0900a8293a42ae33426f710efceda57'
DEPLOYMENT = PROJECT/'R02/production_training_deployment_v2/nodes'
RECEIPTS = {'train_receipt':'train/TRAIN_RECEIPT.json',
            'identity':'train/TRAINING_IDENTITY.json','runtime_receipt':'RUNTIME_RECEIPT.json'}


def local_doc(path, expected=None):
    data = path.read_bytes()
    if expected is not None:need(sha(data)==expected, 'file SHA mismatch: '+str(path))
    return json.loads(data)


def observed_track(track, folder):
    accepted = local_doc(folder/'actual/ACCEPTANCE.json')
    job = local_doc(folder/'JOB.json', accepted['job_sha256'])
    release = local_doc(folder/'ROOT_RELEASE.json')
    deployment = local_doc(folder/'MANIFEST.json')
    need(accepted['status']=='PASS_ACTUAL_TRAIN_2000' and accepted['track_id']==track,
         'actual successful acceptance required: '+track)
    jid=accepted['job_id']; account=accepted['sacct'].strip().split('|')
    need(jid.isdigit() and len(account)>=7 and account[0]==jid and account[2:4]==['COMPLETED','0:0']
         and int(account[4])==accepted['allocated_gpu_seconds'] and 'gres/gpu=1' in account[5]
         and account[6]==accepted['root'], 'exact successful Slurm accounting')
    need(job['stage']=='train' and job['device']=='cuda' and len(job['cases'])==1
         and job['output']=='/out/train-'+track and release['job_sha256']==accepted['job_sha256']
         and release['status']=='RELEASED' and release['stage']=='train', 'executed train release')
    host_root=PurePosixPath(absolute(accepted['root']))
    result=host_root/('output-'+jid)/PurePosixPath(job['output']).relative_to('/out')
    tr=accepted['train_receipt']
    need(tr['status']=='COMPLETE_UNEVALUATED' and tr['completed_updates']==2000
         and tr['resume_checkpoint'] is None and tr['training_id']==accepted['training_id'],
         '2000-step train acceptance required')
    checkpoints={x['step']:x for x in accepted['checkpoints']}
    recorded={x['step']:x for x in tr['checkpoints']}
    need(len(accepted['checkpoints'])==len(tr['checkpoints'])==3
         and set(checkpoints)==set(recorded)==set(NODES),'exact three checkpoints')
    for step in NODES:
        row=checkpoints[step]; item=recorded[step]; name=f'train/STEP_{step}.pt'
        need(row['path']==str(result/name) and item['path']==job['output']+'/'+name
             and row['sha256']==item['sha256'] and row['content_sha256']==item['content_sha256']
             and hash64(row['sha256']) and hash64(row['content_sha256']), 'checkpoint path/hash lineage')
    config=job['cases'][0]['config']
    config_name='control/production/configs/'+track+'.json'
    need(config['path']=='/'+config_name and deployment['mounts'][config['path']]==str(host_root/config_name),
         'deployed config file mapping')
    local_doc(folder/config_name,config['sha256'])
    return accepted,job,release,result,config_name,checkpoints


def bridge(assets, tracks, receipts_dir):
    existing={r['ref']['path']:r for r in assets['files']}
    def add(ref,host,byte_count,local=None):
        need(type(byte_count) is int and byte_count>=0,'actual observed file size required')
        row={'ref':ref,'host_path':absolute(str(host)),'bytes':byte_count,'kind':'regular_file'}
        if local is not None:row['local_copy']=str(local.resolve())
        need(ref['path'] not in existing or existing[ref['path']]==row,'conflicting observed file mapping')
        existing[ref['path']]=row
        return ref

    completed={}
    for track in tracks:
        folder=DEPLOYMENT/track
        accepted,job,release,result,config_name,checkpoints=observed_track(track,folder)
        prefix='/phase1_evidence/'+track
        actual=receipts_dir/track
        listing=local_doc(actual/'OBSERVED_FILES.json')
        need(listing['schema']=='R02_PREDICTION_DEPENDENCY_OBSERVATION_V1'
             and listing['job_id']==accepted['job_id'] and set(listing['files'])==
             {PurePosixPath(n).name for n in RECEIPTS.values()}|{f'STEP_{s}.pt' for s in NODES},
             'exact R02 file observations required')
        bound={}
        for key,name in RECEIPTS.items():
            filename=PurePosixPath(name).name
            row=listing['files'][filename];local=actual/filename
            need(row['host_path']==str(result/name) and hash64(row['sha256'])
                 and local.stat().st_size==row['bytes'],'original R02 metadata bytes/path required')
            doc=local_doc(local,row['sha256'])
            if key=='train_receipt':need(doc==accepted['train_receipt'],'actual train receipt differs from acceptance')
            bound[key]=add({'path':prefix+'/'+filename,'sha256':row['sha256']},row['host_path'],row['bytes'],local)
        for key,name in [('job','JOB.json'),('release','ROOT_RELEASE.json')]:
            f=folder/name
            bound[key]=add({'path':prefix+'/'+name,'sha256':sha(f.read_bytes())},
                           PurePosixPath(accepted['root'])/name,f.stat().st_size,f)
        f=folder/config_name
        add(job['cases'][0]['config'],PurePosixPath(accepted['root'])/config_name,f.stat().st_size,f)
        bound['checkpoints']={}
        for step,item in checkpoints.items():
            name=f'STEP_{step}.pt'; row=listing['files'][name]
            need(row['host_path']==item['path'] and row['sha256']==item['sha256'],'observed checkpoint changed')
            bound['checkpoints'][str(step)]=add({'path':f'/checkpoints/{track}/{name}','sha256':item['sha256']},
                                                item['path'],row['bytes'])
        completed[track]=bound
    return dict(assets,files=list(existing.values()),completed_tracks=completed)


def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['audit','compile'])
    p.add_argument('--track');p.add_argument('--receipts',type=Path);p.add_argument('--out',type=Path)
    a=p.parse_args()
    inventory=load(PROJECT/'DEVELOPMENT_PHASE1_INVENTORY.json',INVENTORY_SHA)
    tracks=[r['track_id'] for r in inventory['training_trajectories']]
    try:
        need(a.track is None or a.track in tracks,'unknown track')
        if a.track:tracks=[a.track]
        if a.action=='audit':
            need(a.track is not None,'audit one observed track at a time')
            accepted,job,release,result,config_name,checkpoints=observed_track(a.track,DEPLOYMENT/a.track)
            print(json.dumps({'track_id':a.track,'job_id':accepted['job_id'],
                'raw_json_required':{key:str(result/name) for key,name in RECEIPTS.items()},
                'metadata_sha256':'PENDING_R02_ACTUAL_BYTE_OBSERVATION',
                'existing_checkpoints_sha_bound_size_needed':list(checkpoints.values())},indent=2))
            return
        need(a.receipts is not None and a.out is not None,'compile requires --receipts and --out')
        assets=bridge(load(BINDINGS,BINDINGS_SHA),tracks,a.receipts)
        jobs,_,plan=compile_jobs('predict',assets,a.track)
        need(len(jobs)==3*len(tracks),'unexpected prediction count')
        a.out.mkdir(parents=True,exist_ok=False)
        for key,item in jobs.items():
            (a.out/(key.replace('::','--')+'.JOB.json')).write_bytes(encode(item['job']))
        (a.out/'BINDINGS.json').write_bytes(encode(assets))
        plan['bindings_sha256']=sha((a.out/'BINDINGS.json').read_bytes())
        (a.out/'CANDIDATES.json').write_bytes(encode(plan))
    except (ValueError,KeyError,TypeError,OSError) as exc:p.exit(2,f'BLOCKED: {exc}\n')


if __name__=='__main__':main()
