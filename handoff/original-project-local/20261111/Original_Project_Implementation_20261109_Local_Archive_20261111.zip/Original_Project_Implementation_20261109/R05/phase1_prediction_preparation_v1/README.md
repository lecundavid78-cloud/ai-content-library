运行目录为本目录，使用相邻冻结的 phase1_v2 和项目原 R02 元数据。

```text
python -B prepare_predictions.py audit --track AsCas12f__S__full_train
python -B prepare_predictions.py compile --track AsCas12f__S__full_train --receipts <回传根目录> --out <新输出目录>
python -B prepare_predictions.py compile --receipts <回传根目录> --out <新输出目录>
```

首次可编译单轨迹三节点。省略 track 时检查全部 12 条完成轨迹并生成 36 份 JOB。输入继续使用锁定的实际 BINDINGS。逐轨迹消费现有节点目录内 JOB、ROOT_RELEASE、MANIFEST、config 和真实 ACCEPTANCE。回传根目录每条轨迹建一目录，内含三个原始 JSON 字节及 OBSERVED_FILES.json。该索引 schema 为 R02_PREDICTION_DEPENDENCY_OBSERVATION_V1，字段为 schema、job_id、files。files 的六个键是 TRAIN_RECEIPT.json、TRAINING_IDENTITY.json、RUNTIME_RECEIPT.json 及 STEP_500.pt、STEP_1000.pt、STEP_2000.pt，每项提供 host_path、sha256、bytes。前三项需要原字节回传。后三项只需核验远端路径、既有 SHA 和 stat 字节数。嵌入 ACCEPTANCE 的 train_receipt 用于比对内容，其序列化形式无法替代服务器原始文件 SHA。

首条具体远端路径和三个真实 checkpoint SHA 见 FIRST_TRACK_GAPS.json。三个原始回执 SHA 当前未知，须由 R02 对实际文件计算并随字节回传。现有 JOB、签发文件和 config 从训练节点目录复用。训练容器路径 /out/train-…/train/STEP_*.pt 仅用于核对训练回执。预测容器通过 /checkpoints/<track>/STEP_*.pt 单文件只读挂载到相同已验服务器字节。/phase1_evidence 下的引用是本地汇编和 R03 收集标识。它们不进入预测挂载。

预测包装沿 R02 已验 v2。环境两父目录最先挂，然后本次新运行控制目录、逐件只读文件和独立可写 /out。保留原镜像、Singularity、实际库文件、native 文件及 Python identity 检查。替换训练专用外层 gate 的 stage、scope、名称和上限，逐节点绑定目标 bundle、checkpoint、JOB、内外 release、MANIFEST 及目标原 core。内部 release 按原 runtime schema 使用 predict、max_updates_per_case=0、对应节点 wall。预测 launcher 最小改动是在既有 launcher 骨架改 stage 校验及 scope。保留单卡、无自动重排、唯一 claim、日志及退出记录。按候选清单挂当条获准来源的 admission/index/pairs/init/config 和 train-only bank。冻结入口只对 bank 做文件哈希，任何评价功能表或来源 heldout 均排除。生成的 JOB 依赖原 runtime。

PREDICTION_RESOURCE_PLAN.json 是既有预算槽位的只读投影。单卡总同时分配上限为一，训练串行由 R02 继续。预测只在同一调度控制下插入，等待当前训练终态并复核账本，避免并发或重复提交。候选累计仍核全 50 槽位预算。原版 3 份沿已验 record/RAW/CSV 和原 target core 精确复用。

输出 CANDIDATES.json 包含每节点 JOB SHA、挂载和分配上限及 tracks_for_r03 字段。预测完成后按真实执行链收集 JOB、release、runtime receipt、RAW、CSV 和 prediction record，供总控／R03封存。实际预测放行、校内包装及首条原始回执收集由 R02 与总控交接。
