import copy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from prepare_predictions import BINDINGS, BINDINGS_SHA, DEPLOYMENT, bridge, load, observed_track

TRACK = 'AsCas12f__S__full_train'


class BridgeTests(unittest.TestCase):
    def test_actual_5222686_resolves_three_real_checkpoint_files(self):
        accepted,job,release,result,_,checkpoints = observed_track(TRACK,DEPLOYMENT/TRACK)
        self.assertEqual(accepted['job_id'],'5222686')
        self.assertTrue(str(result).endswith('/output-5222686/train-'+TRACK))
        self.assertEqual(set(checkpoints),{500,1000,2000})
        self.assertEqual(release['job_sha256'],accepted['job_sha256'])
        self.assertTrue(all(x['path'].startswith(str(result)+'/train/') for x in checkpoints.values()))

    def test_missing_raw_receipt_inventory_cannot_compile(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(FileNotFoundError,'OBSERVED_FILES.json'):
                bridge(load(BINDINGS,BINDINGS_SHA),[TRACK],Path(tmp))

    def test_checkpoint_relocation_must_match_accepted_host_path(self):
        original=observed_track(TRACK,DEPLOYMENT/TRACK)
        accepted=copy.deepcopy(original[0])
        accepted['checkpoints'][0]['path']=original[1]['output']+'/train/STEP_500.pt'
        from prepare_predictions import local_doc
        def altered(path,expected=None):
            return accepted if path.name=='ACCEPTANCE.json' else local_doc(path,expected)
        with patch('prepare_predictions.local_doc',side_effect=altered):
            with self.assertRaisesRegex(ValueError,'checkpoint path/hash lineage'):
                observed_track(TRACK,DEPLOYMENT/TRACK)


if __name__=='__main__':unittest.main()
