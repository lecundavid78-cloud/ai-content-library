"""Single-source production control loop. Native scorer construction stays outside this module."""
import json
from pathlib import Path
import torch
from single_source import validate,training_identity,coverage,need,keys
from resume_state import capture,restore,save_new,load,content_hash


def file_sha(path):
    import hashlib
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()


def optimizer_for(scorer,config):
    return torch.optim.AdamW(scorer.params.values(),lr=config['lr'],betas=(.9,.999),eps=1e-8,weight_decay=0.)


def original_kernels(root):
    """Bind unchanged legacy files, never import its model loader or training CLI."""
    import sys
    root=Path(root).resolve();manifest=root/'CODE_MANIFEST.json'
    need(file_sha(manifest)=='4b0afe0a711a1c8e09af2243da5df94a18f02f5ed6221c6a4c8c64bdb1c733f9','original v2 scientific manifest required')
    files={row['path']:row['sha256'] for row in json.loads(manifest.read_text(encoding='utf-8'))['files']}
    for row in json.loads(manifest.read_text(encoding='utf-8'))['files']:
        if row['path'].endswith('.py'):need(file_sha(root/row['path'])==row['sha256'],'original scientific code changed')
    def check_imports():
        for name,module in list(sys.modules.items()):
            if name.split('.')[0] not in ('pilot','r05_internal'):continue
            source=getattr(module,'__file__',None)
            need(source is not None,'scientific namespace import shadow: '+name)
            path=Path(source).resolve()
            need(path.is_relative_to(root),'scientific module import shadow: '+name)
            rel=path.relative_to(root).as_posix()
            need(rel in files and file_sha(path)==files[rel],'unlocked scientific module: '+name)
    check_imports()
    sys.path.insert(0,str(root))
    from pilot import engine
    from pilot import storage,scorer
    check_imports()
    need(Path(engine.__file__).resolve()==root/'pilot/engine.py','original module import shadow')
    return engine.update,engine.export_prediction


def write_new(path,data):
    with Path(path).open('x',encoding='utf-8') as f:json.dump(data,f,indent=2,allow_nan=False);f.write('\n')


def check_bundle(config,bundles):
    src=config['source'];need(set(bundles)=={src['id']},'exactly one source bundle; no second source/target mounted')
    b=bundles[src['id']]
    need(b['asset_role']=='SOURCE' and b['natural'].protein_id==src['id'] and b['natural'].wt_sha256==src['wt_sha256']
         and len(b['natural'].wt_sequence)==src['length'],'source bundle WT/role mismatch')
    # Actual file hash is established by runner binding below, not a free bundle metadata assertion.
    return b


def initialize(scorer,config,init_path):
    need(file_sha(init_path)==config['init_sha256'],'exact initial file required')
    state=load(init_path)
    keys(state,('schema','architecture','seed','native_sha256','frozen_sha256','parameters'))
    need(state['schema']=='SINGLE_SOURCE_INIT_V1' and state['architecture']==config['architecture'] and state['seed']==config['seed']
         and state['native_sha256']==config['native_sha256'] and state['frozen_sha256']==scorer.base_hash,'exact new-format step0 identity; no legacy checkpoint conversion')
    need(set(state['parameters'])==set(scorer.params),'step0 parameter whitelist')
    for n,p in scorer.params.items():
        x=state['parameters'][n];need(x.shape==p.shape and x.dtype==p.dtype and torch.isfinite(x).all().item(),'initial parameter shape/dtype/finite')
    with torch.no_grad():
        for n,p in scorer.params.items():p.copy_(state['parameters'][n].to(p.device))
    scorer.guard();scorer.verify_frozen()


def train(config,schedule,init_path,bundles,output,*,scorer_factory,update_fn,resume_path=None,prior_attempts=None):
    """update_fn is pinned original engine.update in production; caller supplies qualified scorer."""
    validate(config,schedule);b=check_bundle(config,bundles)
    tid,ident=training_identity(config,schedule)
    out=Path(output);need(not out.exists(),'fresh output directory; resume uses a new attempt directory');out.mkdir(parents=True)
    completed=attempts=0;checkpoints=[];optimizer=scorer=None
    try:
        scorer=scorer_factory(config['architecture'],config['seed']);initialize(scorer,config,init_path)
        optimizer=optimizer_for(scorer,config);optimizer.zero_grad(set_to_none=True)
        if resume_path is not None:
            state=load(resume_path)
            recovered=restore(state,config,schedule,scorer.params,optimizer,frozen_sha256=scorer.base_hash)
            completed=recovered['completed_updates'];attempts=recovered['attempts']
            need(type(prior_attempts) is int and prior_attempts>=attempts,'resume requires prior cumulative attempt ledger including failed attempts')
            attempts=prior_attempts
            scorer.guard();scorer.verify_frozen()
        write_new(out/'TRAINING_IDENTITY.json',{'training_id':tid,**ident,'resume_file_sha256':file_sha(resume_path) if resume_path else None})
        for row in schedule[completed:]:
            attempts+=1
            record=update_fn(scorer,b,row['cross_pairs'],row['within_pairs'],optimizer)
            scorer.guard();completed+=1
            # A successful optimizer update is counted even if subsequent logging/storage fails.
            record.update(completed_update=completed,attempt=attempts,source_id=config['source']['id'])
            with (out/'updates.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(record,allow_nan=False)+'\n')
            optimizer.zero_grad(set_to_none=True)
            if completed in config['checkpoints']:
                proof=scorer.verify_frozen()
                need(proof['frozen_bytes_unchanged'] and proof['frozen_current_sha256']==scorer.base_hash,'original frozen byte gate')
                state=capture(config,schedule,scorer.params,optimizer,frozen_sha256=scorer.base_hash,attempts=attempts,completed_updates=completed)
                path=out/f'STEP_{completed}.pt';publication=save_new(path,state)
                # Verify durable bytes can pass weights-only deserialization and content integrity.
                saved=load(path);need(saved['content_sha256']==state['content_sha256']
                    and content_hash({k:v for k,v in saved.items() if k!='content_sha256'})==state['content_sha256'],'checkpoint readback mismatch')
                checkpoints.append({'step':completed,'path':str(path.resolve()),'sha256':file_sha(path),
                    'content_sha256':state['content_sha256'],'publication':publication})
        scorer.verify_frozen()
        receipt={'schema':'SINGLE_SOURCE_TRAIN_RECEIPT_V1','status':'COMPLETE_UNEVALUATED','training_id':tid,
            'attempts':attempts,'completed_updates':completed,'checkpoints':checkpoints,
            'resume_checkpoint':{'path':str(Path(resume_path).resolve()),'sha256':file_sha(resume_path)} if resume_path else None,
            'coverage':coverage(config,schedule,attempts=attempts,completed_updates=completed)}
        write_new(out/'TRAIN_RECEIPT.json',receipt)
        return receipt
    except BaseException as exc:
        write_new(out/'FAILURE.json',{'status':'FAILED_NO_AUTOMATIC_RETRY','error_type':type(exc).__name__,'error':str(exc),
            'training_id':tid,'attempts':attempts,'completed_updates':completed,'verified_checkpoints':checkpoints,
            'coverage':coverage(config,schedule,attempts=attempts,completed_updates=completed),
            'resume_rule':'only last verified complete snapshot; discard possibly partially updated live state'})
        raise


def predict_node(config,schedule,checkpoint,bundle,output,*,scorer_factory,export_fn):
    """Actual completed node, never hardcoded500; caller binds an authorized label-free target."""
    validate(config,schedule);state=load(checkpoint)
    need(state.get('completed_updates') in config['checkpoints'],'prediction requires a prelocked actual saved node')
    scorer=scorer_factory(config['architecture'],config['seed']);scorer.guard()
    opt=optimizer_for(scorer,config);opt.zero_grad(set_to_none=True)
    restore(state,config,schedule,scorer.params,opt,frozen_sha256=scorer.base_hash)
    src=config['source'];target=bundle['natural']
    need(bundle['asset_role']=='TARGET' and target.protein_id!=src['id'] and target.wt_sha256!=src['wt_sha256'],'target/self-source isolation')
    # Parent/library relationships and exact target release must be admitted by outer gate.
    with torch.no_grad():fields,result=scorer.score(bundle)
    scorer.verify_frozen();out=Path(output);need(not out.exists(),'fresh prediction output');out.mkdir(parents=True)
    return export_fn(out,bundle,fields,result,{'training_id':state['training_id'],'checkpoint_sha256':file_sha(checkpoint),
        'steps_completed':state['completed_updates'],'seed':config['seed'],'active_adaptation':True,'architecture':config['architecture']})


def run_bound(config,schedule,init_path,bundle_spec,output,*,legacy_root,scorer_factory,resume_path=None,prior_attempts=None):
    """Production boundary: caller creates already-qualified native Scorer, no loader/SSH here."""
    keys(bundle_spec,('path','sha256'))
    need(file_sha(bundle_spec['path'])==bundle_spec['sha256']==config['source']['bundle_sha256'],'actual source bundle binding')
    update_fn,_=original_kernels(legacy_root)
    from pilot.storage import load_bundle,tree
    b=load_bundle(bundle_spec['path'],'cpu')
    need(b['asset_role']=='SOURCE','original loaded role must be SOURCE; never promote TARGET or SOURCE_POOL')
    need(b['provenance']['native_lock_sha256']==config['native_sha256'],'native bundle identity')
    b=tree(b,'cuda')
    original_factory=scorer_factory
    def qualified_factory(architecture,seed):
        from pilot.scorer import Scorer
        scorer=original_factory(architecture,seed)
        need(type(scorer) is Scorer,'production requires pinned original Scorer')
        need(sum(p.numel() for p in scorer.params.values())=={'S':597376,'L':589824}[architecture],'exact production trainable count')
        return scorer
    return train(config,schedule,init_path,{config['source']['id']:b},output,
        scorer_factory=qualified_factory,update_fn=update_fn,resume_path=resume_path,prior_attempts=prior_attempts)


def predict_bound(config,schedule,checkpoint,target_spec,output,*,legacy_root,scorer_factory):
    keys(target_spec,('path','sha256'))
    need(file_sha(target_spec['path'])==target_spec['sha256'],'actual target bundle binding')
    _,export_fn=original_kernels(legacy_root)
    from pilot.storage import load_bundle,tree
    from pilot.scorer import Scorer
    b=load_bundle(target_spec['path'],'cpu')
    need(b['asset_role']=='TARGET' and b['provenance']['native_lock_sha256']==config['native_sha256'],'original target role/native identity')
    def qualified_factory(architecture,seed):
        scorer=scorer_factory(architecture,seed)
        need(type(scorer) is Scorer and scorer.architecture==architecture and scorer.seed==seed,'original prediction scorer identity')
        return scorer
    return predict_node(config,schedule,checkpoint,tree(b,'cuda'),output,scorer_factory=qualified_factory,export_fn=export_fn)
