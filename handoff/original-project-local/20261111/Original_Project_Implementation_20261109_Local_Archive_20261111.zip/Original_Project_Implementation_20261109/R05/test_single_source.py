import copy
import json
import random
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
import numpy as np
import torch
from single_source import validate,assemble,training_identity,coverage
from resume_state import capture,restore,save_new,load,content_hash


def fixture(steps=3):
    c={'schema':'SINGLE_SOURCE_CONFIG_V1','source':{'id':'synthetic-source','wt_sha256':'a'*64,'length':4,
        'bank_indices':[0,1,19,20,38],'heldout_positions':[3],'bank_sha256':'b'*64,'bundle_sha256':'c'*64},
        'architecture':'S','seed':123,'steps':steps,'lr':1e-4,'checkpoints':[steps],
        'pairs_per_class':2,'loss':'phaseA-pair-v2-nonempty',
        'optimizer':{'name':'AdamW','betas':[.9,.999],'eps':1e-8,'weight_decay':0.,'clip_norm':1.,'dtype':'float32','scheduler':None,'scaler':None},
        'native_sha256':'d'*64,'init_sha256':'e'*64,'code_sha256':'f'*64,'runtime_sha256':'0'*64}
    batches=[{'within_pairs':[[0,1],[19,20]],'cross_pairs':[[0,19],[1,20]]} for _ in range(steps)]
    return c,assemble(c,batches)


def toy(config,completed=0):
    # No model forward/backward/optimizer.step: synthetic moments are assigned by hand.
    params={'tiny_adapter':torch.nn.Parameter(torch.tensor([.5,1.5]))}
    opt=torch.optim.AdamW(params.values(),lr=config['lr'],betas=(.9,.999),eps=1e-8,weight_decay=0)
    if completed:
        p=params['tiny_adapter'];opt.state[p]={'step':torch.tensor(float(completed)),
            'exp_avg':torch.tensor([.1,.2]),'exp_avg_sq':torch.tensor([.01,.04])}
    return params,opt


class Contracts(unittest.TestCase):
    def test_explicit_budget_not_teaching_hardcode(self):
        for steps in (1,7):
            c,s=fixture(steps);validate(c,s)
            self.assertEqual(len(c['source']['bank_indices']),5)
            self.assertEqual(len(s),steps)

    def test_reject_second_source_and_legacy_fields(self):
        c,s=fixture();bad=copy.deepcopy(s);bad[1]['source_id']='second'
        with self.assertRaises(ValueError):validate(c,bad)
        bad=copy.deepcopy(c);bad['sources']=[c['source'],c['source']]
        with self.assertRaises(ValueError):validate(bad,s)
        bad=copy.deepcopy(c);bad['source']=[c['source']]
        with self.assertRaises(ValueError):validate(bad,s)

    def test_reject_heldout_endpoint_or_class_or_budget(self):
        c,s=fixture()
        bad=copy.deepcopy(c);bad['source']['bank_indices'].append(57)
        with self.assertRaises(ValueError):validate(bad,s)
        bad=copy.deepcopy(s);bad[0]['cross_pairs'][0]=[0,57]
        with self.assertRaises(ValueError):validate(c,bad)
        bad=copy.deepcopy(s);bad[0]['within_pairs']=[]
        with self.assertRaises(ValueError):validate(c,bad)
        for k,v in [('steps',True),('lr',float('nan')),('checkpoints',[1])]:
            bad=copy.deepcopy(c);bad[k]=v
            with self.assertRaises(ValueError):validate(bad,s)

    def test_training_identity_sensitive_to_all_training_rules(self):
        c,s=fixture();h,_=training_identity(c,s)
        for key,value in [('lr',3e-5),('architecture','L'),('seed',47),('code_sha256','1'*64),('runtime_sha256','2'*64),('checkpoints',[1,3])]:
            bad=copy.deepcopy(c);bad[key]=value
            self.assertNotEqual(h,training_identity(bad,s)[0])
        bad=copy.deepcopy(c);bad['source']['bank_sha256']='3'*64
        self.assertNotEqual(h,training_identity(bad,s)[0])
        bad=copy.deepcopy(s);bad[0]['cross_pairs'][0]=[1,19]
        self.assertNotEqual(h,training_identity(c,bad)[0])

    def test_actual_coverage_not_attempts_or_bank_size(self):
        c,s=fixture();r=coverage(c,s,attempts=5,completed_updates=2)
        self.assertEqual(r['observed_variants'],4);self.assertEqual(r['eligible_variants'],5)
        self.assertEqual(r['unseen_bank_indices'],[38]);self.assertEqual(r['pair_counts']['within_pairs']['appearances'],4)
        self.assertEqual(r['pair_counts']['within_pairs']['unique_ordered_pairs'],2)
        self.assertFalse(r['all_train_bank_observed'])
        with self.assertRaises(ValueError):coverage(c,s,attempts=1,completed_updates=2)

    def test_checkpoint_complete_roundtrip_moments_rng_cursor(self):
        c,s=fixture();params,opt=toy(c,2)
        random.seed(11);np.random.seed(12);torch.manual_seed(13)
        state=capture(c,s,params,opt,frozen_sha256='4'*64,attempts=3,completed_updates=2)
        expected=(random.random(),np.random.rand(),torch.rand(3))
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'step2.pt';save_new(f,state);state=load(f)
            with self.assertRaises(ValueError):save_new(f,state)
        new,newopt=toy(c);new['tiny_adapter'].data.zero_()
        r=restore(state,c,s,new,newopt,frozen_sha256='4'*64)
        self.assertTrue(torch.equal(new['tiny_adapter'],params['tiny_adapter']))
        self.assertTrue(torch.equal(newopt.state[new['tiny_adapter']]['exp_avg'],torch.tensor([.1,.2])))
        self.assertEqual(float(newopt.state[new['tiny_adapter']]['step']),2)
        self.assertEqual((r['completed_updates'],r['attempts'],r['next_schedule_index']),(2,3,2))
        self.assertEqual(random.random(),expected[0]);self.assertEqual(np.random.rand(),expected[1]);self.assertTrue(torch.equal(torch.rand(3),expected[2]))

    def test_step0_snapshot_and_no_legacy_conversion(self):
        c,s=fixture();p,o=toy(c);state=capture(c,s,p,o,frozen_sha256='4'*64,attempts=0,completed_updates=0)
        restore(state,c,s,p,o,frozen_sha256='4'*64)
        for old in ({'schema':'FOURCELL_ADAPTER_V1','step':500,'tensors':{}},{'schema':'THREE_TARGET_TRAINING_IDENTITY_V1','sources':['a','b']}):
            with self.assertRaises(ValueError):restore(old,c,s,p,o,frozen_sha256='4'*64)

    def test_reject_incomplete_moments_identity_or_cursor_before_mutation(self):
        c,s=fixture();p,o=toy(c,2);state=capture(c,s,p,o,frozen_sha256='4'*64,attempts=2,completed_updates=2)
        cases=[]
        bad=copy.deepcopy(state);del next(iter(bad['optimizer']['state'].values()))['exp_avg'];cases.append(bad)
        bad=copy.deepcopy(state);bad['next_schedule_index']=1;cases.append(bad)
        bad=copy.deepcopy(state);bad['parameters']['extra']=torch.zeros(1);cases.append(bad)
        bad=copy.deepcopy(state);bad['rng']['torch_cpu']=torch.tensor([1]);cases.append(bad)
        for bad in cases:
            bad['content_sha256']=content_hash({k:v for k,v in bad.items() if k!='content_sha256'})
            new,no=toy(c);before=new['tiny_adapter'].detach().clone()
            with self.assertRaises((ValueError,RuntimeError,TypeError)):restore(bad,c,s,new,no,frozen_sha256='4'*64)
            self.assertTrue(torch.equal(before,new['tiny_adapter']))
        new,no=toy(c);badconfig=copy.deepcopy(c);badconfig['lr']=3e-5
        with self.assertRaises(ValueError):restore(state,badconfig,s,new,no,frozen_sha256='4'*64)
        with self.assertRaises(ValueError):restore(state,c,s,new,no,frozen_sha256='5'*64)

    def test_no_dirty_gradient_or_missing_optimizer_state(self):
        c,s=fixture();p,o=toy(c);p['tiny_adapter'].grad=torch.ones(2)
        with self.assertRaises(ValueError):capture(c,s,p,o,frozen_sha256='4'*64,attempts=1,completed_updates=1)
        p['tiny_adapter'].grad=None
        with self.assertRaises(ValueError):capture(c,s,p,o,frozen_sha256='4'*64,attempts=1,completed_updates=1)

    def test_interrupted_save_never_publishes_partial_final(self):
        c,s=fixture();p,o=toy(c);state=capture(c,s,p,o,frozen_sha256='4'*64,attempts=0,completed_updates=0)
        def broken_save(state,f):f.write(b'partial-checkpoint');raise OSError('synthetic disk interruption')
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'step0.pt'
            with patch('resume_state.torch.save',side_effect=broken_save):
                with self.assertRaises(OSError):save_new(f,state)
            self.assertFalse(f.exists());self.assertEqual(list(Path(d).iterdir()),[])
            publication=save_new(f,state);self.assertTrue(publication['file_fsync'])
            self.assertEqual(load(f)['content_sha256'],state['content_sha256'])

    def test_publication_race_never_overwrites_existing_file(self):
        import os
        c,s=fixture();p,o=toy(c);state=capture(c,s,p,o,frozen_sha256='4'*64,attempts=0,completed_updates=0)
        real_link=os.link
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'step0.pt'
            def raced(src,dst):Path(dst).write_bytes(b'other-publisher');return real_link(src,dst)
            with patch('resume_state.os.link',side_effect=raced):
                with self.assertRaises(FileExistsError):save_new(f,state)
            self.assertEqual(f.read_bytes(),b'other-publisher');self.assertEqual(len(list(Path(d).iterdir())),1)


if __name__=='__main__':unittest.main()
