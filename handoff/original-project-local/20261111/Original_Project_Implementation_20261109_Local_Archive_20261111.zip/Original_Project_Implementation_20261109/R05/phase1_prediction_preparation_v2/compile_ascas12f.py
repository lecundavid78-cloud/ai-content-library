"""Compile the four observed AsCas12f tracks without issuing execution releases."""
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "phase1_prediction_preparation_v1"))
from prepare_predictions import (BINDINGS, BINDINGS_SHA, PROJECT, INVENTORY_SHA,
                                 bridge, compile_jobs, encode, load, local_doc, need, sha)

TARGET = "AsCas12f"
ADMISSION = PROJECT / "R02/source_bundle_admission_v1"
CONTROLLER = PROJECT / "CONTROLLER_PHASE1_SOURCE_ADMISSION_ACTUAL_ACCEPTANCE.json"
PROBE = PROJECT / "R02/production_admission_preparation_v1/PROBE_ACTUAL.stdout"
CONTRACT = ADMISSION / "payload/control/CONTRACT.json"
TERMINAL = PROJECT / "R02/production_training_deployment_v2/TRAIN_TERMINAL_OBSERVATION_20261111T000705Z"


def bind_target(assets):
    control = local_doc(CONTROLLER)
    cpu = local_doc(ADMISSION / "CPU_ADMISSION_ACCEPTANCE_5222068.json")
    need(control["job_id"] == cpu["job_id"] == "5222068"
         and control["state"] == "COMPLETED"
         and control["exit_code"] == cpu["exit_code"] == "0:0"
         and control["collection_sha256"] == cpu["collection"]["sha256"], "CPU admission acceptance")
    collection = load(cpu["collection"]["path"], control["collection_sha256"])
    event, = [e for e in collection["events"] if e["job_id"] == "5222068" and e["terminal"]]
    suffix = f"output-5222068/admitted/{TARGET}/ADMISSION.json"
    actual, = [a for a in event["artifacts"] if a["relative"] == suffix]
    accepted = control["admissions"][TARGET]
    evidence, = [f for f in assets["files"] if f["ref"]["path"] == f"/admission/{TARGET}.json"]
    need(evidence["ref"]["sha256"] == actual["sha256"] == accepted["admission_sha256"]
         and evidence["host_path"] == actual["remote_path"]
         and evidence["bytes"] == actual["bytes"] == Path(evidence["local_copy"]).stat().st_size,
         "exact accepted target admission file")
    doc = load(evidence["local_copy"], actual["sha256"])
    locked, = [r for r in local_doc(CONTRACT)["rows"] if r["id"] == TARGET and r["role"] == "TARGET_H11"]
    probe = local_doc(PROBE)
    need(len(probe["entries"]) == 66, "expected original R02 probe")
    seen, = [r for r in probe["entries"] if r["id"] == TARGET and r["role"] == "TARGET_H11"]
    need(seen["status"] == "MATCH" and seen["path"] == seen["resolved"] == locked["cache"]["path"]
         and seen["sha256"] == locked["cache"]["sha256"] == accepted["bundle_sha256"]
         == doc["bundle_sha256"] == doc["parent_cache_sha256"]
         and type(seen["bytes"]) is int and seen["bytes"] > 0, "actual target cache stat and SHA")
    ref = {"path": f"/bundles/TARGET/{TARGET}.pt", "sha256": seen["sha256"]}
    assets["files"].append({"ref": ref, "host_path": seen["path"], "bytes": seen["bytes"],
                            "kind": "regular_file"})
    assets["targets"][TARGET].update(bundle=ref, evidence=evidence["ref"])
    return seen, actual


def main():
    inventory = load(PROJECT / "DEVELOPMENT_PHASE1_INVENTORY.json", INVENTORY_SHA)
    tracks = [r["track_id"] for r in inventory["training_trajectories"] if r["target"] == TARGET]
    need(len(tracks) == 4, "exactly four AsCas12f tracks required")
    assets = load(BINDINGS, BINDINGS_SHA)
    seen, actual = bind_target(assets)
    assets = bridge(assets, tracks, TERMINAL)
    plans = [compile_jobs("predict", assets, track)[2] for track in tracks]
    plan = plans[0].copy()
    plan.pop("prediction_track_filter")
    plan["prediction_track_filters"] = tracks
    for key in ("jobs", "admission_lineage", "tracks_for_r03"):
        plan[key] = {name: entry for item in plans for name, entry in item[key].items()}
    need(len(plan["jobs"]) == 12 and all(len(item["jobs"]) == 3 for item in plans)
         and len(plan["tracks_for_r03"]) == 4 and plan["original_count"] == 3
         and plan["planned_gpu_seconds_all_50"] == 59400, "unchanged phase 1 inventory and budget")
    plan["bindings_sha256"] = sha(encode(assets))
    plan["target_cache_observation"] = seen
    plan["target_admission_artifact"] = actual
    files = {"BINDINGS.json": encode(assets), "CANDIDATES.json": encode(plan)}
    for key, item in plan["jobs"].items():
        data = encode(item["job"])
        need(sha(data) == item["job_sha256"], "job digest mismatch")
        files[key.replace("::", "--") + ".JOB.json"] = data
    status = {"status": "TWELVE_ASCAS12F_PREDICTION_CANDIDATES_NOT_RELEASED",
              "controller_release": False, "server_submission": False,
              "functional_values_read": False, "candidate_count": 12,
              "tracks": tracks, "planned_gpu_seconds_all_50": 59400,
              "candidate_gpu_seconds": sum(j["allocated_gpu_seconds"] for j in plan["jobs"].values()),
              "inputs_sha256": {str(p): sha(p.read_bytes()) for p in (BINDINGS, CONTROLLER, PROBE, CONTRACT)},
              "files_sha256": {name: sha(data) for name, data in files.items()}}
    out = HERE / "candidates"
    out.mkdir(exist_ok=False)
    for name, data in files.items():
        (out / name).write_bytes(data)
    (out / "STATUS.json").write_bytes(encode(status))


if __name__ == "__main__":
    main()
