import copy
import unittest
from pathlib import Path
from build_phase1 import PROJECT, compile_jobs, load, sha

BINDINGS = PROJECT/'R02/source_bundle_admission_v1/training_candidates_v1/BINDINGS.json'
EXPECTED = '79e01f8bffb852d453b6013450096008e0900a8293a42ae33426f710efceda57'
EMPTY = 'legacy_v2/tests/__init__.py'


class ZeroByteTests(unittest.TestCase):
    def setUp(self):
        self.assets = load(BINDINGS, EXPECTED)
        self.index = next(i for i,r in enumerate(self.assets['files']) if r['ref']['path'].endswith('/'+EMPTY))

    def test_real_pinned_empty_python_file_passes(self):
        row = self.assets['files'][self.index]
        self.assertEqual(row['bytes'],0)
        self.assertEqual(row['ref']['sha256'],sha(b''))
        self.assertEqual((Path(__file__).parent.parent/'runtime_v1'/EMPTY).read_bytes(),b'')
        jobs,configs,plan = compile_jobs('init',self.assets)
        self.assertEqual(set(jobs),{'S','L'})
        self.assertEqual(configs,{})

    def test_negative_and_boolean_byte_counts_rejected(self):
        for count in (-1,True,False):
            with self.subTest(count=count):
                assets=copy.deepcopy(self.assets)
                assets['files'][self.index]['bytes']=count
                with self.assertRaisesRegex(ValueError,'unique observed regular file'):compile_jobs('init',assets)

    def test_missing_empty_file_or_wrong_sha_rejected(self):
        missing=copy.deepcopy(self.assets)
        missing['files'].pop(self.index)
        wrong=copy.deepcopy(self.assets)
        wrong['files'][self.index]['ref']['sha256']='1'*64
        for assets in (missing,wrong):
            with self.assertRaisesRegex(ValueError,'missing actual R02 remote'):compile_jobs('init',assets)

    def test_nonregular_duplicate_or_missing_sha_rejected(self):
        for kind in ('kind','duplicate','sha'):
            assets=copy.deepcopy(self.assets)
            if kind=='kind':assets['files'][self.index]['kind']='directory'
            elif kind=='duplicate':assets['files'].append(copy.deepcopy(assets['files'][self.index]))
            else:del assets['files'][self.index]['ref']['sha256']
            with self.assertRaises(ValueError):compile_jobs('init',assets)


if __name__=='__main__':unittest.main()
