# phase1_v2 零字节修复

唯一编译器变化是 bytes 校验改为 type(bytes) is int 且 bytes >= 0。原 regular_file、实际 SHA 引用、身份和唯一性检查继续执行。ZERO_BYTE_ONLY.diff 给出限定差异。原 phase1 与 runtime_v1 文件保持原 SHA。

真实 BINDINGS 已生成并验收 actual_train_candidates 内12个 JOB、12份 config 和 CANDIDATES.json。各 JOB 文件字节 SHA 与清单相同，两池按架构共用同一干净 INIT，steps2000、seed11、lr1e-4、三个节点均已核。根验收后，R02可直接读取 CANDIDATES.json 的 JOB、挂载与分配上限，并将对应 config 按其中 config.path 逐文件部署。该编译只产生候选，提交由原R02接手。

重放命令及真实输入 SHA 见 COMPILATION_RECEIPT.json。初次命令的相对路径多了一层，已修正，失败时未产生输出。8项回归通过，详 TEST_EXECUTION.json。
