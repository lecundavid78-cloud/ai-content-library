"""Compile exact phase-one job candidates from R02 file observations. No execution."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent / 'runtime_v1'))
from single_source import digest, hash64, need, training_identity

CONTROLLER = '01a1c09c-f9e6-70f1-b9e8-b988b89c755f'
PROJECT = ROOT.parents[1]
INVENTORY_SHA = 'aba1260d74230d1b53e7894750da92fa515fe35f7be1149758553f86b4244cf9'
NODES = (500, 1000, 2000)
TARGETS = {'AsCas12f': 'CAS9_STRP1_Spencer_2017_positive',
           'SpCas9': 'HSP82_YEAST_Flynn_2019', 'TnpB': 'RCRO_LAMBD_Tsuboyama_2023_1ORC'}
INIT_SENTINEL = TARGETS['TnpB']
ORIGINAL = {'TnpB': '4d938c3498a43fb2664ceb4f253aaec18b025cb3f268ed5d4886b3c51d23cd91',
            'AsCas12f': 'f2705ae270690496c16da2680baf5f4163ad2de50e9f7cc532b44ebdd7aa1f81',
            'SpCas9': 'feda3710112ad731493437d4774eb6ee071926944af11db358cf01e6c7b202a4'}
GPU_QUALIFICATION_SHA = '8526648c9cfd27d9a16b184a189ab3ad9171ce7b04cef779bc7b64f34c6af38e'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path, expected):
    data = Path(path).read_bytes()
    need(sha(data) == expected, 'file identity differs: ' + str(path))
    return json.loads(data)


def absolute(path):
    need(isinstance(path, str) and PurePosixPath(path).is_absolute()
         and '..' not in PurePosixPath(path).parts and str(PurePosixPath(path)) == path
         and not path.startswith('//') and path != '/', 'exact absolute POSIX file path')
    return path


def spec(ref):
    need(set(ref) == {'path', 'sha256'} and hash64(ref['sha256']), 'exact path/SHA reference')
    absolute(ref['path'])
    return ref


def encode(doc):
    return (json.dumps(doc, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode()


def admission_rebind(original, deployed):
    leaves = ('bank','index','pairs')
    need(set(original) == set(deployed), 'rebound admission fields changed')
    for name in original:
        if name not in leaves:
            need(original[name] == deployed[name], 'admission non-runtime field changed: '+name)
            continue
        a,b = original[name],deployed[name]
        need({k:v for k,v in a.items() if k!='path'} == {k:v for k,v in b.items() if k!='path'},
             'rebound admission leaf changed: '+name)
        spec({'path':b['path'],'sha256':b['sha256']})


def compile_jobs(stage, assets, only_track=None):
    inventory = load(PROJECT/'DEVELOPMENT_PHASE1_INVENTORY.json', INVENTORY_SHA)
    load(PROJECT/'CONTROLLER_ACTUAL_GPU_QUALIFICATION_ACCEPTANCE.json', GPU_QUALIFICATION_SHA)
    tracks = {x['track_id']: x for x in inventory['training_trajectories']}
    need(len(tracks) == 12 and len(inventory['checkpoint_predictions']) == 36, 'frozen 12/36 inventory')
    need(only_track is None or (stage=='predict' and only_track in tracks), 'track subset is predict-only')
    need(assets['schema'] == 'PHASE1_R02_VERIFIED_BINDINGS_V1' and assets['inventory_sha256'] == INVENTORY_SHA,
         'R02 verified bindings and fixed inventory required')
    observed = {}
    for row in assets['files']:
        ref = spec(row['ref'])
        need(row['kind'] == 'regular_file' and type(row['bytes']) is int and row['bytes'] >= 0 and ref['path'] not in observed,
             'unique observed regular file required')
        absolute(row['host_path'])
        observed[ref['path']] = row

    def verify(ref):
        spec(ref)
        need(ref['path'] in observed and observed[ref['path']]['ref'] == ref,
             'missing actual R02 remote file observation: ' + ref['path'])
        return ref

    def doc(ref):
        verify(ref)
        return load(observed[ref['path']]['local_copy'], ref['sha256'])

    runtime = assets['runtime']
    native = doc(runtime['native_lock'])
    imports = doc(runtime['import_lock'])
    need(native['schema']=='FOURCELL_NATIVE_MEMBERS_V1' and len(native['members'])==6
         and {r['K'] for r in native['members']}=={20,128,512,1024,2048,4096}
         and set(imports['files'])=={'torch','numpy','transformers','transformers.dynamic_module_utils'}
         and all(native[k]==imports[k] for k in ('torch_version','transformers_version','numpy_version')),
         'same six members and actual import lock')
    code = load(runtime['code_inventory_local'], runtime['code_inventory_sha256'])
    need(isinstance(code, dict) and 'runtime_cli.py' in code and all(hash64(h) for h in code.values()),
         'complete deployed runtime code inventory')
    need(code == load(ROOT.parent/'runtime_v1/RUNTIME_CODE_SHA256.json', runtime['code_inventory_sha256']),
         'deployed Python inventory must match pinned runtime_v1 bytes')
    code_root = absolute(runtime['code_root'])
    shared = [verify({'path': code_root+'/'+name, 'sha256': h}) for name,h in code.items()]
    legacy_manifest = ROOT.parent/'runtime_v1/legacy_v2/CODE_MANIFEST.json'
    shared.append(verify({'path': code_root+'/legacy_v2/CODE_MANIFEST.json',
                          'sha256': sha(legacy_manifest.read_bytes())}))
    shared.extend(verify(runtime[k]) for k in ('native_lock','import_lock'))
    for member in native['members']:
        for name,h in member['files_sha256'].items():
            shared.append(verify({'path': member['root']+'/'+name, 'sha256': h}))
    shared.extend(verify(r) for r in imports['files'].values())
    budget = doc(assets['budget'])
    need(budget['status'] == 'PHASE1_BUDGET_LOCKED' and budget['controller'] == CONTROLLER
         and budget['inventory_sha256'] == INVENTORY_SHA and type(budget['max_gpu_seconds']) is int,
         'controller budget lock required')
    slots = assets['slots']
    init_ids = {'S','L'}
    prediction_ids = {p['target']+'::'+p['config_id'] for p in inventory['checkpoint_predictions']}
    expected = {'init': init_ids, 'train': set(tracks), 'predict': prediction_ids}
    need(set(slots) == set(expected) and all(set(slots[k]) == v for k,v in expected.items()), 'exact 2/12/36 slots')
    caps = [s for group in slots.values() for s in group.values()]
    outputs = {PurePosixPath(absolute(s['output'])) for s in caps}
    need(len(outputs)==50 and all(not any(p in outputs for p in o.parents) for o in outputs), 'disjoint outputs')
    need(all(type(s['wall_seconds']) is int and 0 < s['wall_seconds'] <= 1800
             and type(s['allocated_gpu_seconds']) is int and s['allocated_gpu_seconds'] > s['wall_seconds']
             for s in caps), 'single-GPU caps include runtime plus preflight/cleanup')
    planned = sum(s['allocated_gpu_seconds'] for s in caps)
    need(planned <= budget['max_gpu_seconds'], '50 allocated job caps exceed locked budget')
    jobs, generated, lineage, collections = {}, {}, {}, {}
    protected_hashes = {r['target_table_sha256'] for r in inventory['development_routes']}

    def job(key, case, extra):
        slot = slots[stage][key]
        entry = {'schema':'SINGLE_SOURCE_RUNTIME_JOB_V1','stage':stage,'purpose':'EXACT_SINGLE_SOURCE_'+stage.upper(),
                 'device':'cuda','output':slot['output'],'native_lock':runtime['native_lock'],
                 'import_lock':runtime['import_lock'],'material_lock':None,'cases':[case],'runtime_code_sha256':code}
        need(all(r['sha256'] not in protected_hashes for r in shared+extra), 'evaluation table in executable mount')
        output_path=PurePosixPath(slot['output'])
        need(all(output_path != PurePosixPath(r['path']) and output_path not in PurePosixPath(r['path']).parents
                 for r in shared+extra), 'output overlaps an immutable mount')
        mounts = {r['path']: observed[r['path']]['host_path'] for r in shared+extra}
        jobs[key] = {'job':entry,'job_sha256':sha(encode(entry)), 'read_only_file_mounts':mounts,
                     'wall_seconds':slot['wall_seconds'],'allocated_gpu_seconds':slot['allocated_gpu_seconds'],
                     'max_updates_per_case':2000 if stage=='train' else 0}

    if stage == 'init':
        for arch in ('S','L'):
            job(arch, {'source_id':INIT_SENTINEL,'architecture':arch,'seed':11}, [])
    else:
        need(set(assets['initializations']) == init_ids, 'both formal initializations required')
        for arch in sorted(init_ids):
            item = assets['initializations'][arch]
            receipt = doc(item['receipt'])
            verify(item['init'])
            init_job = doc(item['job'])
            init_release = doc(item['release'])
            runtime_receipt = doc(item['runtime_receipt'])
            inspection=doc(item['inspection'])
            need(inspection['schema']=='PHASE1_INIT_INSPECTION_V1' and inspection['init_sha256']==item['init']['sha256']
                 and inspection['checkpoint_schema']=='SINGLE_SOURCE_INIT_V1' and inspection['architecture']==arch
                 and inspection['seed']==11 and inspection['native_sha256']==runtime['native_lock']['sha256']
                 and hash64(inspection['frozen_sha256']) and inspection['frozen_sha256']==inspection['qualified_frozen_sha256']
                 and inspection['trainable_parameters']=={'S':597376,'L':589824}[arch]
                 and inspection['trainable_tensor_count']=={'S':22,'L':24}[arch]
                 and inspection['exact_original_whitelist_verified'] is True,
                 'actual step0 and qualified frozen fingerprint: '+arch)
            need(init_job['stage']=='init' and init_job['cases']==[{'source_id':INIT_SENTINEL,'architecture':arch,'seed':11}]
                 and init_job['device']=='cuda' and init_job['output']==slots['init'][arch]['output']
                 and init_release['max_updates_per_case']==0 and runtime_receipt['actual_native_loads']==1
                 and init_job['native_lock']['sha256']==runtime['native_lock']['sha256']
                 and init_job['runtime_code_sha256']==code and init_job['import_lock']['sha256']==runtime['import_lock']['sha256']
                 and init_release['schema']=='SINGLE_SOURCE_RUNTIME_RELEASE_V1'
                 and init_release['controller']==CONTROLLER and init_release['status']=='RELEASED'
                 and init_release['job_sha256']==item['job']['sha256'] and init_release['stage']=='init'
                 and runtime_receipt['status']=='COMPLETE_UNEVALUATED' and runtime_receipt['stage']=='init'
                 and runtime_receipt['job_sha256']==item['job']['sha256'] and runtime_receipt['release_sha256']==item['release']['sha256']
                 and receipt['status']=='CLEAN_NATIVE_INIT_ONLY' and receipt['trained_checkpoint_loaded'] is False
                 and (receipt['architecture'],receipt['seed'],receipt['sha256'])==(arch,11,item['init']['sha256']),
                 'exact clean initialization evidence: '+arch)
        target_meta = assets['targets']
        need(set(target_meta)==set(TARGETS), 'three target admission metadata records required')
        for target,source in TARGETS.items():
            t=target_meta[target]
            need(hash64(t['wt_sha256']) and t['forbidden_source_ids'] and source not in t['forbidden_source_ids'],
                 'target shared-library/source isolation: '+target)
            original=t['original']
            need(original['acceptance']['sha256']==ORIGINAL[target], 'prelocked Original acceptance')
            accepted=doc(original['acceptance'])
            need(accepted['target_id']==target and accepted['status']=='EXACT_ORIGINAL_EXPORT_ACCEPTED'
                 and accepted['core_metadata_sha256']==t['core']['sha256'], 'Original exact target/core identity')
            core=doc(t['core']);verify(t['natural'])
            need(core['sequence_sha256']==t['wt_sha256']==core['target_meta']['wt_sha256']
                 and core['target_meta']['id']==target, 'exact target core reference')
            for field in ('record','raw','csv'):
                need(verify(original[field])['sha256']==accepted[field+'_sha256'], 'exact Original '+field)
        for tid,track in tracks.items():
            if only_track is not None and tid!=only_track:
                continue
            source,target,arch,bank=(track[k] for k in ('source_id','target','architecture','bank_rule'))
            source_asset=assets['sources'][source]
            sb=verify(source_asset['bundle'])
            evidence=doc(source_asset['evidence'])
            check_cache(evidence,sb,source,'SOURCE',source_asset['wt_sha256'],runtime)
            need(source_asset['wt_sha256']!=target_meta[target]['wt_sha256'],'source and target WT overlap')
            item=source_asset['banks'][bank]
            original=load(item['original_admission_local'],track['source_admission_sha256'])
            deployed=doc(item['admission'])
            admission_rebind(original,deployed)
            refs=[verify({x:deployed[k][x] for x in ('path','sha256')}) for k in ('bank','index','pairs')]
            bank_ref,index_ref,schedule_ref=refs
            need(schedule_ref['sha256']==track['pair_stream_sha256'] and
                 bank_ref['sha256'] not in {r['target_table_sha256'] for r in inventory['development_routes']},
                 'fixed pair stream and no target table as bank')
            index=doc(index_ref);schedule=doc(schedule_ref)
            need((index['source_id'],index['bank_rule'],index['count'],index['wt_sha256'])==
                 (source,bank,track['bank_count'],source_asset['wt_sha256']),'fixed source index and count')
            need(deployed['role']=='SOURCE_TRAIN_ONLY' and deployed['source_id']==source
                 and deployed['target_development_use']==target and deployed['bank_rule']==bank
                 and deployed['count']==track['bank_count'],'source-only admitted route')
            init=assets['initializations'][arch]['init']
            config={k:track[k] for k in ('architecture','steps','seed','lr','checkpoints')}
            config.update(schema='SINGLE_SOURCE_CONFIG_V1',pairs_per_class=128,loss='phaseA-pair-v2-nonempty',
                optimizer={'name':'AdamW','betas':[.9,.999],'eps':1e-8,'weight_decay':0.,'clip_norm':1.,'dtype':'float32','scheduler':None,'scaler':None},
                native_sha256=runtime['native_lock']['sha256'],init_sha256=init['sha256'],
                code_sha256=digest(code),runtime_sha256=digest(imports),
                source={'id':source,'wt_sha256':index['wt_sha256'],'length':index['length'],
                    'bank_indices':index['bank_indices'],'heldout_positions':index['heldout_positions'],
                    'bank_sha256':item['admission']['sha256'],'bundle_sha256':sb['sha256']})
            training_id, identity=training_identity(config,schedule)
            config_ref={'path':absolute(item['config_root'])+'/'+tid+'.json','sha256':sha(encode(config))}
            lineage[tid]={'original_admission_sha256':track['source_admission_sha256'],
                'original_admission_local':item['original_admission_local'],
                'deployed_admission':item['admission'],'index':index_ref,'schedule':schedule_ref,'training_id':training_id}
            base={'source_id':source,'admission':item['admission'],'config':config_ref,
                  'schedule':schedule_ref,'init':init,'prior_attempts':None}
            mounts=[item['admission'],*refs,init]
            if stage=='train':
                generated[tid]=config
                job(tid,dict(base,bundle=sb,checkpoint=None),mounts+[sb])
                continue
            mounts.append(verify(config_ref))
            completed=assets['completed_tracks'][tid]
            tr=doc(completed['train_receipt'])
            executed=doc(completed['job']);release=doc(completed['release']);receipt=doc(completed['runtime_receipt'])
            need(executed['stage']=='train' and executed['cases']==[dict(base,bundle=sb,checkpoint=None)]
                 and executed['runtime_code_sha256']==code and executed['native_lock']==runtime['native_lock']
                 and executed['import_lock']==runtime['import_lock'] and executed['device']=='cuda'
                 and release['status']=='RELEASED' and release['controller']==CONTROLLER
                 and release['max_updates_per_case']==2000 and receipt['actual_native_loads']==1
                 and release['stage']=='train' and release['job_sha256']==completed['job']['sha256']
                 and receipt['status']=='COMPLETE_UNEVALUATED' and receipt['stage']=='train'
                 and receipt['job_sha256']==completed['job']['sha256'] and receipt['release_sha256']==completed['release']['sha256'],
                 'executed train job/release/receipt chain')
            need(doc(completed['identity'])==dict(identity,training_id=training_id,resume_file_sha256=None)
                 and tr['status']=='COMPLETE_UNEVALUATED' and tr['training_id']==training_id
                 and tr['completed_updates']==2000 and tr['resume_checkpoint'] is None
                 and tr['attempts']>=2000,'actual full R03-compatible training receipt')
            checkpoints={r['step']:r for r in tr['checkpoints']}
            need(len(tr['checkpoints'])==3 and set(checkpoints)==set(NODES),'all durable train nodes required')
            target_bundle=verify(target_meta[target]['bundle'])
            check_cache(doc(target_meta[target]['evidence']),target_bundle,target,'TARGET',target_meta[target]['wt_sha256'],runtime)
            collections[tid]={'execution':{'job':completed['job'],'release':completed['release'],'receipt':completed['runtime_receipt']},
                'train_receipt':completed['train_receipt'],'identity':completed['identity'],'checkpoints':completed['checkpoints'],
                'config':config_ref,'schedule':schedule_ref,'init':init,'admission':item['admission'],
                'bank_index':index_ref,'import_lock':runtime['import_lock']}
            for node in inventory['checkpoint_predictions']:
                if node['track_id']!=tid:continue
                step=node['step'];ck=verify(completed['checkpoints'][str(step)])
                need(checkpoints[step]['sha256']==ck['sha256'] and hash64(checkpoints[step]['content_sha256']),
                     'observed checkpoint differs from actual saved node')
                job(target+'::'+node['config_id'],dict(base,bundle=target_bundle,checkpoint=ck),mounts+[target_bundle,ck])
    return jobs,generated,{'schema':'PHASE1_JOB_CANDIDATES_V1','status':'NOT_RELEASED','stage':stage,
        'inventory_sha256':INVENTORY_SHA,'gpu_qualification_sha256':GPU_QUALIFICATION_SHA,
        'budget':assets['budget'],'planned_gpu_seconds_all_50':planned,'prediction_track_filter':only_track,
        'init_count':2,'formal_ledger_successful_train_predict_count':48,'original_count':3,
        'admission_lineage':lineage,'tracks_for_r03':collections,
        'targets_and_exact_originals':assets.get('targets',{}) if stage!='init' else {},'jobs':jobs}


def check_cache(evidence,ref,entity,role,wt,runtime):
    need(evidence['status']=='EXACT_FULLWT_BUNDLE_ADMITTED' and evidence['bundle_sha256']==ref['sha256']
         and (evidence['id'],evidence['role'],evidence['wt_sha256'])==(entity,role,wt)
         and evidence['native_lock_sha256']==runtime['native_lock']['sha256']
         and evidence['full_wt_h11_h12_validated'] is True and evidence['functional_values_present'] is False
         and evidence['cache_schema']=='FOURCELL_PREPARED_V1'
         and evidence['prefix_layer']==11 and evidence['window_rule']=='single-full-WT-forward-no-window'
         and evidence['all_six_member_identities_match'] is True
         and all(hash64(evidence[k]) for k in ('natural_input_sha256','structure_asset_sha256','member_identity_sha256')),
         'exact full-WT cache readmission required: '+entity)


def main():
    p=argparse.ArgumentParser();p.add_argument('stage',choices=['init','train','predict'])
    p.add_argument('--bindings',required=True);p.add_argument('--bindings-sha256',required=True)
    p.add_argument('--track',help='predict only: one prelocked track and its three actual nodes')
    p.add_argument('--out',required=True);a=p.parse_args()
    try:
        assets=load(a.bindings,a.bindings_sha256)
        jobs,configs,manifest=compile_jobs(a.stage,assets,a.track)
    except (ValueError, KeyError, TypeError, OSError) as error:
        p.exit(2, f'BLOCKED: {error}\n')
    manifest['bindings_sha256']=a.bindings_sha256
    out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
    for key,item in jobs.items():
        (out/(key.replace('::','--')+'.JOB.json')).write_bytes(encode(item['job']))
    for key,config in configs.items():
        (out/(key+'.json')).write_bytes(encode(config))
    (out/'CANDIDATES.json').write_bytes(encode(manifest))


if __name__=='__main__':main()
