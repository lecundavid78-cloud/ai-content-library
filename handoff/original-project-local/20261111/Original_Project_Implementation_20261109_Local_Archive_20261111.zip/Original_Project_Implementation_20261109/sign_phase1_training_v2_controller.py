"""Check the bounded mount repair and bind the existing training matrix."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys
import zipfile

D = Path(__file__).resolve().parent
P = D / "R02/production_training_deployment_v2"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def encode(doc):
    return (json.dumps(doc, indent=2) + "\n").encode()


def load_zip(reference, expected):
    path = Path(reference["path"])
    assert path.stat().st_size == reference["bytes"]
    assert sha(path.read_bytes()) == reference["sha256"]
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(expected)
        contents = {name: archive.read(name) for name in archive.namelist()}
    assert {name: sha(data) for name, data in contents.items()} == expected
    return contents


def shell_bindings(script):
    argv = shlex.split(script.replace("\\\n", " "))
    index = argv.index("--bind") + 1
    return argv[:index] + argv[index+1:], argv[index].split(",")


def verify_and_pack():
    prior_path = D / "CONTROLLER_PHASE1_TWELVE_TRAIN_EXECUTION_RELEASE.json"
    prior = read(prior_path)
    template = read(P / "TRAINING_RELEASE_NOT_RELEASED.json")
    assert template["superseded_execution_release_sha256"] == sha(prior_path.read_bytes())
    assert template["prior_formal_gpu_billed_seconds"] == 255
    assert template["remaining_formal_gpu_budget_seconds"] == 59400 - 255
    assert template["candidate_manifest_sha256"] == prior["candidate_manifest_sha256"]
    assert len(template["nodes"]) == len(prior["nodes"]) == 12
    release = template | {"status": "RELEASED", "nodes": []}
    out = D / "controller_phase1_training_signed_v2"
    for i, (old, new) in enumerate(zip(prior["nodes"], template["nodes"])):
        assert old["track_id"] == new["track_id"] and old["job_sha256"] == new["job_sha256"]
        assert new["allocated_gpu_seconds"] == old["allocated_gpu_seconds"] == 1800
        assert new["predecessor_track"] == old["predecessor_track"]
        assert new["supersedes_job"] == ("5222146" if i == 0 else None)
        old_files = load_zip(old["signed_archive"], old["unsigned_files"] | {
            "ROOT_RELEASE.json": old["inner_sha256"], "OUTER_RELEASE.json": old["outer_sha256"]})
        files = load_zip(new["archive"], new["unsigned_files"])
        unchanged = set(old["unsigned_files"]) - {"MANIFEST.json","OUTER_NOT_RELEASED.json","train.sbatch"}
        assert all(old_files[name] == files[name] for name in unchanged | {"ROOT_RELEASE.json"})
        assert sha(files["ROOT_RELEASE.json"]) == new["preserved_inner_sha256"] == old["inner_sha256"]
        old_root, new_root = old["remote_root"], new["remote_root"]
        assert new_root == old_root.replace("/production_train_", "/production_train_v2_")
        assert new["job_name"] == old["job_name"] + "_v2"
        old_batch = old_files["train.sbatch"].decode().replace(old_root,new_root).replace(old["job_name"],new["job_name"])
        new_batch = files["train.sbatch"].decode()
        old_args, old_binds = shell_bindings(old_batch)
        new_args, new_binds = shell_bindings(new_batch)
        assert old_args == new_args and Counter(old_binds) == Counter(new_binds)
        assert new_binds[:2] == ["$R02_BASE_ENV:$R02_BASE_ENV:ro", "$R02_RUNTIME_ENV:$R02_RUNTIME_ENV:ro"]
        old_manifest = json.loads(old_files["MANIFEST.json"])
        new_manifest = json.loads(files["MANIFEST.json"])
        assert new_manifest == old_manifest | {"remote_root":new_root,"supersedes_job":new["supersedes_job"],
            "mounts":{dst:host.replace(old_root,new_root) for dst,host in old_manifest["mounts"].items()}}
        outer_template = json.loads(files["OUTER_NOT_RELEASED.json"])
        assert outer_template == json.loads(old_files["OUTER_NOT_RELEASED.json"]) | {
            "manifest_sha256":sha(files["MANIFEST.json"]),"supersedes_job":new["supersedes_job"]}
        files["OUTER_RELEASE.json"] = encode(outer_template | {"status":"RELEASED","inner_sha256":old["inner_sha256"]})
        folder = out / new["track_id"]
        folder.mkdir(parents=True, exist_ok=True)
        signed = folder / "TRAIN_SIGNED.zip"
        with zipfile.ZipFile(signed, "w") as archive:
            for name, data in sorted(files.items()):
                archive.writestr(zipfile.ZipInfo(name,(2026,11,10,0,0,0)),data,compress_type=zipfile.ZIP_DEFLATED)
        release["nodes"].append(new | {"signed_archive":{"path":str(signed),"sha256":sha(signed.read_bytes()),"bytes":signed.stat().st_size},
            "inner_sha256":old["inner_sha256"],"outer_sha256":sha(files["OUTER_RELEASE.json"])})
    helpers = ("serial_driver.py","serial_remote.py","training_launcher.py")
    assert all(sha((P/name).read_bytes()) == prior["reviewed_helper_files"][str(P.parent/"production_training_deployment_v1"/name)] for name in helpers)
    release["reviewed_helper_files"] = {str(P/name):sha((P/name).read_bytes()) for name in helpers}
    return release


if __name__ == "__main__":
    release = verify_and_pack()
    if len(sys.argv) == 1:
        print("PASS twelve repaired packages, mount order only; not released")
    else:
        probe = Path(sys.argv[1])
        evidence = read(probe)
        assert evidence["status"] == "CONTROLLER_VISIBILITY_PROBE_ACCEPTED"
        assert evidence["expected_visible_rows"] == 92
        release["visibility_probe_acceptance"] = {"path":str(probe),"sha256":sha(probe.read_bytes())}
        path = D/"CONTROLLER_PHASE1_TWELVE_TRAIN_V2_EXECUTION_RELEASE.json"
        with path.open("xb") as stream:
            stream.write(encode(release))
        digest = sha(path.read_bytes())
        subprocess.run([sys.executable,"-B",str(P/"serial_driver.py"),"check","--release",str(path),"--release-sha256",digest],check=True)
        print(digest)
