# 接管说明

当前控制者01a1c09c-f9e6-70f1-b9e8-b988b89c755f。读CONTROL_STATUS.json、CURRENT_STATUS.md、DISPATCH_RECEIPTS.json及各Rxx/STATUS.json；新角色完成后勿重复派已完成工作。误回传ZIP忽略。

当前无服务器任务，RUN_LEDGER仅表头属实。合成测试30项通过；真实数据包/生产实际模型资格尚未完成。EXPERIMENT_SPEC.json是待锁候选，非TRAINING_ADMISSION。真实运行前绑定具体bank/pair/初始化/代码与预算；根不SSH/原始目标标签。独立最终面板仍待历史曝光核对。

若原总控接回，先核此分支和原R05是否仍在完成最终回执；勿并发调度。已完成历史66训练105预测等保留，不按旧heartbeat复跑。继续维护状态/决定/实际job，禁止虚构受理。

## 最新实际作业覆盖旧无作业状态

CPU资格5213902已单次受理；R02当前turn01a1c0cd-bfea-76d3-9b27-573a72a47d2c负责实际监控。签名包/两release/提交回执均在qualification_v1。未获得资格PASS前不得正式训练；只跟这一个job，不重交preflight。输入和runtime最新验收分别CONTROLLER_SOURCE_INPUT_ACCEPTANCE、CONTROLLER_REAL_RUNTIME_CODE_ACCEPTANCE及CONTROLLER_FINAL_CPU_DEPLOYMENT_ACCEPTANCE。

## 当前断点

最新资格作业为5214122，原R02因用量上限停止取证。先读 CONTROLLER_5214122_USAGE_LIMIT_RESUME.json，再核实际终态。阶段一预锁清单在 DEVELOPMENT_PHASE1_INVENTORY.json。训练放行尚待完整资格与资源预算。

最新断点更新。5214122已完成验收，读 CONTROLLER_ACTUAL_CPU_QUALIFICATION_ACCEPTANCE.json。后续核生产单GPU资格与独立评价准备，不恢复旧CPU提交意图。

## 11月10日实际断点

读 CONTROLLER_GPU_DISPATCH_USAGE_INTERRUPTION_20261110.json、CONTROLLER_GPU_WRAPPER_COUNT_FIX_CANDIDATE.diff 和 CONTROL_STATUS.json。单GPU资格已签 CONTROLLER_EXACT_GPU_QUALIFICATION_EXECUTION_RELEASE.json，尚无本地受理；原R02、R05本轮均因平台额度停止，提示11月10日22:25 SGT可再尝试。先查看新回执与原会话状态，再由原R02核同一远端意图/账单。若未受理，修两处82的计数后仅用已有签发包续接一次。R05只接已有正式配置工作，不另开角色。R03本地评价验收已过，真实39预测未封存，标签与正式训练仍未放行。

## 11月10日 单卡已受理

原R02已恢复并单次提交5217253，读CONTROLLER_GPU_SUBMISSION_ACCEPTANCE_5217253.json和R02/gpu_qualification_v1/STATUS.json。10:14 SGT真实观测PENDING (Resources)。后续只跟同一job，禁止重投。正式训练仍待单卡实际验收和精确资产/预算。

5217253已终止，勿按旧预计开始时间继续等待。读CONTROLLER_GPU_TERMINAL_REVIEW_5217253.json。4/6格通过，缺RCRO两种架构的完整验收，正式训练仍待放行。

RCRO补验读CONTROLLER_EXACT_GPU_RCRO_QUALIFICATION_EXECUTION_RELEASE.json，原R02 turn 01a1c419-5858-71c1-8451-b37fbf646416 已接。确认同名作业与原意图再对账。60分钟仅作上限，真实消耗以sacct为准。尚无新job ID。

RCRO补验实际已受理5220319，读CONTROLLER_GPU_RCRO_SUBMISSION_ACCEPTANCE_5220319.json。最新排队等资源，沿同ID跟踪两格和账单。

5220319已完成，CONTROLLER_ACTUAL_GPU_QUALIFICATION_ACCEPTANCE.json为六格合并验收。后续接正式12轨迹配置、资产身份、预算和准入。GPU资格无需重跑。

当前已提交S INIT 5221808与LoRA INIT 5221809，证据CONTROLLER_PHASE1_CLEAN_INIT_SUBMISSION_ACCEPTANCE.json。R02在准备CPU六缓存语义检查和后续编排。不要重复提交INIT。

5221854是CPU缓存语义检查，5221808/09是串行INIT。24个正式来源输入由当前R02执行独立暂存；见CONTROLLER_PHASE1_SOURCE_STAGING_RELEASE.json。所有阶段均已明确派发，不重复。正式12轨迹需要实际INIT和缓存回执，接着生成真实配置和签发。

当前最新断点见CONTROLLER_PHASE1_USAGE_CHECKPOINT_20261110.json。R02提示20:40 SGT可再尝试。三个已受理作业独立运行，根未SSH。源暂存修复候选在phase1_source_rebind_v1，恢复时先查询三个旧ID和源claim，绝不先重投。

已验两INIT及24源文件，见CONTROLLER_PHASE1_CLEAN_INIT_TERMINAL_ACCEPTANCE、CONTROLLER_PHASE1_SOURCE_STAGING_ACCEPTANCE。CPU角色差异见CONTROLLER_PHASE1_CACHE_INSPECTION_REVIEW。原R0216:46有真实恢复，旧20:40额度等待不再决定当前状态。原R02接本地来源准入派生候选，严禁修改历史cache或重编码器。


11月10日17:13 SGT核验两份正式INIT及24件来源暂存均完成。六格CUDA资格通过。来源缓存CPU派生候选已逐件与冻结科学代码比对、5项检查通过，签发4CPU/32GiB/30分钟/0GPU一次实际任务，仅产生正式SOURCE副本及六份跨度准入，父文件与张量不变。30分钟上限给实际指纹/派生/复载检查保留余量。已交原R02执行，同时预接12条正式训练配置；尚无本CPU真实受理ID，正式训练仍为0。


11月10日17:20 SGT实际CPU5222068已COMPLETED0:0，68秒、272核秒、0GPU，根逐件核11回传及六正式准入、三SOURCE派生hash与原始身份一致。正式训练仍未提交。真实配置编译发现合法空__init__.py被bytes>0错误拒绝，已一次交原R05作最小v2修复及真实12配置编译；原R02并行准备串行生产提交，不重做成功CPU/INIT。


11月10日17:53 SGT零字节元信息检查已最小修复，8项回归根复跑PASS；12条真实训练JOB/config根全量重编译一致并验原科学runtime未变。验收bcff94e6…、CANDIDATES292f1dee…。原R02 turn01a1c4dd-ac6d-7722-b05e-5273137da869正在绑定实际配置的生产batch/单卡串行driver候选，等根签精确执行包；此时正式训练提交仍0，不能把配置验收称作已排队。


11月10日18:00 SGT正式12条训练包全部签发，执行release cb90cfd0756a7e3eaf747332582960dd9c85e586ce5e2431d59ae4dfc8db2df1，原R02 turn01a1c4e6-f0a6-7cf3-9a3c-1862da131fb1已收到直接部署与提交指令。3组生产测试含12节点逐字符串挂载/原INIT路径回归根PASS；原科学代码和12配置不变。每条1GPU/8CPU/64GiB/30min、2000更新，失败或模糊受理不自动重投。此时尚待首条实际Slurm ID，不把放行记成已提交。36节点预测后续仍依赖真实checkpoint SHA独立绑定。


实际首单5222146（AsCas12f S full_train）获受理后24秒FAILED127:0。根核5故障文件与实际stderr487d981b…：Singularity在父运行环境挂载前尝试numpy叶文件，容器creation失败，模型入口未启动。后11未投。原R02 turn01a1c4eb-a80e-78e1-9fdf-7f5aa3875afd正在独立v2目录准备仅挂载顺序/修复新作业身份，以及一次0GPU可见性检查候选；不重跑资格/INIT/来源CPU，不改变12科学配置，24GPU秒计入原59400上限。


11月10日18:32 SGT，v2十二包的挂载顺序/集合、原JOB/config/inner字节已通过本地复核。唯一零GPU探针签发7853bd12…；自动审核在启动前拒绝，引用历史本地准备限制，零SSH/零作业。总控核ZIP范围并更正CONTROL_PROTOCOL.md的阶段指针，将现行用户委托与历史准备分开，交原R02对同一操作正常复核一次。实际92项可见性通过前不放行v2训练。


11月10日18:34 SGT，原R02复核同一探针仍在进程启动前被自动审核拒绝。理由为缺用户直接明确许可本次SSH传输私有控制包及远端写入，零连接、零新作业、零GPU。保留拒绝实物，不更换执行方式。十二个v2训练包本地核验完成，等待用户对这份22,309字节包和零GPU探针的明确许可；正式成功仍0，已受理但失败的首单5222146不变。


用户已在总控消息 01a1c51a-c8aa-7652-ae1f-ecc65fa30e72 直接批准确切探针传输和执行。原R02已收到同一包及签发的唯一接续，按正常自动审批。当前仅已派单，等实际回执。


用户明确授权后的零GPU探针已实机通过，根逐行核对92文件，验收 ab0d8ac6…；12条v2训练签发 b80b5acf…，已交原R02。首条仅替代5222146，后11仍按成功门槛单卡串行，账本保留首单24秒失败消耗。当前等替代作业实际编号。


零GPU探针通过后，原R02对v2首条训练的部署及sbatch自动审批于19:00 SGT拒绝，明确上一条人类许可只覆盖探针；训练尝试零SSH、零sbatch、零GPU。R02随后用量中断，界面提示22:08 SGT可再试。正式v2包、签发与92项探针验收保持，需人类对12条精确签包传输与串行单卡训练直接许可后接续。


人类在总控消息 01a1c52e-a5f5-78e2-8001-7243173d1671 明确回复“允许”，覆盖已签发的12个v2训练包、学校项目目录SSH部署和单A800串行sbatch（每单30分钟，v2最多6 GPU小时）。当前原R02仍为平台用量中断，界面提示22:08 SGT可再试。未见v2提交回执或claim。恢复时按用户原消息与固定签发接续一次，先对账，再依正常审批执行。


11月10日20:29 SGT，原R02实际恢复，原22:08等待被新会话状态覆盖。总控再次核对用户消息01a1c52e…及01a1c56f…均覆盖当前有限执行，将已签12条v2作业交原R02续接，先核第一条真实sbatch回执。探针92项已通过，既有准备直接复用。


11月10日20:30 SGT，v2首条AsCas12f S full_train获Slurm受理5222686，替代原失败5222146。20:31实查RUNNING、1 GPU，根核签发、JOB、路径及两个实际回执；尚无完成证据。后续原R02依前驱2,000步与三个检查点验收串行推进，任务账本已登记。


20:44 SGT，v2首条5222686 COMPLETED0:0，752 GPU秒、2,000步、500/1000/2000三个检查点均核验，随后第二条5222736受理且RUNNING。当前1/12训练完成；原R02有界协调器已实际推进后继，R05并行用首条真实回执准备36节点预测接线，未签发或提交预测。


R05已交预测元信息接线工具，根核manifest六件及复跑3项测试通过。编译首条三节点尚需原R02服务器原始训练回执/训练身份/runtime回执三JSON和三个检查点大小元信息；保持GPU权重原地。R02当前串行执行中，采集待合适时点接续。当前无预测和科学指标。


实机训练续进：5222686 COMPLETED, 5222736 COMPLETED, 5222749 RUNNING。总控核对账本与回执，已完成轨迹均2,000步、三检查点齐全；已完成训练GPU秒1330，单卡顺序继续。尚无功能评价指标。


21:16 SGT 实查3条完成、5222795 PENDING，其余8条待当前串行驱动提交。每条独立Slurm job、独立INIT同架构复用，三检查点。现行一次只提交一条是部署顺序；科学训练独立。


人类总控消息01a1c5b6…明确“都排队”，授权将已签训练矩阵的余下任务交Slurm依赖链，保持单A800及原执行条件。原R02已接续，先核旧本地协调器安全交接、真实受理与claim；当前根核4条已有Slurm号、前三完成、尾单5222795已受理，新排队ID待实际回执。


21:56 SGT，根核Slurm逐项依赖、8条受理原日志和各签包：12条现全部受理，3条完成，5222795运行，5223860–5223867按afterok依赖等待。旧本地协调器已退出；余下任务由Slurm启动，各节点另核前驱2,000步与三检查点。未扩单卡预算，实际RUN_LEDGER已登记。


11月11日08:07 SGT，AsCas12f四条实际完成2,000步，12检查点通过。SpCas9首条5223860依赖已解除，等待GPU资源；其他7条等前序。R02已归档原始回执与stat/hash，R05接续用真实回执准备四轨迹预测专用目标绑定。未提交预测，尚无指标。

## Kaggle 侧任务

读取 Kaggle_Pilot_20261111/WORK_ORDER.md 与 DISPATCH_RECEIPTS.json，随后看各角色 STATUS.json。首包为独立合成测试。GROK_INSTRUCTIONS.md 随最终包交接。真实运行由用户指定 Grok 执行，收到证据后再决定是否能作为备用算力。学校 RUN_LEDGER.csv 不混记尚未运行的 Kaggle 试跑。

Kaggle 首包交付物为 Kaggle_Pilot_20261111/Kaggle_Dual_T4_Grok_20261111.zip。验收状态见同目录 CONTROLLER_ACCEPTANCE.json。请保留 Grok 回传的原始 ZIP 和 Kaggle 运行标识，再核显存、时间、恢复和两卡独立性。

Kaggle 已回传实机结果。以 Kaggle_Pilot_20261111/CONTROLLER_KAGGLE_RUN_ACCEPTANCE_20261111.json 为准。两张卡各跑独立任务与同会话跨进程恢复已验证，合成步时不能估算正式作业耗时。
