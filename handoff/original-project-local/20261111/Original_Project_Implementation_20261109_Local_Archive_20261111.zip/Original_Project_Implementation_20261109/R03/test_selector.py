import copy,json,unittest
from pathlib import Path
from selector import select


def fixture():
    config=json.loads((Path(__file__).parent/'selection_config.json').read_text())
    config['locked_config_ids']=['candidate']
    rows=[dict(config_id='candidate',target=t,source_id='source-'+t,assay_id='assay',role='DEVELOPMENT',
        support_sha256='a'*64,H20=4.,Spearman=.4,Original_H20=3.,Original_Spearman=.4,
        B=594,bank_rule='small594',lr=.0001,steps=500,architecture='S',seed=11) for t in config['development_targets']]
    config.update(stage_locked=True,budget_locked=True)
    config['locked_routes']=[dict(target=r['target'],source_id=r['source_id'],assay_id=r['assay_id'],support_sha256=r['support_sha256'],admitted=True,bank_counts={'small594':594,'full_train':n}) for r,n in zip(rows,[948,6496,10619])]
    config['locked_configs']={'candidate':{k:rows[0][k] for k in ('architecture','bank_rule','lr','steps','seed')}}
    return config,rows


class Checks(unittest.TestCase):
    def test_positive_and_alias_dedup(self):
        cfg,rows=fixture();r=select(rows+[dict(rows[0])],cfg)
        self.assertEqual(r['selected'],'candidate');self.assertEqual(r['summaries'][0]['mean_delta_H20'],1.)
        self.assertFalse(r['final_validation_completed'])
    def test_rho_damage_no_promotion(self):
        cfg,rows=fixture()
        for r in rows:r['Spearman']=.35
        self.assertEqual(select(rows,cfg)['status'],'RETAIN_ORIGINAL_NO_PROMOTION')
    def test_final_or_missing_target_rejected(self):
        cfg,rows=fixture();rows[0]['role']='FINAL'
        with self.assertRaises(ValueError):select(rows,cfg)
        cfg,rows=fixture()
        with self.assertRaises(ValueError):select(rows[:-1],cfg)
    def test_na_and_support_changes_rejected(self):
        cfg,rows=fixture();rows[0]['Spearman']=None
        with self.assertRaises(ValueError):select(rows,cfg)
        cfg,rows=fixture();cfg['locked_config_ids']=['candidate','second']
        more=[dict(r,config_id='second') for r in rows];more[0]['support_sha256']='b'*64
        with self.assertRaises(ValueError):select(rows+more,cfg)
    def test_endpoint_counts_do_not_reweight_target(self):
        cfg,rows=fixture();rows[0]['H20']=6.;rows[1]['H20']=3.;rows[2]['H20']=3.
        extras=[dict(rows[0],assay_id='assay'+str(i)) for i in range(8)]
        cfg['locked_routes'] += [dict(cfg['locked_routes'][0],assay_id=r['assay_id']) for r in extras]
        self.assertEqual(select(rows+extras,cfg)['summaries'][0]['mean_delta_H20'],1.)
    def test_missing_candidate_and_wrong_seed_rejected(self):
        cfg,rows=fixture();cfg['locked_config_ids'].append('missing')
        with self.assertRaises(ValueError):select(rows,cfg)
        cfg,rows=fixture();rows[0]['seed']=47
        with self.assertRaises(ValueError):select(rows,cfg)
    def test_tie_shorter_recipe_deterministic(self):
        cfg,rows=fixture();cfg['locked_config_ids']=['candidate','longer']
        cfg['locked_configs']['longer']=dict(cfg['locked_configs']['candidate'],steps=1000)
        more=[dict(r,config_id='longer',steps=1000) for r in rows]
        self.assertEqual(select(more+rows,cfg)['selected'],'candidate')
    def test_single_target_peak_not_sufficient(self):
        cfg,rows=fixture();rows[0]['H20']=12.;rows[1]['H20']=2.;rows[2]['H20']=2.
        self.assertIsNone(select(rows,cfg)['selected'])


class ExternalLockChecks(unittest.TestCase):
    def test_full_bank_different_B_across_targets_pass(self):
        cfg,rows=fixture()
        cfg['locked_configs']['candidate']['bank_rule']='full_train'
        for r,n in zip(rows,[948,6496,10619]):r.update(bank_rule='full_train',B=n)
        self.assertEqual(select(rows,cfg)['selected'],'candidate')
    def test_all_configs_omit_same_assay_rejected(self):
        cfg,rows=fixture()
        cfg['locked_routes'].append(dict(cfg['locked_routes'][0],assay_id='second_assay'))
        with self.assertRaises(ValueError):select(rows,cfg)
    def test_source_replacement_rejected(self):
        cfg,rows=fixture();rows[0]['source_id']='different-source'
        with self.assertRaises(ValueError):select(rows,cfg)
    def test_same_config_different_semantics_rejected(self):
        cfg,rows=fixture();rows[1]['lr']=.00003
        with self.assertRaises(ValueError):select(rows,cfg)
    def test_wrong_route_B_rejected(self):
        cfg,rows=fixture();rows[1]['B']=6496
        with self.assertRaises(ValueError):select(rows,cfg)
    def test_budget_or_stage_unlocked_rejected(self):
        for field in ('budget_locked','stage_locked'):
            cfg,rows=fixture();cfg[field]=False
            with self.assertRaises(ValueError):select(rows,cfg)

if __name__=='__main__':unittest.main(verbosity=2)
