from copy import deepcopy
from pathlib import Path
import json
import tempfile
import unittest

from phase1 import admission_gate, raw


class RebindTest(unittest.TestCase):
    def setUp(self):
        d = tempfile.TemporaryDirectory()
        self.addCleanup(d.cleanup)
        self.root = Path(d.name)
        index = dict(source_id='source', bank_rule='full_train', count=2,
                     bank_indices=[1, 3], heldout_positions=[4], wt_sha256='a'*64, length=4)
        index_ref = self.save('index.json', index)
        schedule = self.save('pairs.json', {'synthetic_pairs': [[1, 3]]})
        admission = dict(source_id='source', role='SOURCE_TRAIN_ONLY', target_development_use='target',
                         bank_rule='full_train', count=2, seed=11, steps=2000,
                         pairs_each_class_per_step=128, same_bank_and_stream_for_S_and_LoRA=True,
                         bank={'path': 'F:/old/bank.tsv', 'sha256': 'b'*64},
                         index=dict(index_ref, path='F:/old/index.json'),
                         pairs=dict(schedule, path='F:/old/pairs.json'))
        self.original = self.save('original.json', admission)
        self.deployed = deepcopy(admission)
        for key in ('bank', 'index', 'pairs'):
            self.deployed[key]['path'] = '/source/locked/' + Path(admission[key]['path']).name
        self.spec = dict(original_admission=self.original, schedule=schedule, bank_index=index_ref,
                         admission_lineage=dict(original_admission_sha256=self.original['sha256'],
                            original_admission_local='F:/old/original.json',
                            index=self.deployed['index'], schedule=self.deployed['pairs'], training_id='tid'))
        self.plan = dict(source_admission_sha256=self.original['sha256'],
                         pair_stream_sha256=schedule['sha256'], target='target', source_id='source',
                         bank_rule='full_train', bank_count=2, seed=11, steps=2000)
        self.config = {'source': {k: index[k] for k in ('bank_indices','heldout_positions','wt_sha256','length')}}
        self.config['source']['id'] = 'source'
        self.job = {'cases': [{'schedule': self.deployed['pairs']}]}
        self.bind_deployed()

    def save(self, name, obj):
        p = self.root/name
        p.write_text(json.dumps(obj), encoding='utf-8')
        return dict(path=name, sha256=raw.sha(p))

    def bind_deployed(self):
        ref = self.save('deployed.json', self.deployed)
        runtime = dict(ref, path='/source/locked/deployed.json')
        self.spec['admission'] = ref
        self.spec['admission_lineage']['deployed_admission'] = runtime
        self.job['cases'][0]['admission'] = dict(runtime)
        self.config['source']['bank_sha256'] = ref['sha256']

    def gate(self):
        admission_gate(self.root, self.spec, self.plan, self.job, self.config, 'tid', {'c'*64})

    def test_path_only_rebind(self):
        self.assertNotEqual(self.original['sha256'], self.spec['admission']['sha256'])
        self.gate()

    def test_non_path_change_even_if_job_and_config_resealed(self):
        self.deployed['bank']['sha256'] = 'd'*64
        self.bind_deployed()
        with self.assertRaisesRegex(ValueError, 'rebound admission leaf'):
            self.gate()

    def test_full_pair_bytes(self):
        self.save('pairs.json', {'synthetic_pairs': [[3, 1]]})
        with self.assertRaisesRegex(ValueError, 'sealed bytes changed'):
            self.gate()

    def test_wrong_execution_or_split(self):
        with self.subTest('job admission path'):
            self.job['cases'][0]['admission']['path'] = '/source/other/deployed.json'
            with self.assertRaisesRegex(ValueError, 'actual deployed admission identity'):
                self.gate()
        self.bind_deployed()
        with self.subTest('config split'):
            self.config['source']['heldout_positions'] = [2]
            with self.assertRaisesRegex(ValueError, 'exact admitted bank/split'):
                self.gate()

    def test_missing_original(self):
        (self.root/'original.json').unlink()
        with self.assertRaisesRegex(ValueError, 'sealed artifact escape/missing'):
            self.gate()
