# R03 阶段一独立评价消费者

本独立版本接入 R05 的 SOURCE admission 路径重绑；旧 `R03/phase1` 保留。接线来源是 `R05/phase1/build_phase1.py` 输出的 `PHASE1_JOB_CANDIDATES_V1`。候选文件本身并非执行或标签放行回执。

阶段一使用已锁的三个开发目标、12 条单源训练轨迹、每条轨迹 500／1000／2000 步及三个原版，共 39 份完整预测。配置和路线来自本目录保存的根预锁文件。生产验收依赖真实 GPU 作业产物，CPU 六格资格只作为已有资格证据。

旧正式评价的 H20、Spearman、同位点指标、目标表解析和独立 RAW 重建代码逐字节复用。CPU 运行库检查函数原样抽出。生产接线差异见 `PRODUCTION_WIRING.diff`，实际来源与哈希见 `REUSE_PROVENANCE.json`。模型预测沿原始完整 19L 重建，容差为 atol 2e-5、rtol 2e-4。每个目标所有方法共用固定全测量池，解析后核对清单中的原 canonical 支持摘要。TnpB 另核原有序摘要，AsCas12f 沿既有精确表后记有序摘要规则。

## 待根和产物所有者绑定

| 接口 | 需要的真实绑定 |
|---|---|
| Joint seal | `R03_PHASE1_JOINT_SEAL_V1 / SEALED_ALL_39_UNLABELLED`。包含 `admission`、`ledger`、`tracks`、`targets`、`predictions` 和固定 `target_tables`。文件引用使用 bundle 内相对路径和 SHA256。 |
| 阶段放行与预算 | `PHASE1_BUDGET_AND_EXECUTION_LOCKED` 精确绑定两份预锁、各目标 core／缓存及禁止来源 ID（含已知同母本及共享文库）。它引用 `PHASE1_BUDGET_LOCKED` 和具体 GPU 秒上限。账本投影为根核验的 `PHASE1_TERMINAL_LEDGER_ACCEPTED`，绑定预算 SHA、累计 GPU 秒、48 个成功 train/predict JOB SHA。完整实际调度账本仍由总控保存。 |
| 12 条轨迹 | 用 R05 `tracks_for_r03[track_id]` 的既有字段，把文件引用投影为 bundle 内相对路径；`admission` 指部署件。另附 `original_admission`（原 R01 文件原始字节的 bundle 引用）及原样嵌入 `admission_lineage[track_id]`。lineage 和执行 JOB 内的路径保持原始绝对路径，仅外层 bundle 文件引用相对化。当前仍要求单份完整从零训练回执；若未来续跑，另接实际分段证据。 |
| 39 份预测 | `target::config_id` 或 `target::Original`。每份含 `record/raw/csv`，适配预测另有实际 R05 execution。Original 引用旧已验 `original_acceptance` 的精确字节。各目标含 `core/natural/bundle_sha256`。 |
| CPU 和评价放行 | 确定 CPU 实际运行库路径、SHA、线程和部署后的模块清单。先跑 `preflight` 并持久化真实 PRE_LABEL。由根签 `R03_PHASE1_EVALUATION_RELEASE_V1`，绑定精确 seal／manifest／runtime／PRE_LABEL 文件 SHA 和三个只读表，两个额外访问标志 `source_heldout_access`、`final_target_access` 均为 false。再由独立 `evaluate` 重跑 gate、比对前次回执并解析标签。 |

命令行使用 `python -B phase1.py preflight --help` 查看参数。正式运行的预算、seal、运行库和评价 release 尚待绑定。阶段一选择使用现有 selector 的指标护栏输出诊断，并按根的六组匹配比较判定 small594 是否全面占优。输出不晋级任何架构或 checkpoint。

原始 admission SHA 必须与预锁一致；两份文件独立核字节 SHA，且内容差异只允许三条 `bank.path/index.path/pairs.path`。执行 JOB 的 admission、pair 引用（含路径）绑定 R05 lineage，训练配置绑定部署件 SHA，原始 pair 流和源索引按完整字节核对，拆分元数据逐项匹配。源 bank 数值表无需复制到评价包；其内容摘要在原始及部署件中保持一致，并排除三个保护表的 SHA。

本地验证使用 `python -B -m unittest -v test_rebind`，只构造虚拟元数据及 pair 文件。旧四项清单/放行测试沿用既有记录，本轮未重跑。真实新预测、真实 RAW 重建、实际服务器运行库及正式功能评价均待验收。
