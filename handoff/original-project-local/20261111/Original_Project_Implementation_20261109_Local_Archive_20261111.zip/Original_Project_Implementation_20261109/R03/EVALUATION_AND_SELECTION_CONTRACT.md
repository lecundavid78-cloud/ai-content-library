# 原项目单来源：独立评价与开发选择合同提案

2026-11-09；新总控01a1c09c-f9e6-70f1-b9e8-b988b89c755f。当前仅本地准备，无训练、SSH/sbatch、新标签读取、历史正式评价重跑。本提案不继承旧两来源/random/三seed训练图，也不移植MiniLM。

## 有限开发选择

每模型单一来源，复用ESM2既有排名，不新增随机臂。严格消费根EXPERIMENT_SPEC的条件阶段：bank_rule=small594/full_train，full_train实际B按路线为948/6496/10619；lr=1e-4/3e-5、完成更新500/1000/2000、S/L、seed11。不由选择器创造全因子或额外256/250候选；沿根12条数据长度及条件6条lr轨迹上限，资源仍待锁。

全局配置身份为architecture/bank_rule/lr/steps/seed，不含路线实际B。外部locked_routes必须预列完整target/source_id/assay_id/support_sha256/admitted和bank_counts；B逐route核对，full_train不要求跨目标相等。locked_config_ids及locked_configs明确每阶段完整配置；stage_locked/budget_locked任一未锁即停止。共同漏assay、替换source或同ID语义变更一律拒绝，不能从rows并集推断完整性。
整位点source train/heldout分离，heldout不补训练、不选步；500/1000/2000为根规定里程碑，若同run取前缀必须独立封存精确checkpoint/日程身份并由R05确认一致，不假装后半程更新是额外独立重复。固定只功能pair训练、原底座/VRH沿R05合同。一次正式训练采用单个事前固定初始化，不以开发多个seed择最优。来源bank、support、pair、loss、lr、completed updates、初始化、代码全部进身份；attempt与completed分账。

开发最终选一个全局配方，不为各目标分别挑赢家、不学融合。完整候选ID清单必须预锁，任何缺项不能删“输家”后选；原始结果有技术失败时先按预锁终态规则处理，不记功能阴性，当前selector遇NA/缺项硬拒绝。

## 指标与建议选择门槛（需总控锁）

H20沿已验真实定义：同一原全合法实测assay内linear q90，y≥阈值含标签并列；预测前20边界并列取期望命中，P20=H20/20。各方法同母本、同终点、完整实测支持和顺序；不缩交集、不删非有限、不补零。N<20为NA；全局恒定预测rho为NA，H20仍报告并列期望且标非区分。within/between原资格和NA规则逐字节复用已验metrics_reference.py（含合格within位点上恒定预测rho=0），不能把within0替代global NA。预测全19L/RAW先封存，独立数值/实际代码/runtime和身份门通过后才读许可评价标签。

建议相对同身份Original：目标等权平均ΔH20≥1个（即ΔP20≥0.05），平均Δrho≥−0.01；任一目标ΔH20不得低于−2、Δrho不得低于−0.05，且至少2/3目标H20真正改善。全部是务实开发筛选护栏，不是显著性、非劣性检验或原架构GO定理。旧真实指标H20 Original约3/20，故“多1命中”比NDCG .02可解释；旧rho约0.19–0.45，Top20增加但rho下降0.04–0.06确曾发生，故另设rho护栏，不能用H20抵销排序伤害。−0.01并非已标定的生物意义或噪声界，只是保守提案，需总控在新结果前锁定。阈值参考旧开发尺度，不能再用旧三目标验证它是独立阈值。

过护栏者按平均ΔH20降序，再平均Δrho，再较短更新/较小bank规则（small594优先full_train）/预锁config_id排序；没有合格者保留Original，不强选一个“最不差”适配。Top20与rho完整分报，各候选结果保留；一个有限面板筛出配方不证明普适性。selector只是纯内存开发选择器，不是标签读取权限门，也不声称运行等于正式GO。

## 统计单位与隔离

同source-target端点内的多assay先平均，独立来源路线在每目标内平均，最后目标等权；真实同母本/共享库依赖先分组。相同模型/assay别名仅计一次，不能把更多assay当更多独立蛋白。不同终点不混绝对功能值；若不同assay可共同纳入某目标宏平均，必须先由总控锁端点角色及分组，不能由评价器自动生物准入。source_id是已分组独立来源单位，不能直接拿任意assay名冒充独立来源。

TnpB/AsCas12f/SpCas9旧三目标全属已曝光开发，当前不得改称盲测。最终检验目标/来源依赖组尚未指定，final_targets=[]是实际缺口，不可据此宣布独立确认；若暂无独立面板，只能交开发结论并停止。最终组不能以既有模型效果挑选，需预先准入及与训练/开发依赖隔离。目标可否作为其他路线SOURCE按当前总控角色锁，预测该目标的训练绝不含其标签/共享目标库；selector单纯source_id!=target检查不替代哈希/家族隔离审核。

开发选择先于最终值释放；最终使用已选单一recipe和事前final seed，完整预测封存后独立评价，不用最终值改来源、lr、B、步数、实现或停止，不再挑seed重训。最终失败如实报告，不回头择新配方在同一final上自称确认。

## 当前可执行证据

selection_config.json为待锁提案；selector.py只接已验指标和元数据，不打开文件、不导入模型；test_selector.py仅构造指标。metrics_reference.py与上一轮正式生产副本字节一致；本次只运行修订选择器14个必要合成正反例，不重跑历史指标或新标签。STATUS.json与FILE_HASHES.json记录实际结果及父字节来源。待锁：来源资格/固定路线与分组、完整候选清单及资源、阈值、开发支持hash与精确放行、独立final面板/seed与角色。

