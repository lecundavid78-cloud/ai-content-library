"""Fixed three-table dispatch. Pure bytes only; disk access remains runner release gate."""
import csv
import hashlib
import io
import json
from vendor_q import consumer as c
import normalized_q_parser
import spencer_parser

AA='ACDEFGHIKLMNPQRSTVWY'
FIXED={
 'TnpB':dict(sha256='08fe18b5c6fb5f19c277de81b1652708fbcb622106df77d3b9f4f8f6e5aa667f',bytes=592753,
    expected_count=7227,expected_sites=406,WT_sha256='664a76d6a9477d502e8c1314fd7611b592af1468e8864e3e40678d58690d98b6',
    assay_id='ASSAY_TNPB_PROTEIN_DMS',protein_column_value='TnpB',format='NORMALIZED_TSV8',
    support_order_digest='613ecf07395260e01dab160372e576deee5d54fc3c401afd43a7dc02ec711182',
    support_digest_policy='PREEXISTING_SAME_TABLE_ORDER_DIGEST_V1',canonical_support_sha256=None),
 'AsCas12f':dict(sha256='13483cc3f4ee0dcb878c51ae49dce6793809721449b7e39220f203abc6383f0e',bytes=734238,
    expected_count=7941,expected_sites=421,WT_sha256='0ab5028a39a90077b55a9041eeed82a289f00b01957b2c6f0c0a139fe0ce7ea1',
    assay_id='ASSAY_ASCAS12F_GFP_DMS',protein_column_value='AsCas12f',format='NORMALIZED_TSV8',
    support_order_digest=None,support_digest_policy='POST_RELEASE_EXACT_TABLE_ORDER_DIGEST_V1',canonical_support_sha256=None),
 'SpCas9':dict(sha256='e7ecd32e91a43fba00f4dc3524a85907161b27d8d0e22434ea13ec015dcd500a',bytes=11338062,
    expected_count=8117,expected_sites=None,WT_sha256='0b7df5a184af9a6086e68775743c9f88f90fc81cf58931719cfa4b8e48d3f6ef',
    assay_id='CAS9_STRP1_Spencer_2017_positive',protein_column_value=None,format='SPENCER_PG_CSV',
    support_order_digest=None,support_digest_policy='OLD_CANONICAL_AND_POST_RELEASE_ORDER_DIGEST_V1',
    canonical_support_sha256='c569a0fc62cf426438e60ed51e9bb2b116a56a1f6c229f35ece72c9148941400')}
HEADER=['mutant','mutated_sequence','DMS_score','DMS_score_bin']


def support_hash(variants):
    # Exact production_new_targets_v2/target_labels.py encoding, not lexicographic sort.
    keys=sorted(variants,key=lambda v:(int(v[1:-1]),AA.index(v[-1])))
    return hashlib.sha256(json.dumps(keys,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()


def validate_specs(specs):
    c.need(set(specs)==set(FIXED),'exact three fixed target tables')
    for target,spec in specs.items():
        c.need(spec['target_id']==target,'target spec identity')
        for field,value in FIXED[target].items():c.need(spec.get(field)==value,'fixed label spec changed: '+target+'/'+field)
        c.need(spec['role']=='TARGET_EVALUATION' and spec['direction']=='higher'
               and spec['score_transform']=='identity','exact target role/score direction')
    return True


def parse_target(raw,sequence,spec):
    target=spec['target_id'];fixed=FIXED[target]
    validate_specs({t:(spec if t==target else dict(v,target_id=t,role='TARGET_EVALUATION',direction='higher',score_transform='identity')) for t,v in FIXED.items()})
    c.need(hashlib.sha256(sequence.encode()).hexdigest()==fixed['WT_sha256'],'fixed full target reference')
    c.need(len(raw)==fixed['bytes'] and hashlib.sha256(raw).hexdigest()==fixed['sha256'],'exact locked full table bytes')
    if fixed['format']=='NORMALIZED_TSV8':
        order,labels=normalized_q_parser.parse_target(raw,sequence,spec)
    else:
        header=next(csv.reader(io.StringIO(raw.decode('utf-8-sig'))))
        c.need(header==HEADER,'exact old Spencer CSV header')
        labels=spencer_parser.parse_spencer_csv(raw,sequence,fixed['expected_count'])
        order=list(labels)
        c.need(support_hash(order)==fixed['canonical_support_sha256'],'old canonical measured support changed')
    c.need(len(labels)==len(order)==len(set(order))==fixed['expected_count'],'complete unique measured pool')
    if fixed['expected_sites'] is not None:
        c.need(len({int(v[1:-1]) for v in order})==fixed['expected_sites'],'full measured site count')
    return order,labels


def support_receipt(sequence,order,spec):
    return dict(target_id=spec['target_id'],assay_id=spec['assay_id'],N=len(order),
        measured_sites=len({int(v[1:-1]) for v in order}),WT_sha256=hashlib.sha256(sequence.encode()).hexdigest(),
        table_sha256=spec['sha256'],support_digest_policy=spec['support_digest_policy'],
        ordered_support_digest=c.digest(order),ordered_digest_encoding='Q.digest(JSON compact ordered canonical mutation list)',
        canonical_support_sha256=support_hash(order),
        canonical_encoding='old Sp R03 sort(position1, AA20 alternate index), compact JSON ensure_ascii=True',
        parsed_only_after_PRE_LABEL_and_exact_root_release=True,all_models_same_complete_support=True)
