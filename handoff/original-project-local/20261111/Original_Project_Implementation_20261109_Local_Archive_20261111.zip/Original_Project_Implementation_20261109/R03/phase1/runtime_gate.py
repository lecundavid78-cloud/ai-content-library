import inspect, os, platform, sys
from pathlib import Path
import numpy as np
import scipy
import metrics_reference as metrics
import matrix_consumer as m
from vendor_q import consumer as q

THREAD_KEYS=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS')

def runtime_identity():
    libs={'numpy':Path(np.__file__),'scipy':Path(scipy.__file__),
          'scipy_rankdata':Path(inspect.getfile(metrics.rankdata))}
    return dict(python_version=platform.python_version(),python_executable=str(Path(sys.executable).resolve()),
        numpy_version=np.__version__,scipy_version=scipy.__version__,
        libraries={n:dict(path=str(p.resolve()),sha256=q.sha(p)) for n,p in libs.items()},
        threads={k:os.environ.get(k) for k in THREAD_KEYS},pythonhashseed=os.environ.get('PYTHONHASHSEED'))

def runtime_gate(contract):
    m.need(contract['status']=='CONTROLLER_LOCKED_CPU_RUNTIME','runtime not locked')
    actual=runtime_identity()
    m.need(all(v in ('1','2') for v in actual['threads'].values()),'bounded CPU threads')
    m.need(actual==contract['identity'],'actual numerical runtime differs')
    return actual
