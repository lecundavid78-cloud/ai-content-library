"""No-label matrix adapter. Pure metrics; no label opener, model, or scheduler.

Normalized metadata schema is provisional until actual R01/R05 bindings arrive.
Q raw replay and metrics are byte-identical vendored modules, not new formulae.
"""
import hashlib
import json
from pathlib import Path
import numpy as np
from vendor_q import consumer as q
import metrics_reference as metrics

TARGETS = ('TnpB', 'AsCas12f', 'SpCas9')
RETRIEVERS = ('ESM2', 'VESM', 'ProSST')
SEEDS = (11, 23, 47)
ARCH = ('S', 'L')
METRICS = ('H20', 'P20', 'Spearman')


def need(ok, message):
    if not ok:
        raise ValueError(message)


def verify_imported_code(manifest_path, expected_sha):
    """Verify actual loaded files, not only a directory copy."""
    raw = Path(manifest_path).read_bytes()
    need(hashlib.sha256(raw).hexdigest() == expected_sha, 'manifest bytes')
    manifest = json.loads(raw)
    from vendor_q import artifacts, independent_vrh
    import sys
    loaded = {m.__name__: Path(m.__file__).resolve() for m in
              (sys.modules[__name__], q, artifacts, independent_vrh, metrics)}
    need(set(manifest['modules']) == set(loaded), 'loaded module set')
    for name, path in loaded.items():
        need(q.sha(path) == manifest['modules'][name]['sha256'], 'imported bytes: '+name)
    return {name: str(path) for name, path in loaded.items()}


def validate_graph(graph):
    """Mechanical metadata only; this does NOT accept a seal or release labels."""
    need(graph['schema'] == 'R03_THREE_TARGET_NORMALIZED_GRAPH_V1', 'graph schema')
    need(set(graph['targets']) == set(TARGETS), 'exact targets')
    models = graph['models']
    slots = graph['slots']
    expected = {(t, seed, p, name, arch) for t in TARGETS for seed in SEEDS
                for p, names in [('retrieved', RETRIEVERS), ('random', ('1', '2', '3'))]
                for name in names for arch in ARCH}
    keys = [(s['target'], s['seed'], s['policy'], s['name'], s['architecture']) for s in slots]
    need(len(keys) == 108 and set(keys) == expected, '108 exact unique references')
    need(set(graph['originals']) == set(TARGETS), 'one Original per target')
    need(len({s['model_id'] for s in slots}) <= 84, 'v2 upper bound 84 models')
    need(set(models) == {s['model_id'] for s in slots}, 'unreferenced/missing models')
    signatures = {}
    slot_map = dict(zip(keys, slots))
    for mid, m in models.items():
        need(m['architecture'] in ARCH and m['seed'] in SEEDS, 'model identity')
        need(len(m['source_groups']) == len(set(m['source_groups'])) == 2, 'independent source groups')
        need(len(m['source_reference_sha256s']) == 2, 'two source references')
        need(m['steps'] == 500 and m['source_steps'] == [250, 250], 'fixed updates')
        need(m['objective'] == 'phaseA-pair-v2-nonempty' and m['natural_updates'] == 0, 'pair-only')
        need(m['within_pairs'] == m['cross_pairs'] == 128, 'fixed pair counts')
        need(m['B'] == graph['B'] > 0 and graph['B'] <= 2048, 'global common B')
        need(m['heldout_used_for_selection'] is False, 'heldout selection forbidden')
        need(len(m['training_identity_sha256']) == 64, 'training identity')
        sig = m['training_identity_sha256']
        need(sig not in signatures, 'identical training identity must share model ID')
        signatures[sig] = mid
    for s in slots:
        t = graph['targets'][s['target']]
        m = models[s['model_id']]
        need(m['seed'] == s['seed'] and m['architecture'] == s['architecture'], 'slot/model mismatch')
        need(not set(m['source_groups']) & set(t['forbidden_source_groups']), 'target library leakage')
        need(t['reference_sha256'] not in m['source_reference_sha256s'], 'target exact WT leakage')
        peer_arch = 'L' if s['architecture'] == 'S' else 'S'
        peer = models[slot_map[(s['target'], s['seed'], s['policy'], s['name'], peer_arch)]['model_id']]
        for field in ('source_groups', 'source_support_sha256', 'pair_schedule_sha256', 'B'):
            need(m[field] == peer[field], 'architecture pairing: '+field)
    for arch in ARCH:
        for seed in SEEDS:
            initial = {m['initial_state_sha256'] for m in models.values()
                       if m['architecture'] == arch and m['seed'] == seed}
            need(len(initial) == 1, 'same-architecture same-seed initial state')
    for name in ('1', '2', '3'):
        for seed in SEEDS:
            for arch in ARCH:
                ids = [slot_map[(t, seed, 'random', name, arch)]['model_id'] for t in ('TnpB', 'AsCas12f')]
                need(ids[0] == ids[1], 'shared TnpB/As random pair model')
    for t in TARGETS:
        for policy, names in [('retrieved', RETRIEVERS), ('random', ('1', '2', '3'))]:
            pairs = []
            for name in names:
                sources = {tuple(models[slot_map[(t, seed, policy, name, 'S')]['model_id']]['source_groups'])
                           for seed in SEEDS}
                need(len(sources) == 1, 'fixed source pair across initialization seeds')
                pairs.append(next(iter(sources)))
            if policy == 'random':
                need(len({frozenset(pair) for pair in pairs}) == 3, 'three distinct random source pairs')
    return {'status': 'METADATA_ONLY_PASS_NOT_PRELABEL', 'references': 111,
            'unique_trainings': len(models), 'actual_label_access_authorized': False}


def evaluate_one(sequence, measured_order, labels, predictions):
    """In-memory only; deployment may call only after exact release and real replay."""
    full = q.canonical(sequence)
    need(len(measured_order) >= 2 and len(set(measured_order)) == len(measured_order), 'measured support')
    need(set(labels) == set(measured_order) and set(measured_order) <= set(full), 'full legal support')
    y = np.asarray([labels[v] for v in measured_order], dtype=np.float64)
    need(np.isfinite(y).all(), 'nonfinite label: no row dropping')
    threshold = float(np.quantile(y, .9, method='linear'))
    positive_n = int((y >= threshold).sum())
    positions = np.asarray([int(v[1:-1]) for v in measured_order])
    scores, rows = {}, []
    for mid, p in predictions.items():
        need(set(p) == set(full), 'complete 19L required')
        need(all(np.isfinite(float(v)) for v in p.values()), 'nonfinite full 19L')
        s = np.asarray([p[v] for v in measured_order], dtype=np.float64)
        scores[mid] = s
        rho = metrics.spearman_average(y, s)
        row = dict(model_id=mid, N=len(y), M=positive_n, coverage=1., threshold_q90_linear=threshold,
                   Spearman=float(rho) if np.isfinite(rho) else None,
                   Spearman_status='OK' if np.isfinite(rho) else 'CONSTANT_TRUTH_OR_PREDICTION',
                   H20=None, P20=None, H20_status='NOT_DEFINED_N_LT20')
        if len(y) >= 20:
            result = metrics.top20(y, s, positive_threshold=threshold)
            row.update(H20=result['H20_expected'], P20=result['P20'],
                       H20_status='OK' if len(y) > 20 and 0 < positive_n < len(y)
                       else 'NOT_DISCRIMINATING_POOL_OR_HIGH_GROUP',
                       boundary_tie_n=result['boundary_tie_n'], boundary_slots=result['boundary_slots'],
                       random_H20=20*positive_n/len(y), H20_ceiling=min(20, positive_n))
        rows.append(row)
    sites, summaries = metrics.site_diagnostics(y, positions, scores)
    return dict(methods=rows, site_rows=sites, site_summary=summaries)


def fourcell_differences(cells, original):
    """One retriever, target and seed; C contains exactly three metric rows/arch.

    Means require all three valid values; no drop-NA or mean prediction ensemble.
    """
    need(set(cells) == {'A1', 'A2', 'A3', 'A4'}, 'four cell set')
    need(len(cells['A1']) == len(cells['A2']) == 3, 'three random draws')
    output = []
    def mean(rows, key):
        vals = [r[key] for r in rows]
        return None if any(v is None for v in vals) else float(np.mean(vals))
    for draw in (0, 1, 2, None):
        r = {a: ({k: mean(cells[a], k) for k in METRICS} if draw is None else cells[a][draw])
             for a in ('A1', 'A2')}
        r.update(A3=cells['A3'], A4=cells['A4'], Original=original)
        pairs = [('A3', 'A1'), ('A4', 'A2'), ('A2', 'A1'), ('A4', 'A3')]
        pairs += [(a, 'Original') for a in ('A1', 'A2', 'A3', 'A4')]
        for left, right in pairs:
            row = dict(draw='MEAN_3_METRICS' if draw is None else str(draw+1), contrast=left+'-'+right)
            for key in METRICS:
                x, y = r[left][key], r[right][key]
                row[key] = None if x is None or y is None else x-y
            output.append(row)
        interaction = dict(draw='MEAN_3_METRICS' if draw is None else str(draw+1), contrast='(A4-A2)-(A3-A1)')
        for key in METRICS:
            vals = [r[a][key] for a in ('A4', 'A2', 'A3', 'A1')]
            interaction[key] = None if any(v is None for v in vals) else vals[0]-vals[1]-vals[2]+vals[3]
        output.append(interaction)
    return output
