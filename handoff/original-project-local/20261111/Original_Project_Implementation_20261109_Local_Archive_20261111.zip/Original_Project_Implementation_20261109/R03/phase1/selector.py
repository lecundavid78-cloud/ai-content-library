"""Pure in-memory development selector; no disk labels/model/network imports."""
import math


def require(ok,message):
    if not ok:raise ValueError(message)


def average(rows,key):return sum(r[key] for r in rows)/len(rows)


def select(rows,config):
    """Rows already metric outputs, one per config/target/source/assay.

    No final data accepted; required supports must be the same across all configs.
    Not a substitute for production seal/release or evaluator numerical gates.
    """
    require(rows,'empty metric records')
    required={'config_id','target','source_id','assay_id','role','support_sha256',
              'H20','Spearman','Original_H20','Original_Spearman','B','bank_rule','lr','steps','architecture','seed'}
    targets=set(config['development_targets']);grid=config['proposed_search'];groups={};seen={};baselines={}
    require(config.get('stage_locked') is True and config.get('budget_locked') is True,'stage/budget not locked')
    locked=config.get('locked_routes');recipes=config.get('locked_configs');expected=config.get('locked_config_ids')
    require(locked and recipes and expected and len(expected)==len(set(expected)) and set(recipes)==set(expected),'explicit routes/config inventory required')
    routes={}
    for route in locked:
        key=(route['target'],route['source_id'],route['assay_id'])
        require(key not in routes and route['admitted'] is True,'duplicate/unadmitted route')
        require(route['target'] in targets and route['source_id']!=route['target'],'route target/source')
        routes[key]=route
    require({r['target'] for r in locked}==targets,'locked target coverage')
    for r in rows:
        require(required<=set(r),'missing selection fields')
        require(r['role']=='DEVELOPMENT' and r['target'] in targets,'final/unapproved target access')
        require(r['source_id']!=r['target'],'target cannot be own source')
        require(isinstance(r['support_sha256'],str) and len(r['support_sha256'])==64,'measured support identity')
        for k in ('H20','Spearman','Original_H20','Original_Spearman'):
            require(type(r[k]) in (int,float) and math.isfinite(r[k]),'NA/nonfinite is not a valid selection score')
        require(0<=r['H20']<=20 and 0<=r['Original_H20']<=20 and -1<=r['Spearman']<=1 and -1<=r['Original_Spearman']<=1,'metric range')
        require(r['architecture'] in grid['architectures'] and r['bank_rule'] in grid['bank_rules'] and r['lr'] in grid['learning_rates']
                and r['steps'] in grid['completed_updates'] and r['seed']==grid['seed'],'outside frozen proposed search')
        route=(r['target'],r['source_id'],r['assay_id'])
        require(route in routes,'unlocked source/assay route')
        declared=routes[route]
        require(r['support_sha256']==declared['support_sha256'],'external support lock mismatch')
        require(type(r['B']) is int and r['B']==declared['bank_counts'][r['bank_rule']],'actual route B differs from bank rule')
        require(r['config_id'] in recipes,'unlocked config ID')
        semantic={k:r[k] for k in ('architecture','bank_rule','lr','steps','seed')}
        require(semantic==recipes[r['config_id']],'config ID semantic mismatch')
        identity=(r['support_sha256'],r['Original_H20'],r['Original_Spearman'])
        require(route not in baselines or baselines[route]==identity,'support or Original baseline changed')
        baselines[route]=identity
        key=(r['config_id'],route)
        if key in seen:
            require(seen[key]==r,'conflicting duplicate alias')
            continue
        seen[key]=r;groups.setdefault(r['config_id'],[]).append(r)
    support_set=set(routes);summaries=[]
    require(expected is not None and len(expected)==len(set(expected)) and set(groups)==set(expected),'exact prelocked config inventory required; no missing losers')
    for cid,values in groups.items():
        require({(r['target'],r['source_id'],r['assay_id']) for r in values}==support_set,'incomplete config support')
        require({r['target'] for r in values}==targets,'all prelocked development targets required')
        signatures={(r['architecture'],r['bank_rule'],r['lr'],r['steps'],r['seed']) for r in values}
        require(len(signatures)==1,'per-target best configuration is forbidden')
        cells={}
        for r in values:
            cells.setdefault((r['target'],r['source_id']),[]).append(
                dict(H=r['H20']-r['Original_H20'],rho=r['Spearman']-r['Original_Spearman']))
        sources=[dict(target=t,H=average(v,'H'),rho=average(v,'rho')) for (t,s),v in cells.items()]
        per_target=[]
        for target in sorted(targets):
            values_t=[r for r in sources if r['target']==target]
            per_target.append(dict(target=target,H=average(values_t,'H'),rho=average(values_t,'rho')))
        thresholds=config['proposed_decision_thresholds'];tol=thresholds['float_tolerance']
        h=average(per_target,'H');rho=average(per_target,'rho')
        pass_gates=(h+tol>=thresholds['mean_delta_H20_min'] and rho+tol>=thresholds['mean_delta_Spearman_min']
            and min(r['H'] for r in per_target)+tol>=thresholds['worst_target_delta_H20_min']
            and min(r['rho'] for r in per_target)+tol>=thresholds['worst_target_delta_Spearman_min']
            and sum(r['H']>tol for r in per_target)/len(per_target)+tol>=thresholds['target_fraction_H20_improved_min'])
        architecture,bank_rule,lr,steps,seed=next(iter(signatures))
        summaries.append(dict(config_id=cid,mean_delta_H20=h,mean_delta_Spearman=rho,per_target=per_target,
                              eligible=pass_gates,steps=steps,bank_rule=bank_rule,
                              actual_B_by_route=[dict(target=r['target'],source_id=r['source_id'],assay_id=r['assay_id'],B=r['B']) for r in values],architecture=architecture,lr=lr,seed=seed))
    eligible=[r for r in summaries if r['eligible']]
    eligible.sort(key=lambda r:(-r['mean_delta_H20'],-r['mean_delta_Spearman'],r['steps'],grid['bank_rules'].index(r['bank_rule']),r['config_id']))
    return dict(status='DEVELOPMENT_RECIPE_SELECTED_NOT_FINAL_VALIDATION' if eligible else 'RETAIN_ORIGINAL_NO_PROMOTION',
                selected=eligible[0]['config_id'] if eligible else None,summaries=summaries,
                final_validation_completed=False,thresholds_are_controller_unlocked_proposal=config['status'].startswith('PROPOSED'))
