"""Pure in-memory parser. No path, filesystem, model or label-reader entry."""
import csv,io,math,re
from vendor_q.consumer import need
AA='ACDEFGHIKLMNPQRSTVWY'
def parse_spencer_csv(raw,reference,expected_rows=8117):
    reader=csv.DictReader(io.StringIO(raw.decode('utf-8-sig')))
    head=reader.fieldnames
    need(head is not None and len(head)==len(set(head)) and {'mutant','DMS_score'}<=set(head),'SPENCER_HEADER_CHANGED')
    rows=list(reader);need(len(rows)==expected_rows,'SPENCER_FIXED_FULL_MEASUREMENT_POOL_REQUIRED')
    out={}
    for row in rows:
        need(None not in row and None not in row.values(),'SPENCER_ROW_WIDTH_CHANGED')
        variant=row['mutant'];m=re.fullmatch(r'([ACDEFGHIKLMNPQRSTVWY])([1-9][0-9]*)([ACDEFGHIKLMNPQRSTVWY])',variant)
        need(m is not None and variant not in out,'SPENCER_DUPLICATE_OR_NON_SINGLE_VARIANT')
        wt,pos,mut=m.group(1),int(m.group(2)),m.group(3)
        need(1<=pos<=len(reference) and reference[pos-1]==wt and mut!=wt,'SPENCER_WT_OR_NUMBERING_CHANGED')
        score=float(row['DMS_score']);need(math.isfinite(score),'SPENCER_NONFINITE_NO_ROW_DROPPING')
        out[variant]=score
    return out
