"""CPU-only stage-one consumer. No producer imports or functional IO in preflight."""
import argparse
import csv
import json
from pathlib import Path
import sys

import numpy as np
import matrix_consumer as metrics
import runtime_gate
import single_source
import selector
import target_parser
from vendor_q import consumer as raw

ROOT = Path(__file__).resolve().parent
CONTROLLER = '01a1c09c-f9e6-70f1-b9e8-b988b89c755f'
INVENTORY_SHA = 'aba1260d74230d1b53e7894750da92fa515fe35f7be1149758553f86b4244cf9'
POLICY_SHA = '110eecafb98f59f4208f421d3c1832b8de234ab5bb6a26cea64b9620da4b6ece'
TOLERANCE = {'atol': 2e-5, 'rtol': 2e-4}
ORIGINAL_ACCEPTANCE = {
    'TnpB': '4d938c3498a43fb2664ceb4f253aaec18b025cb3f268ed5d4886b3c51d23cd91',
    'AsCas12f': 'f2705ae270690496c16da2680baf5f4163ad2de50e9f7cc532b44ebdd7aa1f81',
    'SpCas9': 'feda3710112ad731493437d4774eb6ee071926944af11db358cf01e6c7b202a4',
}
need = metrics.need


def read(path, digest):
    need(raw.sha(path) == digest, 'locked bytes differ: ' + str(path))
    return json.loads(Path(path).read_bytes())


def document(bundle, spec):
    return json.loads(raw.bound(bundle, spec).read_bytes())


def inventory_gate(inventory, policy, seal):
    tracks = {r['track_id']: r for r in inventory['training_trajectories']}
    routes = {r['target']: r for r in inventory['development_routes']}
    recipes = policy['phase1_configurations']
    nodes = {(r['target'], r['config_id']): r for r in inventory['checkpoint_predictions']}
    expected = {(target, cid) for target in routes for cid in recipes}
    need(len(tracks) == 12 and len(routes) == 3 and len(recipes) == 12
         and len(inventory['checkpoint_predictions']) == 36 and set(nodes) == expected, 'fixed inventory 12/36')
    need(set(seal['tracks']) == set(tracks) and set(seal['targets']) == set(routes), 'missing track/target')
    need(set(seal['predictions']) == {t + '::' + cid for t, cid in expected}
         | {t + '::Original' for t in routes}, 'exact 39 sealed predictions required')
    for target, spec in seal['target_tables'].items():
        route = routes[target]
        need((spec['sha256'], spec['assay_id'], spec['expected_count']) ==
             (route['target_table_sha256'], route['assay_id'], route['measured_count']), 'fixed assay/table')
        need(spec['mount_path'] == '/protected/' + target + '/full_table', 'exact read-only target mount slot')
    target_parser.validate_specs(seal['target_tables'])
    return tracks, routes, recipes, nodes


def chain(bundle, spec, stage):
    job, release, receipt = (document(bundle, spec[name]) for name in ('job', 'release', 'receipt'))
    need(job['schema'] == 'SINGLE_SOURCE_RUNTIME_JOB_V1' and job['stage'] == stage
         and job['device'] == 'cuda' and len(job['cases']) == 1, 'formal R05 job')
    need(release['schema'] == 'SINGLE_SOURCE_RUNTIME_RELEASE_V1' and release['controller'] == CONTROLLER
         and release['status'] == 'RELEASED' and release['stage'] == stage
         and release['job_sha256'] == spec['job']['sha256'] and release['device'] == job['device']
         and release['max_updates_per_case'] == (2000 if stage == 'train' else 0), 'formal R05 release')
    need(receipt['status'] == 'COMPLETE_UNEVALUATED' and receipt['stage'] == stage
         and receipt['job_sha256'] == spec['job']['sha256'] and receipt['release_sha256'] == spec['release']['sha256']
         and receipt['device'] == job['device'] and receipt['actual_native_loads'] == 1, 'real R05 runtime receipt')
    return job


def track_gate(bundle, spec, planned, target_sha, forbidden):
    job = chain(bundle, spec['execution'], 'train')
    case = job['cases'][0]
    config, schedule, receipt, actual = (document(bundle, spec[name])
        for name in ('config', 'schedule', 'train_receipt', 'identity'))
    training_id, identity = single_source.training_identity(config, schedule)
    source = config['source']
    need(source['id'] == planned['source_id'] and source['id'] not in forbidden
         and source['wt_sha256'] != target_sha and len(source['bank_indices']) == planned['bank_count'],
         'source, target and bank isolation')
    for field in ('architecture', 'steps', 'lr', 'seed', 'checkpoints'):
        need(config[field] == planned[field], 'trajectory differs: ' + field)
    need(config['pairs_per_class'] == 128 and config['code_sha256'] == raw.digest(job['runtime_code_sha256'])
         and config['native_sha256'] == job['native_lock']['sha256']
         and config['init_sha256'] == spec['init']['sha256'], 'trajectory code/native/init')
    for field in ('config', 'schedule', 'init'):
        need(case[field]['sha256'] == spec[field]['sha256'], 'executed trajectory file: ' + field)
    need(case['source_id'] == source['id'] and case['bundle']['sha256'] == source['bundle_sha256']
         and case['admission']['sha256'] == planned['source_admission_sha256'], 'executed SOURCE mount')
    admission = document(bundle, spec['admission'])
    need(spec['admission']['sha256'] == planned['source_admission_sha256']
         and admission['role'] == 'SOURCE_TRAIN_ONLY' and admission['source_id'] == source['id']
         and admission['pairs']['sha256'] == planned['pair_stream_sha256'] == case['schedule']['sha256']
         and admission['bank_rule'] == planned['bank_rule'] and admission['count'] == planned['bank_count'],
         'R01 train-only stream')
    index = document(bundle, spec['bank_index'])
    need(spec['bank_index']['sha256'] == admission['index']['sha256']
         and source['bank_sha256'] == spec['admission']['sha256']
         and source['bank_indices'] == index['bank_indices']
         and source['heldout_positions'] == index['heldout_positions']
         and source['wt_sha256'] == index['wt_sha256'], 'exact admitted bank/split, metadata only')
    need(spec['import_lock']['sha256'] == job['import_lock']['sha256']
         and config['runtime_sha256'] == raw.digest(document(bundle, spec['import_lock'])), 'producer runtime lock')
    raw.bound(bundle, spec['init'])
    need(actual == dict(identity, training_id=training_id, resume_file_sha256=None)
         and receipt['schema'] == 'SINGLE_SOURCE_TRAIN_RECEIPT_V1' and receipt['status'] == 'COMPLETE_UNEVALUATED'
         and receipt['training_id'] == training_id and receipt['completed_updates'] == planned['steps']
         and receipt['resume_checkpoint'] is None and receipt['attempts'] >= receipt['completed_updates'],
         'completed trajectory and attempts')
    checkpoints = {row['step']: row for row in receipt['checkpoints']}
    need(len(receipt['checkpoints']) == 3 and set(checkpoints) == set(planned['checkpoints'])
         and set(spec['checkpoints']) == {str(step) for step in checkpoints}, 'all three durable nodes')
    for step, row in checkpoints.items():
        ref = spec['checkpoints'][str(step)]
        need(row['sha256'] == ref['sha256'] and single_source.hash64(row['content_sha256']), 'node checkpoint identity')
        raw.bound(bundle, ref)
    return training_id, config, checkpoints


def preflight(bundle, seal, inventory, policy):
    tracks, routes, recipes, nodes = inventory_gate(inventory, policy, seal)
    cores, natural = {}, {}
    for target, spec in seal['targets'].items():
        core = document(bundle, spec['core'])
        need(core['target_meta']['id'] == target and core['sequence_sha256'] == seal['target_tables'][target]['WT_sha256']
             and core['sequence_sha256'] == core['target_meta']['wt_sha256'], 'target reference')
        with np.load(raw.bound(bundle, spec['natural']), allow_pickle=False) as arrays:
            natural[target] = {name: arrays[name] for name in arrays.files}
        cores[target] = core
    admitted = document(bundle, seal['admission'])
    need(admitted['controller'] == CONTROLLER and admitted['status'] == 'PHASE1_BUDGET_AND_EXECUTION_LOCKED'
         and admitted['inventory_sha256'] == INVENTORY_SHA and admitted['policy_sha256'] == POLICY_SHA
         and admitted['original_acceptance_sha256'] == ORIGINAL_ACCEPTANCE
         and set(admitted['forbidden_source_ids']) == set(routes)
         and set(admitted['targets']) == set(routes), 'exact budget and role lock')
    for target, refs in seal['targets'].items():
        need(admitted['targets'][target] == refs and admitted['forbidden_source_ids'][target],
             'admitted core/cache and nonempty target isolation list')
    budget = document(bundle, admitted['budget'])
    need(budget['inventory_sha256'] == INVENTORY_SHA and budget['controller'] == CONTROLLER
         and budget['status'] == 'PHASE1_BUDGET_LOCKED' and type(budget['max_gpu_seconds']) is int
         and budget['max_gpu_seconds'] > 0, 'exact finite stage budget')
    ledger = document(bundle, seal['ledger'])
    need(ledger['status'] == 'PHASE1_TERMINAL_LEDGER_ACCEPTED'
         and ledger['controller'] == CONTROLLER and ledger['budget_sha256'] == admitted['budget']['sha256']
         and type(ledger['gpu_seconds']) is int and 0 < ledger['gpu_seconds'] <= budget['max_gpu_seconds'],
         'terminal budget accounting')
    executions = [item['execution']['job']['sha256'] for item in seal['tracks'].values()]
    executions += [item['execution']['job']['sha256'] for key,item in seal['predictions'].items()
                   if not key.endswith('::Original')]
    need(len(set(executions)) == 48 and set(executions) == set(ledger['successful_job_sha256']),
         'exact completed train and predict jobs')
    completed = {tid: track_gate(bundle, seal['tracks'][tid], track,
        cores[track['target']]['sequence_sha256'], admitted['forbidden_source_ids'][track['target']])
        for tid, track in tracks.items()}
    scores = {t: {} for t in routes}
    proofs = {}
    for key, spec in seal['predictions'].items():
        target, cid = key.split('::')
        core = cores[target]
        record, proof = raw.load_prediction(bundle, spec, sequence=core['sequence'], members=core['members'],
            natural_arrays=natural[target], msa_spans=core['msa_spans'], vrh_config=core['vrh_config'],
            tolerance=TOLERANCE)
        need(record['protein_id'] == target and record['score_direction'] == 'higher'
             and record['natural_provenance']['natural_input_sha256'] == core['natural_input_sha256'],
             'prediction/core natural identity')
        if cid == 'Original':
            accepted = document(bundle, spec['original_acceptance'])
            need(spec['original_acceptance']['sha256'] == ORIGINAL_ACCEPTANCE[target]
                 and accepted['status'] == 'EXACT_ORIGINAL_EXPORT_ACCEPTED' and accepted['target_id'] == target
                 and accepted['core_metadata_sha256'] == seal['targets'][target]['core']['sha256']
                 and all(accepted[field + '_sha256'] == spec[field]['sha256'] for field in ('record','raw','csv'))
                 and record['active_adaptation'] is False and record['steps_completed'] == 0 and record['seed'] is None,
                 'exact Original export reuse')
        else:
            node = nodes[target, cid]
            tid, config, checkpoints = completed[node['track_id']]
            recipe = recipes[cid]
            step = node['step']
            need(step == recipe['steps'] and all(config[f] == recipe[f] for f in ('architecture','seed','lr'))
                 and tracks[node['track_id']]['bank_rule'] == recipe['bank_rule'], 'milestone/config routing')
            job = chain(bundle, spec['execution'], 'predict')
            case = job['cases'][0]
            train_case = document(bundle, seal['tracks'][node['track_id']]['execution']['job'])['cases'][0]
            need(case['checkpoint']['sha256'] == checkpoints[step]['sha256'] == record['checkpoint_sha256']
                 and case['bundle']['sha256'] == admitted['targets'][target]['bundle_sha256']
                 and job['native_lock']['sha256'] == config['native_sha256']
                 and job['import_lock']['sha256'] == seal['tracks'][node['track_id']]['import_lock']['sha256']
                 and case['source_id'] == config['source']['id']
                 and raw.digest(job['runtime_code_sha256']) == config['code_sha256']
                 and all(case[f]['sha256'] == train_case[f]['sha256'] for f in ('config','schedule','init','admission'))
                 and record['training_id'] == tid and record['steps_completed'] == step
                 and record['active_adaptation'] is True and record['architecture'] == config['architecture']
                 and record['seed'] == config['seed'], 'prediction executed exact saved node')
        with raw.bound(bundle, spec['csv']).open(encoding='utf-8-sig', newline='') as stream:
            scores[target][cid] = {row['variant_id']: float(row['score']) for row in csv.DictReader(stream)}
        proofs[key] = proof
    return cores, scores, proofs


def release_gate(release, pre, persisted):
    need(pre == persisted and pre['status'] == 'PHASE1_PRE_LABEL_ACCEPTED', 'persisted PRE_LABEL differs')
    need(release['schema'] == 'R03_PHASE1_EVALUATION_RELEASE_V1' and release['controller'] == CONTROLLER
         and release['status'] == 'RELEASED' and release['source_heldout_access'] is False
         and release['final_target_access'] is False, 'exact development-only release')
    for field in ('seal_sha256','manifest_sha256','runtime_sha256','target_tables'):
        need(release[field] == pre[field], 'release differs: ' + field)


def evaluate(pre, inventory, policy, cores, scores, output):
    routes = {r['target']: r for r in inventory['development_routes']}
    parsed = {}
    for target, spec in pre['target_tables'].items():
        order, values = target_parser.parse_target(Path(spec['mount_path']).read_bytes(), cores[target]['sequence'], spec)
        proof = target_parser.support_receipt(cores[target]['sequence'], order, spec)
        need(proof['canonical_support_sha256'] == routes[target]['support_sha256'], 'full fixed measured support')
        parsed[target] = (order, values, proof)
    write(output/'LABEL_SUPPORT_RECEIPT.json', {t: item[2] for t,item in parsed.items()})
    recipes = policy['phase1_configurations']
    results, rows = {}, []
    for target, (order, values, _) in parsed.items():
        results[target] = metrics.evaluate_one(cores[target]['sequence'], order, values, scores[target])
        by_model = {row['model_id']: row for row in results[target]['methods']}
        route = routes[target]
        for cid, recipe in recipes.items():
            rows.append(dict(config_id=cid, **{k: route[k] for k in ('target','source_id','assay_id','support_sha256')},
                role='DEVELOPMENT', B=route['bank_counts'][recipe['bank_rule']], **recipe,
                **{k: by_model[cid][k] for k in ('H20','Spearman')},
                **{'Original_'+k: by_model['Original'][k] for k in ('H20','Spearman')}))
    locked = dict(policy, stage_locked=True, budget_locked=True, locked_config_ids=list(recipes),
        locked_configs=recipes, locked_routes=[dict(route, admitted=True) for route in routes.values()])
    selection = selector.select(rows, locked)
    summaries = {r['config_id']: r for r in selection['summaries']}
    pairs = [(a,b) for a in recipes for b in recipes if recipes[a]['bank_rule'] == 'small594'
             and recipes[b]['bank_rule'] == 'full_train'
             and all(recipes[a][k] == recipes[b][k] for k in ('architecture','lr','steps','seed'))]
    need(len(pairs) == 6, 'all six matched bank comparisons required')
    tol = policy['proposed_decision_thresholds']['float_tolerance']
    differences = [summaries[a][key]-summaries[b][key] for a,b in pairs
                   for key in ('mean_delta_H20','mean_delta_Spearman')]
    bank = 'small594' if min(differences) >= -tol and max(differences) > tol else 'full_train'
    # Keep all diagnostics. The phase-one branch is the bank rule, not architecture promotion.
    selection.pop('selected')
    selection.pop('status')
    write(output/'RESULTS.json', dict(by_target=results, development_diagnostics=selection,
                                     phase1_bank_rule=bank, phase2_authorized=False))


def write(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('preflight','evaluate'))
    for field in ('bundle','seal','seal-sha','manifest-sha','runtime','runtime-sha','output'):
        parser.add_argument('--'+field, required=True)
    for field in ('prelabel','prelabel-sha','release','release-sha'):
        parser.add_argument('--'+field)
    args = parser.parse_args()
    if args.stage == 'evaluate' and not all((args.prelabel,args.prelabel_sha,args.release,args.release_sha)):
        parser.error('persisted PRE_LABEL and exact root release with SHA are required')
    modules = read(ROOT/'MODULE_MANIFEST.json', args.manifest_sha)
    imports = {}
    for name, spec in modules.items():
        path = Path(sys.modules[name].__file__).resolve()
        need(path == ROOT/spec['path'] and raw.sha(path) == spec['sha256'], 'actual import differs: '+name)
        imports[name] = str(path)
    runtime = runtime_gate.runtime_gate(read(args.runtime,args.runtime_sha))
    seal = read(args.seal,args.seal_sha)
    need(seal['schema'] == 'R03_PHASE1_JOINT_SEAL_V1' and seal['status'] == 'SEALED_ALL_39_UNLABELLED',
         'actual joint seal required')
    inventory = read(ROOT/'DEVELOPMENT_PHASE1_INVENTORY.json',INVENTORY_SHA)
    policy = read(ROOT/'DEVELOPMENT_POLICY_PRELOCK.json',POLICY_SHA)
    output = Path(args.output)
    output.mkdir(exist_ok=False)
    cores, scores, proofs = preflight(args.bundle,seal,inventory,policy)
    pre = dict(status='PHASE1_PRE_LABEL_ACCEPTED',seal_sha256=args.seal_sha,manifest_sha256=args.manifest_sha,
               runtime_sha256=args.runtime_sha,target_tables=seal['target_tables'],predictions=39,
               runtime_identity=runtime,imports=imports,replay_digest=raw.digest(proofs))
    write(output/'PRE_LABEL_ACCEPTANCE.json',pre)
    write(output/'RAW_PROOF.json',proofs)
    if args.stage == 'evaluate':
        release = read(args.release,args.release_sha)
        need(release['prelabel_sha256'] == args.prelabel_sha, 'release binds persisted PRE_LABEL bytes')
        release_gate(release,pre,read(args.prelabel,args.prelabel_sha))
        evaluate(pre,inventory,policy,cores,scores,output)


if __name__ == '__main__':
    main()
