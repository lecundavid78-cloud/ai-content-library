"""Actual R05 export consumer: NumPy/stdlib, no producer/model/label imports.

All functions fail closed. Artifact paths are confined to a sealed bundle.
The target/heldout table is NEVER opened by this module, even after a release.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import numpy as np
from .artifacts import need, AcceptanceError
from .independent_vrh import reconstruct, ensemble, compare

ROOT_LOCK_SHA='01f238dbfaa9615db7bb3b304397cb0471dc2c945c420ddf64aafb1926b87fad'
PRODUCER_READY_SHA='5f995e5530b43fdbf3abff0c11708c25943cb987bd602a1198456367bbe173bf'
PRODUCER_MANIFEST_SHA='0bf1f3c73577f6c243abddc8970664069f7c0ce3865f790fb80e2c6bb5a7ec16'
PRODUCER_ZIP_SHA='7a7e9a8d02e2494c2c58a4ea0bbc36d9b2b411dfad4e685c561d8f60d07b186c'
PRODUCER_ACCEPTANCE_SHA='d3b69249869f441a6a3d08f02ebac765111973719d6f1417fb25630872a61037'
PROTOCOL_SHA='c674b5e8d05f994cb932b502033907658144f5226401f1822a32770088cf44b3'
K=(20,128,512,1024,2048,4096)
CELLS={'A1':('C','S'),'A2':('C','L'),'A3':('R','S'),'A4':('R','L')}
METHODS=tuple(CELLS)+('Original',)
AA='ACDEFGHIKLMNPQRSTVWY'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def digest(x):
    # Match pilot/contracts.py; unlike file SHA this is a semantic digest.
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def canonical(seq):
    need(seq and not set(seq)-set(AA),'canonical WT required')
    return [f'{w}{i}{a}' for i,w in enumerate(seq,1) for a in AA if a!=w]


def array_digest(a):
    a=np.asarray(a)
    return hashlib.sha256(str(a.dtype).encode()+b'\0'+json.dumps(list(a.shape)).encode()+b'\0'+np.ascontiguousarray(a).tobytes()).hexdigest()


def bound(root,spec):
    """Hash only explicitly sealed, confined prediction/metadata files."""
    root=Path(root).resolve();rel=Path(spec['path'])
    need(not rel.is_absolute() and '..' not in rel.parts,'relative sealed paths only')
    p=(root/rel).resolve();need(p.is_relative_to(root) and p.is_file(),'sealed artifact escape/missing')
    need(sha(p)==spec['sha256'],'sealed bytes changed: '+str(rel))
    return p


def load_root_lock(path):
    need(sha(path)==ROOT_LOCK_SHA,'root role lock differs from exact controller lock')
    lock=json.loads(Path(path).read_text(encoding='utf-8-sig'))
    need(lock['schema']=='FOURCELL_TARGET_AND_POOL_LOCK_V1' and lock['protocol_sha256']==PROTOCOL_SHA,'root lock/protocol schema')
    t=lock['target']
    need(t['id']=='TnpB' and t['role']=='TARGET' and t['length']==408,'only locked TnpB408 target')
    need(t['protected_evaluation_table']['sha256']=='08fe18b5c6fb5f19c277de81b1652708fbcb622106df77d3b9f4f8f6e5aa667f','full historic target pool identity')
    # Do not stat/hash/open the protected table or any source heldout table.
    return lock


def verify_final_producer(code_root,acceptance_path,archive_path):
    """Verify final scientific bytes; does not import or run the producer."""
    from zipfile import ZipFile
    root=Path(code_root).resolve()
    need(sha(root/'CODE_READY.json')==PRODUCER_READY_SHA,'final CODE_READY byte identity')
    need(sha(root/'CODE_MANIFEST.json')==PRODUCER_MANIFEST_SHA,'final code manifest byte identity')
    ready=json.loads((root/'CODE_READY.json').read_text(encoding='utf-8'))
    manifest=json.loads((root/'CODE_MANIFEST.json').read_text(encoding='utf-8'))
    need(sha(acceptance_path)==PRODUCER_ACCEPTANCE_SHA,'exact v3 controller acceptance bytes')
    accepted=json.loads(Path(acceptance_path).read_text(encoding='utf-8'))
    need(accepted['schema']=='CONTROLLER_R05_V3_INIT_COMPATIBILITY_ACCEPTANCE' and accepted['bound_files']==40 and accepted['zip_members']==44 and accepted['actual_qualification_passed'] is False and accepted['is_execution_release'] is False,'v3 acceptance fields/scope')
    need(ready['status']=='CODE_READY_FOR_R02_REAL_QUALIFICATION' and ready['protocol_sha256']==PROTOCOL_SHA and ready['real_qualification_passed'] is False,'code acceptance is not real qualification')
    need(ready['code_manifest']['sha256']==PRODUCER_MANIFEST_SHA,'ready/manifest binding')
    need(accepted['code_ready_sha256']==PRODUCER_READY_SHA and accepted['manifest_sha256']==PRODUCER_MANIFEST_SHA and accepted['zip_sha256']==PRODUCER_ZIP_SHA and accepted['passed'] is True,'controller producer acceptance mismatch')
    need(len(manifest['files'])==40,'exact 40 scientific/code bindings')
    names=set()
    for row in manifest['files']:
        p=bound(root,row);need(p.stat().st_size==row['bytes'],'scientific file size differs');names.add(Path(row['path']).as_posix())
    need({p.relative_to(root).as_posix() for p in root.rglob('*.py')}=={n for n in names if n.endswith('.py')},'unmanifested or missing producer Python')
    need(sha(archive_path)==PRODUCER_ZIP_SHA,'final producer ZIP identity')
    with ZipFile(archive_path) as z:
        need(len(z.namelist())==44 and len(set(z.namelist()))==44,'exact ZIP member count')
        for row in manifest['files']:
            need(hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256'],'ZIP scientific bytes differ')
        need(hashlib.sha256(z.read('CODE_READY.json')).hexdigest()==PRODUCER_READY_SHA,'ZIP CODE_READY differs')
    return {'status':'FINAL_PRODUCER_BYTES_BOUND_NOT_QUALIFICATION_RELEASE','code_files':40,'zip_members':44,
            'code_ready_sha256':PRODUCER_READY_SHA,'manifest_sha256':PRODUCER_MANIFEST_SHA,'zip_sha256':PRODUCER_ZIP_SHA,
            'producer_imported_or_run':False,'real_qualification_passed':False}


def verify_raw(record,arrays,*,sequence,members,natural_arrays,msa_spans,vrh_config,tolerance):
    """Independent replay of one real-format record, no diagnostic truth."""
    need(tolerance=={'atol':2e-5,'rtol':2e-4},'FP32 tolerance must not be widened')
    L=len(sequence);ids=canonical(sequence);n=19*L
    need(record['schema']=='FOURCELL_PREDICTION_V1' and record['status']=='RAW_COMPLETE_UNEVALUATED','actual producer record schema/status')
    need(record['wt_sha256']==hashlib.sha256(sequence.encode()).hexdigest(),'RAW WT SHA')
    need(record['members']==members and set(members)==set(map(str,K)),'native six-member identities differ')
    need(record['vrh_config']==vrh_config and record['n_full19l']==n and record['coverage']==1.,'configuration/coverage mismatch')
    need(record['normalization']=='complete19L' and record['statistics_gradient']=='full' and record['no_functional_labels'] is True,'scoring/label boundary')
    need(record['raw_layout']=='canonical [L,25]; input mapping separate' and record['variant_order_digest']==digest(ids),'RAW layout/order')
    need(arrays['variant_ids'].dtype.kind in 'US' and arrays['variant_ids'].tolist()==ids,'complete canonical variants differ')
    need(arrays['member_scores'].shape==arrays['member_zscores'].shape==(6,n) and arrays['ensemble'].shape==(n,),'score shapes')
    for a in arrays.values():
        need(a.dtype.kind!='O','object arrays forbidden')
        if a.dtype.kind=='f':need(np.isfinite(a).all(),'nonfinite RAW field')
    reports=[];vectors=[];natural_ids={};mapping_ids={}
    common=('adapter_msa_profile','foldseek_mapped_profile','context_mask','context_quality','rsa_weights','plddt_weights')
    for name in common:
        need((name in arrays)==(name in natural_arrays),'natural presence mismatch: '+name)
        if name in arrays:
            need(arrays[name].dtype==natural_arrays[name].dtype and np.array_equal(arrays[name],natural_arrays[name]),'natural field changed: '+name)
            natural_ids[name]=array_digest(arrays[name])
    for row,k in enumerate(K):
        m=members[str(k)];vocab=m['vocab']
        need(len(vocab)==25 and len(set(vocab))==25 and not set(AA)-set(vocab),'AA25 vocabulary')
        logits=arrays[f'logits_{k}'];logp=arrays[f'logp_{k}']
        need(logits.shape==logp.shape==(L,25) and logits.dtype==np.float32 and logp.dtype==np.float32,'real FP32 canonical AA25 fields')
        token=arrays[f'input_ids_{k}'];ss=arrays[f'structure_tokens_{k}'];mask=arrays[f'token_mask_{k}'];special=arrays[f'special_mask_{k}'];ix=arrays[f'canonical_index_{k}'];ri=arrays[f'raw_row_index_{k}']
        need(token.ndim==2 and token.shape[0]==1 and token.dtype.kind in 'iu' and ss.shape==mask.shape==special.shape==token.shape,'encoder field shapes')
        need(ss.dtype.kind in 'iu' and mask.dtype==special.dtype==np.bool_ and mask.all(),'encoder types/attention mask')
        need(ix.shape==(L,) and ix.dtype.kind in 'iu' and len(set(ix.tolist()))==L and np.all((ix>=0)&(ix<token.shape[1])),'canonical encoder indices')
        need(np.array_equal(np.flatnonzero(~special[0]),ix) and not special[0,ix].any(),'special/canonical separation')
        need(np.all((token>=0)&(token<25)) and ''.join(vocab[int(i)] for i in token[0,ix])==sequence,'input IDs WT mismatch')
        need(ri.dtype.kind in 'iu' and np.array_equal(ri,np.arange(L)),'RAW row map is not canonical')
        codes=natural_arrays[f'structure_codes_{k}']
        need(codes.shape==(L,) and codes.dtype.kind in 'iu' and np.all((codes>=0)&(codes<k)),'complete native structure codes')
        need(np.array_equal(ss[0,ix],codes+3) and np.all((ss[0,special[0]]>=0)&(ss[0,special[0]]<=2)),'structure token mapping')
        valid=arrays[f'structure_code_valid_{k}'];need(valid.dtype==np.bool_ and valid.shape==(L,) and valid.all(),'structure token validity')
        msa=arrays[f'msa_logp25_{k}'];span=arrays[f'msa_span_{k}']
        need(span.dtype.kind in 'iu' and span.tolist()==list(msa_spans[str(k)]),'MSA span identity')
        need(msa.dtype==natural_arrays[f'msa_logp25_{k}'].dtype and np.array_equal(msa,natural_arrays[f'msa_logp25_{k}']),'MSA field changed')
        vector,details,arithmetic=reconstruct(logits,msa,tuple(span.tolist()),sequence,vocab,vrh_config,arrays.get('rsa_weights'),arrays.get('plddt_weights'))
        reports.append(compare(f'K{k}.AA25.logsoftmax',details['raw_logp25'],logp,tolerance))
        reports.append(compare(f'K{k}.raw_to_full19L',vector,arrays['member_scores'][row],tolerance))
        vectors.append(vector)
        natural_ids[f'structure_codes_{k}']=array_digest(codes);natural_ids[f'msa_{k}']=array_digest(msa);natural_ids[f'span_{k}']=span.tolist()
        mapping_ids[str(k)]=digest({x:array_digest(arrays[f'{x}_{k}']) for x in ('input_ids','structure_tokens','token_mask','special_mask','canonical_index','raw_row_index')})
    final,z,means,std=ensemble(vectors)
    reports.append(compare('complete19L.member_zscores',z,arrays['member_zscores'],tolerance))
    reports.append(compare('complete19L.ensemble',final,arrays['ensemble'],tolerance))
    return {'status':'PASS_INDEPENDENT_RAW_REPLAY','candidate_count':n,'members':6,'checks':reports,'natural_identity':digest(natural_ids),'mapping_identity':digest(mapping_ids),
            'config_identity':digest(vrh_config),'member_identity':digest(members),'diagnostics_used_as_truth':False,'functional_labels_read':False}


def load_prediction(root,spec,**expected):
    """Read only the three actual exported prediction artifacts."""
    record_path=bound(root,spec['record']);record=json.loads(record_path.read_text(encoding='utf-8-sig'))
    raw_path=bound(root,spec['raw']);csv_path=bound(root,spec['csv'])
    need(record['raw_sha256']==sha(raw_path) and record['csv_sha256']==sha(csv_path),'record/raw/CSV byte identities')
    with np.load(raw_path,allow_pickle=False) as z:arrays={k:z[k].copy() for k in z.files}
    report=verify_raw(record,arrays,**expected)
    with csv_path.open(encoding='utf-8-sig',newline='') as stream:
        reader=csv.DictReader(stream);need(reader.fieldnames==['variant_id','score'],'prediction CSV header')
        rows=list(reader)
    need([r['variant_id'] for r in rows]==canonical(expected['sequence']),'prediction CSV full19L order')
    values=np.array([float(r['score']) for r in rows],dtype=np.float64)
    report['checks'].append(compare('CSV_vs_RAW_ensemble',arrays['ensemble'],values,expected['tolerance']))
    return record,report


def training_gate(method,record,train,*,policy_lock):
    if method=='Original':
        need(record['active_adaptation'] is False and record['steps_completed']==0 and record['seed'] is None,'Original active adaptation')
        need(train is None,'Original must not consume a training receipt');return
    policy,architecture=CELLS[method]
    need(record['active_adaptation'] is True and record['architecture']==architecture and record['policy']==policy,'cell implementation/source policy')
    need(train['schema']=='FOURCELL_TRAIN_RECEIPT_V1' and train['status']=='TRAIN_COMPLETE_UNEVALUATED' and train['cell']==method,'actual train receipt')
    need(train['steps_completed']==500 and train['seed']==11 and train['loss_interface']=='phaseA-pair-v2-nonempty' and train['natural_adaptation_updates']==0,'fixed F-only training')
    need(train['optimizer']=={'name':'AdamW','lr':1e-4,'betas':[.9,.999],'eps':1e-8,'weight_decay':0.,'clip_norm':1.},'unique frozen optimizer')
    need(train['architecture']==architecture and train['policy']==policy and train['target_id']=='TnpB','training target/cell')
    need(set(train['source_ids'])==set(policy_lock[policy]) and set(train['updates_per_source'])==set(policy_lock[policy]) and set(train['updates_per_source'].values())=={250},'two exact sources,250 updates each')
    need(train['normalization']=='complete19L' and train['statistics_gradient']=='full' and train['frozen_byte_check_passed'] is True and train['reload_exact'] is True,'training frozen/reload qualification')
    need(train['init_sha256']==policy_lock['init_sha256_by_arch'][architecture] and train['schedule_sha256']==policy_lock['schedule_sha256_by_policy'][policy],'paired init/schedule identity')
    need(record['training']==train and record['checkpoint_sha256']==train['checkpoint_sha256'],'prediction from exact last checkpoint')


def accounting_gate(rows,expected_jobs):
    need(rows and len({r['job_id'] for r in rows})==len(rows),'unique complete actual job ledger')
    need({r['job_id'] for r in rows}==set(expected_jobs),'missing/extra billed job')
    for r in rows:
        need(r['state'] in {'COMPLETED','FAILED','CANCELLED','TIMEOUT','OUT_OF_MEMORY'},'nonterminal job')
        need(type(r['allocated_seconds']) is int and r['allocated_seconds']>=0 and type(r['gpu_count']) is int and r['gpu_count']>=0,'invalid allocation')
    return {'job_count':len(rows),'cumulative_GPU_seconds':sum(r['allocated_seconds']*r['gpu_count'] for r in rows),'failed_jobs_included':True}


def qualification_gate(q,policy_lock):
    need(q['status']=='REAL_QUALIFICATION_PASS_NOT_TRAINING_ADMISSION' and set(q['architecture'])=={'S','L'},'real two-architecture qualification missing')
    for arch,count in (('S',597376),('L',589824)):
        r=q['architecture'][arch]
        need(r['trainable_parameters']==count and r['head_autograd'] is True and r['frozen_bytes_unchanged'] is True and r['reload_exact'] is True,'real parameter/head/reload qualification')
        need(r['init_sha256']==policy_lock['init_sha256_by_arch'][arch] and len(r['steps'])==2,'qualified paired initialization/two probe steps')
        for step in r['steps']:
            need(len(step['head_input_gradient_norms'])==6 and all(math.isfinite(v) and v>0 for v in step['head_input_gradient_norms'].values()),'real head gradient proof')


def five_condition_gate(records,replays,trains,*,root_lock,policy_lock,qualification,bindings,updates,parameter_updates):
    """Bind actual producer records after independent numeric replay.

    Hash verification of every passed document is the sealed IO adapter's job;
    unbound claims alone never produce the final PRE_LABEL acceptance.
    """
    need(set(records)==set(replays)==set(METHODS) and set(trains)==set(CELLS),'all five, no extras')
    need(root_lock['target']['id']=='TnpB' and root_lock['target']['length']==408,'only TnpB408')
    need(root_lock['schema']=='FOURCELL_TARGET_AND_POOL_LOCK_V1' and root_lock['protocol_sha256']==PROTOCOL_SHA,'original root role schema required; runtime projection obsolete')
    need(root_lock['target']['role']=='TARGET' and all(s['role']=='SOURCE_POOL' for s in root_lock['sources']),'root functional roles')
    need(bindings['target_lock_sha256']==ROOT_LOCK_SHA,'must bind original root-role file SHA')
    need(bindings['code_ready_sha256']==PRODUCER_READY_SHA and bindings['code_manifest_sha256']==PRODUCER_MANIFEST_SHA,'only final controller-accepted producer')
    source_ids={s['id'] for s in root_lock['sources']}
    need(set(policy_lock['C'])|set(policy_lock['R'])==source_ids and len(policy_lock['C'])==len(policy_lock['R'])==2 and not set(policy_lock['C'])&set(policy_lock['R']),'retrieval vs forced complement')
    need(policy_lock['target_lock_sha256']==bindings['target_lock_sha256'],'source policy does not bind root role lock')
    qualification_gate(qualification,policy_lock)
    for method in METHODS:
        r=records[method];n=replays[method]
        need(r['condition']==method and r['protein_id']=='TnpB' and r['n_full19l']==7752,'condition/target7752')
        for key in ('code_ready_sha256','native_lock_sha256'):
            need(r[key]==bindings[key],'producer identity lock mismatch')
        need(r['target_lock_sha256']==bindings['target_lock_sha256'],'prediction does not bind root role lock')
        need(n['status']=='PASS_INDEPENDENT_RAW_REPLAY' and n['candidate_count']==7752,'actual independent RAW replay required')
        for key in ('natural_identity','mapping_identity','config_identity','member_identity'):
            need(n[key]==replays['Original'][key],'five conditions do not share '+key)
        need(r['prepared_bundle_sha256']==records['Original']['prepared_bundle_sha256'],'target bundle changed across methods')
        training_gate(method,r,trains.get(method),policy_lock=policy_lock)
        if method in CELLS:
            rows=updates[method];tr=trains[method]
            need(len(rows)==500 and [x['step'] for x in rows]==list(range(1,501)),'complete actual 500-step log')
            ordered=sorted(tr['source_ids'])
            need([x['source_id'] for x in rows]==[ordered[i%2] for i in range(500)],'source alternation changed')
            need(all(math.isfinite(x['loss']) and math.isfinite(x['unclipped_gradient_norm']) and x['unclipped_gradient_norm']>0 for x in rows),'loss/gradient update evidence')
            p=parameter_updates[method]
            parameter_update_gate(p['document'],tr,expected_member_identity=digest(r['members']),receipt_file_sha256=p['file_sha256'])
            arch=CELLS[method][1]
            need(tr['frozen_sha256']==qualification['architecture'][arch]['base_frozen_sha256'],'train/qualification frozen base differs')
    return {'status':'ALL_FIVE_IDENTITY_AND_TRAINING_METADATA_PASS','label_table_opened':False,
            'not_a_final_PRE_LABEL':'all artifact byte/import identities,root release and actual ledger must still bind'}


def final_release_gate(release,*,prelabel,expected_root_sha=ROOT_LOCK_SHA):
    """Metadata-only final gate. It deliberately has NO functional-file IO."""
    need(release['schema']=='FOURCELL_R03_EVALUATION_RELEASE_V1' and release['status']=='RELEASED' and release['controller_chat']=='01a1868c-f2f5-7472-b24f-b4a9ac5ee794','exact final root release')
    need(prelabel['status']=='PRE_LABEL_ACCEPTED' and release['prelabel_digest']==digest(prelabel),'release must follow exact PRE_LABEL')
    need(release['root_role_lock_sha256']==prelabel['root_role_lock_sha256']==expected_root_sha,'role lock binding')
    need(release['joint_seal_sha256']==prelabel['joint_seal_sha256'] and release['consumer_manifest_sha256']==prelabel['consumer_manifest_sha256'],'seal/consumer binding')
    need(release['target_id']=='TnpB' and release['allowed_conditions']==list(METHODS) and release['target_table']==prelabel['target_table'],'exact one full target table')
    need(release['target_table']['sha256']=='08fe18b5c6fb5f19c277de81b1652708fbcb622106df77d3b9f4f8f6e5aa667f','not old80/20 holdout')
    need(prelabel['actual_byte_and_import_identity_verified'] is True and prelabel['all_five_raw_replayed'] is True and prelabel['actual_accounting_verified'] is True,'unverified production prerequisite')
    return {'status':'FINAL_RELEASE_METADATA_MATCH_ONLY','target_label_table_opened':False,'label_loader':'NOT_IMPLEMENTED_IN_THIS_STAGE'}


def imported_identity_gate(expected_hashes):
    from . import artifacts, independent_vrh
    actual={__name__:Path(__file__),artifacts.__name__:Path(artifacts.__file__),independent_vrh.__name__:Path(independent_vrh.__file__)}
    need(set(expected_hashes)==set(actual),'actual imported module set must be pinned')
    report={}
    for name,path in actual.items():
        h=sha(path);need(h==expected_hashes[name],'actual imported code SHA mismatch: '+name)
        report[name]={'actual_import_path':str(path.resolve()),'sha256':h}
    return report


def expected_parameter_shapes(architecture):
    """Exact names/shapes read from accepted ContextAdapter / Q,V whitelist."""
    if architecture=='S':
        out={'context.0.weight':[64,46],'context.0.bias':[64],'context.2.weight':[64,64],'context.2.bias':[64]}
        for k in K:
            out[f'down.ProSST-{k}.weight']=[64,768]
            out[f'down.ProSST-{k}.bias']=[64]
            out[f'up.ProSST-{k}.weight']=[768,64]
        return out
    need(architecture=='L','unknown adapter architecture')
    return {f'{k}/prosst.encoder.layer.11.attention.self.{projection}.{ab}':([32,768] if ab=='A' else [768,32])
            for k in K for projection in ('query','value') for ab in ('A','B')}


def _sha_string(x):
    return isinstance(x,str) and len(x)==64 and all(c in '0123456789abcdef' for c in x)


def parameter_update_gate(doc,train,*,expected_member_identity,receipt_file_sha256):
    """Validate the exact R05 v2 JSON sidecar and its training-receipt chain.

    This does not reread weight tensors; actual byte SHA is provided by the
    confined IO loader below, not by a semantic JSON digest.
    """
    need(_sha_string(receipt_file_sha256) and receipt_file_sha256==train['parameter_update_receipt_sha256'],'parameter receipt file/training SHA mismatch')
    need(doc['schema']=='FOURCELL_PARAMETER_UPDATE_RECEIPT_V1' and doc['status']=='PARAMETER_CHANGE_AND_FROZEN_BYTES_PASS','actual v2 sidecar schema/status')
    arch=train['architecture'];shapes=expected_parameter_shapes(arch)
    need(doc['architecture']==arch and doc['seed']==train['seed']==11 and doc['initial_step']==0 and doc['final_step']==doc['steps_observed']==train['steps_completed']==500,'sidecar architecture/seed/observed0-to500')
    need(doc['policy']==train['policy'] and doc['source_ids']==train['source_ids'] and doc['target_id']==train['target_id']=='TnpB','sidecar source policy/target')
    need(doc['member_identity']==expected_member_identity and _sha_string(doc['member_identity']),'sidecar member identity')
    need(doc['init_sha256']==train['init_sha256'] and doc['checkpoint_sha256']==train['checkpoint_sha256'],'sidecar init/final file identity')
    proof=doc['frozen_proof']
    need(proof['frozen_initial_sha256']==proof['frozen_current_sha256']==train['frozen_sha256'] and _sha_string(train['frozen_sha256']) and proof['frozen_bytes_unchanged'] is True,'frozen whole-model proof')
    heads=proof['head_initial_sha256'];current=proof['head_current_sha256']
    need(set(heads)==set(current)==set(map(str,K)) and heads==current and all(_sha_string(x) for x in heads.values()) and type(proof['head_requires_grad_count']) is int and proof['head_requires_grad_count']==0,'six complete frozen heads or grad flags changed')
    rows=doc['per_tensor'];names=[r['name'] for r in rows]
    need(len(names)==len(set(names))==len(shapes) and set(names)==set(shapes),'exact adapter tensor whitelist')
    total=0;changed_names=[];unchanged=[];numel=0
    need(all(type(doc[k]) is int for k in ('trainable_tensor_count','trainable_parameter_count','changed_elements','changed_tensors')),'aggregate counters must be integers, not booleans')
    for r in rows:
        n=r['name'];need(r['shape']==shapes[n] and r['dtype']=='torch.float32','adapter shape/FP32 dtype')
        count=math.prod(shapes[n]);need(type(r['numel']) is int and r['numel']==count,'per-tensor element count')
        c=r['changed_elements'];need(type(c) is int and 0<=c<=count,'invalid per-tensor changed count')
        a,b=r['init_tensor_sha256'],r['final_tensor_sha256']
        # Numerical x!=y does not distinguish signed zeros, whereas byte
        # hashes do. Positive numeric movement must change content hashes;
        # zero movement need not imply byte-identical signed-zero encodings.
        need(_sha_string(a) and _sha_string(b) and (c==0 or a!=b),'content SHA versus numerical movement inconsistent')
        mx,l2=r['max_abs_delta'],r['l2_delta']
        need(isinstance(mx,(int,float)) and isinstance(l2,(int,float)) and math.isfinite(mx) and math.isfinite(l2) and mx>=0 and l2>=0,'nonfinite/negative delta')
        if c==0:
            need(mx==l2==0,'unchanged tensor has nonzero delta');unchanged.append(n)
        else:
            need(mx>0 and l2>0 and l2+1e-12*max(1.,mx)>=mx and l2<=math.sqrt(c)*mx+1e-12*max(1.,l2),'delta norms disagree with changed count');changed_names.append(n)
        total+=c;numel+=count
    need(numel=={'S':597376,'L':589824}[arch] and doc['trainable_tensor_count']==len(shapes) and doc['trainable_parameter_count']==numel,'total whitelist/count mismatch')
    need(total>0 and doc['changed_elements']==train['changed_elements']==total,'zero/incorrect aggregate movement')
    need(doc['changed_tensors']==len(changed_names) and doc['unchanged_tensor_names']==sorted(unchanged),'unchanged branch disclosure inconsistent')
    all_changed=(len(changed_names)==len(shapes))
    need(doc['all_trainable_tensors_changed'] is all_changed and train['all_trainable_tensors_changed'] is all_changed,'incorrect all-tensors-changed claim')
    return {'status':'PARAMETER_SIDECAR_CHAIN_PASS_NOT_FUNCTIONAL_GAIN','architecture':arch,'changed_elements':total,'changed_tensors':len(changed_names),'unchanged_tensors':len(unchanged),'complete_heads_checked':6,'checkpoint_tensors_independently_loaded':False}


def load_parameter_update(root,spec,train,*,expected_member_identity):
    p=bound(root,spec)
    need(sha(p)==train['parameter_update_receipt_sha256'],'train binds different parameter sidecar bytes')
    return parameter_update_gate(json.loads(p.read_text(encoding='utf-8-sig')),train,expected_member_identity=expected_member_identity,receipt_file_sha256=sha(p))


def prelabel_receipt(*,root_lock,root_lock_file_sha,joint_seal_sha,consumer_manifest_sha,identity_receipt,ledger_receipt,artifact_byte_checks,import_checks):
    """Compose PRE_LABEL only after preceding independent gates, no labels.

    Caller supplies already verified machine receipts, not user booleans.
    Actual bundled IO/orchestration binding remains pending CODE_READY.
    """
    need(root_lock_file_sha==ROOT_LOCK_SHA,'exact root role lock bytes required')
    need(identity_receipt['status']=='ALL_FIVE_IDENTITY_AND_TRAINING_METADATA_PASS','all five identity gate')
    need(artifact_byte_checks and all(x['actual_sha256']==x['expected_sha256'] for x in artifact_byte_checks),'all actual artifact bytes checked')
    need(import_checks and ledger_receipt['job_count']>0,'actual imports and complete billed jobs required')
    need(ledger_receipt['failed_jobs_included'] is True,'failed allocations omitted')
    return {'schema':'FOURCELL_PRE_LABEL_ACCEPTANCE_V1','status':'PRE_LABEL_ACCEPTED','root_role_lock_sha256':ROOT_LOCK_SHA,
            'joint_seal_sha256':joint_seal_sha,'consumer_manifest_sha256':consumer_manifest_sha,'target_id':'TnpB',
            'target_table':root_lock['target']['protected_evaluation_table'],
            'all_five_raw_replayed':True,'actual_byte_and_import_identity_verified':True,'actual_accounting_verified':True,
            'artifact_byte_checks':artifact_byte_checks,'import_checks':import_checks,'ledger':ledger_receipt,'functional_label_table_opened':False}
