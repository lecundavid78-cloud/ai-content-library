"""Actual producer-format CPU consumer; no target/heldout label loader."""
