"""Independent NumPy raw-AA25 -> full VRH -> canonical19L reference.

No producer imports, diagnostic inputs, model/label/filesystem access or autograd.
Float casts mirror the locked arithmetic; statistics' ddof is always explicit.
"""
import math
import numpy as np
from .artifacts import need
AA='ACDEFGHIKLMNPQRSTVWY'
class NumericReconstructionError(ValueError):
    pass

def _std(a):
    a=np.asarray(a)
    if a.size<2:return np.asarray(np.nan,dtype=a.dtype)
    if not bool(np.sum((a-a.mean())**2)>0):return np.asarray(0.,dtype=a.dtype)
    return a.std(ddof=1)

def logsoftmax(a):
    a=np.asarray(a);m=a.max(axis=1,keepdims=True);x=a-m
    return x-np.log(np.exp(x).sum(axis=1,keepdims=True))

def _ratio(rho,sp,sm):
    rho=np.clip(rho,0.,1.);num=rho*sp;den=num+(1.-rho)*sm
    need(np.isfinite(den) and den>0,'INVALID_SCALE_MAPPING_DENOMINATOR')
    return np.clip(num/den,0.,1.)

def features(raw,msa,span,sequence,ids):
    need(msa is not None,'ENTROPY_REQUIRES_NATIVE_MSA');start,end=span;L=len(sequence)
    need(type(start) is int and type(end) is int and 0<=start<end<=L,'INVALID_ALIGNMENT_SPAN')
    need(msa.ndim==2 and msa.shape==(end-start,25),'MSA_ROWS_SPAN_OR_AA25_MISMATCH')
    n=min(end-start,len(msa),len(raw)-start);need(n>0,'EMPTY_ALIGNED_SPAN')
    x=raw[start:start+n,ids].astype(np.float64);y=msa[:n,ids].astype(np.float64)
    wt=np.array([AA.index(a) for a in sequence[start:start+n]]);r=np.arange(n)
    lp=logsoftmax(x);pref=np.exp(lp);pll=np.log(np.maximum(pref[r,wt],1e-12)).mean()
    mask=np.arange(20)[None,:]!=wt[:,None];sp=_std((x-x[r,wt,None])[mask]);sm=_std((y-y[r,wt,None])[mask])
    need(np.isfinite(sp) and np.isfinite(sm) and sm>0,'INVALID_NATIVE_MARGIN_SCALE')
    pi=np.clip(-pll/math.log(20),0.,1.);h=np.clip((-(np.exp(lp)*lp).sum(1).mean())/math.log(20),0.,1.)
    xc=x-x.mean(1,keepdims=True);yc=y-y.mean(1,keepdims=True)
    den=np.sqrt(np.maximum((xc*xc).sum(1)*(yc*yc).sum(1),1e-24))
    corr=np.nan_to_num((xc*yc).sum(1)/den,nan=0.,posinf=0.,neginf=0.).mean();rot=.5*(1.-corr)
    rho=np.clip((1.-h)*pi+h*rot,0.,1.)
    return dict(n=n,n_native_sites=n,pll_plm=pll,rho_pi=pi,hbar=h,corr_rm=corr,rho_rot=rot,rho=rho,scale_plm=sp,scale_msa=sm,alpha_pi=_ratio(pi,sp,sm),alpha=_ratio(rho,sp,sm))

def calibrate(raw,sequence,ids,disable):
    dtype=raw.dtype;maximum=raw.max(0);background=maximum+np.log(np.exp(raw-maximum).sum(0))-np.asarray(math.log(len(raw)),dtype=dtype)
    b=background[ids];std=_std(b);bz=np.zeros(25,dtype=dtype)
    if std>1e-8:bz[ids]=(b-b.mean())/std
    local=raw[:,ids].astype(np.float64);bf=b.astype(np.float64);bc=bf-bf.mean();bs=(bc*bc).sum()
    consistency=np.float64(0.)
    if bs>1e-24:
        lc=local-local.mean(1,keepdims=True);ld=np.sqrt(np.maximum((lc*lc).sum(1),1e-24))
        consistency=np.nan_to_num((lc*bc).sum(1)/(ld*np.sqrt(bs)),nan=0.,posinf=0.,neginf=0.).mean()
    kappa=np.float64(1.) if disable else max(np.float64(0.),consistency)
    wt=np.array([ids[AA.index(a)] for a in sequence]);w=raw[np.arange(len(sequence)),wt];ws=_std(w)
    wz=(w-w.mean())/ws if ws>1e-8 else w*np.asarray(0.,dtype=dtype)
    return dict(background=background,background_z=bz,background_std=std,bg_consistency=consistency,bg_scale=kappa,kappa=kappa,
        entropy=-(np.exp(raw)*raw).sum(1),wt_log_probability=w,wt_confidence=1./(1.+np.exp(-wz)),calibrated_on_raw=True)

def structure(L,dtype,rsa,plddt,config):
    out=np.ones(L,dtype=dtype);d={}
    if rsa is not None:
        a=np.asarray(rsa,dtype=dtype).reshape(-1);need(a.shape==(L,) and np.isfinite(a).all(),'INVALID_RSA')
        a=np.clip(a,0.,1.);valid=a[a>0];mean=valid.mean() if len(valid) else np.asarray(0.,dtype=dtype);std=_std(valid) if len(valid)>1 else np.asarray(0.,dtype=dtype)
        d.update(rsa=a,rsa_mean=mean,rsa_std=std)
        if config['use_rsa_decay']:
            mode=config['rsa_decay_mode'];decay=np.maximum(a-mean,0.)
            if mode=='std_scaled':decay=std*decay
            elif mode=='adaptive':decay=np.maximum(1.-2.*mean,0.).astype(dtype)*a
            elif mode!='above_mean':decay=a
            out=out*((1.+decay) if config['task_type']=='surface' else (1.-decay))
    if plddt is not None:
        p=np.asarray(plddt,dtype=dtype).reshape(-1);need(p.shape==(L,) and np.isfinite(p).all(),'INVALID_PLDDT')
        p=np.clip(p,0.,1.);valid=p[p>0];mean=valid.mean() if len(valid) else np.asarray(0.,dtype=dtype);disorder=1.-valid if len(valid) else p
        std=_std(disorder) if len(disorder)>1 else np.asarray(0.,dtype=dtype);d.update(plddt=p,plddt_mean=mean,plddt_disorder_std=std)
        if config['use_plddt_decay']:
            q=np.maximum((1.-p)-(1.-mean),0.)
            if config['plddt_decay_mode']=='std_scaled':q=q*std
            out=out*(1.-q)
    d['structure_factor']=out
    return d

def reconstruct(logits,msa,span,sequence,vocab,config,rsa=None,plddt=None):
    logits=np.asarray(logits);L=len(sequence)
    need(logits.shape==(L,25) and logits.dtype in (np.dtype('float32'),np.dtype('float64')) and np.isfinite(logits).all(),'FINITE_FP32_OR_FP64_AA25_REQUIRED')
    need(L>0 and not set(sequence)-set(AA) and len(vocab)==25 and len(set(vocab))==25 and all(a in vocab for a in AA),'CANONICAL_WT_AND_EXACT_VOCAB_REQUIRED')
    ids=np.array([vocab.index(a) for a in AA]);raw=logsoftmax(logits)
    if msa is not None:
        msa=np.asarray(msa);need(msa.dtype in (np.dtype('float32'),np.dtype('float64')) and np.isfinite(msa).all(),'FINITE_NATIVE_MSA_REQUIRED')
        need(msa.shape==(span[1]-span[0],25) and 0<=span[0]<span[1]<=L,'INVALID_NATIVE_MSA_SPAN')
        need(np.allclose(logsoftmax(msa),msa,atol=2e-5,rtol=0),'NATIVE_MSA_NOT_NORMALIZED_LOGP25')
    spec=config['alpha_spec'];d={}
    if spec is None or str(spec).lower() in ('entropy','auto','adaptive'):
        d=features(raw,msa,span,sequence,ids);alpha=d['alpha']
    else:alpha=np.float64(float(spec))
    bs=config['background_spec'];beta=1.-alpha if bs is None or str(bs).lower() in ('one_minus_alpha','1-alpha','auto','dynamic') else np.float64(float(bs))
    need(np.isfinite(alpha) and np.isfinite(beta),'FINITE_MIX_WEIGHTS_REQUIRED');d.update(alpha=alpha,background_weight=beta)
    fused=raw.copy()
    if msa is not None:
        start,end=span;fused[start:end]=np.asarray(1.-alpha,dtype=raw.dtype)*raw[start:end]+np.asarray(alpha,dtype=raw.dtype)*msa.astype(raw.dtype)
    else:need(alpha==0,'NONZERO_ALPHA_REQUIRES_MSA')
    cal=calibrate(raw,sequence,ids,config['disable_adaptive_ccd']);st=structure(L,raw.dtype,rsa,plddt,config)
    values=fused[:,ids];wt=np.array([AA.index(a) for a in sequence]);delta=values-values[np.arange(L),wt,None]
    b=cal['background_z'][ids];bg_delta=b[None,:]-b[wt,None]
    penalty=np.asarray(cal['bg_scale']*beta,dtype=raw.dtype)*bg_delta;score20=(delta-penalty)*st['structure_factor'][:,None]
    need(np.isfinite(score20).all(),'NONFINITE_RECONSTRUCTION')
    mask=np.arange(20)[None,:]!=wt[:,None];vector=score20[mask]
    d.update(cal);d.update(st);d.update(raw_logp25=raw,fused_logp25=fused,score20=score20)
    return vector,d,dict(aa20_ids=ids.tolist(),span=list(span),margin_ddof=1,background_ddof=1,ensemble_ddof=0,raw_dtype=str(raw.dtype),features_dtype='float64',normalization_dtype='float64')

def ensemble(member_scores):
    x=np.asarray(member_scores,dtype=np.float64);need(x.ndim==2 and x.shape[0]==6 and x.shape[1]>0 and np.isfinite(x).all(),'COMPLETE_SIX_FINITE_MEMBER_UNIVERSE_REQUIRED')
    mean=x.mean(1);std=x.std(1,ddof=0);active=std>0;z=np.zeros_like(x);z[active]=(x[active]-mean[active,None])/std[active,None]
    return z.mean(0),z,mean,std

def compare(name,expected,observed,tolerance):
    a=np.asarray(expected,dtype=np.float64);b=np.asarray(observed,dtype=np.float64)
    need(a.shape==b.shape,'RECONSTRUCTION_SHAPE/'+name);need(np.isfinite(a).all() and np.isfinite(b).all(),'RECONSTRUCTION_NONFINITE/'+name)
    error=np.abs(a-b);limit=tolerance['atol']+tolerance['rtol']*np.abs(b);ratio=error/limit
    report=dict(layer=name,count=int(a.size),max_abs_error=float(error.max(initial=0)),max_tolerance_ratio=float(ratio.max(initial=0)),mismatch_count=int((error>limit).sum()),atol=tolerance['atol'],rtol=tolerance['rtol'])
    if report['mismatch_count']:
        error=NumericReconstructionError('INDEPENDENT_VRH_MISMATCH/'+name)
        error.numeric_report=dict(failed_check=report);raise error
    return report

def verify_member(expected,diagnostic,stored_logp,member_vector,tol):
    vector,d,meta=expected;reports=[]
    def check(name,a,b):
        try:reports.append(compare(name,a,b,tol))
        except NumericReconstructionError as e:
            e.numeric_report.update(checks_completed=reports,arithmetic=meta);raise
    check('AA25.logits_to_stored_logp',d['raw_logp25'],stored_logp)
    for key,value in d.items():
        need(key in diagnostic,'MISSING_REQUIRED_DIAGNOSTIC/'+key)
        if isinstance(value,bool):need(diagnostic[key] is value,'DIAGNOSTIC_FLAG/'+key)
        elif key in ('n','n_native_sites'):need(diagnostic[key]==value,'EXACT_SPAN_COUNT/'+key)
        else:check(key,value,diagnostic[key])
    check('canonical19L.member_score',vector,member_vector)
    return dict(status='PASS_INDEPENDENT_RAW_TO_MEMBER',arithmetic=meta,checks=reports,numeric_checks=len(reports),elements_checked=sum(x['count'] for x in reports))
