"""Pure failure helper for the inherited NumPy arithmetic."""
class AcceptanceError(ValueError):
    pass


def need(ok, message):
    if not ok:
        raise AcceptanceError(message)
