"""Actual inventory metadata with synthetic seal/release and checkpoint fixtures."""
import copy
import json
from pathlib import Path
from unittest import TestCase

import phase1 as p

ROOT = Path(__file__).parent


class PhaseOneTests(TestCase):
    def setUp(self):
        self.inventory = p.read(ROOT/'DEVELOPMENT_PHASE1_INVENTORY.json',p.INVENTORY_SHA)
        self.policy = p.read(ROOT/'DEVELOPMENT_POLICY_PRELOCK.json',p.POLICY_SHA)
        tables = {target: dict(spec,target_id=target,role='TARGET_EVALUATION',direction='higher',
                   score_transform='identity',mount_path=f'/protected/{target}/full_table')
                  for target,spec in p.target_parser.FIXED.items()}
        self.seal = dict(target_tables=tables, targets=dict.fromkeys(tables),
            tracks={r['track_id']: None for r in self.inventory['training_trajectories']},
            predictions={**{r['target']+'::'+r['config_id']:None for r in self.inventory['checkpoint_predictions']},
                         **{t+'::Original':None for t in tables}})

    def test_actual_39_inventory_and_all_milestones(self):
        tracks,routes,recipes,nodes = p.inventory_gate(self.inventory,self.policy,self.seal)
        self.assertEqual((len(tracks),len(routes),len(recipes),len(nodes)),(12,3,12,36))
        for node in nodes.values():
            track = tracks[node['track_id']]
            self.assertEqual(track['target'],node['target'])
            self.assertEqual(node['step'],recipes[node['config_id']]['steps'])
            self.assertIn(node['step'],track['checkpoints'])

    def test_missing_original_or_milestone_hard_stop(self):
        for key in ('AsCas12f::Original',next(iter(self.seal['predictions']))):
            seal = copy.deepcopy(self.seal)
            del seal['predictions'][key]
            with self.assertRaisesRegex(ValueError,'39 sealed'):
                p.inventory_gate(self.inventory,self.policy,seal)

    def test_target_support_or_mount_substitution_rejected(self):
        self.seal['target_tables']['SpCas9']['mount_path'] = '/wrong'
        with self.assertRaisesRegex(ValueError,'mount slot'):
            p.inventory_gate(self.inventory,self.policy,self.seal)
        self.seal['target_tables']['SpCas9']['mount_path'] = '/protected/SpCas9/full_table'
        self.seal['target_tables']['SpCas9']['expected_count'] = 8100
        with self.assertRaisesRegex(ValueError,'fixed assay'):
            p.inventory_gate(self.inventory,self.policy,self.seal)

    def test_evaluation_requires_exact_persisted_gate(self):
        pre = dict(status='PHASE1_PRE_LABEL_ACCEPTED',seal_sha256='seal',manifest_sha256='code',
                   runtime_sha256='runtime',target_tables=self.seal['target_tables'])
        release = dict(pre,schema='R03_PHASE1_EVALUATION_RELEASE_V1',status='RELEASED',controller=p.CONTROLLER,
                       source_heldout_access=False,final_target_access=False)
        p.release_gate(release,pre,copy.deepcopy(pre))
        with self.assertRaisesRegex(ValueError,'persisted'):
            p.release_gate(release,pre,dict(pre,seal_sha256='other'))
        with self.assertRaisesRegex(ValueError,'development-only'):
            p.release_gate(dict(release,source_heldout_access=True),pre,pre)
