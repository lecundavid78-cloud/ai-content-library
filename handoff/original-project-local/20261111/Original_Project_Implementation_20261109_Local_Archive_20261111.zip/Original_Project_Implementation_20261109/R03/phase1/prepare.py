"""Freeze provenance and copy only historical code/metadata for this consumer."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
E = HERE.parents[1]
OLD = E.parents[1]/'Research_Diagnosis_20261108/ThreeTarget_FourCell_Replication_20261108/R03_Evaluation/production_v1/entry'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(name, value):
    (HERE/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')


def main():
    modules, provenance = {}, {}
    parent_manifest = json.loads((OLD/'ENTRY_MANIFEST.json').read_bytes())['modules']
    names = ['matrix_consumer','metrics_reference','target_parser','normalized_q_parser','spencer_parser',
             'vendor_q','vendor_q.consumer','vendor_q.artifacts','vendor_q.independent_vrh']
    files = {name: OLD/parent_manifest[name]['path'] for name in names}
    for name, src in files.items():
        assert sha(src) == parent_manifest[name]['sha256']
    files.update(selector=HERE.parent/'selector.py', single_source=E/'R05/runtime_v1/single_source.py')
    for name, src in files.items():
        relative = parent_manifest[name]['path'] if name in parent_manifest else name+'.py'
        dest = HERE/relative
        dest.parent.mkdir(exist_ok=True, parents=True)
        dest.write_bytes(src.read_bytes())
        provenance[relative] = dict(source=str(src),sha256=sha(dest),byte_identical=True)
        modules[name] = dict(path=relative,sha256=sha(dest))
    source = (OLD/'runner.py').read_text(encoding='utf-8')
    inherited = [ast.get_source_segment(source,node) for node in ast.parse(source).body
                 if isinstance(node,ast.FunctionDef) and node.name in ('runtime_identity','runtime_gate')]
    assert len(inherited) == 2
    runtime = ('import inspect, os, platform, sys\nfrom pathlib import Path\nimport numpy as np\n'
               'import scipy\nimport metrics_reference as metrics\nimport matrix_consumer as m\n'
               'from vendor_q import consumer as q\n\n'
               "THREAD_KEYS=('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS')\n\n"
               + '\n\n'.join(inherited)+'\n')
    (HERE/'runtime_gate.py').write_text(runtime,encoding='utf-8')
    provenance['runtime_gate.py'] = dict(source=str(OLD/'runner.py'), source_sha256=sha(OLD/'runner.py'),
                                        exact_functions=['runtime_identity','runtime_gate'])
    for name, path in [('runtime_gate','runtime_gate.py'),('__main__','phase1.py')]:
        modules[name] = dict(path=path,sha256=sha(HERE/path))
    for name in ('DEVELOPMENT_PHASE1_INVENTORY.json','DEVELOPMENT_POLICY_PRELOCK.json'):
        (HERE/name).write_bytes((E/name).read_bytes())
        provenance[name] = dict(source=str(E/name),sha256=sha(HERE/name),byte_identical=True)
    put('MODULE_MANIFEST.json',modules)
    put('REUSE_PROVENANCE.json',provenance)
    delta = difflib.unified_diff(source.splitlines(True),(HERE/'phase1.py').read_text(encoding='utf-8').splitlines(True),
                                 fromfile='old/runner.py',tofile='phase1.py')
    (HERE/'PRODUCTION_WIRING.diff').write_text(''.join(delta),encoding='utf-8')


if __name__ == '__main__':
    main()
