"""Q full normalized-table pure parser; only exact protein/assay/N/order are parameters. No file IO."""
import csv,io,math,re
from vendor_q import consumer as c
LABEL_COLUMNS=['protein', 'variant', 'pos1', 'wt', 'mut', 'score', 'sample_id', 'assay_id']
class fourcell_contract:
    @staticmethod
    def position(sequence,variant):
        match=re.fullmatch(r"([ACDEFGHIKLMNPQRSTVWY])([1-9][0-9]*)([ACDEFGHIKLMNPQRSTVWY])",variant)
        c.need(match is not None,"single mutation format")
        w,p,a=match.groups();p=int(p)
        c.need(1<=p<=len(sequence) and sequence[p-1]==w and a!=w,"WT/site/substitution mismatch")
        return p

def parse_target(raw, sequence, spec):
    """Exact historical normalized table; pure parser for synthetic CPU tests."""
    rd=csv.DictReader(io.StringIO(raw.decode('utf-8-sig')),delimiter='\t')
    c.need(rd.fieldnames==LABEL_COLUMNS,'fixed TnpB table columns')
    rows=list(rd)
    c.need(len(rows)==spec['expected_count'],'full original TnpB measured support required')
    labels={};order=[];sample_ids=set()
    for r in rows:
        v=r['variant'];pos=fourcell_contract.position(sequence,v)
        c.need(r['protein']==spec['protein_column_value'] and r['assay_id']==spec['assay_id'],'one exact TnpB assay')
        c.need(r['pos1']==str(pos) and r['wt']==v[0] and r['mut']==v[-1],'label coordinate mapping')
        c.need(v not in labels and r['sample_id'] and r['sample_id'] not in sample_ids,'duplicate variant/sample')
        score=float(r['score']);c.need(math.isfinite(score),'no nonfinite label dropping')
        labels[v]=score;order.append(v);sample_ids.add(r['sample_id'])
    if spec['support_order_digest'] is not None:
        c.need(c.digest(order)==spec['support_order_digest'],'exact full measured support order')
    else:
        c.need(spec['support_digest_policy']=='POST_RELEASE_EXACT_TABLE_ORDER_DIGEST_V1','explicit whole-table identity policy required')
    return order,labels
