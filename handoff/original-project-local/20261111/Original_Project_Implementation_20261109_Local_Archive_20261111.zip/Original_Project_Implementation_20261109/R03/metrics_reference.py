"""Pure CPU metrics copied from audited E3-01, with provenance. No file IO."""
from __future__ import annotations
import math
from collections.abc import Sequence
import numpy as np
from scipy.stats import rankdata
class InvalidEvaluation(ValueError): pass
class InvalidInput(ValueError): pass
def require(ok,msg):
    if not ok: raise InvalidInput(msg)
def _finite_vector(values: Sequence[float], name: str) -> np.ndarray:
    array = np.asarray(values, dtype=np.float64)
    if array.ndim != 1 or array.size < 2:
        raise InvalidEvaluation(f"{name}: expected a one-dimensional vector with >=2 rows")
    if not np.isfinite(array).all():
        raise InvalidEvaluation(f"{name}: non-finite values are not silently removed")
    return array

def _paired_vectors(y_true: Sequence[float], scores: Sequence[float]) -> tuple[np.ndarray, np.ndarray]:
    y = _finite_vector(y_true, "y_true")
    s = _finite_vector(scores, "scores")
    if y.shape != s.shape:
        raise InvalidEvaluation("All models must cover the same observed rows in the same order")
    return y, s

def spearman_average(y_true: Sequence[float], scores: Sequence[float]) -> float:
    """Pearson correlation of average ranks, NaN for either constant vector."""
    y, s = _paired_vectors(y_true, scores)
    ry = rankdata(y, method="average")
    rs = rankdata(s, method="average")
    ry = ry - ry.mean()
    rs = rs - rs.mean()
    denominator = np.linalg.norm(ry) * np.linalg.norm(rs)
    if denominator == 0.0:
        return float("nan")
    return float(np.clip(np.dot(ry, rs) / denominator, -1.0, 1.0))

def top20(y,s,*,positive_threshold):
 y=np.asarray(y,dtype=np.float64);s=np.asarray(s,dtype=np.float64)
 require(len(y)==len(s)>=20 and np.isfinite(y).all() and np.isfinite(s).all(),'INVALID_TOP20_SUPPORT')
 require(math.isfinite(positive_threshold),'MISSING_FULL_ASSAY_THRESHOLD')
 positive=y>=positive_threshold;cut=np.partition(s,len(s)-20)[len(s)-20];above=s>cut;tie=s==cut
 slots=20-int(above.sum());tn=int(tie.sum());p=above.astype(float)+tie*slots/tn
 return {'H20_expected':float(p@positive),'P20':float(p@positive)/20,'weights':p,'positive':positive,
  'boundary_score':float(cut),'boundary_tie_n':tn,'boundary_slots':slots,'positive_threshold_from_full_assay':positive_threshold}

def rho(y,s,within=False):
 if within and len(set(s))==1 and len(set(y))>1:return 0.0
 return spearman_average(y,s)

def site_diagnostics(y,positions,scores):
 sites=np.unique(positions);rows=[]
 for p in sites:
  ix=np.flatnonzero(positions==p);a=y[ix];n=len(ix);eb=n>=5;ew=eb and len(np.unique(a))>=2
  row={'position1':int(p),'observed_n':n,'distinct_labels':len(np.unique(a)),'between_eligible':eb,'within_eligible':ew,'mean_label':float(a.mean())}
  for m,b in scores.items():
   bb=b[ix];row[m+'_mean_prediction']=float(bb.mean());row[m+'_within_rho']=rho(a,bb,within=True) if ew else None
   good=bad=ties=total=0
   if ew:
    i,j=np.triu_indices(n,1);valid=a[i]!=a[j];prod=np.sign(a[i][valid]-a[j][valid])*np.sign(bb[i][valid]-bb[j][valid])
    good=int((prod>0).sum());bad=int((prod<0).sum());ties=int((prod==0).sum());total=len(prod)
   row.update({m+'_pair_valid_n':total,m+'_pair_correct':good,m+'_pair_incorrect':bad,m+'_pair_score_ties':ties,
    m+'_pair_accuracy':(good+.5*ties)/total if total else None})
  rows.append(row)
 summary={}
 for m in scores:
  be=[r for r in rows if r['between_eligible']];wi=[r for r in rows if r['within_eligible']];npairs=sum(r[m+'_pair_valid_n'] for r in wi)
  summary[m]={'between_qualified_sites':len(be),'within_qualified_sites':len(wi),
   'between_site_mean_rho':rho(np.array([r['mean_label'] for r in be]),np.array([r[m+'_mean_prediction'] for r in be])) if len(be)>=2 else None,
   'within_site_equal_site_rho':float(np.mean([r[m+'_within_rho'] for r in wi])) if wi else None,
   'within_valid_pair_n':npairs,'within_pair_accuracy':sum(r[m+'_pair_correct']+.5*r[m+'_pair_score_ties'] for r in wi)/npairs if npairs else None}
 return rows,summary
