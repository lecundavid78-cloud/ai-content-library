from datetime import datetime,timezone
import csv
import hashlib
import io
import json
from pathlib import Path

D=Path(__file__).resolve().parent
P=D/'R02/source_bundle_admission_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def write(p,o):p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

owner=read(P/'CPU_ADMISSION_ACCEPTANCE_5222068.json')
collection=Path(owner['collection']['path'])
assert sha(collection)==owner['collection']['sha256']
receipt=read(collection);event=receipt['events'][0]
assert event['job_id']=='5222068' and event['state']=='COMPLETED' and event['exit_code']=='0:0'
assert event['elapsed_seconds']==68 and '|billing=4,cpu=4,mem=32G,node=1|' in event['sacct']
assert receipt['release_sha256']==sha(D/'CONTROLLER_PHASE1_SOURCE_ADMISSION_CPU_EXECUTION_RELEASE.json')
assert event['deployment_unchanged'] is True
for ref in event['artifacts']:
    p=Path(ref['local_path']);assert sha(p)==ref['sha256'] and p.stat().st_size==ref['bytes']
refs={x['relative']:x for x in event['artifacts']}
assert read(Path(refs['output-5222068/EXIT.json']['local_path']))['exit_code']==0
plan=read(P/'payload/control/CONTRACT.json')
actual={}
for row in plan['rows']:
    target=row['id'];ref=refs[f'output-5222068/admitted/{target}/ADMISSION.json']
    doc=read(Path(ref['local_path']));old=row['inspection']
    assert doc['id']==target and doc['status']=='EXACT_FULLWT_BUNDLE_ADMITTED'
    assert doc['role']==('SOURCE' if row['role']=='SOURCE_H11' else 'TARGET')
    assert doc['parent_cache_sha256']==row['cache']['sha256']
    assert doc['controller_admission_sha256']==plan['controller_admission']['sha256']
    assert doc['derivation_execution_release_sha256']=='75070fbaab851595618ef150ad5e142e91fc5a0d0c8d60202933270db13e76b2'
    for key in ('wt_sha256','native_lock_sha256','natural_input_sha256','structure_asset_sha256','member_identity_sha256'):
        assert doc[key]==old[key],(target,key)
    assert doc['full_wt_h11_h12_validated'] is True and doc['all_six_member_identities_match'] is True
    assert doc['functional_values_present'] is False and doc['prefix_layer']==11
    assert doc['window_rule']=='single-full-WT-forward-no-window'
    assert set(doc['actual_span'])=={'20','128','512','1024','2048','4096'}
    assert len({v['canonical_count'] for v in doc['actual_span'].values()})==1
    for v in doc['actual_span'].values():
        assert v['h11_shape']==v['h12_shape'] and v['h11_shape']==[1,v['canonical_count']+2,768]
    if doc['role']=='SOURCE':
        output=next(x for x in event['source_outputs'] if f'/{target}/SOURCE.pt' in x['path'])
        assert output['sha256']==doc['bundle_sha256'] and output['bytes']>0
    else:assert doc['bundle_sha256']==row['cache']['sha256']
    actual[target]={'role':doc['role'],'bundle_sha256':doc['bundle_sha256'],'admission_sha256':ref['sha256']}
result={'status':'SIX_CACHE_FORMAL_SOURCE_CPU_ACCEPTED','utc':datetime.now(timezone.utc).isoformat(),
        'job_id':'5222068','state':'COMPLETED','exit_code':'0:0','elapsed_seconds':68,
        'CPU_core_seconds':272,'GPU_seconds':0,'collection_sha256':sha(collection),
        'artifacts_verified':len(event['artifacts']),'admissions':actual,'training_release':False,
        'remaining_engineering':'Compiler incorrectly rejects pinned empty __init__.py; original R05 assigned minimal repair and real 12-config compilation.'}
accept=D/'CONTROLLER_PHASE1_SOURCE_ADMISSION_ACTUAL_ACCEPTANCE.json';write(accept,result)
status=read(D/'CONTROL_STATUS.json');status.update(updated_utc=result['utc'],stage='SOURCE_CPU_ACCEPTED_COMPILER_EMPTY_FILE_REPAIR',phase='SOURCE_CPU_ACCEPTED_COMPILER_EMPTY_FILE_REPAIR')
status['phase1_formal_source_admission'].update(status=result['status'],job_id='5222068',acceptance=str(accept),acceptance_sha256=sha(accept))
status['active_roles']=['R05','R02'];status['phase1_config_preparation']['status']='MINIMAL_EMPTY_PINNED_FILE_REPAIR_AND_REAL_BINDING_COMPILE'
write(D/'CONTROL_STATUS.json',status)
ledger=D/'RUN_LEDGER.csv'
with ledger.open(newline='',encoding='utf-8-sig') as f:
    r=csv.DictReader(f);fields=r.fieldnames;rows=list(r)
if not any(r['job_id']=='5222068' for r in rows):
    rows.append(dict(job_id='5222068',purpose='formal SOURCE derivatives and six cache admissions',status='COMPLETED_0:0_SIX_ADMISSIONS_ACCEPTED',submitted_utc='2026-11-10T09:15:02+00:00',receipt=str(accept),config_sha256=receipt['release_sha256']))
with ledger.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
note='\n\n11月10日17:20 SGT实际CPU5222068已COMPLETED0:0，68秒、272核秒、0GPU，根逐件核11回传及六正式准入、三SOURCE派生hash与原始身份一致。正式训练仍未提交。真实配置编译发现合法空__init__.py被bytes>0错误拒绝，已一次交原R05作最小v2修复及真实12配置编译；原R02并行准备串行生产提交，不重做成功CPU/INIT。\n'
for name in ('CURRENT_STATUS.md','HAND_BACK.md','DECISION_LOG.md'):
    with (D/name).open('a',encoding='utf-8') as f:f.write(note)
print(json.dumps({'acceptance_sha256':sha(accept),'verified_artifacts':len(event['artifacts']),'formal_training_jobs':0}))
