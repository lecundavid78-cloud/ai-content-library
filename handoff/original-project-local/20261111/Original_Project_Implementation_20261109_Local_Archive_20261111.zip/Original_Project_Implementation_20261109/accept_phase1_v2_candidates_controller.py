import hashlib
import importlib.util
import json
from datetime import datetime,timezone
from pathlib import Path

D=Path(__file__).resolve().parent
V=D/'R05/phase1_v2';P=V/'actual_train_candidates'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
old=(D/'R05/phase1/build_phase1.py').read_text()
new=(V/'build_phase1.py').read_text()
assert new==old.replace("row['kind'] == 'regular_file' and row['bytes'] > 0 and ref['path'] not in observed",
                      "row['kind'] == 'regular_file' and type(row['bytes']) is int and row['bytes'] >= 0 and ref['path'] not in observed")
spec=importlib.util.spec_from_file_location('phase1_v2_compiler',V/'build_phase1.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
bindings=D/'R02/source_bundle_admission_v1/training_candidates_v1/BINDINGS.json'
assert sha(bindings)=='79e01f8bffb852d453b6013450096008e0900a8293a42ae33426f710efceda57'
jobs,configs,plan=module.compile_jobs('train',read(bindings))
candidate=read(P/'CANDIDATES.json');expected=plan|{'bindings_sha256':sha(bindings)}
assert candidate==expected and len(jobs)==len(configs)==12
assert candidate['planned_gpu_seconds_all_50']==59400
science=read(D/'R05/runtime_v1/RUNTIME_CODE_SHA256.json')
assert all(sha(D/'R05/runtime_v1'/name)==value for name,value in science.items())
init={'S':'611f6c926cd56459422382f0c47f5bcec024f1a7296d834af541e260c5a22ed1',
      'L':'84a18d839de170ea59550f420fb0f1f3f724df4c5fa71a57509d100a2f4c74ae'}
rows=[]
for tid,item in sorted(jobs.items()):
    job=read(P/(tid+'.JOB.json'));config=read(P/(tid+'.json'))
    assert job==item['job'] and config==configs[tid]
    assert sha(P/(tid+'.JOB.json'))==item['job_sha256']
    assert job['cases'][0]['config']['sha256']==sha(P/(tid+'.json'))
    assert job['runtime_code_sha256']==science and job['stage']=='train'
    assert len(job['cases'])==1 and item['max_updates_per_case']==2000
    target,arch,bank=tid.split('__')
    assert config['architecture']==arch and config['steps']==2000 and config['seed']==11
    assert config['lr']==1e-4 and config['checkpoints']==[500,1000,2000]
    assert config['pairs_per_class']==128 and config['init_sha256']==init[arch]
    assert config['source']['id']==module.TARGETS[target]
    assert config['source']==configs[f'{target}__'+('L' if arch=='S' else 'S')+f'__{bank}']['source']
    rows.append({'track':tid,'job_sha256':sha(P/(tid+'.JOB.json')),'config_sha256':sha(P/(tid+'.json')),
                 'source':config['source']['id'],'training_bank_count':len(config['source']['bank_indices'])})
record={'status':'TWELVE_REAL_TRAIN_CANDIDATES_ACCEPTED_NOT_EXECUTION_RELEASE',
        'utc':datetime.now(timezone.utc).isoformat(),'compiler_sha256':sha(V/'build_phase1.py'),
        'candidates':{'path':str(P/'CANDIDATES.json'),'sha256':sha(P/'CANDIDATES.json')},
        'bindings_sha256':sha(bindings),'root_replayed_regressions':8,
        'exact_one_guard_change':True,'frozen_scientific_runtime_unchanged':True,
        'root_independently_recompiled':True,'tracks':rows,
        'formal_execution_release':False,'next':'Bind exact production batch, deployment, per-job runtime releases and serial driver; then controller execution release.'}
output=D/'CONTROLLER_PHASE1_V2_REAL_TRAIN_CANDIDATES_ACCEPTANCE.json'
output.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'acceptance_sha256':sha(output),'compiler_sha256':record['compiler_sha256'],
                  'candidates_sha256':record['candidates']['sha256'],'tracks':len(rows)}))
