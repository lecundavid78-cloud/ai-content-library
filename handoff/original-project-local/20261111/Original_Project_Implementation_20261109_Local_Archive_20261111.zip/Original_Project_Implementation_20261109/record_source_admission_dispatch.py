from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

D=Path(__file__).resolve().parent
C=D.parent/'Framework_Convergence_Review_20261109/Continuity_20261109'
now=datetime.now(timezone.utc).isoformat()
def read(p): return json.loads(p.read_bytes())
def write(p,o): p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
release=D/'CONTROLLER_PHASE1_SOURCE_ADMISSION_CPU_EXECUTION_RELEASE.json'
row={'role':'R02','turn':'01a1c4bb-2c4c-7670-ba93-e1a7b6486e31',
     'status':'EXACT_CPU_EXECUTION_RELEASE_DISPATCHED_AWAIT_ACTUAL_ID',
     'release':str(release),'sha256':hashlib.sha256(release.read_bytes()).hexdigest(),
     'resources':{'CPU':4,'memory_GiB':32,'seconds':1800,'GPU':0},
     'formal_training':False,'updated_utc':now}
status=read(D/'CONTROL_STATUS.json')
status.update(updated_utc=now,phase='SOURCE_FORMAL_ADMISSION_CPU_RELEASE_DISPATCHED',
              stage='SOURCE_FORMAL_ADMISSION_CPU_RELEASE_DISPATCHED',
              training_jobs_submitted=0,training_admission=False)
status['phase1_formal_source_admission']=row
status['next_actions']=['Collect this exact CPU job and actual six admissions.',
                       'Bind real derived caches and existing clean initializations into twelve training configurations.',
                       'After exact production checks, release the serial single-GPU training queue.']
write(D/'CONTROL_STATUS.json',status)
dispatch=read(D/'DISPATCH_RECEIPTS.json');dispatch['phase1_formal_source_admission']=row
write(D/'DISPATCH_RECEIPTS.json',dispatch)
log=D/'DECISION_LOG.md'
text='\n\n11月10日17:13 SGT核验两份正式INIT及24件来源暂存均完成。六格CUDA资格通过。来源缓存CPU派生候选已逐件与冻结科学代码比对、5项检查通过，签发4CPU/32GiB/30分钟/0GPU一次实际任务，仅产生正式SOURCE副本及六份跨度准入，父文件与张量不变。30分钟上限给实际指纹/派生/复载检查保留余量。已交原R02执行，同时预接12条正式训练配置；尚无本CPU真实受理ID，正式训练仍为0。\n'
for name in ('CURRENT_STATUS.md','HAND_BACK.md','DECISION_LOG.md'):
    with (D/name).open('a',encoding='utf-8') as f:f.write(text)
p=C/'PROJECT_STATE.json';continuity=read(p)
continuity.update(phase=status['phase'],last_updated_utc=now,active_stage=str(D),
                  next_safe_action=str(release),formal_training_release=False,
                  execution_readiness='All six CUDA qualification cells passed; both formal clean initializations accepted; 24 source input files staged. Exact CPU formal-source derivation released to original R02. Await actual job/six admissions, then compile and release twelve training trajectories. No formal training submitted yet.')
continuity['current_review_scope']='Original-project finite single-source implementation and authorized execution; obsolete teaching and quota pointers are historical.'
continuity['source_admission_cpu_dispatch']=row
write(p,continuity)
print(json.dumps({'updated_utc':now,'stage':status['stage'],'training_jobs':0}))
