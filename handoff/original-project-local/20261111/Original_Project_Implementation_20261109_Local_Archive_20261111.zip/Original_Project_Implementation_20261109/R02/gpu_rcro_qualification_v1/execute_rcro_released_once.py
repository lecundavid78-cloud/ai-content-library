"""Verify, submit at most once, and collect the controller's exact GPU qualification."""
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
SOURCE = PROJECT.parent.parent



def need(ok, message):
    if not ok:
        raise ValueError(message)


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def dump(path, value):
    with path.open("x", encoding="utf-8") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def verified_plan(release_sha):
    release = (PROJECT / "CONTROLLER_EXACT_GPU_RCRO_QUALIFICATION_EXECUTION_RELEASE.json").read_bytes()
    need(sha(release) == release_sha, "controller release SHA mismatch")
    r = json.loads(release)
    need(r["status"] == "RELEASED_EXACT_GPU_RCRO_QUALIFICATION_ONLY" and r["scope"] == {
        "gpu": 1, "cpu": 8, "memory_gib": 64, "slurm_seconds": 3600, "max_submissions": 1,
        "max_optimizer_updates": 4, "formal_training": False, "target_labels": False,
        "automatic_retry": False,
    }, "controller GPU scope")
    for name in ("cpu_acceptance", "signed_package", "unsigned_package", "outer_release", "inner_release"):
        ref = r[name]
        blob = Path(ref["path"]).read_bytes()
        need(sha(blob) == ref["sha256"] and len(blob) == ref["bytes"], "signed reference changed: " + name)
    intent = json.loads((HERE / "SUBMISSION_INTENT_NOT_RELEASED.json").read_bytes())
    for key in ("unsigned_package", "scope", "job_sha256", "sbatch_sha256", "exact_remote_root",
                "local_submission_claim", "remote_submission_claim", "allocation_claim"):
        need(r[key] == intent[key], "candidate intent mismatch: " + key)
    expected_inner = json.loads((HERE / "R05_ROOT_RELEASE_NOT_RELEASED.json").read_bytes())
    expected_outer = json.loads((HERE / "GPU_ACTION_RELEASE_NOT_RELEASED.json").read_bytes())
    need(json.loads(Path(r["inner_release"]["path"]).read_bytes()) == expected_inner | {"status": "RELEASED"}, "exact inner release scope")
    need(json.loads(Path(r["outer_release"]["path"]).read_bytes()) == expected_outer | {"status": "RELEASED", "inner_sha256": r["inner_release"]["sha256"]}, "exact outer release scope")
    release_paths = {"control/GPU_ACTION_RELEASE.json": r["outer_release"],
                     "control/R05_ROOT_RELEASE.json": r["inner_release"]}
    with zipfile.ZipFile(r["signed_package"]["path"]) as signed, zipfile.ZipFile(r["unsigned_package"]["path"]) as original:
        names = signed.namelist()
        need(len(names) == len(set(names)) == len(original.namelist()) + len(release_paths) and signed.testzip() is None, "signed ZIP integrity")
        need(set(names) == set(original.namelist()) | release_paths.keys(), "extra signed payload")
        need(all(signed.read(name) == original.read(name) for name in original.namelist()), "candidate bytes changed")
        for name in names:
            rel = PurePosixPath(name)
            need(not rel.is_absolute() and ".." not in rel.parts and "\\" not in name, "invalid path")
        for name, ref in release_paths.items():
            need(signed.read(name) == Path(ref["path"]).read_bytes(), "release bytes changed")
        need(sha(signed.read("gpu_qualification.sbatch")) == r["sbatch_sha256"], "sbatch SHA")
        need(sha(signed.read("control/JOB.json")) == r["job_sha256"], "JOB SHA")
        lock = json.loads(signed.read("control/GPU_DEPLOYMENT_LOCK.json"))
        imports = json.loads(signed.read("control/IMPORT_LOCK.json"))
        files = {name: sha(signed.read(name)) for name in names}
    need(lock["env"]["R02_RUN_ROOT"] == r["exact_remote_root"] == "/public/home/s20223010065/RFduffision/Original_Project_Implementation_20261109/gpu_rcro_qualification_v1", "run root mismatch")
    need(Path(r["local_submission_claim"]) == HERE / ".submit_intent", "local intent mismatch")
    need(r["remote_submission_claim"] == r["exact_remote_root"] + "/.submit_intent", "remote intent mismatch")
    return {"release": r, "lock": lock, "imports": imports, "files": files, "controller_release_sha256": release_sha}


COMMON = r'''
from pathlib import Path
import base64, datetime, hashlib, io, json, os, re, shutil, socket, subprocess, zipfile

r = PLAN["release"]
R = Path(r["exact_remote_root"])
S = "/public/gridview_20250224/slurm/bin/"
user = "s20223010065"
name = "OriginalProject_GPUqual_RCRO_20261110"
fields = "JobIDRaw,JobName%100,State%40,ExitCode,ElapsedRaw,AllocTRES%150,WorkDir%300,User,Start,End"

def cmd(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=40)
    if p.returncode:
        raise RuntimeError(repr((args, p.returncode, p.stderr)))
    return p.stdout

def sha_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()

def write_new(path, value):
    with path.open("x", encoding="utf-8") as f:
        json.dump(value, f, indent=2)
        f.write("\n")

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

assert cmd(["id", "-un"]).strip() == user

def discover():
    account = cmd([S+"sacct", "-X", "-n", "-P", "-S", "2026-11-09", "-u", user,
                   "--name", name, "--format="+fields])
    queue = cmd([S+"squeue", "-h", "-u", user, "-o", "%i|%j|%T|%b"])
    return account, queue

def readiness():
    account, queue = discover()
    receipt = {"utc":utc(),"hostname":socket.gethostname(),"sacct_exact":account,
               "active_queue":queue,"root_exists":R.exists(),"intent_exists":(R/".submit_intent").exists(),
               "allocation_claim_exists":(R/".gpu_allocation_claim").exists()}
    conflicts = []
    for line in queue.splitlines():
        job, job_name, state, gres = line.split("|")
        if job_name == name or "gpu" in gres.lower():
            conflicts.append(line)
    receipt["conflicts"] = conflicts
    if R.exists() or account.strip() or conflicts:
        receipt["status"] = "STOP_RECONCILE_OR_WAIT_FOR_GPU"
        return receipt
    env = PLAN["lock"]["env"]
    for key in ("R02_RUNTIME_ENV","R02_BASE_ENV","R02_SIF","R02_SINGULARITY","R02_MODELROOT","R02_EXISTING2048"):
        assert os.access(env[key], os.R_OK), key
    assert os.access(env["R02_SINGULARITY"], os.X_OK)
    for binding in PLAN["imports"]["files"].values():
        assert sha_file(Path(binding["path"])) == binding["sha256"], "existing library bytes changed"
    partition_gres = cmd([S+"sinfo","-h","-p","Gnode","-o","%G"])
    assert "NVIDIAA800-SXM4-80GB" in partition_gres, "frozen A800 type unavailable in partition"
    receipt.update(status="READY_FOR_SINGLE_SUBMIT", partition_gres=partition_gres,
                   disk_free_bytes=shutil.disk_usage(R.parent).free, verified_existing_library_files=4)
    return receipt
'''

PRECHECK = COMMON + r'''
print(json.dumps(readiness()))
'''

SUBMIT = COMMON + r'''
preflight = readiness()
if preflight["status"] != "READY_FOR_SINGLE_SUBMIT":
    print(json.dumps(preflight))
    raise SystemExit(0)
assert preflight["disk_free_bytes"] >= 8 * 1024**3, "insufficient free storage for qualification artifacts"
blob = base64.b64decode(PLAN["archive"])
assert hashlib.sha256(blob).hexdigest() == r["signed_package"]["sha256"]
z = zipfile.ZipFile(io.BytesIO(blob))
assert z.testzip() is None and len(z.namelist()) == len(PLAN["files"])
assert set(z.namelist()) == set(PLAN["files"])
for n, digest in PLAN["files"].items():
    p = Path(n)
    assert not p.is_absolute() and ".." not in p.parts and "\\" not in n
    assert hashlib.sha256(z.read(n)).hexdigest() == digest
os.umask(0o077)
R.mkdir(exist_ok=False)
for n, digest in PLAN["files"].items():
    p = R/n
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("xb") as f:
        f.write(z.read(n))
    assert sha_file(p) == digest
logs = R/"logs"
logs.mkdir()
release_sha = r["outer_release"]["sha256"]
args = [S+"sbatch","--parsable","--chdir="+str(R),"--output="+str(logs/"gpu-%j.out"),
        "--error="+str(logs/"gpu-%j.err"),"--export=ALL,R02_RELEASE_SHA256="+release_sha,
        str(R/"gpu_qualification.sbatch")]
intent = {"utc":utc(),"preflight":preflight,"root":str(R),"command":args,
          "scope":r["scope"],"controller_release_sha256":PLAN["controller_release_sha256"],
          "signed_archive_sha256":r["signed_package"]["sha256"],"outer_sha256":release_sha,
          "inner_sha256":r["inner_release"]["sha256"],"sbatch_sha256":r["sbatch_sha256"]}
write_new(R/".submit_intent", intent)
result = {"status":"SUBMIT_STARTED_RECONCILE_BEFORE_ANY_ACTION","intent":intent}
write_new(R/"SUBMISSION_ATTEMPT.json",result)
p = subprocess.run(args,cwd=R,capture_output=True,text=True,timeout=40)
result.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
if p.returncode == 0 and re.fullmatch(r"[0-9]+(?:;[^\s;]+)?",p.stdout.strip()):
    result.update(status="EXACT_GPU_QUALIFICATION_SBATCH_ACCEPTED_NOT_PASS",job_id=p.stdout.strip().split(";")[0])
else:
    result["status"] = "SBATCH_NONZERO_OR_AMBIGUOUS_RECONCILE_NO_RETRY"
write_new(R/"SUBMISSION_RECEIPT.json",result)
print(json.dumps(result))
'''

COLLECT = COMMON + r'''
job = PLAN["job_id"]
if job is None:
    account, queue = discover()
    candidates = {row.split("|")[0] for row in account.splitlines()}
    candidates.update(row.split("|")[0] for row in queue.splitlines() if row.split("|")[1] == name)
    receipt = R/"SUBMISSION_RECEIPT.json"
    if receipt.exists():
        accepted = json.loads(receipt.read_bytes()).get("job_id")
        if accepted:
            candidates.add(accepted)
    if len(candidates) != 1:
        print(json.dumps({"status":"NO_UNIQUE_ACCEPTED_JOB","sacct":account,"queue":queue,"candidates":sorted(candidates)}))
        raise SystemExit(0)
    job = candidates.pop()
assert job.isdigit()
sacct = cmd([S+"sacct","-X","-n","-P","-j",job,"--format="+fields])
rows = [line.split("|") for line in sacct.splitlines()]
assert len(rows) <= 1
if not rows:
    queue = cmd([S+"squeue","-h","-j",job,"-o","%i|%j|%T|%R"])
    print(json.dumps({"status":"PENDING_ACCOUNTING","job_id":job,"queue":queue}))
    raise SystemExit(0)
row = rows[0]
assert (row[0],row[1],row[6],row[7]) == (job,name,str(R),user), "accounting identity mismatch"
state = row[2].split()[0].rstrip("+")
terminal = state in ("COMPLETED","FAILED","TIMEOUT","CANCELLED","OUT_OF_MEMORY","NODE_FAIL","PREEMPTED","BOOT_FAIL","DEADLINE","REVOKED")
out = R/("output-"+job)
cells = sorted(str(p.relative_to(out)) for p in out.glob("qualification/*/*/QUALIFICATION.json"))
data = {"status":"TERMINAL" if terminal else "ACTIVE","utc":utc(),"job_id":job,"state":state,
        "exit_code":row[3],"elapsed_seconds":int(row[4] or 0),"alloc_tres":row[5],"sacct":sacct,
        "terminal":terminal,"cells":cells,"files":[]}
if not terminal:
    data["queue"] = cmd([S+"squeue","-h","-j",job,"-o","%i|%j|%T|%R"])
    if state == "PENDING":
        forecast = subprocess.run([S+"squeue","--start","-h","-j",job,
                                  "-o","%i|%S|%R"],capture_output=True,text=True,timeout=20)
        data["scheduler_start_forecast"] = {"returncode":forecast.returncode,
                                            "stdout":forecast.stdout,"stderr":forecast.stderr}
if terminal:
    data["deployment_unchanged"] = all(sha_file(R/n) == v for n,v in PLAN["files"].items())
    selected = [R/".submit_intent", R/"SUBMISSION_ATTEMPT.json", R/"SUBMISSION_RECEIPT.json",
                R/".gpu_allocation_claim/job_id"] + list((R/"logs").glob("gpu-"+job+".*"))
    if out.exists():
        selected += [p for p in out.rglob("*") if p.is_file() and p.relative_to(out).parts[0]
                     not in {"home","tmp","hf_local","hf_modules",".cache"} and "__pycache__" not in p.parts
                     and not {"hf_modules","hf_local"}.intersection(p.relative_to(out).parts)]
        native = out/"qualification/NATIVE_LOAD.json"
        if native.exists():
            for load in json.loads(native.read_bytes()).values():
                runtime_path = Path(load["actual_model_source"])
                assert runtime_path.is_relative_to(Path("/out"))
                actual = out/runtime_path.relative_to(Path("/out"))
                selected += [actual, actual.with_name("configuration_prosst.py")]
    total = 0
    for p in sorted(set(selected)):
        if not p.is_file():
            continue
        assert p.resolve().is_relative_to(R.resolve())
        size = p.stat().st_size
        f = {"path":p.relative_to(R).as_posix(),"remote_path":str(p),"bytes":size,"sha256":sha_file(p)}
        if size <= 16*1024**2 and p.suffix != ".pt":
            total += size
            assert total <= 80*1024**2
            f["content"] = base64.b64encode(p.read_bytes()).decode()
        data["files"].append(f)
print(json.dumps(data))
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("check", "precheck", "submit", "collect"))
    parser.add_argument("--job")
    parser.add_argument("--release-sha256", required=True)
    args = parser.parse_args()
    plan = verified_plan(args.release_sha256)
    if args.action == "check":
        for code in (PRECHECK, SUBMIT, COLLECT):
            compile(code, "<remote>", "exec")
        print(json.dumps({"status":"LOCAL_SIGNED_DEPLOYMENT_PASS","files":len(plan["files"])}))
        return
    path = SOURCE / "Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2"
    sys.path.insert(0, str(path))
    from remote_qualification import SSH, PYTHON
    claim = Path(plan["release"]["local_submission_claim"])
    if args.action == "submit":
        precheck = json.loads((HERE / "GPU_REMOTE_PRECHECK.json").read_bytes())
        need(precheck["status"] == "READY_FOR_SINGLE_SUBMIT", "readiness check required")
        dump(claim, {k: plan["release"][k] for k in ("signed_package", "exact_remote_root",
             "outer_release", "inner_release", "sbatch_sha256", "scope")})
        plan["archive"] = base64.b64encode(Path(plan["release"]["signed_package"]["path"]).read_bytes()).decode()
    if args.action == "collect":
        need(args.job is None or args.job.isdecimal(), "numeric Slurm job ID required")
        plan["job_id"] = args.job
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    code = {"submit": SUBMIT, "precheck": PRECHECK, "collect": COLLECT}[args.action]
    proc = subprocess.run(SSH + [PYTHON], input=("PLAN="+repr(plan)+"\n"+code).encode(),
                          capture_output=True, timeout=240)
    (HERE / (stamp+"_"+args.action+".stderr")).write_bytes(proc.stderr)
    if proc.returncode:
        (HERE / (stamp+"_"+args.action+".stdout")).write_bytes(proc.stdout)
        raise SystemExit(proc.stderr.decode(errors="replace").splitlines()[-14:])
    data = json.loads(proc.stdout)
    if args.action != "collect":
        (HERE / (stamp+"_"+args.action+".stdout")).write_bytes(proc.stdout)
        target = HERE / ("GPU_SUBMISSION_RECEIPT.json" if args.action == "submit" else "GPU_REMOTE_PRECHECK.json")
    else:
        target_dir = HERE / ("GPU_JOB_" + data.get("job_id", "UNKNOWN"))
        target_dir.mkdir(exist_ok=True)
        for entry in data.get("files", []):
            if "content" not in entry:
                continue
            value = base64.b64decode(entry.pop("content"))
            need(len(value) == entry["bytes"] and sha(value) == entry["sha256"], "returned artifact identity")
            rel = Path(entry["path"])
            need(not rel.is_absolute() and ".." not in rel.parts, "unsafe returned relative path")
            dest = target_dir / "run" / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            if dest.exists():
                need(sha(dest.read_bytes()) == entry["sha256"], "previous receipt differs")
            else:
                dest.write_bytes(value)
        target = target_dir / (stamp+"_COLLECTION.json")
    dump(target, data)
    print(json.dumps({"receipt":str(target),"sha256":sha(target.read_bytes()),"status":data["status"],
                      "job_id":data.get("job_id"),"state":data.get("state"),"elapsed_seconds":data.get("elapsed_seconds"),
                      "cells":len(data.get("cells",[])),"conflicts":data.get("conflicts"),
                      "forecast":data.get("scheduler_start_forecast")}))


if __name__ == "__main__":
    main()
