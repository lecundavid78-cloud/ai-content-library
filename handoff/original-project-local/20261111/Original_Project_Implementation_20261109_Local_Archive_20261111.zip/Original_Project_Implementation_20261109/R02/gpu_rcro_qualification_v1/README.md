# RCRO GPU 资格补验候选

只运行 RCRO 的 S 和 LoRA。每格执行两次原资格更新，使用原签发包中的前两批、原生六成员、数值设置和完整验收。7 个 RCRO 输入逐字节继承。Spencer 和 HSP82 已验收的四格复用。旧作业 5217253 的 RCRO 部分没有通过回执，保留为历史证据。本候选没有正式训练、真实功能数值表或目标标签。

隔离包中的 `runtime_contract.py` 只允许单来源 RCRO CUDA 资格动作，拒绝旧放行身份，严格核对 3,300 秒与每格 2 次更新。`native_runtime.py` 仅修改汇总状态与前缀前向记账。原生加载、模型、评分、梯度、恢复、导出和阈值沿用原件。其余代码、输入和 native/import 锁保持原字节。完整变更和文件哈希见补丁与清单。

资源为单 A800、8 CPU、64 GiB。Slurm 上限 3,600 秒，容器 timeout 在 3,480 秒发 TERM，20 秒后可强制终止。R05 内部 3,300 秒从前置验证后起算。最终使用 `sacct` 核算，不用上限冒充实耗。新运行根及提交、分配 claim 见 intent。总控审查后按下列顺序签发。

1. 使用内层模板，将 `status` 改为 `RELEASED`，保存并计算 SHA256。
2. 使用外层模板，将 `status` 改为 `RELEASED`，填入实际内层 SHA256，保存并计算外层 SHA256。
3. 仅把两份放行文件追加到未签 ZIP，路径为 `control/R05_ROOT_RELEASE.json` 和 `control/GPU_ACTION_RELEASE.json`。签包字节全部锁定。控制文件沿用父放行记录字段，用本轮 intent 覆盖资源及路径，设 `status=RELEASED_EXACT_GPU_RCRO_QUALIFICATION_ONLY`，填写已签 ZIP 和双放行文件的 path、SHA256、bytes。保存为项目根 `CONTROLLER_EXACT_GPU_RCRO_QUALIFICATION_EXECUTION_RELEASE.json`。
4. 仅取得精确签发后，部署器以 `check --release-sha256 <总控文件SHA>` 本地核验签名顺序及完整集合，再按受控流程检查远端并提交一次。已有 claim、既有同名记录或返回不明时先只读对账。此包未获得部署放行。

验收预期为 RCRO S/L 两份通过回执、4 次更新、6 次 native 完整前缀前向、12 次 scorer 调用、72 次成员 head 调用、每格 1,197 个完整 19L 输出。需验证部署和实际导入身份、梯度与冻结、前缀与恢复游标、RAW/CSV 和 Slurm 终态。新两格通过后才能与旧四格一起复核。CPU 本地测试只覆盖包和门控，未验证 CUDA。
