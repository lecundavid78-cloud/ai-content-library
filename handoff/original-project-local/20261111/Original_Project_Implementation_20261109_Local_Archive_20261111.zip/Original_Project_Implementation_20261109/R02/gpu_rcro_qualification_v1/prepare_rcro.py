"""Build the isolated RCRO qualification candidate from the exact signed parent."""
import difflib
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
OLD = HERE.parent / "gpu_qualification_v1"
SOURCE = "RCRO_LAMBD_Tsuboyama_2023_1ORC"
PARENT_SHA = "68a97075283239e93dee3d59ee91116ef9e8e955462bf04c8148085789da3634"
REVIEW_SHA = "9781affa2445f7e1de410ef20e84e853b758455c92d8276cb73d9204461a1594"
NEW_ROOT = "gpu_rcro_qualification_v1"
NEW_JOB = "OriginalProject_GPUqual_RCRO_20261110"
OUTER_SCHEMA = "R02_EXACT_GPU_RCRO_QUALIFICATION_RELEASE_V1"
INNER_SCHEMA = "SINGLE_SOURCE_RUNTIME_RCRO_QUALIFICATION_RELEASE_V1"
SUMMARY = "RCRO_TWO_CELL_PASS_NOT_FORMAL_TRAINING"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def write(name, value):
    (HERE / name).write_bytes(encode(value))


def replace(data, edits):
    for old, new in edits:
        old, new = old.encode(), new.encode()
        if b"\r\n" in data:
            old, new = old.replace(b"\n", b"\r\n"), new.replace(b"\n", b"\r\n")
        if data.count(old) != 1:
            raise ValueError(f"Unexpected parent bytes for {old!r}")
        data = data.replace(old, new)
    return data


def main():
    parent = PROJECT / "GPU_QUALIFICATION_SIGNED_V1.zip"
    review = PROJECT / "CONTROLLER_GPU_TERMINAL_REVIEW_5217253.json"
    assert sha(parent.read_bytes()) == PARENT_SHA and sha(review.read_bytes()) == REVIEW_SHA
    reviewed = json.loads(review.read_bytes())
    assert reviewed["job_id"] == "5217253" and len(reviewed["successful_cells"]) == 4
    assert reviewed["rcro_S_acceptance_missing"] and reviewed["rcro_L_acceptance_missing"]
    with zipfile.ZipFile(parent) as z:
        assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 84
        prior = {name: z.read(name) for name in z.namelist()}
    retained_controls = {"control/" + n for n in ("IMPORT_LOCK.json", "NATIVE_LOCK.json",
                         "QUALIFICATION_SOURCE_ROLE_CONTRACT.md")}
    files = {n: b for n, b in prior.items() if n.startswith(("code/", f"inputs/{SOURCE}/"))
             or n in retained_controls}
    contract = "code/runtime_contract.py"
    files[contract] = replace(prior[contract], [
        ("def preflight(job_path,code_root):",
         f"def qualification_scope(job):\n    need(job['stage']=='qualify' and job['device']=='cuda',"
         f"'RCRO CUDA qualification only')\n    cases=job['cases']\n    need(isinstance(cases,list) "
         f"and len(cases)==1 and cases[0]['source_id']=='{SOURCE}','exactly one RCRO case')\n\n\ndef preflight(job_path,code_root):"),
        ("    root=Path(code_root).resolve()", "    qualification_scope(job)\n    root=Path(code_root).resolve()"),
        ("        need(len(cases)==3 and {c['source_id'] for c in cases}==SOURCES,'three admitted sources exactly once; both architectures run internally')\n", ""),
        ("and set(materials['sources'])==SOURCES", f"and set(materials['sources'])=={{'{SOURCE}'}}"),
        ("    r=read(release_path)", "    qualification_scope(job)\n    r=read(release_path)"),
        ("r['schema']=='SINGLE_SOURCE_RUNTIME_RELEASE_V1'", f"r['schema']=='{INNER_SCHEMA}'"),
        ("0<r['wall_seconds']<=1800,'bounded qualification/runtime wall <=1800 seconds'",
         "r['wall_seconds']==3300,'exact RCRO qualification wall 3300 seconds'"),
        ("need(r['max_updates_per_case']==(2 if job['stage']=='qualify' else 0 if job['stage'] in ('init','predict') else read(bound(job['cases'][0]['config']))['steps']),'stage update cap')",
         "need(type(r['max_updates_per_case']) is int and r['max_updates_per_case']==2,'stage update cap')"),
    ])
    native = "code/native_runtime.py"
    files[native] = replace(prior[native], [
        ("THREE_SOURCE_SIX_CELL_PASS_NOT_FORMAL_TRAINING", SUMMARY),
        ("'actual_native_prefix_full_forwards':18", "'actual_native_prefix_full_forwards':len(checked)*len(members)"),
    ])
    material = json.loads(prior["control/MATERIAL_LOCK.json"])
    material["sources"] = {SOURCE: material["sources"][SOURCE]}
    files["control/MATERIAL_LOCK.json"] = encode(material)
    job = json.loads(prior["control/JOB.json"])
    job["cases"] = [x for x in job["cases"] if x["source_id"] == SOURCE]
    job["material_lock"]["sha256"] = sha(files["control/MATERIAL_LOCK.json"])
    job["runtime_code_sha256"] = {n[5:]: sha(b) for n, b in files.items()
                                 if n.startswith("code/") and n.endswith(".py")}
    files["control/JOB.json"] = encode(job)
    launcher = "control/gpu_action_launcher.py"
    files[launcher] = replace(prior[launcher], [
        ("R02_EXACT_GPU_QUALIFICATION_RELEASE_V1", OUTER_SCHEMA),
        ("SINGLE_SOURCE_RUNTIME_RELEASE_V1", INNER_SCHEMA),
        ('"slurm_seconds": 1200', '"slurm_seconds": 3600'),
        ('"wall_seconds": 1080', '"wall_seconds": 3300'),
        ('"max_updates": 12', '"max_updates": 4'),
        ('    require(not (root / "out/qualification").exists()',
         f'    require([case["source_id"] for case in job["cases"]] == ["{SOURCE}"], "exact RCRO only")\n'
         '    require(not (root / "out/qualification").exists()'),
    ])
    batch = "gpu_qualification.sbatch"
    files[batch] = replace(prior[batch], [
        ("OriginalProject_GPUqual_20261109", NEW_JOB),
        ("/gpu_qualification_v1\n", f"/{NEW_ROOT}\n"),
        ("00:20:00", "01:00:00"),
        ('"Slurm_cap_seconds":1200', '"Slurm_cap_seconds":3600'),
        ("--kill-after=20 1140", "--kill-after=20 3480"),
    ])
    lock = json.loads(prior["control/GPU_DEPLOYMENT_LOCK.json"])
    root = lock["env"]["R02_RUN_ROOT"].rsplit("/", 1)[0] + "/" + NEW_ROOT
    lock["env"]["R02_RUN_ROOT"] = root
    lock.update(sbatch_sha256=sha(files[batch]), Slurm_seconds=3600, container_seconds=3480,
                R05_alarm_seconds=3300, parent_signed_sha256=PARENT_SHA, terminal_review_sha256=REVIEW_SHA)
    deploy_lock = "control/GPU_DEPLOYMENT_LOCK.json"
    files[deploy_lock] = encode(lock)
    manifest = "control/GPU_PAYLOAD_SHA256.json"
    files[manifest] = encode({"schema": "R02_GPU_MOUNTED_BYTES_V1",
                             "files": {n: sha(b) for n, b in sorted(files.items()) if n != batch}})
    unsigned = HERE / "GPU_RCRO_QUALIFICATION_UNSIGNED_V1.zip"
    with zipfile.ZipFile(unsigned, "w") as z:
        for n, b in sorted(files.items()):
            z.writestr(zipfile.ZipInfo(n, (2026, 11, 10, 0, 0, 0)), b, compress_type=zipfile.ZIP_DEFLATED)
    with zipfile.ZipFile(unsigned) as z:
        assert z.testzip() is None and all(z.read(n) == b for n, b in files.items())
    inner = json.loads(prior["control/R05_ROOT_RELEASE.json"])
    inner.update(schema=INNER_SCHEMA, status="NOT_RELEASED", wall_seconds=3300,
                 job_sha256=sha(files["control/JOB.json"]))
    outer = json.loads(prior["control/GPU_ACTION_RELEASE.json"])
    outer.update(schema=OUTER_SCHEMA, status="NOT_RELEASED", slurm_seconds=3600,
                 max_updates=4, inner_sha256=None, job_sha256=inner["job_sha256"],
                 launcher_sha256=sha(files[launcher]), manifest_sha256=sha(files[manifest]),
                 deployment_lock_sha256=sha(files[deploy_lock]))
    write("R05_ROOT_RELEASE_NOT_RELEASED.json", inner)
    write("GPU_ACTION_RELEASE_NOT_RELEASED.json", outer)
    scope = dict(gpu=1, cpu=8, memory_gib=64, slurm_seconds=3600, max_submissions=1,
                 max_optimizer_updates=4, formal_training=False, target_labels=False, automatic_retry=False)
    write("SUBMISSION_INTENT_NOT_RELEASED.json", {
        "status": "NOT_RELEASED", "controller": outer["controller"],
        "exact_remote_root": root, "exact_job_name": NEW_JOB,
        "remote_submission_claim": root + "/.submit_intent",
        "allocation_claim": root + "/.gpu_allocation_claim",
        "local_submission_claim": str(HERE / ".submit_intent"), "scope": scope,
        "unsigned_package": {"path": str(unsigned), "sha256": sha(unsigned.read_bytes()),
                             "bytes": unsigned.stat().st_size},
        "signed_package": None, "outer_release": None, "inner_release": None,
        "job_sha256": inner["job_sha256"], "sbatch_sha256": lock["sbatch_sha256"],
        "container_seconds": 3480, "internal_seconds": 3300, "submit_allowed": False})
    write("PACKAGE_MANIFEST.json", {
        "parent_archive_sha256": PARENT_SHA, "controller_terminal_review_sha256": REVIEW_SHA,
        "prior_cells_reused": reviewed["successful_cells"], "prior_partial_rcro_is_pass": False,
        "unsigned_count": len(files), "signed_count_expected": len(files) + 2,
        "files": {n: {"sha256": sha(b), "bytes": len(b)} for n, b in sorted(files.items())},
        "changed": sorted(n for n, b in files.items() if n in prior and prior[n] != b),
        "removed": sorted(prior.keys() - files.keys()), "scope": scope})
    diff = []
    for name in (contract, native, launcher, batch):
        diff.extend(difflib.unified_diff(prior[name].decode().splitlines(True), files[name].decode().splitlines(True),
                                         "parent/" + name, "rcro/" + name))
    (HERE / "RCRO_QUALIFICATION.patch").write_bytes("".join(diff).encode())
    wrapper = replace((OLD / "execute_released_once.py").read_bytes(), [
        ('RELEASE_SHA = "940b0d020480523a2d2f896514977897abed96615f7d60e29f8ebde4998ecb04"', ''),
        ('def verified_plan():', 'def verified_plan(release_sha):'),
        ('CONTROLLER_EXACT_GPU_QUALIFICATION_EXECUTION_RELEASE.json', 'CONTROLLER_EXACT_GPU_RCRO_QUALIFICATION_EXECUTION_RELEASE.json'),
        ('sha(release) == RELEASE_SHA', 'sha(release) == release_sha'),
        ('"controller_release_sha256": RELEASE_SHA', '"controller_release_sha256": release_sha'),
        ('"RELEASED_EXACT_GPU_QUALIFICATION_ONLY"', '"RELEASED_EXACT_GPU_RCRO_QUALIFICATION_ONLY"'),
        ('"slurm_seconds": 1200', '"slurm_seconds": 3600'),
        ('"max_optimizer_updates": 12', '"max_optimizer_updates": 4'),
        ('OriginalProject_GPUqual_20261109', NEW_JOB),
        ('    plan = verified_plan()', '    plan = verified_plan(args.release_sha256)'),
        ('    parser.add_argument("--job")', '    parser.add_argument("--job")\n    parser.add_argument("--release-sha256", required=True)'),
        ('    need(lock["env"]["R02_RUN_ROOT"] == r["exact_remote_root"], "run root mismatch")',
         f'    need(lock["env"]["R02_RUN_ROOT"] == r["exact_remote_root"] == "{root}", "run root mismatch")'),
        ('    release_paths = {"control/GPU_ACTION_RELEASE.json": r["outer_release"],',
         '    intent = json.loads((HERE / "SUBMISSION_INTENT_NOT_RELEASED.json").read_bytes())\n'
         '    for key in ("unsigned_package", "scope", "job_sha256", "sbatch_sha256", "exact_remote_root",\n'
         '                "local_submission_claim", "remote_submission_claim", "allocation_claim"):\n'
         '        need(r[key] == intent[key], "candidate intent mismatch: " + key)\n'
         '    expected_inner = json.loads((HERE / "R05_ROOT_RELEASE_NOT_RELEASED.json").read_bytes())\n'
         '    expected_outer = json.loads((HERE / "GPU_ACTION_RELEASE_NOT_RELEASED.json").read_bytes())\n'
         '    need(json.loads(Path(r["inner_release"]["path"]).read_bytes()) == expected_inner | {"status": "RELEASED"}, "exact inner release scope")\n'
         '    need(json.loads(Path(r["outer_release"]["path"]).read_bytes()) == expected_outer | {"status": "RELEASED", "inner_sha256": r["inner_release"]["sha256"]}, "exact outer release scope")\n'
         '    release_paths = {"control/GPU_ACTION_RELEASE.json": r["outer_release"],'),
    ])
    (HERE / "execute_rcro_released_once.py").write_bytes(wrapper)


if __name__ == "__main__":
    main()
