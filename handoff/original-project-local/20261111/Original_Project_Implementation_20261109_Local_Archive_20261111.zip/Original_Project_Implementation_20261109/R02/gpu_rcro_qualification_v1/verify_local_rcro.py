"""Exercise the exact isolated release guards with disposable fixtures, without model or SSH."""
import ast
import json
import os
from pathlib import Path
import tempfile
import unittest
import zipfile

import execute_rcro_released_once as deploy
from prepare_rcro import HERE, SOURCE, encode, sha


def need(ok, message):
    if not ok:
        raise ValueError(message)


class ScopeChecks(unittest.TestCase):
    def setUp(self):
        temp = tempfile.TemporaryDirectory()
        self.addCleanup(temp.cleanup)
        self.root = Path(temp.name)
        with zipfile.ZipFile(HERE / "GPU_RCRO_QUALIFICATION_UNSIGNED_V1.zip") as archive:
            archive.extractall(self.root)
        self.control = self.root / "control"
        self.job_path = self.control / "JOB.json"
        self.job = json.loads(self.job_path.read_bytes())
        self.inner = json.loads((HERE / "R05_ROOT_RELEASE_NOT_RELEASED.json").read_bytes()) | {"status": "RELEASED"}
        self.outer = json.loads((HERE / "GPU_ACTION_RELEASE_NOT_RELEASED.json").read_bytes()) | {"status": "RELEASED"}
        self.launch = {"__name__": "fixture"}
        exec(compile((self.control / "gpu_action_launcher.py").read_bytes(), "<launcher>", "exec"), self.launch)
        self.contract = {"need": need, "keys": lambda row, keys: need(set(row) == set(keys), "keys"),
                         "file_sha": lambda p: sha(p.read_bytes()),
                         "read": lambda p: json.loads(p.read_bytes()), "CONTROLLER": self.outer["controller"]}
        tree = ast.parse((self.root / "code/runtime_contract.py").read_bytes())
        tree.body = [node for node in tree.body if isinstance(node, ast.FunctionDef)
                     and node.name in {"authorize", "qualification_scope"}]
        exec(compile(tree, "<runtime contract functions>", "exec"), self.contract)
        self.env = self.launch["CACHE_ENV"] | {
            "SLURM_JOB_ID": "123", "SLURM_CPUS_PER_TASK": "8", "CUDA_VISIBLE_DEVICES": "0",
            "R02_RUN_ROOT": json.loads((self.control / "GPU_DEPLOYMENT_LOCK.json").read_bytes())["env"]["R02_RUN_ROOT"]}

    def sign_fixture(self, **inner_changes):
        inner = encode(self.inner | inner_changes)
        self.inner_path = self.control / "R05_ROOT_RELEASE.json"
        self.inner_path.write_bytes(inner)
        outer = encode(self.outer | {"inner_sha256": sha(inner)})
        (self.control / "GPU_ACTION_RELEASE.json").write_bytes(outer)
        self.env["R02_RELEASE_SHA256"] = sha(outer)

    def test_unsigned_fails_and_signed_fixture_passes(self):
        with self.assertRaises(FileNotFoundError):
            self.launch["gate"](self.root, self.env)
        self.sign_fixture()
        self.assertEqual(self.launch["gate"](self.root, self.env), self.job)
        old = os.environ.get("SLURM_JOB_ID")
        os.environ["SLURM_JOB_ID"] = "123"
        try:
            self.contract["authorize"](self.job_path, self.inner_path, self.job)
        finally:
            if old is None:
                os.environ.pop("SLURM_JOB_ID")
            else:
                os.environ["SLURM_JOB_ID"] = old

    def test_wrong_source_extra_source_and_formal_stage(self):
        scope = self.contract["qualification_scope"]
        for changes in ({"cases": [{"source_id": "other"}]},
                        {"cases": self.job["cases"] + self.job["cases"]}, {"stage": "train"}):
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                scope(self.job | changes)

    def test_wrong_limits_and_old_inner_rejected_by_both_gates(self):
        for changes in ({"wall_seconds": 3301}, {"wall_seconds": 1800}, {"wall_seconds": 0},
                        {"max_updates_per_case": 3}, {"schema": "SINGLE_SOURCE_RUNTIME_RELEASE_V1"}):
            self.sign_fixture(**changes)
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                self.launch["gate"](self.root, self.env)
            old = os.environ.get("SLURM_JOB_ID")
            os.environ["SLURM_JOB_ID"] = "123"
            try:
                with self.assertRaises(ValueError):
                    self.contract["authorize"](self.job_path, self.inner_path, self.job)
            finally:
                if old is None:
                    os.environ.pop("SLURM_JOB_ID")
                else:
                    os.environ["SLURM_JOB_ID"] = old

    def test_old_outer_and_mounted_bytes_rejected(self):
        self.sign_fixture()
        (self.root / "code/runtime_cli.py").write_text("changed", encoding="utf8")
        with self.assertRaisesRegex(ValueError, "mounted file changed"):
            self.launch["gate"](self.root, self.env)
        self.outer["schema"] = "R02_EXACT_GPU_QUALIFICATION_RELEASE_V1"
        self.sign_fixture()
        with self.assertRaisesRegex(ValueError, "exact controller"):
            self.launch["gate"](self.root, self.env)

    def test_real_candidate_identity_and_deploy_count_guard(self):
        from prepare_rcro import PROJECT
        with zipfile.ZipFile(PROJECT / "GPU_QUALIFICATION_SIGNED_V1.zip") as parent:
            inputs = sorted((self.root / "inputs").rglob("*.*"))
            self.assertEqual(len(inputs), 7)
            for file in inputs:
                name = file.relative_to(self.root).as_posix()
                self.assertTrue(name.startswith("inputs/" + SOURCE + "/"))
                self.assertEqual(file.read_bytes(), parent.read(name))
        self.assertIn("len(original.namelist()) + len(release_paths)", (HERE / "execute_rcro_released_once.py").read_text())
        self.assertIn('len(z.namelist()) == len(PLAN["files"])', deploy.SUBMIT)
        for name in (deploy.PRECHECK, deploy.SUBMIT, deploy.COLLECT):
            compile(name, "<remote>", "exec")

    def test_runtime_summary_uses_available_qualification_arguments(self):
        tree = ast.parse((self.root / "code/native_runtime.py").read_bytes())
        fn = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "qualification")
        summary = fn.body[-1].value.args[1]
        args = {"checked": [None], "members": dict.fromkeys(range(6)),
                "summaries": [{"actual_updates": 2}, {"actual_updates": 2}]}
        result = eval(compile(ast.Expression(summary), "<actual summary expression>", "eval"), args)
        self.assertEqual((result["actual_native_prefix_full_forwards"], result["actual_total_optimizer_updates"]), (6, 4))


if __name__ == "__main__":
    unittest.main(verbosity=2)
