# R02 本地运行接口预检｜2026-11-09

本轮仅完成本地历史代码与运行元数据核对。未SSH、未执行远端命令、未sbatch、未加载模型/检查点张量、未读取新目标功能标签；新训练未准入。全部新增文件仅在本轮R02目录。

## 结论与最小改造边界

旧部署不是可直接改配置运行的通用训练器。实际历史部署副本与R05 v2以下六个关键源码逐字节一致（见JSON证据），但入口仍固定旧总控/协议、两来源、三个旧seed、500步与固定AdamW。单来源、可配steps/lr、中间checkpoint和完整optimizer恢复均需R05新版本接口与CPU验收；不得在旧部署目录就地改或把旧FINAL_500当完整resume状态。

|项目|实际限制与证据位置（R05_Code/v2相对路径）|新实现必须满足|
|---|---|---|
|单来源|replication_contract.py:26–29要求恰好2独立来源；pilot/contracts.py:validate_schedule要求2来源、排序交替、各250步；build_schedule.py固定500、每源250批|恰好一个准入来源，单来源日程/训练支持/整位点隔离与pair非空；不保留伪造第二来源|
|steps|pilot/contracts.py:STEPS=500；engine.py:train保存state(500)/FINAL_500，receipt也500；run_replication.py:131/140预测只接受500末态|显式预算及completed_updates，合法步骤的保存/推理恢复，不把attempt数当更新数|
|lr与身份|pilot/contracts.py:OPTIMIZER lr=1e-4、AdamW betas .9/.999、eps1e-8、weight_decay0、clip1；engine.py读取常量；replication_contract.py training_key包含常量优化器、steps500|lr/损失/来源bank/日程/初始化/长序列规则/代码纳入不可变训练身份；本报告不选择新值|
|中间checkpoint|engine.py只在循环末torch.save；updates.jsonl记录500步，不是恢复点|按预锁节奏原子保存，记录实际完成更新位置、文件hash；推理能验证任一被明确准入步，不默认选最佳|
|完整恢复|scorer.py:120–136状态只有schema/架构/seed/step/member_identity/frozen_sha/tensors；train永远restore0并新建AdamW，无optimizer.load_state_dict或RNG状态|独立full-resume schema，含AdamW动量/step、RNG、日程游标、attempt/completed计数、身份；拒绝以参数-only恢复冒充连续训练|
|实际部署器|R02 dispatch_training_seed.py固定22/波12000秒/11,23,47和旧remote root；prepare_training_jobs.py固定66图；旧collector也核500/250|新独立目录、小范围新plan/release/manifest/collector；旧66图及成功作业只读保留|
|封存与推理|run_replication.py config exact_keys及训练receipt步骤门槛；full19L/VRH/相对位置/cache h11仍是科学底座|保留完整WT与19L、六成员、VRH/统计梯度等原科学定义；不能复用h12/整蛋白检索向量冒充h11|

旧代码不支持“原来训练一半，换lr/来源后继续并仍叫同一条恢复”；更改身份须独立新实验，不能静默接受。当前固定方向是一次正式训练不挑seed，旧三seed图不得重新部署。本轮无新正式steps/lr/cadence、开发选模规则或预算决定。

## 可复用资产（历史已验，不等于现在远端可读）

RUNTIME_METADATA_EVIDENCE.json给出18个来源的真实全WT h11缓存路径、SHA、长度和来源资格证明；目标TnpB408/AsCas12f422/SpCas91368的3个h11 bundle路径/hash，以及3份Original的真实RAW/CSV/record本地/远端路径/hash。3份Original的9个文件本次在本地重新核SHA一致。源码六关键文件在历史最终staging中与authoring一致。模型锁NATIVE_LOCK、全66检查点封存、最终175作业对账也按实物hash引用。

复用条件：WT/结构token/天然输入/六模型+tokenizer+实际导入代码/h11布局/精度/窗口一致。天然缓存与Original可复用；旧训练checkpoint、双来源pair schedule和它的指标不能冒充新单来源实验。新来源不在这18个缓存中时，先由R01指出缺口，不能新搜或暗换名单。POLG2185的天然MSA仅[0,861)，原全长cache不表示天然对齐覆盖全长，不允许造padding概率。现存缓存的远端存在性、权限、环境和GPU空闲均未在本轮确认。

## 真实单步成本依据

从66个真实500步updates.jsonl和TRAIN_RECEIPT提取132条“来源×架构×seed”统计，每条250步；只导出秒数、来源、步骤和身份，不导出loss/功能值。

|架构|各来源稳态平均步时范围|各来源稳态均值的中位数|真实66训练中该架构总GPU秒|
|---|---:|---:|---:|
|S|0.1198–0.1474秒|0.1308秒|4459|
|LoRA|0.1565–0.6140秒|0.2005秒|6098|

“稳态”仅统计该来源第一次更新之外的249步。首步、forward/fullVRH均值、job分配时间和train_elapsed逐条列在证据JSON，不以稳态乘步数冒充完整成本。以上是旧双来源交替、FP32/fullWT/h11配方在既有单A800上的观察，未证明新单来源或新lr同耗时。短/长来源、冷加载、保存多份AdamW状态、完整恢复验证、预测导出、失败重试均需另计。下一阶段预算采用逐来源固定开销+实际steps×来源均值+checkpoint/恢复/评分开销和余量的明确账本，最终GPU预算由总控决定；本轮没有资格计时或预算申请。

历史运行还证明不能只看shell exit0：5197618父TIMEOUT296秒但完整产物经独立数值准入，5197619缺预测/FAILED157秒（extern158）由唯一5198385重算替代；均须计费。Slurm提前B:TERM可能早于内部保护；新包装脚本建议继承已验无提前TERM版本，保留明确内/外/Slurm硬上限，不篡改旧脚本。该行政修复不构成科学标准放宽。

## 下一阶段最小CPU资格检查规格（本轮未代R05实现/执行）

1. 配置/schema：缺来源身份、steps、lr、损失、初始化、pair/支持hash、恢复策略、cadence或release时硬拒；旧two-source/seed-wave默认不能隐式进入新方向。新总控与旧控制权限明确区分。
2. 单来源日程：每个有效completed update只消费同一准入bank；pair在train-only支持内，heldout整位点绝不进入；两种pair真实非空；WT/家族组与目标分离。可用合成bank检查，不读功能表。
3. 真实配置穿透：steps/lr改变应到optimizer/identity/预算/推理允许步；不能只改manifest而底层仍1e-4/500。lr、step/cursor、来源bank、loss或代码不符恢复必须拒绝。
4. 合成CPU连续vs中断恢复：固定小模型及预锁pairs，跑N更新；于k保存完整训练状态/退出/新进程恢复到N，与连续N的参数、AdamW状态、RNG、日程游标、预测一致。包含保存失败/不完整文件拒绝、CPU-map-location、零步和最后一步边界。此测试证明恢复机制，不是ProSST真实模型通过。
5. 明确adapter-only vs full-resume：旧FOURCELL_ADAPTER_V1可用于同身份推理或显式新初始化，不能进入full-resume；各类checkpoint白名单和禁用pickle边界清晰。
6. 中间checkpoint：原子写/完成标记、实际completed_updates、唯一不可变保存步/文件hash；输入变化和tensor非有限/shape或dtype错误硬拒。attempt、完成更新、恢复重复work和预算分开计账。
7. 科学底座：合成h11/WT/结构位置验证六成员full19L输出，窗口/partial MSA/span/mask保持；拒h12替h11、截断冒充全长、缺字段补0；Original原文件回归hash不变。禁止用合成pass宣称模型加载成功。
8. 本地包装与隔离：bash -n、命令参数/科学代码hash/实际import路径锁、source-only训练和无标签预测mount白名单、单GPU队列与唯一attempt intent、断连先对账不重投；无训练release时CPU检查不得触发SSH/sbatch或加载模型。

完成CPU合同后仍须总控签署具体真实接口资格与资源计划，才可核服务器现状并运行有限真模型检查；不能凭此静态报告直接训练。源表准入、开发/最终分割及评价选择合同由R01/R03/总控负责，本角色不补标签或选择科学配方。
