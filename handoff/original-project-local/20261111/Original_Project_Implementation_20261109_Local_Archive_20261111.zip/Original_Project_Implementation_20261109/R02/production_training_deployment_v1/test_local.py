import copy
import json
import shlex
from pathlib import Path
import subprocess
import tempfile
import unittest
import zipfile

from prepare_production import HERE,ROOT,READY,read,sha
from serial_driver import verify
from training_launcher import validate


class ProductionChecks(unittest.TestCase):
    def setUp(self):
        self.template=read(HERE/"TRAINING_RELEASE_NOT_RELEASED.json")

    def test_exact_twelve_jobs_configs_and_full_mount_hashes(self):
        bindings=read(ROOT/"R02/source_bundle_admission_v1/training_candidates_v1/BINDINGS.json")
        known={r["ref"]["path"]:r for r in bindings["files"]}
        jobs=read(READY/"CANDIDATES.json")["jobs"]
        self.assertEqual(len(self.template["nodes"]),12)
        self.assertEqual(sum(n["allocated_gpu_seconds"] for n in self.template["nodes"]),21600)
        predecessor=None
        for n in self.template["nodes"]:
            self.assertEqual(n["predecessor_track"],predecessor)
            predecessor=n["track_id"]
            folder=HERE/"nodes"/n["track_id"]
            with zipfile.ZipFile(n["archive"]["path"]) as z:
                self.assertIsNone(z.testzip())
                self.assertEqual({name:sha(z.read(name)) for name in z.namelist()},n["unsigned_files"])
                job=json.loads(z.read("JOB.json"))
                self.assertEqual(job,jobs[n["track_id"]]["job"])
                config=json.loads(z.read(job["cases"][0]["config"]["path"].lstrip("/")))
                manifest=json.loads(z.read("MANIFEST.json"))
                validate(job,config,manifest["scope"])
                for item in manifest["actual_mounted_files"]:
                    if item["path"]==job["cases"][0]["config"]["path"]:
                        self.assertEqual(item["sha256"],sha(z.read(item["path"].lstrip("/"))))
                    else:
                        self.assertEqual(item["sha256"],known[item["path"]]["ref"]["sha256"])
            subprocess.run(["F:/programming language/Git/bin/bash.exe","-n",str(folder/"train.sbatch")],check=True)
            batch=(folder/"train.sbatch").read_text()
            env={"RUN":n["remote_root"],"R02_RUNTIME_ENV":"/public/home/s20223010065/RFduffision/ZERO_SHOT_MODELS_P2R_20261024_v1/env_prosst",
                 "R02_BASE_ENV":"/public/home/s20223010065/software/miniconda3/envs/prosst",
                 "OUT":n["remote_root"]+"/output-TEST"}
            argv=shlex.split(batch.replace("\\\n"," "))
            expanded=argv[argv.index("--bind")+1]
            for var,value in env.items():
                expanded=expanded.replace("$"+var,value)
            self.assertNotIn("$",expanded)
            actual={}
            for bind in expanded.split(","):
                parts=bind.split(":")
                host,dst=parts[:2]
                mode=parts[2] if len(parts)==3 else "rw"
                self.assertNotIn(dst,actual)
                self.assertEqual(mode,"rw" if dst=="/out" else "ro")
                actual[dst]=host
            extra={"/runcontrol":env["RUN"],env["R02_RUNTIME_ENV"]:env["R02_RUNTIME_ENV"],
                   env["R02_BASE_ENV"]:env["R02_BASE_ENV"],"/out":env["OUT"]}
            self.assertEqual(actual,manifest["mounts"]|extra)
            for dst,host in manifest["mounts"].items():
                if host.startswith(env["RUN"]+"/"):
                    self.assertEqual((folder/host.removeprefix(env["RUN"]+"/")).read_bytes(),
                                     (folder/dst.lstrip("/")).read_bytes())

    def test_wrong_protocol_and_identity_rejected(self):
        n=self.template["nodes"][0]
        folder=HERE/"nodes"/n["track_id"]
        job=read(folder/"JOB.json")
        config=read(folder/job["cases"][0]["config"]["path"].lstrip("/"))
        scope=read(folder/"MANIFEST.json")["scope"]
        for field,value in (("steps",2001),("seed",23),("lr",1e-3),("checkpoints",[2000])):
            c=copy.deepcopy(config)
            c[field]=value
            with self.subTest(field=field),self.assertRaises(AssertionError):
                validate(job,c,scope)
        with self.assertRaises(AssertionError):
            validate(job,config,scope|{"bundle_sha256":"0"*64})
        j=copy.deepcopy(job)
        j["cases"][0]["checkpoint"]={"path":"/old","sha256":"0"*64}
        with self.assertRaises(AssertionError):
            validate(j,config,scope)

    def test_unreleased_no_network_and_exit_json(self):
        p=HERE/"TRAINING_RELEASE_NOT_RELEASED.json"
        with self.assertRaises(AssertionError):
            verify(p,sha(p.read_bytes()))
        node=self.template["nodes"][0]
        batch=(HERE/"nodes"/node["track_id"]/"train.sbatch").read_text()
        trap=next(line for line in batch.splitlines() if line.startswith("trap "))
        start=batch.index("finish() {")
        end=batch.index(trap,start)
        finish=batch[start:end]
        with tempfile.TemporaryDirectory() as tmp:
            p=subprocess.run(["F:/programming language/Git/bin/bash.exe","-c",
                              'OUT="$1"\nSTART=$(date +%s)\n'+finish+trap+"\nexit 17","_",tmp])
            self.assertEqual(p.returncode,17)
            self.assertEqual(json.loads((Path(tmp)/"ALLOCATION_END.json").read_bytes())["exit_code"],17)
        for name in ("serial_driver.py","serial_remote.py","training_launcher.py"):
            compile((HERE/name).read_bytes(),name,"exec")


if __name__=="__main__":
    unittest.main(verbosity=2)
