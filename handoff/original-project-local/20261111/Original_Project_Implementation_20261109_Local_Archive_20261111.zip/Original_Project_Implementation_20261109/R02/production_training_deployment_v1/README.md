# 十二条正式训练部署候选

已消费 R05 phase1_v2 的实际十二份 JOB/config 和总控 59,400 秒正式预算。每条单卡 A800、8 CPU、64 GiB、Slurm 1,800 秒、容器 1,740 秒、R05 内部 1,500 秒。十二训练的分配上限为 21,600 秒，现行矩阵仍为 small594／full_train × S／LoRA × 三条固定来源路线，seed11、lr1e-4、2,000 更新及 500／1000／2000 节点。

每节点候选包只含新 JOB、原 lock 字节、实际 config、部署 manifest、外层训练门、batch 和待签模板。其余模型、库、代码、来源 bundle、对应单 bank／index／pair、干净 INIT 直接绑定已有实际文件。config 本身是显式只读挂载。启动前外层逐项验证挂载文件大小及 SHA、包内 launcher/JOB/config 字节和双 release，原 R05 再检查实际导入路径和库版本、全 native 文件、SOURCE 和 INIT 身份及完整恢复协议。每条作业的命令、唯一根、claim、Slurm 回执和实际账单独立。

签发时，对每个 unsigned ZIP 保留所有字节，追加 ROOT_RELEASE.json 与 OUTER_RELEASE.json。先将 INNER_NOT_RELEASED.json 的 status 设 RELEASED，计算内层 SHA，再将 OUTER_NOT_RELEASED.json 的 status 设 RELEASED 并填入 inner_sha256。总控顶层复制 TRAINING_RELEASE_NOT_RELEASED.json，置 status=RELEASED，逐节点追加 signed_archive 的 path/sha256/bytes、inner_sha256 和 outer_sha256。顶层文件 SHA 是 serial_driver 的必填参数。节点模板中的配置和实际宿主机挂载路径已经冻结。

运行入口

```text
python -B serial_driver.py check --release <总控实际release路径> --release-sha256 <实际SHA>
python -B serial_driver.py submit --release <同一release> --release-sha256 <同一SHA> --index 0
python -B serial_driver.py collect --release <同一release> --release-sha256 <同一SHA> --index 0
```

后续 index 递增。每次提交前，独占本地 claim，远端复验无同名受理记录、无现有根与提交 claim、无其他 GPU 作业；后继另在远端重核前驱 sacct 为 COMPLETED 0:0、逻辑退出成功、runtime／JOB／release 一致、实际完成 2,000 步且三个检查点文件 SHA 与完成回执相同。先核输入身份，再部署新节点。每次调用最多一次 sbatch。作业内另有 allocation claim。失败、配额或身份不符及模糊受理都停止，没有自动重投。调度等待时通过 collect 只读查询，终态完成后生成 ACCEPTANCE.json，驱动才能继续下一节点。

本地检查覆盖 12 个实际配置与原件逐字节一致、全部新包和挂载哈希、12 个 Bash 语法、未签 release 拒绝、错误来源／seed／步骤／学习率／检查点拒绝。用 shlex 解析 batch 的 --bind 并展开受控变量，逐节点核与 manifest 完全相同，仅额外允许 /runcontrol、两个已准入环境及 /out。对新 control/config 文件逐项检查其在包内存在。原模板目录全局替换会漂移已有代码和 INIT 路径，已改为仅替换 RUN 整行并纳入回归。

本目录新增 wrapper、编排和测试，未修改 R05 科学文件。本地无 GPU/SSH 或生产提交。尚待总控对实际包和全部放行 SHA 签发，以及真实容器逐文件挂载验收。collect 保留 Slurm、训练逻辑完成回执和检查点 SHA，详细训练日志与大检查点仍保留远端原路径，后续封存收集须绑定同一任务身份。正式推理需要在本阶段训练产物实际封存后另签。
