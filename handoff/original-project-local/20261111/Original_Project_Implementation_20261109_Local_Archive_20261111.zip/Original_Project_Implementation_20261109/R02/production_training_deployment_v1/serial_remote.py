"""One exact Slurm submission or one read-only collection per invocation."""
import base64
import hashlib
import io
import json
import os
from pathlib import Path,PurePosixPath
import pwd
import re
import subprocess
import zipfile

assert pwd.getpwuid(os.geteuid()).pw_name=="s20223010065"
S="/public/gridview_20250224/slurm/bin/"
node=PLAN["node"]
root=Path(node["remote_root"])


def command(a):
    p=subprocess.run(a,capture_output=True,text=True,timeout=40)
    assert p.returncode==0,p.stderr
    return p.stdout


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    with p.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


def emit(e):
    print(json.dumps(e),flush=True)


def accept(previous_root,jid,expected_job):
    account=command([S+"sacct","-X","-n","-P","-j",jid,
        "--format=JobIDRaw,JobName%100,State,ExitCode,ElapsedRaw,AllocTRES%150,WorkDir%300"])
    lines=account.splitlines()
    assert len(lines)==1
    row=lines[0].split("|")
    assert row[0]==jid and row[6]==str(previous_root)
    if row[2]!="COMPLETED" or row[3]!="0:0":
        return {"status":"NOT_SUCCESSFUL_TERMINAL","job_id":jid,"sacct":account,"state":row[2]}
    assert int(row[4])<=1800 and "gres/gpu=1" in row[5]
    outer=read(previous_root/"OUTER_RELEASE.json")
    assert outer["job_sha256"]==expected_job
    job=read(previous_root/"JOB.json")
    out=previous_root/("output-"+jid)
    logical=read(out/"LOGICAL_EXIT.json")
    assert logical["returncode"]==0 and logical["job_sha256"]==expected_job and logical["slurm_job_id"]==jid
    location=out/Path(job["output"]).relative_to("/out")
    runtime=read(location/"RUNTIME_RECEIPT.json")
    assert runtime["status"]=="COMPLETE_UNEVALUATED" and runtime["stage"]=="train"
    assert runtime["job_sha256"]==expected_job and runtime["release_sha256"]==outer["inner_sha256"]
    tr=read(location/"train/TRAIN_RECEIPT.json")
    assert tr["status"]=="COMPLETE_UNEVALUATED" and tr["completed_updates"]==2000 and tr["resume_checkpoint"] is None
    assert tr["attempts"]>=2000 and len(tr["checkpoints"])==3
    checkpoints=[]
    for cp in tr["checkpoints"]:
        assert cp["step"] in (500,1000,2000)
        p=out/Path(cp["path"]).relative_to("/out")
        assert sha(p)==cp["sha256"]
        checkpoints.append({"step":cp["step"],"sha256":cp["sha256"],"content_sha256":cp["content_sha256"],"path":str(p)})
    assert {c["step"] for c in checkpoints}=={500,1000,2000}
    return {"status":"PASS_ACTUAL_TRAIN_2000","job_id":jid,"sacct":account,"allocated_gpu_seconds":int(row[4]),
            "job_sha256":expected_job,"root":str(previous_root),"checkpoints":checkpoints,
            "training_id":tr["training_id"],"train_receipt":tr}


if PLAN["action"]=="submit":
    assert not root.exists() and not root.is_symlink(),"existing intent; reconcile"
    if PLAN["predecessor"] is not None:
        previous=PLAN["predecessor"]
        actual=accept(Path(previous["root"]),previous["job_id"],previous["job_sha256"])
        assert actual["status"]=="PASS_ACTUAL_TRAIN_2000" and actual["checkpoints"]==previous["checkpoints"]
    queue=command([S+"squeue","-h","-u","s20223010065","-o","%i|%j|%T|%b"])
    assert not any("gpu" in row.lower() for row in queue.splitlines()),"another queued/active GPU job"
    history=command([S+"sacct","-X","-n","-P","-S","2026-11-10","-u","s20223010065",
                     "--name",node["job_name"],"--format=JobIDRaw,State,ExitCode"])
    assert not history.strip(),"existing accepted name"
    blob=base64.b64decode(PLAN["archive"],validate=True)
    assert hashlib.sha256(blob).hexdigest()==node["signed_archive"]["sha256"]
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        expected=node["unsigned_files"]|{"ROOT_RELEASE.json":node["inner_sha256"],"OUTER_RELEASE.json":node["outer_sha256"]}
        assert len(z.namelist())==len(expected) and set(z.namelist())==set(expected) and z.testzip() is None
        for n,h in expected.items():
            p=PurePosixPath(n)
            assert not p.is_absolute() and ".." not in p.parts
            assert hashlib.sha256(z.read(n)).hexdigest()==h
        manifest=json.loads(z.read("MANIFEST.json"))
        # Existing assets and the exact source-only mount set are verified before deployment.
        for r in manifest["actual_mounted_files"]:
            host=Path(manifest["mounts"][r["path"]])
            if host.is_relative_to(root):
                data=z.read(r["path"].lstrip("/"))
                assert len(data)==r["bytes"] and hashlib.sha256(data).hexdigest()==r["sha256"]
            else:
                assert host.is_file() and host.stat().st_size==r["bytes"] and sha(host)==r["sha256"]
        os.umask(0o077)
        root.mkdir(exist_ok=False)
        for n,h in expected.items():
            p=root/n
            p.parent.mkdir(exist_ok=True,parents=True)
            with p.open("xb") as f:
                f.write(z.read(n))
            assert sha(p)==h
    (root/"logs").mkdir()
    args=[S+"sbatch","--parsable","--chdir="+str(root),"--output="+str(root/"logs/train-%j.out"),
          "--error="+str(root/"logs/train-%j.err"),"--export=ALL,R02_TRAINING_OUTER_SHA="+node["outer_sha256"],
          str(root/"train.sbatch")]
    with (root/".submit_intent").open("x") as f:
        json.dump({"release_sha256":PLAN["release_sha256"],"args":args},f)
    emit({"status":"SUBMIT_STARTED","track_id":node["track_id"],"command":args})
    p=subprocess.run(args,capture_output=True,text=True,timeout=40)
    m=re.fullmatch(r"([0-9]+)(?:;[^\s;]+)?",p.stdout.strip())
    good=p.returncode==0 and m is not None
    e={"status":"SLURM_ACCEPTED" if good else "AMBIGUOUS_OR_FAILED_NO_RETRY","returncode":p.returncode,
       "stdout":p.stdout,"stderr":p.stderr,"job_id":m[1] if good else None,"track_id":node["track_id"],
       "job_sha256":node["job_sha256"],"root":str(root)}
    with (root/"SUBMISSION_RECEIPT.json").open("x") as f:
        json.dump(e,f)
    emit(e)
    assert good
else:
    e=accept(root,PLAN["job_id"],node["job_sha256"])
    e["track_id"]=node["track_id"]
    emit(e)
