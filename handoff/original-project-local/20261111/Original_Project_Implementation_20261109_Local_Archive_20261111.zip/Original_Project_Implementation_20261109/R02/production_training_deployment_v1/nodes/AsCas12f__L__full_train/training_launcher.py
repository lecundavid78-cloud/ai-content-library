"""Exact training gate ahead of the unchanged R05 runtime."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


def read(p):
    return json.loads(Path(p).read_bytes())


def sha(p):
    with Path(p).open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


def validate(job,config,scope):
    assert (job["stage"],job["purpose"],job["device"])==("train","EXACT_SINGLE_SOURCE_TRAIN","cuda")
    assert len(job["cases"])==1 and job["material_lock"] is None
    case=job["cases"][0]
    assert case["checkpoint"] is None and case["prior_attempts"] is None
    assert case["source_id"]==config["source"]["id"]==scope["source_id"]
    assert (config["steps"],config["seed"],config["lr"],config["checkpoints"],config["pairs_per_class"])==(
        2000,11,1e-4,[500,1000,2000],128)
    assert config["architecture"]==scope["architecture"]
    for key,field in (("admission","bank_sha256"),("bundle","bundle_sha256"),("init","init_sha256")):
        value=config["source"][field] if key!="init" else config[field]
        assert case[key]["sha256"]==value==scope[key+"_sha256"]
    assert case["schedule"]["sha256"]==scope["schedule_sha256"] and job["output"]==scope["output"]


def main():
    root=Path("/runcontrol")
    assert Path(__file__).resolve()==root/"training_launcher.py"
    outer=read(root/"OUTER_RELEASE.json")
    assert sha(root/"OUTER_RELEASE.json")==os.environ["R02_TRAINING_OUTER_SHA"]
    assert outer["status"]=="RELEASED" and outer["schema"]=="PHASE1_EXACT_TRAIN_OUTER_V1"
    assert outer["controller"]=="01a1c09c-f9e6-70f1-b9e8-b988b89c755f"
    assert (outer["gpu"],outer["cpu"],outer["memory_gib"],outer["slurm_seconds"],outer["updates"])==(1,8,64,1800,2000)
    assert outer["automatic_retry"] is False and outer["target_labels"] is False
    for key,name in (("job_sha256","JOB.json"),("inner_sha256","ROOT_RELEASE.json"),("manifest_sha256","MANIFEST.json")):
        assert outer[key]==sha(root/name)
    manifest=read(root/"MANIFEST.json")
    for name,h in manifest["package_files"].items():
        assert sha(root/name)==h
    for spec in manifest["actual_mounted_files"]:
        assert Path(spec["path"]).stat().st_size==spec["bytes"] and sha(spec["path"])==spec["sha256"]
    job=read(root/"JOB.json")
    validate(job,read(job["cases"][0]["config"]["path"]),manifest["scope"])
    assert os.environ.get("SLURM_JOB_ID","").isdigit() and os.environ.get("SLURM_CPUS_PER_TASK")=="8"
    assert os.environ.get("CUDA_VISIBLE_DEVICES") and "," not in os.environ["CUDA_VISIBLE_DEVICES"]
    for k,v in {"HF_HOME":"/out/hf","HF_MODULES_CACHE":"/out/hf_modules","TRANSFORMERS_CACHE":"/out/hf/hub",
                "XDG_CACHE_HOME":"/out/.cache","PYTHONPATH":"/code","CUBLAS_WORKSPACE_CONFIG":":4096:8"}.items():
        assert os.environ.get(k)==v
    assert not Path(job["output"]).exists()
    args=[sys.executable,"-B","/code/runtime_cli.py","execute","--job",str(root/"JOB.json"),
          "--release",str(root/"ROOT_RELEASE.json")]
    with Path("/out/TRAIN.stdout").open("xb") as stdout,Path("/out/TRAIN.stderr").open("xb") as stderr:
        result=subprocess.run(args,stdout=stdout,stderr=stderr)
    Path("/out/LOGICAL_EXIT.json").write_text(json.dumps({
        "returncode":result.returncode,"job_sha256":outer["job_sha256"],"slurm_job_id":os.environ["SLURM_JOB_ID"]})+"\n")
    raise SystemExit(result.returncode)


if __name__=="__main__":
    main()
