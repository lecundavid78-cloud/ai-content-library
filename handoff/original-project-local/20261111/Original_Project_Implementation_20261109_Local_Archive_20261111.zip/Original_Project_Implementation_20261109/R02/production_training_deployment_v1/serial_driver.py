"""Exact one-node-at-a-time deployment. Ambiguous submissions keep exclusive claims."""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(b):
    return hashlib.sha256(b).hexdigest()


def enc(o):
    return (json.dumps(o,indent=2)+"\n").encode()


def verify(release_path,release_sha):
    assert sha(release_path.read_bytes())==release_sha
    release=json.loads(release_path.read_bytes())
    expected=json.loads((HERE/"TRAINING_RELEASE_NOT_RELEASED.json").read_bytes())
    assert release["schema"]==expected["schema"] and release["status"]=="RELEASED"
    for k,v in expected.items():
        if k not in ("status","nodes"):
            assert release[k]==v,k
    assert len(release["nodes"])==12
    for r,e in zip(release["nodes"],expected["nodes"]):
        for k,v in e.items():
            assert r[k]==v,k
        signed=r["signed_archive"]
        p=Path(signed["path"])
        assert sha(p.read_bytes())==signed["sha256"] and p.stat().st_size==signed["bytes"]
        with zipfile.ZipFile(p) as z:
            names=set(e["unsigned_files"])|{"ROOT_RELEASE.json","OUTER_RELEASE.json"}
            assert len(z.namelist())==len(names) and set(z.namelist())==names and z.testzip() is None
            assert all(sha(z.read(n))==h for n,h in e["unsigned_files"].items())
            inner=json.loads(z.read("ROOT_RELEASE.json"))
            outer=json.loads(z.read("OUTER_RELEASE.json"))
            assert inner==json.loads(z.read("INNER_NOT_RELEASED.json"))|{"status":"RELEASED"}
            assert outer==json.loads(z.read("OUTER_NOT_RELEASED.json"))|{
                "status":"RELEASED","inner_sha256":sha(z.read("ROOT_RELEASE.json"))}
            assert r["inner_sha256"]==sha(z.read("ROOT_RELEASE.json"))
            assert r["outer_sha256"]==sha(z.read("OUTER_RELEASE.json"))
    return release


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("action",choices=("check","submit","collect"))
    parser.add_argument("--release",type=Path,required=True)
    parser.add_argument("--release-sha256",required=True)
    parser.add_argument("--index",type=int,default=0)
    args=parser.parse_args()
    release=verify(args.release,args.release_sha256)
    assert 0<=args.index<12
    node=release["nodes"][args.index]
    folder=HERE/"nodes"/node["track_id"]
    runtime=folder/"actual"
    runtime.mkdir(exist_ok=True)
    predecessor=None
    if args.index:
        previous=release["nodes"][args.index-1]
        previous_receipt=HERE/"nodes"/previous["track_id"]/"actual/ACCEPTANCE.json"
        if args.action=="submit":
            predecessor=json.loads(previous_receipt.read_bytes())
            assert predecessor["status"]=="PASS_ACTUAL_TRAIN_2000" and predecessor["track_id"]==previous["track_id"]
    remote=(HERE/"serial_remote.py").read_bytes()
    compile(remote,"<remote>","exec")
    if args.action=="check":
        print("PASS exact twelve signed nodes and remote program compilation")
        return
    plan={"action":args.action,"node":node,"predecessor":predecessor,
          "release_sha256":args.release_sha256,"job_id":None}
    if args.action=="submit":
        with Path(node["local_claim"]).open("xb") as f:
            f.write(enc({"release_sha256":args.release_sha256,"archive":node["signed_archive"]}))
        plan["archive"]=base64.b64encode(Path(node["signed_archive"]["path"]).read_bytes()).decode()
    else:
        sub=json.loads((runtime/"SUBMISSION.json").read_bytes())
        plan["job_id"]=sub["job_id"]
    transport=ROOT.parent.parent/"Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2"
    sys.path.insert(0,str(transport))
    from remote_qualification import SSH,PYTHON
    rc=None
    try:
        p=subprocess.run(SSH+[PYTHON],input=("PLAN="+repr(plan)+"\n").encode()+remote,capture_output=True,timeout=300)
        rc,out,err=p.returncode,p.stdout,p.stderr
    except subprocess.TimeoutExpired as exc:
        out,err=exc.stdout or b"",exc.stderr or b""
    except OSError as exc:
        out,err=b"",str(exc).encode()
    import datetime
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    (runtime/(stamp+".stderr")).write_bytes(err)
    result=[]
    for line in out.splitlines():
        try:
            event=json.loads(line)
        except ValueError:
            continue
        result.append(event)
    receipt={"returncode":rc,"events":result,"release_sha256":args.release_sha256}
    (runtime/(stamp+"_RECEIPT.json")).write_bytes(enc(receipt))
    for e in result:
        if e["status"]=="SLURM_ACCEPTED":
            with (runtime/"SUBMISSION.json").open("xb") as f:
                f.write(enc(e))
        if e["status"]=="PASS_ACTUAL_TRAIN_2000":
            with (runtime/"ACCEPTANCE.json").open("xb") as f:
                f.write(enc(e))
    print(json.dumps(receipt))


if __name__=="__main__":
    main()
