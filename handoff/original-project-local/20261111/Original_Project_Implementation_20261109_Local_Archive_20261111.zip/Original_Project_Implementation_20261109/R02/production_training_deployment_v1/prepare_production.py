"""Freeze twelve actual R05 configs without signing or deploying any training job."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile
from training_launcher import validate

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
READY=ROOT/"R05/phase1_v2/actual_train_candidates"


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read(p):
    return json.loads(p.read_bytes())


def enc(o):
    return (json.dumps(o,indent=2)+"\n").encode()


def main():
    c=read(READY/"CANDIDATES.json")
    binding_path=ROOT/"R02/source_bundle_admission_v1/training_candidates_v1/BINDINGS.json"
    assert c["bindings_sha256"]==sha(binding_path.read_bytes()) and len(c["jobs"])==12
    assert c["planned_gpu_seconds_all_50"]==59400
    bindings=read(binding_path)
    bank={r["ref"]["path"]:r for r in bindings["files"]}
    inv=read(ROOT/"DEVELOPMENT_PHASE1_INVENTORY.json")
    env=read(ROOT/"R02/qualification_v1/EXACT_RUNTIME_ENV_V3.json")["env"]
    init_root=env["R02_RUN_ROOT"].rsplit("/",1)[0]
    # Start from the already-tested INIT wrapper rather than introducing a model entry.
    with zipfile.ZipFile(ROOT/"PHASE1_INIT_S_SIGNED.zip") as z:
        batch_template=z.read("gpu_init.sbatch").decode()
    nodes=[]
    for number,t in enumerate(inv["training_trajectories"]):
        key=t["track_id"]
        item=c["jobs"][key]
        folder=HERE/"nodes"/key
        folder.mkdir(parents=True,exist_ok=True)
        job=read(READY/(key+".JOB.json"))
        config=read(READY/(key+".json"))
        case=job["cases"][0]
        assert item["job"]==job and sha((READY/(key+".JOB.json")).read_bytes())==item["job_sha256"]
        assert sha((READY/(key+".json")).read_bytes())==case["config"]["sha256"]
        scope={"source_id":t["source_id"],"architecture":t["architecture"],"output":job["output"],
               "bank_rule":t["bank_rule"],"target_route":t["target"]}
        scope.update({k+"_sha256":case[k]["sha256"] for k in ("admission","bundle","init","schedule")})
        validate(job,config,scope)
        files={"JOB.json":(READY/(key+".JOB.json")).read_bytes(),"training_launcher.py":(HERE/"training_launcher.py").read_bytes(),
               "control/NATIVE_LOCK.json":(ROOT/"R02/qualification_v1/payload_final_v3/control/NATIVE_LOCK.json").read_bytes(),
               "control/IMPORT_LOCK.json":(ROOT/"R02/qualification_v1/ACTUAL_IMPORT_LOCK.json").read_bytes(),
               case["config"]["path"].lstrip("/"):(READY/(key+".json")).read_bytes()}
        root=init_root+"/production_train_"+key
        mounts={dst:host for dst,host in item["read_only_file_mounts"].items() if not dst.startswith("/control/")}
        for n in ("control/NATIVE_LOCK.json","control/IMPORT_LOCK.json",case["config"]["path"].lstrip("/")):
            mounts["/"+n]=root+"/"+n
        actual=[]
        for dst,host in sorted(mounts.items()):
            if dst==case["config"]["path"]:
                actual.append({"path":dst,"sha256":case["config"]["sha256"],"bytes":len(files[dst.lstrip("/")])})
            else:
                r=bank[dst]
                actual.append({"path":dst,"sha256":r["ref"]["sha256"],"bytes":r["bytes"]})
        assert not any("/TARGET/" in r["path"] or "/original/" in r["path"] for r in actual)
        manifest={"scope":scope,"actual_mounted_files":actual,"package_files":{n:sha(b) for n,b in files.items()},
                  "mounts":mounts,"remote_root":root,"predecessor_track":nodes[-1]["track_id"] if nodes else None}
        files["MANIFEST.json"]=enc(manifest)
        inner={"schema":"SINGLE_SOURCE_RUNTIME_RELEASE_V1","controller":"01a1c09c-f9e6-70f1-b9e8-b988b89c755f",
               "status":"NOT_RELEASED","stage":"train","job_sha256":item["job_sha256"],"wall_seconds":1500,
               "device":"cuda","max_updates_per_case":2000}
        outer={"schema":"PHASE1_EXACT_TRAIN_OUTER_V1","controller":inner["controller"],"status":"NOT_RELEASED",
               "gpu":1,"cpu":8,"memory_gib":64,"slurm_seconds":1800,"updates":2000,"automatic_retry":False,
               "target_labels":False,"job_sha256":inner["job_sha256"],"inner_sha256":None,
               "manifest_sha256":sha(files["MANIFEST.json"])}
        files["INNER_NOT_RELEASED.json"]=enc(inner)
        files["OUTER_NOT_RELEASED.json"]=enc(outer)
        start=batch_template.index(" --bind ")
        end=batch_template.index(" --pwd ",start)
        binds=",".join(host+":"+dst+":ro" for dst,host in sorted(mounts.items()))
        batch=batch_template[:start]+f' --bind "$RUN:/runcontrol:ro,{binds},$R02_RUNTIME_ENV:$R02_RUNTIME_ENV:ro,$R02_BASE_ENV:$R02_BASE_ENV:ro,$OUT:/out" \\\n'+batch_template[end:]
        for old,new in [
            ("OriginalProject_ProdInit_S",f"OriginalProject_Train_{number:02d}"),
            ("RUN="+init_root+"/production_init_S\n","RUN="+root+"\n"),("00:15:00","00:30:00"),
            ('"Slurm_cap_seconds":900','"Slurm_cap_seconds":1800'),
            ("--kill-after=20 820","--kill-after=20 1740"),
            ("R02_RELEASE_SHA256","R02_TRAINING_OUTER_SHA"),
            ('"$RUN/control/GPU_ACTION_RELEASE.json"','"$RUN/OUTER_RELEASE.json"'),
            ('"$RUN/control/R05_ROOT_RELEASE.json"','"$RUN/ROOT_RELEASE.json"'),
            ("/control/gpu_action_launcher.py","/runcontrol/training_launcher.py"),
            ("--env HF_HOME=/out/hf_local","--env HF_HOME=/out/hf"),
            ("--env TRANSFORMERS_CACHE=/out/hf_local/hub","--env TRANSFORMERS_CACHE=/out/hf/hub")]:
            assert old in batch,old
            batch=batch.replace(old,new)
        files["train.sbatch"]=batch.encode()
        for n,b in files.items():
            p=folder/n
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(b)
        subprocess.run(["F:/programming language/Git/bin/bash.exe","-n",str(folder/"train.sbatch")],check=True)
        archive=folder/"TRAIN_UNSIGNED.zip"
        with zipfile.ZipFile(archive,"w") as z:
            for n,b in sorted(files.items()):
                z.writestr(zipfile.ZipInfo(n,(2026,11,10,0,0,0)),b,compress_type=zipfile.ZIP_DEFLATED)
        nodes.append({"track_id":key,"remote_root":root,"job_name":f"OriginalProject_Train_{number:02d}",
                      "archive":{"path":str(archive),"sha256":sha(archive.read_bytes()),"bytes":archive.stat().st_size},
                      "unsigned_files":{n:sha(b) for n,b in files.items()},"job_sha256":item["job_sha256"],
                      "sbatch_sha256":sha(files["train.sbatch"]),"allocated_gpu_seconds":1800,
                      "predecessor_track":manifest["predecessor_track"],"local_claim":str(folder/".submit_intent")})
    release={"schema":"PHASE1_TWELVE_TRAIN_DEPLOYMENT_RELEASE_V1","status":"NOT_RELEASED",
             "controller":"01a1c09c-f9e6-70f1-b9e8-b988b89c755f","nodes":nodes,"max_submissions":12,
             "max_train_gpu_seconds":21600,"formal_total_gpu_cap_seconds":59400,"init_actual_gpu_seconds":231,
             "simultaneous_gpu_max":1,"automatic_retry":False,"target_labels":False,
             "candidate_manifest_sha256":sha((READY/"CANDIDATES.json").read_bytes()),
             "compiler_sha256":sha((ROOT/"R05/phase1_v2/build_phase1.py").read_bytes())}
    (HERE/"TRAINING_RELEASE_NOT_RELEASED.json").write_bytes(enc(release))
    print(json.dumps({"actual_nodes":12,"cap_gpu_seconds":21600,"template_sha256":sha((HERE/"TRAINING_RELEASE_NOT_RELEASED.json").read_bytes())}))


if __name__=="__main__":
    main()
