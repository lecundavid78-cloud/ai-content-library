"""Read only the exact failed first allocation; no retry or deployment."""
import base64
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT.parent.parent/"Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2"))
from remote_qualification import SSH,PYTHON

code=r'''
from pathlib import Path
import base64,hashlib,json,subprocess
root=Path("/public/home/s20223010065/RFduffision/Original_Project_Implementation_20261109/production_train_AsCas12f__S__full_train")
job="5222146"
files=[root/"logs/train-5222146.out",root/"logs/train-5222146.err",root/"SUBMISSION_RECEIPT.json"]
out=root/("output-"+job)
if out.exists():
 files += [p for p in out.rglob("*") if p.is_file() and p.suffix in (".json",".stderr",".stdout",".txt",".jsonl")
           and not set(p.relative_to(out).parts)&{"hf","hf_modules",".cache","tmp","home"}]
result=[]
for p in sorted(set(files)):
 if not p.is_file():continue
 assert p.resolve().is_relative_to(root)
 assert p.stat().st_size<8*1024**2
 b=p.read_bytes()
 result.append({"path":p.relative_to(root).as_posix(),"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest(),
                "payload":base64.b64encode(b).decode()})
print(json.dumps({"job_id":job,"files":result}))
'''
stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
folder=HERE/"nodes/AsCas12f__S__full_train/actual"
proc=subprocess.run(SSH+[PYTHON],input=code.encode(),capture_output=True,timeout=180)
(folder/(stamp+"_FAILURE.stderr")).write_bytes(proc.stderr)
assert proc.returncode==0,proc.stderr.decode(errors="replace")[-2000:]
result=json.loads(proc.stdout)
for row in result["files"]:
 b=base64.b64decode(row.pop("payload"))
 assert hashlib.sha256(b).hexdigest()==row["sha256"]
 p=folder/"run"/row["path"]
 p.parent.mkdir(exist_ok=True,parents=True)
 with p.open("xb") as f:f.write(b)
receipt=folder/(stamp+"_FAILURE_COLLECTION.json")
receipt.write_text(json.dumps(result,indent=2)+"\n",encoding="utf8")
print(json.dumps({"receipt":str(receipt),"sha256":hashlib.sha256(receipt.read_bytes()).hexdigest(),"files":len(result["files"])}))
