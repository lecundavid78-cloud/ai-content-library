"""Freeze exact asset candidates and accounting assumptions without network access."""
import hashlib
import json
import math
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
R02 = HERE.parent
ROOT = R02.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(name, data):
    (HERE / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def ref(path):
    return {"path": str(path), "sha256": sha(path)}


def main():
    acceptance = ROOT / "CONTROLLER_ACTUAL_GPU_QUALIFICATION_ACCEPTANCE.json"
    assert sha(acceptance) == "8526648c9cfd27d9a16b184a189ab3ad9171ce7b04cef779bc7b64f34c6af38e"
    accepted = read(acceptance)
    assert len(accepted["cells"]) == 6 and accepted["total_allocated_gpu_seconds"] == 1852
    old_budget = R02 / "gpu_qualification_v1/FORMAL_BUDGET_DRAFT.json"
    old = read(old_budget)
    inv_path = ROOT / "DEVELOPMENT_PHASE1_INVENTORY.json"
    inv = read(inv_path)
    assert (len(inv["training_trajectories"]), len(inv["checkpoint_predictions"])) == (12, 36)
    history = R02 / "RUNTIME_METADATA_EVIDENCE.json"
    inspection = R02 / "qualification_v1/ACTUAL_RUNTIME_IDENTITY_INSPECTION.json"
    signed = ROOT / "GPU_QUALIFICATION_SIGNED_V1.zip"
    assert sha(signed) == "68a97075283239e93dee3d59ee91116ef9e8e955462bf04c8148085789da3634"
    with zipfile.ZipFile(signed) as z:
        native = json.loads(z.read("control/NATIVE_LOCK.json"))
        imports = json.loads(z.read("control/IMPORT_LOCK.json"))
        env = json.loads(z.read("control/GPU_DEPLOYMENT_LOCK.json"))["env"]
    measured = read(inspection)
    previous_native = {x["path"]: x for x in measured["native_files_metadata"]}
    checks = []

    def add(role, identity, path, digest=None, size=None, resolved=None, mount=None, mode="sha256"):
        checks.append(dict(role=role, id=identity, path=path, sha256_expected=digest, bytes_expected=size,
                           resolved_expected=resolved or (path if mode == "sha256" else None),
                           planned_mount=mount, check=mode))

    for a in old["historical_bundle_candidates_not_readmitted"]:
        if a["kind"].startswith("SOURCE"):
            name = a["source_id"]
            add("SOURCE_H11", name, a["remote_path"], a["sha256"], mount=f"/bundles/SOURCE/{name}.pt")
        else:
            b = a["bundle"]
            add("TARGET_H11", a["target"], b["path"], b["sha256"], mount=b["mount"])
    for a in read(history)["assets"]:
        if a["kind"] == "EXACT_EXISTING_Original":
            for key, f in a["files"].items():
                add("ORIGINAL_PREDICTION", a["target"] + "/" + key, f["remote_path"], f["sha256"], f["bytes"])
    for key, b in imports["files"].items():
        add("IMPORT_LOCK", key, b["path"], b["sha256"], resolved=b["path"])
    for member in native["members"]:
        root = member["root"]
        physical = env["R02_EXISTING2048"] if root == "/existing2048" else env["R02_MODELROOT"] + root.removeprefix("/weights")
        assert root == "/existing2048" or root.startswith("/weights/")
        for relative, digest in member["files_sha256"].items():
            path = physical + "/" + relative
            f = previous_native[path]
            assert digest == f["expected_sha256"]
            add("NATIVE_LOCK", str(member["K"]) + "/" + relative, path, digest, f["bytes"],
                resolved=f["resolved"], mount=root + "/" + relative)
    for f in measured["runtime_paths"]:
        add("RUNTIME_PATH", Path(f["path"]).name, f["path"], size=f["bytes"], resolved=f["resolved"],
            mode="metadata" if f["bytes"] is None else "sha256")
    add("RUNTIME_PYTHON", "container_python", env["R02_RUNTIME_ENV"] + "/bin/python", mode="executable")
    assert len(checks) == len({x["path"] for x in checks}) == 66
    evidence = [ref(p) for p in (acceptance, old_budget, inv_path, history, inspection, signed)]
    plan = dict(schema="R02_PRODUCTION_IDENTITY_PROBE_CANDIDATE_V1", status="PENDING_EXACT_RELEASE",
                provenance=evidence, account="s20223010065", expected_entries=len(checks), paths=checks)
    write("ASSET_ALLOWLIST.json", plan)
    source = (HERE / "probe_body.py").read_text(encoding="utf-8")
    payload = "PLAN = " + repr(plan) + "\n" + source
    compile(payload, "<remote payload>", "exec")
    (HERE / "REMOTE_PROBE.stdin.py").write_bytes(payload.encode("utf-8"))
    command = {"status": "PENDING_EXACT_RELEASE", "stdin": ref(HERE / "REMOTE_PROBE.stdin.py"),
               "allowlist": ref(HERE / "ASSET_ALLOWLIST.json"),
               "ssh_transport": "Use SSH argv of the accepted R02 deployer without changing host/key settings",
               "remote_command": "/usr/bin/timeout --kill-after=10 600 /public/home/s20223010065/software/miniconda3/envs/boltz2/bin/python -B -",
               "local_timeout_seconds": 640, "expected_remote_calls": 1, "gpu_allocations": 0,
               "remote_writes": 0, "model_loads": 0, "functional_value_tables": 0}
    write("EXACT_PROBE_COMMAND_CANDIDATE.json", command)

    cold = []
    for directory in ("gpu_qualification_v1/GPU_JOB_5217253", "gpu_rcro_qualification_v1/GPU_JOB_5220319"):
        f, = (R02 / directory).glob("run/output-*/qualification/NATIVE_LOAD.json")
        cold.append({"receipt": ref(f), "native_identity_and_load_seconds":
                     sum(x["identity_and_load_seconds"] for x in read(f).values())})
    rates = {t["track_id"]: t["historical_max_steady_mean_gpu_seconds"] for t in old["tracks"]}
    assert set(rates) == {t["track_id"] for t in inv["training_trajectories"]}
    # Charged time envelopes reserve cold launch, validation, I/O, exports and shutdown.
    caps = {"init": 900, "train": 1800, "predict_short": 900, "predict_SpCas9": 1200}
    track_plan = []
    for t in inv["training_trajectories"]:
        track = t["track_id"]
        seconds = math.ceil(1.35 * (rates[track] * 2000 + 360))
        assert seconds < caps["train"]
        track_plan.append({"track_id": track, "max_old_steady_mean_sec_per_step": rates[track],
                           "planning_seconds": seconds, "candidate_slurm_cap_seconds": caps["train"]})
    pred_long = sum(p["target"] == "SpCas9" for p in inv["checkpoint_predictions"])
    assert pred_long == 12
    totals = dict(init=2 * caps["init"], training=12 * caps["train"],
                  predict_short=24 * caps["predict_short"], predict_SpCas9=12 * caps["predict_SpCas9"])
    planning = sum(t["planning_seconds"] for t in track_plan) + 2 * 450 + 24 * 450 + 12 * 600
    write("PRODUCTION_BUDGET_CANDIDATE.json", {
        "status": "ESTIMATE_ONLY_NO_RELEASE", "evidence": evidence, "new_gpu_seconds": 0,
        "qualification_actual": {"jobs": accepted["actual_gpu_seconds_by_job"], "total_gpu_seconds": 1852,
                                 "accepted_cell_elapsed_seconds": accepted["cells"], "native_load": cold,
                                 "steady_state_training_measurement": False},
        "formal_matrix": {"init_nodes_if_exact_share_admitted": 2, "training_trajectories": 12,
                          "optimizer_updates": 24000, "checkpoint_predictions": 36, "existing_originals": 3},
        "planning": {"track_rows": track_plan, "training_overhead_per_job_assumed_seconds": 360,
                     "training_margin_multiplier": 1.35, "init_per_job_assumed_seconds": 450,
                     "prediction_short_per_job_assumed_seconds": 450, "prediction_SpCas9_assumed_seconds": 600,
                     "formal_total_seconds": planning},
        "per_job_slurm_caps_seconds": caps, "caps_by_stage_seconds": totals,
        "aggregate_caps_seconds": sum(totals.values()),
        "aggregate_caps_plus_measured_qualification_seconds": sum(totals.values()) + 1852,
        "excluded": ["new bundle generation", "retry jobs", "queue time", "CPU evaluation"]})


if __name__ == "__main__":
    main()
