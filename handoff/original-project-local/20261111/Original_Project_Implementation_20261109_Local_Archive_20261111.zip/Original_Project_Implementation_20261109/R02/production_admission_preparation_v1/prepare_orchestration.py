"""Emit a non-executable production graph and per-allocation resource template."""
from collections import Counter
from prepare import HERE, ROOT, read, ref, write


def main():
    inventory = ROOT / "DEVELOPMENT_PHASE1_INVENTORY.json"
    data = read(inventory)
    probe = HERE / "READONLY_PROBE_RECEIPT.json"
    receipt = read(probe)
    assert receipt["returncode"] == 0 and receipt["exact_inventory_order"] and not receipt["failed_entries"]
    jobs = []
    for architecture in ("S", "L"):
        jobs.append({"id": "init/" + architecture, "stage": "init", "seed": 11,
                     "architecture": architecture, "slurm_seconds": 900, "planning_seconds": 450,
                     "inner_seconds": 720, "one_fresh_native_load": True,
                     "reuse_only_after_exact_role_check": True, "init_sha256": None})
    budget = read(HERE / "PRODUCTION_BUDGET_CANDIDATE.json")
    train_times = {t["track_id"]: t["planning_seconds"] for t in budget["planning"]["track_rows"]}
    for row in data["training_trajectories"]:
        track = row["track_id"]
        train = "train/" + track
        jobs.append({"id": train, "stage": "train", "track": row, "depends_on": ["init/" + row["architecture"]],
                     "slurm_seconds": 1800, "inner_seconds": 1560, "planning_seconds": train_times[track],
                     "one_fresh_native_load": True, "config_sha256": None, "bound_schedule_sha256": None,
                     "checkpoint_steps_to_seal": [500, 1000, 2000]})
        predictions = sorted((p for p in data["checkpoint_predictions"] if p["track_id"] == track),
                             key=lambda p: p["step"])
        assert [p["step"] for p in predictions] == [500, 1000, 2000]
        assert all(p["target"] == row["target"] for p in predictions)
        long_target = row["target"] == "SpCas9"
        jobs.append({"id": "predict-group/" + track, "stage": "predict-group", "depends_on": [train],
                     "requires_sealed_training_receipt": True,
                     "slurm_seconds": 2100 if long_target else 1800, "inner_seconds": 1860 if long_target else 1560,
                     "planning_seconds": 1250 if long_target else 950,
                     "one_fresh_native_load": True, "release_requires_new_R05_group_entry": True,
                     "nodes": [p | {"id": f'predict/{track}/{p["step"]}', "checkpoint_sha256": None,
                                     "job_sha256": None, "receipt_required": True} for p in predictions]})
    assert Counter(j["stage"] for j in jobs) == {"init": 2, "train": 12, "predict-group": 12}
    assert sum(len(j.get("nodes", [])) for j in jobs) == 36
    assert len({j["id"] for j in jobs}) == 26
    caps = sum(j["slurm_seconds"] for j in jobs)
    estimate = sum(j["planning_seconds"] for j in jobs)
    assert (caps, estimate) == (46200, 25456)
    write("PRODUCTION_SERIAL_ORCHESTRATION_CANDIDATE.json", {
        "status": "DESIGN_ONLY_NO_TRAINING_OR_GPU_RELEASE",
        "inventory": ref(inventory), "read_only_observation": ref(probe),
        "resource": {"gpus_per_allocation": 1, "gpu_type": "NVIDIAA800-SXM4-80GB",
                     "cpus_per_task": 8, "memory_gib": 64, "max_simultaneous_allocations": 1,
                     "no_requeue": True},
        "jobs": jobs, "historical_originals_reused": 3, "model_cold_load_count_candidate": 26,
        "current_single_node_cli_cold_load_count_including_init": 50,
        "grouped_allocation_cap_gpu_seconds": caps, "grouped_planning_gpu_seconds": estimate,
        "previous_qualification_billed_gpu_seconds": 1852,
        "frozen_label_policy": "No target labels at model stages",
        "no_automatic_retry": True, "r05_group_entry_actual_status": "NOT_IMPLEMENTED_OR_SIGNED_HERE",
        "resources_are_provisional": True})


if __name__ == "__main__":
    main()
