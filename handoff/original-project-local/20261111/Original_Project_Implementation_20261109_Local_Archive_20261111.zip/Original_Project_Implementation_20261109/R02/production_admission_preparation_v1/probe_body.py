"""Body of the exact read-only request. PLAN is prepended by the local builder."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import pwd
import re
import socket


def file_sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def inspect(spec):
    path = Path(spec["path"])
    output = {key: spec[key] for key in ("role", "id", "path")}
    try:
        actual = path.resolve(strict=True)
        output["resolved"] = str(actual)
        if spec["resolved_expected"] is not None and str(actual) != spec["resolved_expected"]:
            raise ValueError("resolved path mismatch")
        if spec["check"] == "metadata":
            if not path.is_dir() or not os.access(path, os.R_OK | os.X_OK):
                raise ValueError("expected readable and traversable directory")
        elif spec["check"] == "executable":
            if not path.is_file() or not os.access(path, os.X_OK):
                raise ValueError("expected executable interpreter")
        else:
            if not path.is_file():
                raise ValueError("expected regular file")
            stat = path.stat()
            output["bytes"] = stat.st_size
            if spec["bytes_expected"] is not None and stat.st_size != spec["bytes_expected"]:
                raise ValueError("size mismatch")
            output["sha256"] = file_sha(path)
            after = path.stat()
            if (stat.st_size, stat.st_mtime_ns, stat.st_ino, stat.st_dev) != (
                    after.st_size, after.st_mtime_ns, after.st_ino, after.st_dev):
                raise ValueError("changed during read")
            if spec["sha256_expected"] is not None and output["sha256"] != spec["sha256_expected"]:
                raise ValueError("SHA256 mismatch")
        output["status"] = ("MATCH" if spec["sha256_expected"] else
                            "OBSERVED_NEW_HASH_REQUIRES_LOCK" if spec["check"] == "sha256" else "PATH_MATCH")
    except (OSError, ValueError) as error:
        output.update(status="STOP_ASSET_CHECK_FAILED", error=str(error))
    return output


def main():
    rows = PLAN["paths"]
    roles = {"SOURCE_H11", "TARGET_H11", "ORIGINAL_PREDICTION", "IMPORT_LOCK", "NATIVE_LOCK",
             "RUNTIME_PATH", "RUNTIME_PYTHON"}
    if pwd.getpwuid(os.geteuid()).pw_name != PLAN["account"] or len(rows) != PLAN["expected_entries"]:
        raise ValueError("account or inventory mismatch")
    for row in rows:
        p = Path(row["path"])
        if (not p.is_absolute() or ".." in p.parts or row["role"] not in roles
                or row["check"] not in {"sha256", "metadata", "executable"}
                or (row["sha256_expected"] is not None and not re.fullmatch("[0-9a-f]{64}", row["sha256_expected"]))):
            raise ValueError("invalid allowlisted entry")
    results = [inspect(row) for row in rows]
    fail = sum(row["status"] == "STOP_ASSET_CHECK_FAILED" for row in results)
    print(json.dumps({"status": "STOP_ASSET_CHECK_FAILED" if fail else "READ_ONLY_IDENTITY_OBSERVED_NOT_ADMITTED",
                      "utc": datetime.now(timezone.utc).isoformat(), "hostname": socket.gethostname(),
                      "account": PLAN["account"], "failed_entries": fail, "entries": results}))
    raise SystemExit(bool(fail))


if __name__ == "__main__":
    main()
