"""Run exactly the controller-signed asset probe and retain unmodified streams."""
import json
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

from prepare import HERE, ROOT, read, ref, sha, write

RELEASE_SHA = "37ff16201d547b52f736012b853925b00945a86c6eb07bb0580b9eae414a4402"


def main():
    release = ROOT / "CONTROLLER_PHASE1_READONLY_ASSET_PROBE_RELEASE.json"
    assert sha(release) == RELEASE_SHA
    spec = read(release)
    assert spec["status"] == "RELEASED_ONE_EXACT_READONLY_IDENTITY_PROBE"
    assert spec["remote_calls_max"] == 1 and spec["local_timeout_seconds"] == 640
    assert spec["read_only"] is True and spec["automatic_retry"] is False
    assert not any(spec[k] for k in ("remote_writes", "gpu", "sbatch", "model_loads",
                                    "functional_label_tables", "training_admission"))
    for key in ("gpu_qualification", "command_candidate", "allowlist", "stdin"):
        entry = spec[key]
        path = Path(entry["path"])
        assert path.stat().st_size == entry["bytes"] and sha(path) == entry["sha256"]
    command = read(Path(spec["command_candidate"]["path"]))
    for key in ("remote_command", "local_timeout_seconds"):
        assert command[key] == spec[key]
    for key in ("allowlist", "stdin"):
        assert command[key] == {k: spec[key][k] for k in ("path", "sha256")}
    stdin = Path(spec["stdin"]["path"]).read_bytes()
    transport = ROOT.parent.parent / "Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2"
    sys.path.insert(0, str(transport))
    from remote_qualification import SSH
    now = lambda: datetime.now(timezone.utc).isoformat()
    start = now()
    with (HERE / ".readonly_probe_claim").open("x", encoding="utf-8") as marker:
        json.dump({"start_utc": start, "release_sha256": RELEASE_SHA}, marker)
    returncode = None
    error = None
    try:
        p = subprocess.run(SSH + [spec["remote_command"]], input=stdin,
                           capture_output=True, timeout=640)
        stdout, stderr, returncode = p.stdout, p.stderr, p.returncode
    except subprocess.TimeoutExpired as exc:
        stdout, stderr, error = exc.stdout or b"", exc.stderr or b"", "LOCAL_TIMEOUT"
    except OSError as exc:
        stdout, stderr, error = b"", str(exc).encode(), "LOCAL_EXEC_ERROR"
    out, err = HERE / "PROBE_ACTUAL.stdout", HERE / "PROBE_ACTUAL.stderr"
    out.write_bytes(stdout)
    err.write_bytes(stderr)
    try:
        result = json.loads(stdout)
    except ValueError:
        result = {}
    observed = result.get("entries", [])
    expected = read(Path(spec["allowlist"]["path"]))["paths"]
    matched_identity = [(r["role"], r["id"], r["path"]) for r in observed] == [
        (r["role"], r["id"], r["path"]) for r in expected]
    receipt = {"release": ref(release), "start_utc": start, "end_utc": now(), "returncode": returncode,
               "local_error": error, "stdout": ref(out), "stderr": ref(err),
               "remote_status": result.get("status"), "remote_utc": result.get("utc"),
               "observed_rows": len(observed), "expected_rows": len(expected),
               "exact_inventory_order": matched_identity, "failed_entries": [
                   r for r in observed if r.get("status") == "STOP_ASSET_CHECK_FAILED"],
               "new_observed_hashes_pending_lock": [
                   r for r in observed if r.get("status") == "OBSERVED_NEW_HASH_REQUIRES_LOCK"],
               "gpu_seconds": 0, "sbatch": 0, "training_release": False}
    write("READONLY_PROBE_RECEIPT.json", receipt)
    print(json.dumps(receipt, ensure_ascii=False))


if __name__ == "__main__":
    main()
