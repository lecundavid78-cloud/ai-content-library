"""Remote body invoked only with the two exact controller-signed payloads."""
import base64
import hashlib
import io
import json
from pathlib import Path
import pwd
import os
import re
import subprocess
import zipfile

SLURM = "/public/gridview_20250224/slurm/bin/"
ACCOUNT = "s20223010065"


def emit(event):
    print(json.dumps(event), flush=True)


def run(args):
    result = subprocess.run(args, capture_output=True, text=True, timeout=40)
    if result.returncode:
        raise RuntimeError(f"{args[0]} exited {result.returncode}: {result.stderr}")
    return result.stdout


def queue_check(allowed_id=None):
    queue = run([SLURM+"squeue", "-h", "-u", ACCOUNT, "-o", "%i|%j|%T|%b"])
    for line in queue.splitlines():
        jid, name, state, gres = line.split("|")
        if jid == allowed_id:
            assert name == JOBS["S"]["job_name"], "unexpected dependency identity"
        elif "gpu" in gres.lower() or name in {j["job_name"] for j in JOBS.values()}:
            raise RuntimeError("resource conflict: " + line)
    return queue


def validate_new(j):
    root = Path(j["remote_root"])
    assert root.is_absolute() and not root.exists() and not root.is_symlink()
    history = run([SLURM+"sacct", "-X", "-n", "-P", "-S", "2026-11-10", "-u", ACCOUNT,
                   "--name", j["job_name"], "--format=JobIDRaw,JobName%100,State,ExitCode"])
    assert not history.strip(), "existing job identity; reconcile"


def stage(j):
    root = Path(j["remote_root"])
    blob = base64.b64decode(j["signed_b64"], validate=True)
    assert hashlib.sha256(blob).hexdigest() == j["signed_package"]["sha256"]
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        names = j["exact_file_hashes"]
        assert len(z.namelist()) == len(names) == 61 and set(z.namelist()) == set(names)
        files = {n: z.read(n) for n in names}
    assert all(hashlib.sha256(b).hexdigest() == names[n] for n, b in files.items())
    root.mkdir(exist_ok=False)
    for n, b in files.items():
        p = root / n
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("xb") as stream:
            stream.write(b)
        assert hashlib.sha256(p.read_bytes()).hexdigest() == names[n]
    (root/"logs").mkdir()


def submit(j, predecessor=None):
    root = Path(j["remote_root"])
    queue = queue_check(predecessor)
    if predecessor is not None:
        previous = run([SLURM+"sacct", "-X", "-n", "-P", "-j", predecessor,
                        "--format=JobIDRaw,JobName%100,State,ExitCode"])
        for line in previous.splitlines():
            jid, name, state, code = line.split("|")
            assert jid == predecessor and name == JOBS["S"]["job_name"]
            assert state in {"PENDING", "RUNNING", "CONFIGURING", "COMPLETING"} or (
                state == "COMPLETED" and code == "0:0"), "S predecessor failed"
    dep = [] if predecessor is None else ["--dependency=afterok:" + predecessor]
    command = [SLURM+"sbatch", "--parsable", "--chdir="+str(root), "--output="+str(root/"logs/init-%j.out"),
               "--error="+str(root/"logs/init-%j.err"), "--export=ALL,R02_RELEASE_SHA256="+j["outer_release"]["sha256"],
               *dep, str(root/"gpu_init.sbatch")]
    intent = {"architecture": j["architecture"], "job_name": j["job_name"], "root": str(root), "queue": queue,
              "dependency": dep, "command": command, "signed_sha256": j["signed_package"]["sha256"]}
    with Path(j["remote_submit_claim"]).open("x", encoding="utf-8") as stream:
        json.dump(intent, stream)
    emit(intent | {"status": "SUBMIT_STARTED"})
    result = subprocess.run(command, capture_output=True, text=True, timeout=40)
    match = re.fullmatch(r"([0-9]+)(?:;[^\s;]+)?", result.stdout.strip())
    valid = result.returncode == 0 and match is not None
    event = intent | {"status": "SLURM_ACCEPTED" if valid else "SLURM_REJECTED_OR_AMBIGUOUS",
                      "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr,
                      "job_id": match[1] if valid else None}
    with (root/"SUBMISSION_RECEIPT.json").open("x", encoding="utf-8") as stream:
        json.dump(event, stream)
    emit(event)
    if not valid:
        raise RuntimeError("submit failed or ambiguous; reconcile")
    return event["job_id"]


assert pwd.getpwuid(os.geteuid()).pw_name == ACCOUNT
os.umask(0o077)
queue_check()
for arch in ("S", "L"):
    validate_new(JOBS[arch])
    stage(JOBS[arch])
s_job = submit(JOBS["S"])
submit(JOBS["L"], s_job)
