import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import pwd
import re
import subprocess

SLURM = "/public/gridview_20250224/slurm/bin/"
ACCOUNT = "s20223010065"


def emit(value):
    print(json.dumps(value), flush=True)


def run(args):
    p = subprocess.run(args, capture_output=True, text=True, timeout=35)
    if p.returncode:
        raise RuntimeError(repr((args, p.returncode, p.stderr)))
    return p.stdout


assert pwd.getpwuid(os.geteuid()).pw_name == ACCOUNT
os.umask(0o077)
ids = "5221808,5221809"
accounting = run([SLURM+"sacct", "-X", "-n", "-P", "-j", ids,
                  "--format=JobIDRaw,JobName%100,State%40,ExitCode,ElapsedRaw,AllocTRES%150,WorkDir%300,Start,End"])
queue = run([SLURM+"squeue", "-h", "-j", ids, "-o", "%i|%j|%T|%R|%E"])
emit({"status": "INIT_STATUS_OBSERVED", "sacct": accounting, "squeue": queue})

root = Path(PLAN["root"])
assert root.is_absolute() and not root.exists() and not root.is_symlink()
name = PLAN["job_name"]
history = run([SLURM+"sacct", "-X", "-n", "-P", "-S", "2026-11-10", "-u", ACCOUNT,
               "--name", name, "--format=JobIDRaw,JobName%100,State,ExitCode"])
active = run([SLURM+"squeue", "-h", "-u", ACCOUNT, "-n", name, "-o", "%i|%j|%T"])
assert not history.strip() and not active.strip(), "existing CPU inspection; reconcile"
assert set(PLAN["files"]) == set(PLAN["payload"])
staged = {}
for name_in_zip, digest in PLAN["files"].items():
    p = PurePosixPath(name_in_zip)
    assert not p.is_absolute() and ".." not in p.parts and "\\" not in name_in_zip
    b = base64.b64decode(PLAN["payload"][name_in_zip], validate=True)
    assert hashlib.sha256(b).hexdigest() == digest
    staged[name_in_zip] = b
root.mkdir(exist_ok=False)
for n, b in staged.items():
    p = root / n
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("xb") as f:
        f.write(b)
    assert hashlib.sha256(p.read_bytes()).hexdigest() == PLAN["files"][n]
(root/"logs").mkdir()
command = [SLURM+"sbatch", "--parsable", "--chdir="+str(root),
           "--output="+str(root/"logs/cache-%j.out"), "--error="+str(root/"logs/cache-%j.err"),
           str(root/"inspect_cache.sbatch")]
intent = {"root": str(root), "job_name": name, "command": command, "release_sha256": PLAN["release_sha256"],
          "batch_sha256": PLAN["files"]["inspect_cache.sbatch"], "files_verified": len(staged)}
with (root/".submit_intent").open("x", encoding="utf-8") as f:
    json.dump(intent, f)
emit(intent | {"status": "SUBMIT_STARTED"})
result = subprocess.run(command, capture_output=True, text=True, timeout=40)
match = re.fullmatch(r"([0-9]+)(?:;[^\s;]+)?", result.stdout.strip())
accepted = result.returncode == 0 and match is not None
event = intent | {"status": "SLURM_ACCEPTED" if accepted else "SLURM_AMBIGUOUS_OR_REJECTED",
                  "job_id": match[1] if accepted else None, "returncode": result.returncode,
                  "stdout": result.stdout, "stderr": result.stderr}
with (root/"SUBMISSION_RECEIPT.json").open("x", encoding="utf-8") as f:
    json.dump(event, f)
emit(event)
if not accepted:
    raise RuntimeError("ambiguous or rejected submit; reconcile")
