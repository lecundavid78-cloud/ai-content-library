"""Inspect one hash-verified natural cache with the original tensor-only CPU loader."""
import argparse
from dataclasses import asdict
import hashlib
import json
from pathlib import Path

import torch
from pilot.contracts import digest
from pilot.storage import load_bundle
from r05_internal.reference.contracts import natural_sha256


def file_sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()


def inspect(row, native_path):
    p = Path(row["path"])
    assert file_sha(p) == row["sha256_expected"]
    assert file_sha(native_path) == row["native_lock_sha256"]
    lock = json.loads(native_path.read_bytes())
    bundle = load_bundle(p, "cpu")
    provenance = bundle["provenance"]
    natural = bundle["natural"]
    assert natural.protein_id == row["id"] and len(natural.wt_sequence) == row["length"]
    assert provenance["native_lock_sha256"] == row["native_lock_sha256"]
    assert provenance["natural_input_sha256"] == natural_sha256(natural)
    lengths = len(natural.wt_sequence)
    assert bundle["original_all19l"].shape == (19 * lengths,)
    assert bool(torch.isfinite(bundle["original_all19l"]).all())
    for expected in lock["members"]:
        k = expected["K"]
        m = bundle["members"][k]
        c = bundle["caches"][k]
        c.validate(m, natural)
        assert (m.weights_sha256, m.source_sha256, m.tokenizer_sha256, m.cls_sha256) == (
            expected["weights_sha256"], expected["modeling_source_sha256"],
            expected["tokenizer_sha256"], expected["head_sha256"])
        assert c.identity.structure_asset_sha256 == provenance["structure_asset_sha256"]
        assert bundle["h12"][k].shape == c.h11.shape
        assert bool(torch.isfinite(bundle["h12"][k]).all())
    for f in bundle["original_fields"]:
        assert f.logits25.shape == (lengths, 25) and bool(torch.isfinite(f.logits25).all())
    role = bundle["asset_role"]
    intended = row["role"].split("_")[0]
    return {"status": "SEMANTIC_MATCH_PENDING_CONTROLLER_ADMISSION" if role == intended else "ROLE_MISMATCH_STOP",
            "id": row["id"], "role": role, "intended_role": intended, "bundle_sha256": row["sha256_expected"],
            "wt_sha256": natural.wt_sha256, "native_lock_sha256": row["native_lock_sha256"],
            "natural_input_sha256": natural_sha256(natural), "structure_asset_sha256": provenance["structure_asset_sha256"],
            "member_identity_sha256": digest({str(k): asdict(m) for k, m in bundle["members"].items()}),
            "cache_schema": "FOURCELL_PREPARED_V1", "prefix_layer": 11,
            "full_wt_h11_h12_validated": True, "all_six_member_identities_match": True,
            "functional_values_present": False,
            "requires_separate_window_and_assay_identity_check": True}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", type=Path)
    parser.add_argument("native_lock", type=Path)
    args = parser.parse_args()
    rows = json.loads(args.candidate.read_bytes())["rows"]
    assert len(rows) == 6 and len({r["path"] for r in rows}) == 6
    failed = False
    for row in rows:
        try:
            result = inspect(row, args.native_lock)
        except (AssertionError, RuntimeError, OSError, KeyError, ValueError) as exc:
            result = {"id": row["id"], "status": "CACHE_CHECK_FAILED", "error": repr(exc)}
        print(json.dumps(result), flush=True)
        failed |= result["status"] != "SEMANTIC_MATCH_PENDING_CONTROLLER_ADMISSION"
    raise SystemExit(failed)
