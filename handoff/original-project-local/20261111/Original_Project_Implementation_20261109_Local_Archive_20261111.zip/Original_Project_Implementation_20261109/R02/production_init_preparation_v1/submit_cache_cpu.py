"""Deploy the exact six-cache CPU inspection and query the existing INIT jobs."""
import argparse
import base64
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import zipfile

from prepare_init import HERE, ROOT, encode, ref, sha

RELEASE_SHA = "2f55d483328b73aa8e99219f7c8ce7d141169d86dcbb51a66b53de7bdee2eb11"


def prepare():
    release = ROOT / "CONTROLLER_PHASE1_CPU_CACHE_INSPECTION_RELEASE.json"
    assert ref(release)["sha256"] == RELEASE_SHA
    r = json.loads(release.read_bytes())
    assert r["status"] == "RELEASED_ONE_PHASE1_CPU_CACHE_INSPECTION_ONLY"
    assert r["slurm"] == {"name": "OriginalProject_ProdCache_CPU", "max_submissions": 1, "cpu": 4,
                          "memory_gib": 32, "seconds": 900, "gpu": 0}
    for name in ("candidate", "script", "cache_lineage", "actual_server_identity", "code_parent"):
        assert ref(Path(r[name]["path"])) == r[name]
    candidate = Path(r["candidate"]["path"]).read_bytes()
    rows = json.loads(candidate)["rows"]
    assert len(rows) == len({row["path"] for row in rows}) == 6
    with zipfile.ZipFile(r["code_parent"]["path"]) as z:
        files = {n: z.read(n) for n in z.namelist() if n.startswith("code/legacy_v2/") and n.endswith(".py")}
        files["control/NATIVE_LOCK.json"] = z.read("control/NATIVE_LOCK.json")
        files["control/IMPORT_LOCK.json"] = z.read("control/IMPORT_LOCK.json")
        env = json.loads(z.read("control/GPU_DEPLOYMENT_LOCK.json"))["env"]
    assert sha(files["control/NATIVE_LOCK.json"]) == r["native_lock_sha256"]
    files["control/SIX_CACHE_CPU_CANDIDATE.json"] = candidate
    files["control/inspect_cache_cpu.py"] = Path(r["script"]["path"]).read_bytes()
    files["control/RELEASE.json"] = release.read_bytes()
    root = r["exact_remote_root"]
    binds = ",".join(f'{row["path"]}:{row["path"]}:ro' for row in rows)
    for row in rows:
        assert row["path"].startswith("/public/home/s20223010065/") and all(
            char.isalnum() or char in "/._-" for char in row["path"])
    hashes = {n: sha(b) for n, b in sorted(files.items())}
    files["control/PAYLOAD.sha256"] = "".join(f"{h}  {n}\n" for n, h in hashes.items()).encode()
    batch = fr"""#!/bin/bash
#SBATCH --job-name=OriginalProject_ProdCache_CPU
#SBATCH --partition=Gnode
#SBATCH --qos=high
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --time=00:15:00
#SBATCH --no-requeue
set -euo pipefail
umask 077
RUN={root}
cd "$RUN"
test "${{SLURM_CPUS_PER_TASK:?}}" = 4
test -z "${{SLURM_JOB_GPUS:-}}"
printf '%s  %s\n' '{sha(files["control/PAYLOAD.sha256"])}' control/PAYLOAD.sha256 | sha256sum -c --status
sha256sum -c --status control/PAYLOAD.sha256
mkdir .allocation_claim
OUT="$RUN/output-${{SLURM_JOB_ID:?}}"
mkdir "$OUT"
trap 'rc=$?; printf "{{\"exit_code\":%d}}\n" "$rc" > "$OUT/EXIT.json"' EXIT
mkdir "$OUT/home" "$OUT/tmp"
SIF={env["R02_SIF"]}
SING={env["R02_SINGULARITY"]}
printf '%s  %s\n' '{r["runtime_observed"]["cuda.sif"]["sha256"]}' "$SIF" | sha256sum -c --status
printf '%s  %s\n' '{r["runtime_observed"]["singularity"]["sha256"]}' "$SING" | sha256sum -c --status
PYENV={env["R02_RUNTIME_ENV"]}
BASE={env["R02_BASE_ENV"]}
SITE="$PYENV/lib/python3.11/site-packages"
LD="$SITE/torch/lib:$BASE/lib"
for p in "$SITE"/nvidia/*/lib; do test ! -d "$p" || LD="$p:$LD"; done
unset SINGULARITY_BIND SINGULARITY_BINDPATH APPTAINER_BIND APPTAINER_BINDPATH
export CUDA_VISIBLE_DEVICES=""
timeout --signal=TERM --kill-after=15 800 "$SING" exec --cleanenv --containall --no-home \
 --bind "$RUN/code:/code:ro,$RUN/control:/control:ro,$PYENV:$PYENV:ro,$BASE:$BASE:ro,$OUT:/out,{binds}" \
 --pwd /out --env CUDA_VISIBLE_DEVICES= --env NVIDIA_VISIBLE_DEVICES=none \
 --env OMP_NUM_THREADS=4 --env MKL_NUM_THREADS=4 --env OPENBLAS_NUM_THREADS=1 \
 --env PYTHONNOUSERSITE=1 --env PYTHONDONTWRITEBYTECODE=1 --env PYTHONPATH=/code/legacy_v2 \
 --env LD_LIBRARY_PATH="$LD" --env HOME=/out/home --env TMPDIR=/out/tmp \
 "$SIF" "$PYENV/bin/python" -B /control/check_import_then_inspect.py > "$OUT/CACHE_INSPECTION.jsonl" 2> "$OUT/CACHE_INSPECTION.stderr"
"""
    boot = """import hashlib, inspect, json, runpy, sys
from pathlib import Path
import numpy, torch, transformers
import transformers.dynamic_module_utils

lock = json.loads(Path("/control/IMPORT_LOCK.json").read_bytes())
assert (torch.__version__, numpy.__version__, transformers.__version__, sys.version.split()[0]) == (
    lock["torch_version"], lock["numpy_version"], lock["transformers_version"], lock["python_version"])
assert not torch.cuda.is_available()
for module, expected in lock["files"].items():
    path = Path(inspect.getfile(sys.modules[module])).resolve()
    assert path == Path(expected["path"]).resolve()
    with path.open("rb") as stream:
        assert hashlib.file_digest(stream, "sha256").hexdigest() == expected["sha256"]
sys.argv = ["/control/inspect_cache_cpu.py", "/control/SIX_CACHE_CPU_CANDIDATE.json", "/control/NATIVE_LOCK.json"]
runpy.run_path(sys.argv[0], run_name="__main__")
"""
    # Include the import gate in the files that the batch job verifies before entering the container.
    files["control/check_import_then_inspect.py"] = boot.encode()
    old_hash = sha(files["control/PAYLOAD.sha256"])
    hashes["control/check_import_then_inspect.py"] = sha(boot.encode())
    files["control/PAYLOAD.sha256"] = "".join(f"{h}  {n}\n" for n, h in sorted(hashes.items())).encode()
    files["inspect_cache.sbatch"] = batch.replace(old_hash, sha(files["control/PAYLOAD.sha256"])).encode()
    return r, files


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("check", "submit"))
    args = parser.parse_args()
    release, files = prepare()
    manifest = {n: sha(b) for n, b in sorted(files.items())}
    folder = HERE / "cpu_cache_inspection_v1"
    folder.mkdir(exist_ok=True)
    (folder/"inspect_cache.sbatch").write_bytes(files["inspect_cache.sbatch"])
    (folder/"DEPLOYMENT_MANIFEST.json").write_bytes(encode({"release_sha256": RELEASE_SHA, "files": manifest}))
    remote = (HERE/"submit_cache_cpu_remote.py").read_bytes()
    plan = {"root": release["exact_remote_root"], "job_name": release["slurm"]["name"],
            "release_sha256": RELEASE_SHA, "files": manifest,
            "payload": {n: base64.b64encode(b).decode() for n, b in files.items()}}
    payload = ("PLAN = " + repr(plan) + "\n").encode() + remote
    compile(payload, "<remote CPU submit>", "exec")
    subprocess.run(["F:/programming language/Git/bin/bash.exe", "-n", str(folder/"inspect_cache.sbatch")], check=True)
    if args.action == "check":
        print(json.dumps({"files": len(files), "batch_sha256": manifest["inspect_cache.sbatch"]}))
        return
    transport = ROOT.parent.parent / "Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2"
    sys.path.insert(0, str(transport))
    from remote_qualification import SSH, PYTHON
    with (folder/".submit_intent").open("xb") as f:
        f.write(encode({"root": plan["root"], "manifest": ref(folder/"DEPLOYMENT_MANIFEST.json")}))
    rc = None
    try:
        result = subprocess.run(SSH + [PYTHON], input=payload, capture_output=True, timeout=180)
        out, err, rc = result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired as exc:
        out, err = exc.stdout or b"", exc.stderr or b""
    except OSError as exc:
        out, err = b"", str(exc).encode()
    (folder/"SUBMISSION.stdout").write_bytes(out)
    (folder/"SUBMISSION.stderr").write_bytes(err)
    events = [json.loads(line) for line in out.splitlines()]
    receipt = {"utc": datetime.now(timezone.utc).isoformat(), "returncode": rc, "events": events,
               "stdout": ref(folder/"SUBMISSION.stdout"), "stderr": ref(folder/"SUBMISSION.stderr")}
    (folder/"SUBMISSION_RECEIPT.json").write_bytes(encode(receipt))
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
