"""Stage only signed files, then collect metadata from exactly three existing jobs."""
import base64
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import pwd
import subprocess
import zipfile

assert pwd.getpwuid(os.geteuid()).pw_name == "s20223010065"
os.umask(0o077)
root = Path(PLAN["root"])
assert root.is_absolute() and not root.exists() and not root.is_symlink(), "existing staging root; reconcile"
blob = base64.b64decode(ARCHIVE_B64, validate=True)
assert hashlib.sha256(blob).hexdigest() == PLAN["zip_sha256"]
with zipfile.ZipFile(io.BytesIO(blob)) as archive:
    assert archive.testzip() is None and len(archive.namelist()) == 24
    assert set(archive.namelist()) == set(PLAN["files"])
    for name in archive.namelist():
        relative = PurePosixPath(name)
        assert not relative.is_absolute() and ".." not in relative.parts and len(relative.parts) == 3
        data = archive.read(name)
        spec = PLAN["files"][name]
        assert hashlib.sha256(data).hexdigest() == spec["ref"]["sha256"] and len(data) == spec["bytes"]
    root.mkdir(exist_ok=False)
    with (root/".deploy_intent").open("x", encoding="utf-8") as f:
        json.dump({"release_sha256": PLAN["release_sha256"], "zip_sha256": PLAN["zip_sha256"]}, f)
    for name in archive.namelist():
        target = root / name
        assert str(target) == PLAN["files"][name]["host_path"]
        target.parent.mkdir(exist_ok=True, parents=True)
        with target.open("xb") as f:
            f.write(archive.read(name))
        with target.open("rb") as f:
            assert hashlib.file_digest(f, "sha256").hexdigest() == PLAN["files"][name]["ref"]["sha256"]
        assert target.stat().st_size == PLAN["files"][name]["bytes"]
        target.chmod(0o400)
event = {"status": "STAGED_24_HASH_VERIFIED", "utc": datetime.now(timezone.utc).isoformat(),
         "files": list(PLAN["files"].values()), "release_sha256": PLAN["release_sha256"]}
with (root/"DEPLOYMENT_RECEIPT.json").open("x", encoding="utf-8") as f:
    json.dump(event, f)
print(json.dumps(event), flush=True)

slurm = "/public/gridview_20250224/slurm/bin/"
ids = ("5221854", "5221808", "5221809")
proc = subprocess.run([slurm+"sacct", "-X", "-n", "-P", "-j", ",".join(ids),
                       "--format=JobIDRaw,JobName%100,State%40,ExitCode,ElapsedRaw,AllocTRES%150,WorkDir%300,Start,End"],
                      capture_output=True, text=True, timeout=40)
assert proc.returncode == 0, proc.stderr
queue = subprocess.run([slurm+"squeue", "-h", "-j", ",".join(ids), "-o", "%i|%j|%T|%R|%E"],
                       capture_output=True, text=True, timeout=40)
assert queue.returncode == 0, queue.stderr
artifacts = []
jobs = {}
base = root.parent
for job, suffix in (("5221854", "production_cache_inspection_v1"),
                    ("5221808", "production_init_S"), ("5221809", "production_init_L")):
    jobs[job] = base / suffix
terminal = {"COMPLETED", "FAILED", "TIMEOUT", "CANCELLED", "OUT_OF_MEMORY", "NODE_FAIL"}
for line in proc.stdout.splitlines():
    columns = line.split("|")
    job, name, state = columns[:3]
    assert job in jobs and columns[6] == str(jobs[job])
    if state.split()[0] not in terminal:
        continue
    location = jobs[job]
    out = location / ("output-" + job)
    selected = sorted(out.rglob("*")) if out.exists() else []
    selected += sorted((location/"logs").glob("*"+job+"*"))
    for file in selected:
        if not file.is_file() or file.suffix not in {".json", ".jsonl", ".stderr", ".stdout", ".out", ".err", ".pt"}:
            continue
        if file.suffix == ".pt" and file.name != "INIT.pt":
            continue
        if file.stat().st_size > 8 * 1024**2:
            continue
        assert file.resolve().is_relative_to(location)
        data = file.read_bytes()
        artifacts.append({"relative": job+"/"+file.relative_to(location).as_posix(), "remote": str(file),
                          "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data),
                          "payload": base64.b64encode(data).decode()})
print(json.dumps({"status": "EXISTING_JOBS_OBSERVED", "utc": datetime.now(timezone.utc).isoformat(),
                  "sacct": proc.stdout, "squeue": queue.stdout, "artifacts": artifacts}), flush=True)
