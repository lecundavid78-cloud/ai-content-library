"""Verify exact candidate guards, and link all six cache hashes to native-lock receipts."""
import json
from pathlib import Path
import subprocess
import tempfile
import zipfile

from prepare_init import EVIDENCE, HERE, NATIVE_SHA, ROOT, build, encode, ref, sha


def read(path):
    return json.loads(path.read_bytes())


def check_candidates():
    first = build()
    assert first == build()
    for arch in ("S", "L"):
        folder = HERE / arch
        intent = read(folder / "SUBMISSION_INTENT_NOT_RELEASED.json")
        inner = read(folder / "INNER_NOT_RELEASED.json")
        outer = read(folder / "OUTER_NOT_RELEASED.json")
        assert first[arch] == intent["archive"]
        with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(first[arch]["path"]) as z:
            root = Path(tmp)
            assert z.testzip() is None and len(z.namelist()) == 59
            assert {n: sha(z.read(n)) for n in z.namelist()} == intent["files"]
            assert not any(n.startswith("inputs/") or n.endswith(".pt") for n in z.namelist())
            z.extractall(root)
            c = root / "control"
            job = read(c / "JOB.json")
            deploy = read(c / "GPU_DEPLOYMENT_LOCK.json")
            ns = {"__name__": "init_fixture"}
            exec(compile((c / "gpu_action_launcher.py").read_bytes(), "<candidate>", "exec"), ns)
            env = ns["CACHE_ENV"] | {"SLURM_JOB_ID": "123", "SLURM_CPUS_PER_TASK": "8",
                                    "CUDA_VISIBLE_DEVICES": "0", "R02_RUN_ROOT": intent["remote_root"]}
            inner_path = c / "R05_ROOT_RELEASE.json"
            outer_path = c / "GPU_ACTION_RELEASE.json"
            for inner_edits in ({}, {"stage": "qualify"}, {"max_updates_per_case": 1}, {"wall_seconds": 721}):
                inner_path.write_bytes(encode(inner | {"status": "RELEASED"} | inner_edits))
                outer_path.write_bytes(encode(outer | {"status": "RELEASED", "inner_sha256": sha(inner_path.read_bytes())}))
                env["R02_RELEASE_SHA256"] = sha(outer_path.read_bytes())
                try:
                    actual = ns["gate"](root, env)
                except ValueError:
                    assert inner_edits
                else:
                    assert not inner_edits and actual == job
            script = root / "gpu_init.sbatch"
            assert "/inputs" not in script.read_text()
            assert all(f["sha256"] in script.read_text() for f in deploy["observed_runtime_files"].values())
            bash = Path("F:/programming language/Git/bin/bash.exe")
            subprocess.run([str(bash), "-n", str(script)], check=True)
    return first


def check_cache_lineage():
    paths = read(EVIDENCE / "ASSET_ALLOWLIST.json")["paths"]
    historical = ROOT.parent.parent / "Research_Diagnosis_20261108/ThreeTarget_FourCell_Replication_20261108/R02_Runtime"
    src = historical / "ALL18_QUALIFICATION_PREPARATION_V2/COLLECTED_20261108T033352Z/run"
    tgt = historical / "TARGET_CACHE_PREPARATION_V1/COLLECTED_20261108T040745Z/run"
    tnp = ROOT.parent.parent / ("Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/"
                               "QUALIFICATION_PREPARATION_V3/collected_job_5187833")
    routes = []
    for spec in paths:
        if spec["role"] == "SOURCE_H11":
            base, result = src, src / "output-5196127/result"
            index = result / "BATCH_QUALIFICATION_INDEX.json"
        elif spec["role"] == "TARGET_H11":
            if spec["id"] == "TnpB":
                base, result = tnp, tnp / "output-5187833/result"
            else:
                base, result = tgt, tgt / "output-5196457/result"
            index = result / "CACHE_INDEX.json"
            assert read(index)[spec["id"]]["sha256"] == spec["sha256_expected"]
        else:
            continue
        lock = base / "job/NATIVE_LOCK.json"
        receipt = result / "JOB_RECEIPT.json"
        assert ref(lock)["sha256"] == read(receipt)["native_lock_sha256"] == NATIVE_SHA
        assert index.read_bytes().count(spec["sha256_expected"].encode()) == 1
        routes.append({"id": spec["id"], "role": spec["role"], "cache_sha256": spec["sha256_expected"],
                       "cache_index": ref(index), "old_lock": ref(lock), "old_job_receipt": ref(receipt)})
    assert len(routes) == 6
    (HERE / "CACHE_NATIVE_LOCK_LINEAGE.json").write_bytes(encode({
        "native_lock_sha256": NATIVE_SHA, "byte_and_semantic_identity": True, "routes": routes,
        "bridge_required_for_native_lock": False, "cache_deserialized_or_formally_admitted": False}))


if __name__ == "__main__":
    print(json.dumps(check_candidates()))
    check_cache_lineage()
    print("PASS repeat archives; exact stage, time and update gates; no inputs; Bash syntax; six historical lock chains")
