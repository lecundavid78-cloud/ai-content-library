"""Byte-preserving staging of the exact signed source inputs and one accounting snapshot."""
import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import zipfile

from prepare_init import HERE, ROOT, encode, ref, sha

RELEASE_SHA = "e363b2014c8c72e32072e03ffb3e2da540a4b35143b6993e0dfc02366429b5ff"


def prepare():
    release = ROOT / "CONTROLLER_PHASE1_SOURCE_STAGING_RELEASE.json"
    assert ref(release)["sha256"] == RELEASE_SHA
    r = json.loads(release.read_bytes())
    assert r["status"] == "RELEASED_EXACT_SOURCE_TRAIN_ONLY_STAGING_NO_COMPUTE" and r["max_deployments"] == 1
    assert not any(r[k] for k in ("gpu", "sbatch", "model_loads", "functional_bank_parsing",
                                   "target_or_source_heldout_tables", "training_release"))
    assert ref(Path(r["manifest"]["path"])) == r["manifest"]
    manifest = json.loads(Path(r["manifest"]["path"]).read_bytes())
    root = PurePosixPath(r["exact_remote_root"])
    files = {}
    expected = {"TRAINONLY_ADMISSION.json", "train_bank.tsv", "BANK_INDEX.json", "pairs_2000.json"}
    groups = Counter()
    data = io.BytesIO()
    with zipfile.ZipFile(data, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=3) as z:
        for row in r["files"]:
            p = PurePosixPath(row["remote"]).relative_to(root)
            assert len(p.parts) == 3 and ".." not in p.parts and "\\" not in str(p)
            assert p.parts[:2] == (row["source_id"], row["bank_rule"])
            assert row["container"] == {"path": "/inputs/sources/" + p.as_posix(), "sha256": row["local"]["sha256"]}
            allowed = next(g for g in manifest["source_banks"] if (g["source_id"], g["bank_rule"], g["target"]) ==
                           (row["source_id"], row["bank_rule"], row["target_route"]))
            references = [allowed["relocated_admission_local"]] + [x["local"] for x in allowed["leaves"].values()]
            assert row["local"] in references and p.name == Path(row["local"]["path"]).name
            assert p.name in expected and p.as_posix() not in files
            b = Path(row["local"]["path"]).read_bytes()
            assert len(b) == row["local"]["bytes"] and sha(b) == row["local"]["sha256"]
            z.writestr(zipfile.ZipInfo(p.as_posix(), (2026, 11, 10, 0, 0, 0)), b,
                       compress_type=zipfile.ZIP_DEFLATED, compresslevel=3)
            files[p.as_posix()] = {"ref": row["container"], "host_path": row["remote"], "kind": "regular_file",
                                   "bytes": len(b), "source_id": row["source_id"], "bank_rule": row["bank_rule"],
                                   "target_route": row["target_route"]}
            groups[p.parts[:2]] += 1
    assert len(files) == 24 and len(groups) == 6 and set(groups.values()) == {4}
    blob = data.getvalue()
    return {"root": str(root), "release_sha256": RELEASE_SHA, "files": files, "zip_sha256": sha(blob)}, blob


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("check", "deploy"))
    args = parser.parse_args()
    plan, blob = prepare()
    folder = HERE / "source_staging_v1"
    folder.mkdir(exist_ok=True)
    (folder/"CANDIDATE_MANIFEST.json").write_bytes(encode(plan))
    script = (HERE/"stage_source_remote.py").read_bytes()
    compile(script, "<remote>", "exec")
    print(json.dumps({"files": len(plan["files"]), "archive_bytes": len(blob), "archive_sha256": plan["zip_sha256"]}),
          flush=True)
    if args.action == "check":
        return
    transport = ROOT.parent.parent / "Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2"
    sys.path.insert(0, str(transport))
    from remote_qualification import SSH, PYTHON
    with (folder/".deploy_intent").open("xb") as f:
        f.write(encode({"root": plan["root"], "release_sha256": RELEASE_SHA, "zip_sha256": sha(blob)}))
    payload = ("PLAN = " + repr(plan) + "\nARCHIVE_B64 = '").encode() + base64.b64encode(blob) + b"'\n" + script
    rc = None
    try:
        result = subprocess.run(SSH + [PYTHON], input=payload, capture_output=True, timeout=480)
        out, err, rc = result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired as exc:
        out, err = exc.stdout or b"", exc.stderr or b""
    except OSError as exc:
        out, err = b"", str(exc).encode()
    (folder/"STAGING.stdout").write_bytes(out)
    (folder/"STAGING.stderr").write_bytes(err)
    events = []
    for line in out.splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        for item in event.get("artifacts", []):
            data = base64.b64decode(item.pop("payload"), validate=True)
            assert sha(data) == item["sha256"] and len(data) == item["bytes"]
            rel = PurePosixPath(item["relative"])
            assert not rel.is_absolute() and ".." not in rel.parts
            dest = folder/"observed"/rel
            dest.parent.mkdir(exist_ok=True, parents=True)
            with dest.open("xb") as f:
                f.write(data)
            item["local_path"] = str(dest)
        events.append(event)
    staged = next((e for e in events if e.get("status") == "STAGED_24_HASH_VERIFIED"), None)
    if staged:
        assert staged["files"] == list(plan["files"].values())
    receipt = {"utc": datetime.now(timezone.utc).isoformat(), "exit_code": rc, "release_sha256": RELEASE_SHA,
               "staged": staged, "events": [e for e in events if e is not staged],
               "stdout": ref(folder/"STAGING.stdout"), "stderr": ref(folder/"STAGING.stderr"),
               "new_sbatch": 0, "gpu": 0}
    path = folder/"DEPLOYMENT_RECEIPT.json"
    path.write_bytes(encode(receipt))
    print(json.dumps({"receipt": ref(path), "exit_code": rc, "staged_files": len(staged["files"]) if staged else 0,
                      "accounting": [e.get("sacct") for e in receipt["events"] if "sacct" in e]}))


if __name__ == "__main__":
    main()
