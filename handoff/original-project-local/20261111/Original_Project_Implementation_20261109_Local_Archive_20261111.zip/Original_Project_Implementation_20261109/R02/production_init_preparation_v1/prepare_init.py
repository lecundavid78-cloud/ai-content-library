"""Build two independent, unsigned INIT-only candidates using the qualified runtime."""
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
EVIDENCE = HERE.parent / "production_admission_preparation_v1"
SOURCE = "RCRO_LAMBD_Tsuboyama_2023_1ORC"
NATIVE_SHA = "49e8719821c42f359ebbe489879c1094858ffebbd57f83dd557b58c6a04eea38"


def sha(b):
    return hashlib.sha256(b).hexdigest()


def encode(o):
    return (json.dumps(o, indent=2) + "\n").encode()


def ref(p):
    return dict(path=str(p), sha256=sha(p.read_bytes()), bytes=p.stat().st_size)


def replace(b, edits):
    for old, new in edits:
        old, new = old.encode(), new.encode()
        if b"\r\n" in b:
            old, new = old.replace(b"\n", b"\r\n"), new.replace(b"\n", b"\r\n")
        assert b.count(old) == 1, old
        b = b.replace(old, new)
    return b


def build():
    parent = ROOT / "GPU_QUALIFICATION_SIGNED_V1.zip"
    assert ref(parent)["sha256"] == "68a97075283239e93dee3d59ee91116ef9e8e955462bf04c8148085789da3634"
    with zipfile.ZipFile(parent) as z:
        original = {n: z.read(n) for n in z.namelist()}
    probe = EVIDENCE / "READONLY_PROBE_RECEIPT.json"
    observed = json.loads(probe.read_bytes())
    assert observed["returncode"] == 0 and observed["observed_rows"] == 66 and not observed["failed_entries"]
    fresh = {row["id"]: row for row in observed["new_observed_hashes_pending_lock"]}
    assert set(fresh) == {"cuda.sif", "singularity"}
    names = ("control/IMPORT_LOCK.json", "control/NATIVE_LOCK.json")
    common = {n: b for n, b in original.items() if n.startswith("code/") or n in names}
    for n, b in common.items():
        if n.startswith("code/") and n.endswith(".py"):
            current = ROOT / "R05/runtime_v1" / n.removeprefix("code/")
            assert current.read_bytes() == b, n
    assert sha(common["control/NATIVE_LOCK.json"]) == NATIVE_SHA
    outputs = {}
    for arch in ("S", "L"):
        folder = HERE / arch
        folder.mkdir(exist_ok=True)
        files = dict(common)
        job = json.loads(original["control/JOB.json"])
        job.update(stage="init", purpose="EXACT_SINGLE_SOURCE_INIT", device="cuda", output="/out/init-" + arch,
                   material_lock=None, cases=[{"source_id": SOURCE, "architecture": arch, "seed": 11}])
        files["control/JOB.json"] = encode(job)
        lock = json.loads(original["control/GPU_DEPLOYMENT_LOCK.json"])
        env = lock["env"]
        root = env["R02_RUN_ROOT"].rsplit("/", 1)[0] + "/production_init_" + arch
        env["R02_RUN_ROOT"] = root
        name = "OriginalProject_ProdInit_" + arch
        batch = "gpu_init.sbatch"
        narrow_native = ",".join(f"$R02_MODELROOT/ProSST-{k}:/weights/ProSST-{k}:ro"
                                 for k in (20, 128, 512, 1024, 4096))
        assert fresh["cuda.sif"]["path"] == env["R02_SIF"]
        assert fresh["singularity"]["path"] == env["R02_SINGULARITY"]
        verify_host = "\n".join(f'printf \'%s  %s\\n\' "{fresh[k]["sha256"]}" "${envname}" | sha256sum --check --status'
                                for k, envname in (("cuda.sif", "R02_SIF"), ("singularity", "R02_SINGULARITY")))
        files[batch] = replace(original["gpu_qualification.sbatch"], [
            ("OriginalProject_GPUqual_20261109", name),
            ("/gpu_qualification_v1\n", f"/production_init_{arch}\n"),
            ("00:20:00", "00:15:00"),
            ('"Slurm_cap_seconds":1200', '"Slurm_cap_seconds":900'),
            ("--kill-after=20 1140", "--kill-after=20 820"),
            ('$RUN/inputs:/inputs:ro,', ''),
            ('$R02_MODELROOT:/weights:ro', narrow_native),
            ('mkdir "$OUT/home" "$OUT/tmp"', 'mkdir "$OUT/home" "$OUT/tmp"\n' + verify_host),
            ('timeout --signal=TERM', 'unset SINGULARITY_BIND SINGULARITY_BINDPATH APPTAINER_BIND APPTAINER_BINDPATH\n'
             'timeout --signal=TERM'),
        ])
        lock.update(schema="R02_PRODUCTION_INIT_DEPLOYMENT_LOCK_V1", Slurm_seconds=900, container_seconds=820,
                    R05_alarm_seconds=720, sbatch_sha256=sha(files[batch]),
                    observed_runtime_files=fresh, probe_receipt_sha256=ref(probe)["sha256"])
        files["control/GPU_DEPLOYMENT_LOCK.json"] = encode(lock)
        launcher = "control/gpu_action_launcher.py"
        files[launcher] = replace(original[launcher], [
            ("R02_EXACT_GPU_QUALIFICATION_RELEASE_V1", "R02_EXACT_CLEAN_INIT_RELEASE_V1"),
            ('"slurm_seconds": 1200', '"slurm_seconds": 900'),
            ('"max_updates": 12', '"max_updates": 0'),
            ('"stage": "qualify", "wall_seconds": 1080', '"stage": "init", "wall_seconds": 720'),
            ('"max_updates_per_case": 2', '"max_updates_per_case": 0'),
            ('("qualify", "QUALIFICATION_ONLY_MAX2", "cuda", "/out/qualification")',
             f'("init", "EXACT_SINGLE_SOURCE_INIT", "cuda", "/out/init-{arch}")'),
            ('"qualification-only native job")', '"init-only native job")\n'
             f'    require(job["cases"] == [{{"source_id": "{SOURCE}", "architecture": "{arch}", "seed": 11}}]\n'
             '            and job["material_lock"] is None, "architecture-only init scope")'),
            ('root / "out/qualification"', f'root / "out/init-{arch}"'),
        ])
        manifest = "control/GPU_PAYLOAD_SHA256.json"
        files[manifest] = encode({"schema": "R02_GPU_MOUNTED_BYTES_V1", "files": {
            n: sha(b) for n, b in sorted(files.items()) if n != batch}})
        inner = json.loads(original["control/R05_ROOT_RELEASE.json"])
        inner.update(status="NOT_RELEASED", stage="init", wall_seconds=720, max_updates_per_case=0,
                     job_sha256=sha(files["control/JOB.json"]))
        outer = json.loads(original["control/GPU_ACTION_RELEASE.json"])
        outer.update(schema="R02_EXACT_CLEAN_INIT_RELEASE_V1", status="NOT_RELEASED", slurm_seconds=900,
                     max_updates=0, inner_sha256=None, job_sha256=inner["job_sha256"],
                     launcher_sha256=sha(files[launcher]), manifest_sha256=sha(files[manifest]),
                     deployment_lock_sha256=sha(files["control/GPU_DEPLOYMENT_LOCK.json"]))
        (folder / "INNER_NOT_RELEASED.json").write_bytes(encode(inner))
        (folder / "OUTER_NOT_RELEASED.json").write_bytes(encode(outer))
        archive = folder / f"PRODUCTION_INIT_{arch}_UNSIGNED.zip"
        with zipfile.ZipFile(archive, "w") as z:
            for n, b in sorted(files.items()):
                z.writestr(zipfile.ZipInfo(n, (2026, 11, 10, 0, 0, 0)), b, compress_type=zipfile.ZIP_DEFLATED)
        assert len(files) == 59 and not any(n.startswith("inputs/") for n in files)
        intent = {"status": "NOT_RELEASED", "architecture": arch, "job_name": name, "remote_root": root,
                  "local_submit_claim": str(folder / ".submit_intent"),
                  "remote_submit_claim": root + "/.submit_intent", "remote_allocation_claim": root + "/.gpu_allocation_claim",
                  "scope": {"gpu": 1, "cpu": 8, "memory_gib": 64, "slurm_seconds": 900,
                            "max_submissions": 1, "optimizer_updates": 0, "automatic_retry": False},
                  "archive": ref(archive), "job_sha256": inner["job_sha256"], "sbatch_sha256": lock["sbatch_sha256"],
                  "files": {n: sha(b) for n, b in sorted(files.items())}}
        (folder / "SUBMISSION_INTENT_NOT_RELEASED.json").write_bytes(encode(intent))
        outputs[arch] = intent["archive"]
    return outputs


if __name__ == "__main__":
    print(json.dumps(build()))
