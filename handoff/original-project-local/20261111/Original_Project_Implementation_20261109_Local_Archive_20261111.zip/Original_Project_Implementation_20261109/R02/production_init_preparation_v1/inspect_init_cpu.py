"""Read-only CPU verifier for an actual formal INIT and its pinned qualification reference."""
import argparse
import hashlib
import json
from pathlib import Path

import torch

KS = (20, 128, 512, 1024, 2048, 4096)
NATIVE = "49e8719821c42f359ebbe489879c1094858ffebbd57f83dd557b58c6a04eea38"
QUALIFIED = {"S": "611f6c926cd56459422382f0c47f5bcec024f1a7296d834af541e260c5a22ed1",
             "L": "84a18d839de170ea59550f420fb0f1f3f724df4c5fa71a57509d100a2f4c74ae"}


def layout(arch):
    if arch == "L":
        return {f"{k}/prosst.encoder.layer.11.attention.self.{projection}.{part}": shape
                for k in KS for projection in ("query", "value")
                for part, shape in (("A", (32, 768)), ("B", (768, 32)))}
    result = {"context.0.weight": (64, 46), "context.0.bias": (64,),
              "context.2.weight": (64, 64), "context.2.bias": (64,)}
    for k in KS:
        result.update({f"down.ProSST-{k}.weight": (64, 768), f"down.ProSST-{k}.bias": (64,),
                       f"up.ProSST-{k}.weight": (768, 64)})
    return result


def checked_load(path, digest):
    with path.open("rb") as stream:
        assert hashlib.file_digest(stream, "sha256").hexdigest() == digest
        stream.seek(0)
        return torch.load(stream, map_location="cpu", weights_only=True)


def inspect(arch, actual, actual_sha, qualified):
    state = checked_load(actual, actual_sha)
    prior = checked_load(qualified, QUALIFIED[arch])
    expected = layout(arch)
    for data in (state, prior):
        assert set(data) == {"schema", "architecture", "seed", "native_sha256", "frozen_sha256", "parameters"}
        assert (data["schema"], data["architecture"], data["seed"], data["native_sha256"]) == (
            "SINGLE_SOURCE_INIT_V1", arch, 11, NATIVE)
        assert set(data["parameters"]) == set(expected)
        for name, shape in expected.items():
            tensor = data["parameters"][name]
            assert tensor.device.type == "cpu" and tensor.dtype == torch.float32
            assert tuple(tensor.shape) == shape and bool(torch.isfinite(tensor).all())
            if name.startswith("up.") or name.endswith(".B"):
                assert torch.count_nonzero(tensor).item() == 0
    assert state["frozen_sha256"] == prior["frozen_sha256"]
    assert all(torch.equal(state["parameters"][k], prior["parameters"][k]) for k in expected)
    return {"schema": "PHASE1_INIT_INSPECTION_V1", "init_sha256": actual_sha,
            "checkpoint_schema": state["schema"], "architecture": arch, "seed": 11, "native_sha256": NATIVE,
            "frozen_sha256": state["frozen_sha256"], "qualified_frozen_sha256": prior["frozen_sha256"],
            "qualified_init_sha256": QUALIFIED[arch], "trainable_parameters": sum(t.numel() for t in state["parameters"].values()),
            "trainable_tensor_count": len(expected), "exact_original_whitelist_verified": True,
            "exact_seed11_parameters_match_qualified_clean_init": True}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("arch", choices=("S", "L"))
    parser.add_argument("actual", type=Path)
    parser.add_argument("actual_sha")
    parser.add_argument("qualified", type=Path)
    args = parser.parse_args()
    print(json.dumps(inspect(args.arch, args.actual, args.actual_sha, args.qualified)))
