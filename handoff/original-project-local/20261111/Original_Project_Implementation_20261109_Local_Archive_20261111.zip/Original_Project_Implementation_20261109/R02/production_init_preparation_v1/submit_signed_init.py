"""Submit the exact two clean INIT allocations in one serial Slurm dependency chain."""
import argparse
import base64
from datetime import datetime, timezone
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import zipfile

from prepare_init import HERE, ROOT, encode, ref, sha

RELEASE_SHA = "fbdfe17f56d107797cab8afeb0d239533ff697b579e27ac16d69eab4914565c6"


def verify():
    path = ROOT / "CONTROLLER_PHASE1_CLEAN_INIT_EXECUTION_RELEASE.json"
    assert ref(path)["sha256"] == RELEASE_SHA
    release = json.loads(path.read_bytes())
    assert release["status"] == "RELEASED_TWO_EXACT_SERIAL_PHASE1_CLEAN_INIT_ONLY"
    assert release["submission_order"] == ["S", "L"] and release["optimizer_updates"] == 0
    assert not any(release[k] for k in ("training_release", "source_bundle_or_target_bundle_mount",
                                       "functional_labels", "automatic_retry"))
    for key in ("compiler_acceptance", "budget_lock", "remote_identity_acceptance"):
        assert ref(Path(release[key]["path"])) == release[key]
    for arch in ("S", "L"):
        job = release["jobs"][arch]
        intent = json.loads((HERE / arch / "SUBMISSION_INTENT_NOT_RELEASED.json").read_bytes())
        assert job["status"] == "RELEASED_EXACT_PHASE1_CLEAN_INIT_ONLY" and job["architecture"] == arch
        for k, v in intent.items():
            if k != "status":
                assert job[k] == v, k
        assert Path(job["local_submit_claim"]) == HERE / arch / ".submit_intent"
        assert job["scope"] == {"gpu": 1, "cpu": 8, "memory_gib": 64, "slurm_seconds": 900,
                                "max_submissions": 1, "optimizer_updates": 0, "automatic_retry": False}
        for k in ("archive", "signed_package", "inner_release", "outer_release"):
            assert ref(Path(job[k]["path"])) == job[k], k
        signed = Path(job["signed_package"]["path"]).read_bytes()
        files = job["files"] | {"control/R05_ROOT_RELEASE.json": job["inner_release"]["sha256"],
                               "control/GPU_ACTION_RELEASE.json": job["outer_release"]["sha256"]}
        with zipfile.ZipFile(io.BytesIO(signed)) as z:
            assert len(z.namelist()) == len(files) == 61 and z.testzip() is None
            assert set(z.namelist()) == set(files) and {n: sha(z.read(n)) for n in z.namelist()} == files
            for n in files:
                p = PurePosixPath(n)
                assert not p.is_absolute() and ".." not in p.parts and "\\" not in n
                assert n.startswith(("code/", "control/")) or n == "gpu_init.sbatch"
            job_doc = json.loads(z.read("control/JOB.json"))
            assert job_doc["stage"] == "init" and job_doc["material_lock"] is None
            assert job_doc["cases"][0]["architecture"] == arch and job_doc["output"] == "/out/init-" + arch
        job.update(signed_b64=base64.b64encode(signed).decode(), exact_file_hashes=files)
    return release["jobs"]


def main():
    p = argparse.ArgumentParser()
    p.add_argument("mode", choices=("check", "submit"))
    args = p.parse_args()
    jobs = verify()
    remote = (HERE / "submit_init_remote.py").read_bytes()
    payload = ("JOBS = " + repr(jobs) + "\n").encode() + remote
    compile(payload, "<remote init submission>", "exec")
    if args.mode == "check":
        print("PASS exact signed S/L packages, 61 entries each; remote program compiles")
        return
    transport = ROOT.parent.parent / "Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2"
    sys.path.insert(0, str(transport))
    from remote_qualification import SSH, PYTHON
    for arch in ("S", "L"):
        assert not Path(jobs[arch]["local_submit_claim"]).exists(), "existing intent; reconcile"
    for arch in ("S", "L"):
        with Path(jobs[arch]["local_submit_claim"]).open("xb") as f:
            f.write(encode({"architecture": arch, "release_sha256": RELEASE_SHA,
                            "signed_sha256": jobs[arch]["signed_package"]["sha256"]}))
    code = None
    try:
        result = subprocess.run(SSH + [PYTHON], input=payload, capture_output=True, timeout=240)
        code, out, err = result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired as exc:
        out, err = exc.stdout or b"", exc.stderr or b""
    except OSError as exc:
        out, err = b"", str(exc).encode()
    stdout, stderr = HERE / "INIT_SUBMISSION.stdout", HERE / "INIT_SUBMISSION.stderr"
    stdout.write_bytes(out)
    stderr.write_bytes(err)
    events = []
    for line in out.splitlines():
        try:
            events.append(json.loads(line))
        except ValueError:
            continue
    receipt = {"utc": datetime.now(timezone.utc).isoformat(), "returncode": code, "events": events,
               "stdout": ref(stdout), "stderr": ref(stderr), "release_sha256": RELEASE_SHA}
    path = HERE / "INIT_SUBMISSION_RECEIPT.json"
    path.write_bytes(encode(receipt))
    print(json.dumps(receipt))


if __name__ == "__main__":
    main()
