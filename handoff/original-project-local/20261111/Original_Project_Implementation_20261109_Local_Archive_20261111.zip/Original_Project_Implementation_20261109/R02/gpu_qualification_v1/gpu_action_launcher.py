"""Gate the mounted qualification payload before importing the model runtime."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys

CONTROLLER = "01a1c09c-f9e6-70f1-b9e8-b988b89c755f"
OUTER = {
    "schema": "R02_EXACT_GPU_QUALIFICATION_RELEASE_V1",
    "controller": CONTROLLER, "status": "RELEASED", "action": "execute",
    "gpu_count": 1, "cpu_count": 8, "memory_gib": 64, "slurm_seconds": 1200,
    "formal_training": False, "target_labels": False, "max_submissions": 1,
    "max_updates": 12,
}
INNER = {
    "schema": "SINGLE_SOURCE_RUNTIME_RELEASE_V1", "controller": CONTROLLER,
    "status": "RELEASED", "stage": "qualify", "wall_seconds": 1080,
    "device": "cuda", "max_updates_per_case": 2,
}
CACHE_ENV = {
    "HF_HOME": "/out/hf_local", "HF_MODULES_CACHE": "/out/hf_modules",
    "TRANSFORMERS_CACHE": "/out/hf_local/hub", "XDG_CACHE_HOME": "/out/.cache",
    "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1",
    "CUBLAS_WORKSPACE_CONFIG": ":4096:8", "PYTHONPATH": "/code",
}
RELEASES = {"GPU_ACTION_RELEASE.json", "R05_ROOT_RELEASE.json"}
MANIFEST = "GPU_PAYLOAD_SHA256.json"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def gate(root, env):
    control = root / "control"
    outer_path = control / "GPU_ACTION_RELEASE.json"
    require(env.get("R02_RELEASE_SHA256") == sha(outer_path), "outer release SHA")
    outer = read(outer_path)
    inner = control / "R05_ROOT_RELEASE.json"
    job_path = control / "JOB.json"
    expected = OUTER | {
        "inner_sha256": sha(inner), "job_sha256": sha(job_path),
        "launcher_sha256": sha(control / "gpu_action_launcher.py"),
        "manifest_sha256": sha(control / MANIFEST),
        "deployment_lock_sha256": sha(control / "GPU_DEPLOYMENT_LOCK.json"),
    }
    require(outer == expected, "exact controller GPU qualification release")
    require(read(inner) == INNER | {"job_sha256": sha(job_path)}, "inner release scope")
    manifest = read(control / MANIFEST)
    require(manifest["schema"] == "R02_GPU_MOUNTED_BYTES_V1", "manifest schema")
    observed = set()
    for dirname in ("code", "inputs", "control"):
        for path in (root / dirname).rglob("*"):
            require(not path.is_symlink(), "symlink in frozen payload")
            if path.is_file():
                observed.add(path.relative_to(root).as_posix())
    excluded = {"control/" + name for name in RELEASES | {MANIFEST}}
    require(observed - excluded == set(manifest["files"]), "exact mounted inventory")
    for relative, digest in manifest["files"].items():
        parts = PurePosixPath(relative).parts
        require(len(parts) > 1 and parts[0] in ("code", "inputs", "control")
                and ".." not in parts, "invalid inventory path")
        require(sha(root.joinpath(*parts)) == digest, "mounted file changed: " + relative)
    job = read(job_path)
    require((job["stage"], job["purpose"], job["device"], job["output"]) ==
            ("qualify", "QUALIFICATION_ONLY_MAX2", "cuda", "/out/qualification"),
            "qualification-only native job")
    require(not (root / "out/qualification").exists(), "fresh output required")
    require(env.get("SLURM_JOB_ID", "").isdigit() and env.get("SLURM_CPUS_PER_TASK") == "8",
            "Slurm job identity and CPU count")
    visible = env.get("CUDA_VISIBLE_DEVICES", "")
    require(bool(visible) and "," not in visible and visible not in ("-1", "none", "NoDevFiles"),
            "one scheduler-assigned CUDA device required")
    require(all(env.get(name) == value for name, value in CACHE_ENV.items()),
            "cache, determinism and import environment at interpreter startup")
    lock = read(control / "GPU_DEPLOYMENT_LOCK.json")
    require(env.get("R02_RUN_ROOT") == lock["env"]["R02_RUN_ROOT"], "deployed run root")
    return job


def main():
    gate(Path("/"), os.environ)
    require(Path(__file__).resolve() == Path("/control/gpu_action_launcher.py"),
            "actual launcher path")
    argv = [sys.executable, "-B", "/code/runtime_cli.py", "execute", "--job",
            "/control/JOB.json", "--release", "/control/R05_ROOT_RELEASE.json"]
    out = Path("/out")
    with (out / "GPU_ACTION.stdout").open("xb") as stdout, (out / "GPU_ACTION.stderr").open("xb") as stderr:
        proc = subprocess.run(argv, stdout=stdout, stderr=stderr, check=False)
    (out / "GPU_ACTION_RECEIPT.json").write_text(json.dumps({
        "argv": argv, "returncode": proc.returncode, "slurm_job_id": os.environ["SLURM_JOB_ID"],
        "outer_release_sha256": os.environ["R02_RELEASE_SHA256"],
        "status": "EXITED_REQUIRES_OUTPUT_AND_SACCT_ACCEPTANCE",
    }, indent=2) + "\n", encoding="utf-8")
    raise SystemExit(proc.returncode)


if __name__ == "__main__":
    main()
