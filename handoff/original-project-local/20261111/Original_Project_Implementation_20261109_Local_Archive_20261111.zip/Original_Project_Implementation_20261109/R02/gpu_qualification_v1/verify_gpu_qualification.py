"""Independently verify terminal job evidence, without loading checkpoints or labels."""
import argparse
from collections import Counter
import csv
import json
import math
from pathlib import Path
import zipfile

import numpy as np

from execute_released_once import HERE, dump, need, sha, verified_plan


def read(path):
    return json.loads(path.read_bytes())


def verify(collection):
    plan = verified_plan()
    release = plan["release"]
    data = read(collection)
    job = data["job_id"]
    run = collection.parent / "run"
    out = run / ("output-" + job)
    qual = out / "qualification"
    need(data["terminal"], "terminal Slurm evidence required")
    index = {row["path"]: row for row in data["files"]}
    for name, info in index.items():
        path = run / name
        if path.is_file():
            need(sha(path.read_bytes()) == info["sha256"], "local evidence hash: " + name)
    gpu_tres = dict(field.split("=", 1) for field in data["alloc_tres"].split(",") if "=" in field)
    base = {"job_id": job, "sacct": data["sacct"], "state": data["state"], "exit_code": data["exit_code"],
            "allocation_seconds": data["elapsed_seconds"], "alloc_tres": data["alloc_tres"],
            "gpu_seconds": data["elapsed_seconds"] * int(gpu_tres.get("gres/gpu", 0)),
            "collection": {"path": str(collection), "sha256": sha(collection.read_bytes())},
            "deployed_bytes_unchanged": data.get("deployment_unchanged"),
            "formal_training_release": False, "target_labels_read": False}
    if data["state"] != "COMPLETED" or data["exit_code"] != "0:0":
        completed = []
        attempts = []
        for path in qual.glob("*/*/*/updates.jsonl"):
            for line in path.read_text(encoding="utf-8").splitlines():
                if line:
                    update = json.loads(line)
                    completed.append(update["completed_update"])
                    attempts.append(update["attempt"])
        return base | {
            "status": "GPU_QUALIFICATION_STOP_TERMINAL_FAILURE_NO_RETRY",
            "successful_cell_receipts": len(data["cells"]), "logged_completed_updates": len(completed),
            "logged_update_records": len(attempts),
            "runtime_receipt": read(qual / "RUNTIME_RECEIPT.json") if (qual / "RUNTIME_RECEIPT.json").is_file() else None,
            "failure_paths": [str(out / n) for n in ("GPU_ACTION.stderr", "qualification/FAILURE.txt")
                              if (out / n).is_file()] + [str(p) for p in (run / "logs").glob("*.err")],
        }

    need(gpu_tres.get("gres/gpu") == "1" and gpu_tres.get("cpu") == "8", "exact Slurm resources")
    need(0 < data["elapsed_seconds"] <= 1200, "GPU allocation cap")
    need(data["deployment_unchanged"], "signed deployment changed")
    accepted = read(run / "SUBMISSION_RECEIPT.json")
    need(accepted["job_id"] == job and accepted["stdout"].strip().split(";")[0] == job, "original sbatch receipt")
    runtime = read(qual / "RUNTIME_RECEIPT.json")
    need(runtime["status"] == "COMPLETE_UNEVALUATED" and runtime["stage"] == "qualify"
         and runtime["purpose"] == "QUALIFICATION_ONLY_MAX2" and runtime["device"] == "cuda"
         and runtime["actual_native_loads"] == 1 and runtime["job_sha256"] == release["job_sha256"]
         and runtime["release_sha256"] == release["inner_release"]["sha256"], "CUDA runtime identity")
    launcher = read(out / "GPU_ACTION_RECEIPT.json")
    need(launcher["returncode"] == 0 and launcher["slurm_job_id"] == job
         and launcher["outer_release_sha256"] == release["outer_release"]["sha256"], "outer execution receipt")

    members = {"20", "128", "512", "1024", "2048", "4096"}
    with zipfile.ZipFile(release["signed_package"]["path"]) as archive:
        native = json.loads(archive.read("control/NATIVE_LOCK.json"))
        job_cfg = json.loads(archive.read("control/JOB.json"))
        sources = {row["source_id"] for row in job_cfg["cases"]}
        naturals = {source: json.loads(archive.read(f"inputs/{source}/{source}.json")) for source in sources}
    loads = read(qual / "NATIVE_LOAD.json")
    need(set(loads) == members, "all native members loaded")
    for spec in native["members"]:
        load = loads[str(spec["K"])]
        actual = out / Path(load["actual_model_source"].removeprefix("/out/"))
        need(sha(actual.read_bytes()) == spec["modeling_source_sha256"], "actual model code SHA")
        need(sha(actual.with_name("configuration_prosst.py").read_bytes()) == spec["configuration_source_sha256"],
             "actual native configuration code SHA")
        need(not any(load["loading_info"].get(k) for k in
                     ("missing_keys", "unexpected_keys", "mismatched_keys", "error_msgs")), "native load keys")
    summary = read(qual / "QUALIFICATION_SUMMARY.json")
    need(summary["status"] == "THREE_SOURCE_SIX_CELL_PASS_NOT_FORMAL_TRAINING"
         and summary["actual_total_optimizer_updates"] == 12
         and summary["actual_native_prefix_full_forwards"] == 18
         and not summary["formal2000_training"], "qualification accounting")
    expected = {(source, architecture) for source in sources for architecture in ("S", "L")}
    need(Counter((x["source_id"], x["architecture"]) for x in summary["cells"]) == Counter(expected), "six cells")
    cells = []
    for row in summary["cells"]:
        source, arch = row["source_id"], row["architecture"]
        folder = qual / source / arch
        need(row == read(folder / "QUALIFICATION.json") and row["actual_updates"] == len(row["gradients"]) == 2
             and row["resume_new_instance_exact"] and row["frozen_bytes_unchanged"]
             and row["actual_scorer_calls"] == 6 and row["actual_member_head_calls"] == 36,
             "cell acceptance")
        for step in row["gradients"]:
            norms = step["head_input_gradient_norms"]
            need(set(norms) == members and all(math.isfinite(x) and x > 0 for x in norms.values()), "six head gradients")
        first = read(folder / "first/PAUSE_RECEIPT.json")
        second = read(folder / "second/TRAIN_RECEIPT.json")
        need(first["completed_updates"] == first["attempts"] == 1
             and second["completed_updates"] == second["attempts"] == 2
             and second["resume_checkpoint"]["sha256"] == first["checkpoints"][0]["sha256"], "resume sequence")
        update_times = []
        for phase, step in (("first", 1), ("second", 2)):
            lines = (folder / phase / "updates.jsonl").read_text(encoding="utf-8").splitlines()
            need(len(lines) == 1, "exact single update per phase")
            update = json.loads(lines[0])
            need(update["attempt"] == update["completed_update"] == step, "exact update cursor")
            update_times.append(update.get("elapsed_seconds"))
        checkpoint = (folder / "second/STEP_2.pt").relative_to(run).as_posix()
        need(index[checkpoint]["sha256"] == row["checkpoint_sha256"], "final qualification checkpoint SHA")
        natural = naturals[source]
        sequence = natural["wt_sequence"]
        length = len(sequence)
        full = read(folder.parent / "FULL_SPAN.json")
        need(full["WT_length"] == length and full["normalization_universe"] == 19 * length
             and full["truncation"] is False and set(full["members"]) == members, "full WT span")
        pred = folder / "RAW_SOURCE_QUALIFICATION"
        record = read(pred / "PREDICTION_RECORD.json")
        need(record["n_full19l"] == 19 * length and record["no_functional_labels"] is True
             and record["wt_sha256"] == natural["wt_sha256"] and record["protein_id"] == source, "prediction identity")
        need(sha((pred / "RAW.npz").read_bytes()) == record["raw_sha256"] == row["raw_export_sha256"]
             and sha((pred / "PREDICTIONS.csv").read_bytes()) == record["csv_sha256"], "raw export SHA")
        ids = [f"{wt}{pos}{alt}" for pos, wt in enumerate(sequence, 1)
               for alt in "ACDEFGHIKLMNPQRSTVWY" if alt != wt]
        with np.load(pred / "RAW.npz", allow_pickle=False) as raw:
            need(raw["variant_ids"].tolist() == ids and raw["ensemble"].shape == (19 * length,)
                 and np.isfinite(raw["ensemble"]).all(), "canonical finite 19L")
            for member in members:
                logits = raw["logits_" + member]
                need(logits.shape == (length, 25) and np.isfinite(logits).all(), "native finite logits")
            with (pred / "PREDICTIONS.csv").open(newline="") as stream:
                export = list(csv.DictReader(stream))
            need([x["variant_id"] for x in export] == ids
                 and np.array_equal([float(x["score"]) for x in export], raw["ensemble"]), "CSV/NPZ agreement")
        cells.append({"source": source, "architecture": arch, "candidates": 19 * length,
                      "cell_seconds": row["elapsed_seconds"], "update_seconds": update_times})
    return base | {"status": "PASS_ACTUAL_CUDA_QUALIFICATION_ONLY", "cells": cells,
                   "actual_updates": 12, "native_full_prefix_forwards": 18, "scorer_calls": 36, "member_head_calls": 216,
                   "runtime_seconds": runtime["elapsed_seconds"],
                   "locked_libraries_actual_import_gate_passed": True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("collection", type=Path)
    args = parser.parse_args()
    report = verify(args.collection.resolve())
    path = HERE / ("GPU_QUALIFICATION_ACCEPTANCE_" + report["job_id"] + ".json")
    dump(path, report)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
