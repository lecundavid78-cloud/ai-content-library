import copy
from pathlib import Path
import tempfile
import unittest
import zipfile

from gpu_action_launcher import CACHE_ENV, gate, read, sha
from prepare_candidate import HERE, ACCEPTED, encode


class LauncherChecks(unittest.TestCase):
    def setUp(self):
        work = tempfile.TemporaryDirectory()
        self.addCleanup(work.cleanup)
        self.root = Path(work.name)
        with zipfile.ZipFile(HERE / "GPU_QUALIFICATION_UNSIGNED_V1.zip") as archive:
            archive.extractall(self.root)
        control = self.root / "control"
        self.inner = control / "R05_ROOT_RELEASE.json"
        self.outer = control / "GPU_ACTION_RELEASE.json"
        self.env = CACHE_ENV | {
            "CUDA_VISIBLE_DEVICES": "0", "SLURM_JOB_ID": "123", "SLURM_CPUS_PER_TASK": "8",
            "R02_RUN_ROOT": read(control / "GPU_DEPLOYMENT_LOCK.json")["env"]["R02_RUN_ROOT"],
        }

    def release_fixture(self, **outer_overrides):
        """Only ever writes synthetic release objects inside a disposable test directory."""
        inner = read(HERE / "R05_ROOT_RELEASE_NOT_RELEASED.json") | {"status": "RELEASED"}
        self.inner.write_bytes(encode(inner))
        outer = read(HERE / "GPU_ACTION_RELEASE_NOT_RELEASED.json") | {
            "status": "RELEASED", "inner_sha256": sha(self.inner),
        } | outer_overrides
        self.outer.write_bytes(encode(outer))
        self.env["R02_RELEASE_SHA256"] = sha(self.outer)

    def test_unsigned_absence_denied(self):
        with self.assertRaises(FileNotFoundError):
            gate(self.root, self.env)

    def test_valid_fixture_cpu_and_gpu_job_differ_only_by_device(self):
        self.release_fixture()
        with zipfile.ZipFile(ACCEPTED / "CPU_QUALIFICATION_CACHEFIX_SIGNED_V1.zip") as cpu:
            with zipfile.ZipFile(HERE / "GPU_QUALIFICATION_UNSIGNED_V1.zip") as gpu:
                self.assertNotIn("control/GPU_ACTION_RELEASE.json", gpu.namelist())
                self.assertNotIn("control/R05_ROOT_RELEASE.json", gpu.namelist())
                for name in cpu.namelist():
                    if name.startswith(("code/", "inputs/")):
                        self.assertEqual(cpu.read(name), gpu.read(name), name)
            job = copy.deepcopy(gate(self.root, self.env))
            job["device"] = "cpu"
            import json
            self.assertEqual(job, json.loads(cpu.read("control/JOB.json")))

    def test_outer_scope_and_outer_hash(self):
        self.release_fixture(formal_training=True)
        with self.assertRaisesRegex(ValueError, "controller"):
            gate(self.root, self.env)
        self.release_fixture()
        self.env["R02_RELEASE_SHA256"] = "0" * 64
        with self.assertRaisesRegex(ValueError, "outer release SHA"):
            gate(self.root, self.env)

    def test_inner_hash_and_cap(self):
        self.release_fixture()
        self.inner.write_bytes(encode(read(self.inner) | {"max_updates_per_case": 3}))
        with self.assertRaisesRegex(ValueError, "controller"):
            gate(self.root, self.env)
        self.outer.write_bytes(encode(read(self.outer) | {"inner_sha256": sha(self.inner)}))
        self.env["R02_RELEASE_SHA256"] = sha(self.outer)
        with self.assertRaisesRegex(ValueError, "inner release scope"):
            gate(self.root, self.env)

    def test_changed_code_and_extra_payload(self):
        self.release_fixture()
        extra = self.root / "code/unlocked.py"
        extra.write_text("extra", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "inventory"):
            gate(self.root, self.env)
        extra.unlink()
        (self.root / "code/runtime_cli.py").write_text("changed", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "mounted file changed"):
            gate(self.root, self.env)

    def test_missing_or_multiple_cuda_devices(self):
        self.release_fixture()
        for value in ("", "0,1", "-1"):
            with self.subTest(value=value), self.assertRaisesRegex(ValueError, "CUDA device"):
                gate(self.root, self.env | {"CUDA_VISIBLE_DEVICES": value})

    def test_all_four_cache_variables_mandatory(self):
        self.release_fixture()
        for name in ("HF_HOME", "HF_MODULES_CACHE", "TRANSFORMERS_CACHE", "XDG_CACHE_HOME"):
            with self.subTest(name=name), self.assertRaisesRegex(ValueError, "interpreter startup"):
                gate(self.root, self.env | {name: ""})

    def test_existing_output_rejected(self):
        self.release_fixture()
        (self.root / "out/qualification").mkdir(parents=True)
        with self.assertRaisesRegex(ValueError, "fresh output"):
            gate(self.root, self.env)


if __name__ == "__main__":
    unittest.main()
