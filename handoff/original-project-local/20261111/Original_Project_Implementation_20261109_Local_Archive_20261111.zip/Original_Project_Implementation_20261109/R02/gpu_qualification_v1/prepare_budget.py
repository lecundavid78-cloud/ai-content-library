"""Check formal inventory metadata and compute an explicitly historical budget."""
import math
from pathlib import Path

from prepare_candidate import PROJECT, CPU, ACCEPTED, need, read, receipt, sha, write


def main():
    inventory_path = PROJECT / "DEVELOPMENT_PHASE1_INVENTORY.json"
    history_path = PROJECT / "HISTORICAL_TIMING_PLANNING.json"
    evidence_path = PROJECT / "R02/RUNTIME_METADATA_EVIDENCE.json"
    r01 = PROJECT / "R01/production_inputs_v1"
    ledger_path = ACCEPTED / "CPU_QUALIFICATION_ATTEMPT_LEDGER.json"
    inv, history, evidence, ledger = map(read, (inventory_path, history_path, evidence_path, ledger_path))
    ready = read(r01 / "READY.json")
    need(sha(r01 / "READY.json") == inv["source_ready_sha256"], "exact R01 bank root")
    routes = {row["target"]: row for row in inv["development_routes"]}
    need(len(routes) == 3, "expected three targets")
    old_times = {(row["source_id"], row["architecture"]): row for row in history["rows"]}
    tracks = inv["training_trajectories"]
    expected = {(target, arch, bank) for target in routes for arch in ("S", "L")
                for bank in ("full_train", "small594")}
    need(len(tracks) == len(expected) == 12 and expected == {
        (row["target"], row["architecture"], row["bank_rule"]) for row in tracks}, "trajectory grid")
    outputs = {(row["track_id"], row["target"], step) for row in tracks for step in (500, 1000, 2000)}
    predictions = inv["checkpoint_predictions"]
    need(len(predictions) == len(outputs) == 36 and outputs == {
        (row["track_id"], row["target"], row["step"]) for row in predictions}, "prediction grid")
    timings = []
    sources = {}
    source_ids = {row["source_id"] for row in routes.values()}
    historical_assets = [row for row in evidence["assets"]
                         if row["kind"] == "TARGET_fullWT_h11_bundle"
                         or row.get("source_id") in source_ids]
    for track in tracks:
        source_id, target, bank, arch = (track[k] for k in ("source_id", "target", "bank_rule", "architecture"))
        need(routes[target]["source_id"] == source_id, "wrong target/source")
        need((track["steps"], track["seed"], track["lr"], track["checkpoints"]) ==
             (2000, 11, 1e-4, [500, 1000, 2000]), "schedule mismatch")
        binding = ready["sources"][source_id]["banks"][bank]
        admission = Path(binding["path"])
        need(sha(admission) == binding["sha256"] == track["source_admission_sha256"], "source admission identity")
        row = read(admission)
        need(row["source_id"] == source_id and row["bank_rule"] == bank
             and row["count"] == track["bank_count"]
             and row["pairs"]["sha256"] == track["pair_stream_sha256"]
             and row["pairs_each_class_per_step"] == 128 and row["steps"] == 2000,
             "pair/admission metadata mismatch")
        sources.setdefault(source_id, {})[bank] = {
            "role": row["role"], "count": row["count"], "admission": binding,
            "index": row["index"], "train_only_bank": row["bank"], "pair_schedule": row["pairs"],
        }
        old = old_times[source_id, arch]
        per_update = old["max_historical_steady_mean_seconds"]
        timings.append({
            "track_id": track["track_id"], "historical_rows": old["historical_rows"],
            "historical_max_steady_mean_gpu_seconds": per_update,
            "historical_based_update_seconds": 2000 * per_update,
            "assumed_startup_restore_checkpoint_seconds": 120,
            "illustrative_job_seconds_with_margin": math.ceil(1.25 * (2000 * per_update + 120)),
        })
    compute = sum(row["historical_based_update_seconds"] for row in timings)
    init_reserve, train_reserve, prediction_reserve = 2 * 120, 12 * 120, 36 * 180
    rough = math.ceil(1.25 * (compute + init_reserve + train_reserve + prediction_reserve))
    write("FORMAL_BUDGET_DRAFT.json", {
        "status": "ILLUSTRATIVE_ONLY_NOT_RELEASED",
        "evidence": {path.name: receipt(path) for path in (inventory_path, history_path, evidence_path,
                     r01 / "READY.json", r01 / "VALIDATION.json", ledger_path,
                     CPU / "ACTUAL_RUNTIME_IDENTITY_INSPECTION.json")},
        "measured_new_CPU": {"qualification_allocated_seconds": 1076,
                             "failed_plus_success_core_seconds": ledger["total_CPU_core_seconds"],
                             "GPU_seconds": ledger["GPU_seconds"], "cells": ledger["cells"]},
        "qualification_GPU_candidate": {"single_GPU_hard_seconds": 1200, "measured_seconds": None},
        "formal_counts": {"clean_init_jobs_if_shared_exactly_by_architecture": 2, "trajectories": 12,
                          "optimizer_updates": 24000, "checkpoint_predictions": 36, "new_originals": 0},
        "old_GPU_data_scope": "historical two-source alternating updates; no new single-source GPU timings",
        "tracks": timings, "source_contract_metadata_only": sources,
        "historical_bundle_candidates_not_readmitted": historical_assets,
        "illustration": {"update_compute_seconds": compute, "init_reserve_seconds": init_reserve,
                         "train_io_reserve_seconds": train_reserve, "prediction_reserve_seconds": prediction_reserve,
                         "margin_fraction_assumed": .25, "formal_GPU_seconds_illustrative": rough,
                         "including_qualification_cap_seconds_illustrative": rough + 1200},
        "excluded_unknowns": ["new bundle creation, if required", "queue time", "failed/requeued jobs",
                              "storage, transfer and CPU evaluation", "any additional timing or recovery allocations"],
        "calibration_required": ["new GPU model import/CUDA and six-cell run", "native weight/hash and bundle I/O",
                                 "real warm/steady single-source timings and checkpoint write/restore",
                                 "per-target full19L and seal durations, especially 1368 aa SpCas9",
                                 "actual scheduler accounting before any production budget decision"],
        "new_GPU_seconds": 0, "new_model_loads": 0, "functional_target_labels_read": False,
    })


if __name__ == "__main__":
    main()
