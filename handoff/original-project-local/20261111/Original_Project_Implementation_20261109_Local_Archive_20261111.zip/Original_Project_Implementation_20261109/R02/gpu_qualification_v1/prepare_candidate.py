"""Build the unsigned qualification artifact from the accepted CPU archive."""
import hashlib
import io
import json
from pathlib import Path
import zipfile

from gpu_action_launcher import INNER, MANIFEST, OUTER, sha, read

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
CPU = HERE.parent / "qualification_v1"
ACCEPTED = CPU / "cachefix_execution_v1"
PARENT_SHA = "54bdc09586d31fe304cf6be6539e4cd3126f6a3a419eb76ab3bf3dc8cfaf5732"
ACCEPTANCE_SHA = "eee9e65ad326e7ab165f9257745b9719b2d6010818a0096f10e926c7d7fb17e7"
LOCKS = ("IMPORT_LOCK.json", "NATIVE_LOCK.json", "MATERIAL_LOCK.json",
         "QUALIFICATION_SOURCE_ROLE_CONTRACT.md")


def need(condition, message):
    if not condition:
        raise ValueError(message)


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode("utf-8")


def digest(blob):
    return hashlib.sha256(blob).hexdigest()


def write(name, value):
    (HERE / name).write_bytes(encode(value))


def receipt(path):
    return {"path": str(path), "sha256": sha(path), "bytes": path.stat().st_size}


def main():
    acceptance = PROJECT / "CONTROLLER_ACTUAL_CPU_QUALIFICATION_ACCEPTANCE.json"
    need(sha(acceptance) == ACCEPTANCE_SHA, "controller CPU acceptance identity")
    accepted = read(acceptance)
    need((accepted["job"], accepted["actual_cells"], accepted["actual_optimizer_updates"],
          accepted["formal_training_release"]) == ("5214122", 6, 12, False), "CPU qualification scope")
    for name in ("owner_receipt", "source_collection"):
        item = accepted[name]
        need(sha(Path(item["path"])) == item["sha256"], "CPU returned evidence changed")
    parent = ACCEPTED / "CPU_QUALIFICATION_CACHEFIX_SIGNED_V1.zip"
    need(sha(parent) == PARENT_SHA, "accepted CPU archive changed")
    with zipfile.ZipFile(parent) as source:
        names = source.namelist()
        need(len(names) == len(set(names)) and source.testzip() is None, "CPU archive integrity")
        payload = {name: source.read(name) for name in names
                   if name.startswith(("code/", "inputs/")) or name in {"control/" + x for x in LOCKS}}
        cpu_job = json.loads(source.read("control/JOB.json"))
    need(cpu_job["device"] == "cpu" and cpu_job["stage"] == "qualify", "CPU job scope")
    job = cpu_job | {"device": "cuda"}
    need(len(job["cases"]) == 3 and job["output"] == "/out/qualification", "scope changed")
    code = {name.removeprefix("code/"): digest(value) for name, value in payload.items()
            if name.startswith("code/") and name.endswith(".py")}
    need(code == job["runtime_code_sha256"], "real frozen kernel files do not match job")
    for name in ("native_lock", "import_lock", "material_lock"):
        ref = job[name]
        need(digest(payload[ref["path"].lstrip("/")]) == ref["sha256"], "job lock identity")
    launcher = HERE / "gpu_action_launcher.py"
    batch = HERE / "gpu_qualification.sbatch"
    batch_bytes = batch.read_bytes().replace(b"\r\n", b"\n")
    env = read(CPU / "EXACT_RUNTIME_ENV_V3.json")["env"]
    env["R02_RUN_ROOT"] = env["R02_RUN_ROOT"].removesuffix("/cpu_qualification_v1") + "/gpu_qualification_v1"
    for name, value in env.items():
        key = "RUN" if name == "R02_RUN_ROOT" else name
        need(f"\n{key}={value}\n".encode() in batch_bytes, "script path mismatch: " + name)
    for line in ("#SBATCH --time=00:20:00", "#SBATCH --cpus-per-task=8", "#SBATCH --mem=64G",
                 "#SBATCH --gres=gpu:NVIDIAA800-SXM4-80GB:1", "#SBATCH --no-requeue"):
        need(line.encode() in batch_bytes.splitlines(), "Slurm request mismatch")
    lock = {
        "schema": "R02_GPU_DEPLOYMENT_LOCK_V1", "env": env,
        "cpu_archive_sha256": PARENT_SHA, "cpu_acceptance_sha256": ACCEPTANCE_SHA,
        "sbatch_sha256": digest(batch_bytes), "Slurm_seconds": 1200, "container_seconds": 1140,
        "R05_alarm_seconds": 1080, "max_submissions": 1,
    }
    payload["control/GPU_DEPLOYMENT_LOCK.json"] = encode(lock)
    payload["control/JOB.json"] = encode(job)
    payload["control/gpu_action_launcher.py"] = launcher.read_bytes()
    manifest = {name: digest(value) for name, value in sorted(payload.items())}
    manifest_bytes = encode({"schema": "R02_GPU_MOUNTED_BYTES_V1", "files": manifest})
    payload["control/" + MANIFEST] = manifest_bytes
    payload["gpu_qualification.sbatch"] = batch_bytes
    archive = HERE / "GPU_QUALIFICATION_UNSIGNED_V1.zip"
    output = io.BytesIO()
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as zipped:
        for name, value in sorted(payload.items()):
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
            zipped.writestr(info, value, compress_type=zipfile.ZIP_DEFLATED)
    archive.write_bytes(output.getvalue())
    inner = INNER | {"status": "NOT_RELEASED", "job_sha256": manifest["control/JOB.json"]}
    outer = OUTER | {
        "status": "NOT_RELEASED", "inner_sha256": None, "job_sha256": inner["job_sha256"],
        "launcher_sha256": manifest["control/gpu_action_launcher.py"],
        "manifest_sha256": digest(manifest_bytes),
        "deployment_lock_sha256": manifest["control/GPU_DEPLOYMENT_LOCK.json"],
    }
    write("R05_ROOT_RELEASE_NOT_RELEASED.json", inner)
    write("GPU_ACTION_RELEASE_NOT_RELEASED.json", outer)
    write("SUBMISSION_INTENT_NOT_RELEASED.json", {
        "status": "NOT_RELEASED", "purpose": "QUALIFICATION_ONLY_MAX2",
        "unsigned_archive": receipt(archive), "remote_root_must_be_new": env["R02_RUN_ROOT"],
        "remote_submission_claim": env["R02_RUN_ROOT"] + "/.submit_intent",
        "local_submission_claim": str(HERE / ".submit_intent"),
        "allocation_claim": env["R02_RUN_ROOT"] + "/.gpu_allocation_claim",
        "sbatch_sha256": digest(batch_bytes), "inner_release_sha256": None,
        "outer_release_sha256": None, "sacct_or_submit_job_id": None,
        "submit_allowed": False, "no_automatic_retry": True,
    })
    write("PACKAGE_MANIFEST.json", {
        "archive": receipt(archive), "cpu_parent": receipt(parent), "cpu_acceptance": receipt(acceptance),
        "cpu_job_sha256": sha_from_parent(parent, "control/JOB.json"),
        "gpu_job_sha256": inner["job_sha256"], "semantic_job_diff": {"device": ["cpu", "cuda"]},
        "code_leaves_identical": sum(name.startswith("code/") for name in manifest),
        "inputs_leaves_identical": sum(name.startswith("inputs/") for name in manifest),
        "python_leaves_identical": len(code), "archive_file_sha256": {name: digest(x) for name, x in payload.items()},
        "resource_lock": lock, "execution_release": False,
    })


def sha_from_parent(path, member):
    with zipfile.ZipFile(path) as parent:
        return digest(parent.read(member))


if __name__ == "__main__":
    main()
