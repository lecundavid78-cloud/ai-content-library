# 三来源派生与六缓存正式准入候选

本地实现绑定总控准入文件 SHA `aa26eef533d4635de96a3c16607eca104e8e359faad6e6933b657a89b1eb765b`。只允许 Spencer→AsCas12f、HSP82→SpCas9、RCRO→TnpB 三条路线。每源 wrapper 绑定父缓存实际 SHA、CPU 检查记录、WT／自然／结构／六成员身份，以及 small594、full_train 的原件和部署 admission、index 与既定 pair SHA。CPU 包只包含这些元数据，不包含 bank 数值、pair 流或目标标签。

源派生用原 weights-only loader 校验父对象，再读原始 tensor-only 字典，仅把新 artifact 的 asset_role 设为 SOURCE，并在 provenance 加入 original_asset_role、parent_cache_sha256、controller_admission_sha256、derivation_execution_release_sha256、wrapper_sha256。拒绝已有同名 provenance 字段，拒绝 TARGET 或三源以外对象。旧对象路径不变。

保存后用原 loader 重新加载，恢复待比较对象中的原角色与原 provenance，并比较整个递归对象指纹。指纹包含每个张量的字节、dtype、shape，以及序列、MSA、原始分数、词表、所有天然元数据。允许变化的部分只有上述显式角色和新增 provenance。重新计算旧父文件 SHA 确认原件未变。每源输出独立 SOURCE.pt、真实 SHA、ADMISSION.json，失败保留 FAILURE.json。三份 TARGET 只读取验证，不输出改写对象。

六份缓存都通过原 H11Cache.validate 检查 AA 与结构 token、映射、mask、相对位置、密封张量摘要、层 11／eval、原生权重／head／tokenizer 身份。补核 h12、原 logits 和 19L、自然 MSA、旧 span 的形状及逐位点跨度，输出逐成员量化器锁 SHA。量化器锁来自原生清单及旧身份链，本次不再运行量化器。TnpB 旧收集中没有独立 FULL_SPAN 文件，因此以明确的 CURRENT_CPU_EXACT_TENSOR_SPAN 模式核当前对象的实际完整张量跨度，辅以先前已完成的真实 CPU inspection；不把候选期待值称为旧实测。

签发时先审阅 CONTRACT 和三个 wrapper，再将 RELEASE_NOT_RELEASED.json 的状态设为 RELEASED。schema、contract_sha256、script_sha256、wrapper_sha256、三源与资源字段必须保留。将最终文件追加到 ZIP 的 control/EXECUTION_RELEASE.json，锁定新 ZIP 和放行 SHA，以及 CPU_PACKAGE_MANIFEST、sbatch 与全部部署叶文件。新根固定为 production_source_admission_v1，独占 .submit_intent；作业内 .allocation_claim 防重复启动。以 R02_SOURCE_ADMISSION_RELEASE_SHA 传入实际放行 SHA。候选内原控制文件和脚本均由批处理哈希校验，放行文件由外部已签 SHA 核对，原始执行 release 的 SHA 再记入新 provenance。

资源为一次 CPU 作业，4 核、32 GiB、900 秒、0 GPU，容器 800 秒。现有六缓存 CPU 检查实耗 167 秒，本候选还会对三份新副本保存／重载与多次摘要，规划预留约 4 倍旧检查时间。实际派生时长尚未测量，触及上限则保留失败证据，不重投。用新独立输出 /out/admitted。需记录整个 Slurm 分配账单，原 SIF／Singularity 和运行库身份均沿用已观测版本。

本地通过脚本编译、原元数据验证、五组权限负例、Bash 语法及 EXIT JSON。当前本机无 torch，未执行真实 tensor 派生。远端实际 SOURCE.pt SHA 和正式 EXACT_FULLWT_BUNDLE_ADMITTED 证据在执行后才生成。当前不据此启动训练。
