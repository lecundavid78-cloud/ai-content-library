"""Compile actual source/init identities with R05; mark metadata requiring final staging."""
import hashlib
import json
from pathlib import Path
import sys
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/"R05/phase1"))
from build_phase1 import compile_jobs, encode, ORIGINAL


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def main():
    out=HERE/"training_candidates_v1"
    out.mkdir(exist_ok=True)
    facts=sorted((HERE/"actual_execution_v1").glob("*_RECEIPT.json"))
    receipt=next(read(p) for p in reversed(facts) if any(e.get("terminal") for e in read(p)["events"]))
    actual=next(e for e in receipt["events"] if e.get("terminal"))
    assert actual["state"]=="COMPLETED" and actual["exit_code"]=="0:0" and actual["deployment_unchanged"]
    imports=read(ROOT/"R02/qualification_v1/ACTUAL_IMPORT_LOCK.json")
    observation=read(ROOT/"R02/production_admission_preparation_v1/PROBE_ACTUAL.stdout")
    observed={r["path"]:r for r in observation["entries"]}
    initdir=ROOT/"R02/production_init_preparation_v1"
    prior=ROOT.parent.parent/"Research_Diagnosis_20261108/ThreeTarget_FourCell_Replication_20261108"
    bridge=prior/"R02_Runtime/ORIGINAL_CPU_BRIDGE_PREPARATION_V1/COLLECTED_20261108T044359Z/run/output-5196852/result"
    bundle=prior/"R03_Evaluation/production_v1/bundle/f"
    files={}
    pending=[]
    def add(local, path, host, needs_stage=False):
        local=Path(local)
        h=sha(local)
        r={"path":path,"sha256":h}
        item={"ref":r,"kind":"regular_file","bytes":local.stat().st_size,"host_path":host,"local_copy":str(local)}
        if path in files:
            assert files[path]==item
        files[path]=item
        if needs_stage:
            pending.append(item)
        return r
    meta_root="/public/home/s20223010065/RFduffision/Original_Project_Implementation_20261109/production_phase1_control_v1"
    def control(local,name):
        return add(local,"/phase1meta/"+name,meta_root+"/"+name,True)
    init_release=read(ROOT/"CONTROLLER_PHASE1_CLEAN_INIT_EXECUTION_RELEASE.json")
    shared_init={}
    for arch,job_id in (("S","5221808"),("L","5221809")):
        job=init_release["jobs"][arch]
        with zipfile.ZipFile(job["signed_package"]["path"]) as z:
            for name in ("control/JOB.json","control/R05_ROOT_RELEASE.json","control/NATIVE_LOCK.json","control/IMPORT_LOCK.json"):
                local=out/arch/name
                local.parent.mkdir(exist_ok=True,parents=True)
                local.write_bytes(z.read(name))
            if arch=="S":
                for name in z.namelist():
                    if name.startswith("code/"):
                        local=ROOT/"R05/runtime_v1"/name.removeprefix("code/")
                        assert sha(local)==hashlib.sha256(z.read(name)).hexdigest()
                        add(local,"/"+name,job["remote_root"]+"/"+name)
        init=ROOT/"R02/production_init_preparation_v1/source_staging_v1/observed"/job_id/("output-"+job_id)/("init-"+arch)
        shared_init[arch]={
          "init":add(init/"INIT.pt",f"/initializations/{arch}/INIT.pt",job["remote_root"]+f"/output-{job_id}/init-{arch}/INIT.pt"),
          "receipt":control(init/"INIT_RECEIPT.json",arch+"/INIT_RECEIPT.json"),
          "job":control(out/arch/"control/JOB.json",arch+"/INIT_JOB.json"),
          "release":control(out/arch/"control/R05_ROOT_RELEASE.json",arch+"/INIT_RELEASE.json"),
          "runtime_receipt":control(init/"RUNTIME_RECEIPT.json",arch+"/RUNTIME_RECEIPT.json"),
          "inspection":control(ROOT/f"PHASE1_INIT_{arch}_INSPECTION.json",arch+"/INIT_INSPECTION.json")}
    native=read(out/"S/control/NATIVE_LOCK.json")
    native_ref=add(out/"S/control/NATIVE_LOCK.json","/control/NATIVE_LOCK.json",
                   init_release["jobs"]["S"]["remote_root"]+"/control/NATIVE_LOCK.json")
    import_ref=add(out/"S/control/IMPORT_LOCK.json","/control/IMPORT_LOCK.json",
                   init_release["jobs"]["S"]["remote_root"]+"/control/IMPORT_LOCK.json")
    allow=read(ROOT/"R02/production_admission_preparation_v1/ASSET_ALLOWLIST.json")
    for spec in allow["paths"]:
        if spec["role"] not in ("NATIVE_LOCK","IMPORT_LOCK"):continue
        mount=spec["planned_mount"] or spec["path"]
        seen=observed[spec["path"]]
        assert seen["sha256"]==spec["sha256_expected"]
        files[mount]={"ref":{"path":mount,"sha256":seen["sha256"]},"kind":"regular_file",
                      "bytes":seen["bytes"],"host_path":spec["path"]}
    runtime={"native_lock":native_ref,"import_lock":import_ref,"code_root":"/code",
             "code_inventory_local":str(ROOT/"R05/runtime_v1/RUNTIME_CODE_SHA256.json"),
             "code_inventory_sha256":sha(ROOT/"R05/runtime_v1/RUNTIME_CODE_SHA256.json")}
    sources={}
    targets={}
    result_root=Path(actual["source_outputs"][0]["path"]).parent.parent
    evidence_dir=HERE/"actual_execution_v1/run"/("output-"+actual["job_id"])/"admitted"
    by_source={r["path"].split("/")[-2]:r for r in actual["source_outputs"]}
    records={p.parent.name:read(p) for p in evidence_dir.glob("*/ADMISSION.json")}
    assert len(records)==6
    for name,r in records.items():
        evidence=add(evidence_dir/name/"ADMISSION.json",f"/admission/{name}.json",str(result_root/name/"ADMISSION.json").replace("\\","/"))
        if r["role"]=="SOURCE":
            b=by_source[name]
            files[f"/bundles/SOURCE/{name}.pt"]={"ref":{"path":f"/bundles/SOURCE/{name}.pt","sha256":b["sha256"]},
                  "kind":"regular_file","bytes":b["bytes"],"host_path":b["path"]}
            sources[name]={"wt_sha256":r["wt_sha256"],"bundle":files[f"/bundles/SOURCE/{name}.pt"]["ref"],
                           "evidence":evidence,"banks":{}}
        else:
            targets[name]={"wt_sha256":r["wt_sha256"],"forbidden_source_ids":[name]+[
                k for k,s in records.items() if s["role"]=="SOURCE" and s["wt_sha256"]==r["wt_sha256"]],
                "original":{"acceptance":control(bundle/ORIGINAL[name],f"original/{name}/ACCEPTANCE.json")},
                "core":control(bridge/name/"CORE_METADATA.json",f"original/{name}/CORE_METADATA.json"),
                "natural":control(bridge/name/"NATURAL.npz",f"original/{name}/NATURAL.npz")}
            for field,filename in (("record","PREDICTION_RECORD.json"),("raw","RAW.npz"),("csv","PREDICTIONS.csv")):
                targets[name]["original"][field]=control(bridge/name/filename,f"original/{name}/"+filename)
    relocated=read(ROOT/"phase1_source_rebind_v1/RELOCATION_MANIFEST.json")
    staging=read(initdir/"source_staging_v1/ACTUAL_SOURCE_BINDINGS.json")["files"]
    staged={r["ref"]["path"]:r for r in staging}
    for b in relocated["source_banks"]:
        admission=read(Path(b["relocated_admission_local"]["path"]))
        for key in ("bank","index","pairs"):
            leaf=b["leaves"][key]
            r=staged[leaf["container"]["path"]]
            assert r["ref"]==leaf["container"]
            files[r["ref"]["path"]]=dict(r)
            if key!="bank":
                files[r["ref"]["path"]]["local_copy"]=leaf["local"]["path"]
        r=b["relocated_admission_container"]
        seen=staged[r["path"]]
        add(b["relocated_admission_local"]["path"],r["path"],seen["host_path"])
        sources[b["source_id"]]["banks"][b["bank_rule"]]={
            "original_admission_local":b["original_admission"]["path"],"admission":r,"config_root":"/control/production/configs"}
    assets={"schema":"PHASE1_R02_VERIFIED_BINDINGS_V1",
            "inventory_sha256":sha(ROOT/"DEVELOPMENT_PHASE1_INVENTORY.json"),
            "files":list(files.values()),"runtime":runtime,
            "budget":control(ROOT/"CONTROLLER_PHASE1_BUDGET_LOCK.json","BUDGET.json"),
            "slots":read(ROOT/"PHASE1_RUNTIME_SLOTS_CANDIDATE.json")["slots"],
            "initializations":shared_init,"sources":sources,"targets":targets}
    assets["files"]=list(files.values())
    (out/"BINDINGS.json").write_bytes(encode(assets))
    (out/"CONTROL_STAGING_REQUIRED.json").write_bytes(encode({"status":"PENDING_EXACT_STAGING_RELEASE",
         "files":pending,"root":meta_root,"training_release":False,"compiler_output_verified":False}))
    jobs,configs,manifest=compile_jobs("train",assets)
    assert len(jobs)==len(configs)==12
    for name,item in jobs.items():
        (out/(name+".JOB.json")).write_bytes(encode(item["job"]))
    for name,c in configs.items():
        (out/(name+".json")).write_bytes(encode(c))
    (out/"BINDINGS.json").write_bytes(encode(assets))
    (out/"CANDIDATES.json").write_bytes(encode(manifest))
    (out/"CONTROL_STAGING_REQUIRED.json").write_bytes(encode({"status":"PENDING_EXACT_STAGING_RELEASE",
         "files":pending,"root":meta_root,"training_release":False,
         "compiler_output_verified":True,"jobs":12,"configs":12}))
    print(json.dumps({"jobs":len(jobs),"configs":len(configs),"bindings_sha256":sha(out/"BINDINGS.json"),
                      "candidate_sha256":sha(out/"CANDIDATES.json"),"pending_control_files":len(pending)}))


if __name__=="__main__":
    main()
