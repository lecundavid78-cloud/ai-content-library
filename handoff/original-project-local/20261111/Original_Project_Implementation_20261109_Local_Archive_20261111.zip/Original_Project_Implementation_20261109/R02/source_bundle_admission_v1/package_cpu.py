"""Reuse the verified CPU inspection container wrapper with an exact new contract."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile
from prepare import HERE, ROOT, sha, enc, main


def build():
    main()
    old = ROOT/"R02/production_init_preparation_v1"
    sys.path.insert(0,str(old))
    import submit_cache_cpu
    _, prior = submit_cache_cpu.prepare()
    files = {n:b for n,b in prior.items() if n.startswith("code/") or n in (
             "control/NATIVE_LOCK.json","control/IMPORT_LOCK.json")}
    for p in (HERE/"payload/control").rglob("*"):
        if p.is_file():
            files[p.relative_to(HERE/"payload").as_posix()] = p.read_bytes()
    files["control/derive_sources_cpu.py"] = (HERE/"derive_sources_cpu.py").read_bytes()
    boot = prior["control/check_import_then_inspect.py"].decode()
    old_argv = 'sys.argv = ["/control/inspect_cache_cpu.py", "/control/SIX_CACHE_CPU_CANDIDATE.json", "/control/NATIVE_LOCK.json"]'
    assert boot.count(old_argv)==1
    boot = boot.replace(old_argv,
        'assert len(sys.argv) == 2\nrelease_sha = sys.argv[1]\n'
        'sys.argv = ["/control/derive_sources_cpu.py", "/control/CONTRACT.json", "/control/EXECUTION_RELEASE.json", release_sha, "/out/admitted"]')
    files["control/check_import_then_inspect.py"] = boot.encode()
    digest = lambda b:hashlib.sha256(b).hexdigest()
    files["control/PAYLOAD.sha256"] = "".join(f"{digest(b)}  {n}\n" for n,b in sorted(files.items())).encode()
    batch = prior["inspect_cache.sbatch"].decode()
    replacements = [
        ("OriginalProject_ProdCache_CPU", "OriginalProject_SourceAdmission_CPU"),
        ("/production_cache_inspection_v1", "/production_source_admission_v1"),
        (digest(prior["control/PAYLOAD.sha256"]),digest(files["control/PAYLOAD.sha256"])),
        ('mkdir .allocation_claim',
         ': "${R02_SOURCE_ADMISSION_RELEASE_SHA:?exact release required}"\n'
         'printf \'%s  %s\\n\' "$R02_SOURCE_ADMISSION_RELEASE_SHA" control/EXECUTION_RELEASE.json | sha256sum -c --status\n'
         'mkdir .allocation_claim'),
        ('--env LD_LIBRARY_PATH="$LD"',
         '--env HF_HOME=/out/hf --env HF_MODULES_CACHE=/out/hf_modules --env TRANSFORMERS_CACHE=/out/hf/hub --env XDG_CACHE_HOME=/out/.cache --env LD_LIBRARY_PATH="$LD"'),
        ('/control/check_import_then_inspect.py >', '/control/check_import_then_inspect.py "$R02_SOURCE_ADMISSION_RELEASE_SHA" >'),
        ("CACHE_INSPECTION.jsonl", "ADMISSION.stdout"), ("CACHE_INSPECTION.stderr", "ADMISSION.stderr")]
    for a,b in replacements:
        assert batch.count(a)==1,a
        batch=batch.replace(a,b)
    files["source_admission.sbatch"]=batch.encode()
    batch_path=HERE/"source_admission.sbatch"
    batch_path.write_bytes(batch.encode())
    subprocess.run(["F:/programming language/Git/bin/bash.exe","-n",str(batch_path)],check=True)
    archive=HERE/"SOURCE_ADMISSION_CPU_UNSIGNED.zip"
    with zipfile.ZipFile(archive,"w") as z:
        for n,b in sorted(files.items()):
            z.writestr(zipfile.ZipInfo(n,(2026,11,10,0,0,0)),b,compress_type=zipfile.ZIP_DEFLATED)
    result={"status":"LOCAL_CANDIDATE_NOT_RELEASED","archive":{"path":str(archive),"sha256":sha(archive),"bytes":archive.stat().st_size},
            "files":{n:digest(b) for n,b in sorted(files.items())},"resources":{"cpu":4,"memory_gib":32,"seconds":900,"gpu":0},
            "release_template":{"path":str(HERE/"RELEASE_NOT_RELEASED.json"),"sha256":sha(HERE/"RELEASE_NOT_RELEASED.json")},
            "new_remote_root":"/public/home/s20223010065/RFduffision/Original_Project_Implementation_20261109/production_source_admission_v1",
            "local_claim":str(HERE/".submit_intent"),"max_submissions":1}
    (HERE/"CPU_PACKAGE_MANIFEST.json").write_bytes(enc(result))
    print(json.dumps(result["archive"]))


if __name__=="__main__":
    build()
