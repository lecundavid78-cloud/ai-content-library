"""Build exact metadata-only admission wrappers; never parse functional scores."""
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
INIT = HERE.parent / "production_init_preparation_v1"
ROUTES = {"CAS9_STRP1_Spencer_2017_positive": "AsCas12f",
          "HSP82_YEAST_Flynn_2019": "SpCas9", "RCRO_LAMBD_Tsuboyama_2023_1ORC": "TnpB"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path, deployed):
    return {"path": deployed, "sha256": sha(path)}


def enc(value):
    return (json.dumps(value, indent=2) + "\n").encode()


def main():
    control = HERE / "payload/control"
    control.mkdir(exist_ok=True, parents=True)
    index = {}

    def put(local, name):
        b = local.read_bytes()
        dest = control / name
        dest.parent.mkdir(exist_ok=True, parents=True)
        dest.write_bytes(b)
        mount = "/control/" + name
        index[mount] = {"local": str(dest), "sha256": sha(dest), "bytes": len(b)}
        return ref(dest, mount)

    with zipfile.ZipFile(ROOT / "GPU_QUALIFICATION_SIGNED_V1.zip") as z:
        lock = control / "NATIVE_LOCK.json"
        lock.write_bytes(z.read("control/NATIVE_LOCK.json"))
    native = put(lock, "NATIVE_LOCK.json")
    assert native["sha256"] == "49e8719821c42f359ebbe489879c1094858ffebbd57f83dd557b58c6a04eea38"
    source_manifest = ROOT / "phase1_source_rebind_v1/RELOCATION_MANIFEST.json"
    assert sha(source_manifest) == "74481adac402a91fafe70babb322480df8c4fd43abbbe841d7d1ace4349cb49e"
    banks = json.loads(source_manifest.read_bytes())["source_banks"]
    actual = INIT / "source_staging_v1/observed/5221854/output-5221854/CACHE_INSPECTION.jsonl"
    inspection = [json.loads(l) for l in actual.read_text().splitlines()]
    parent = json.loads((INIT / "SIX_CACHE_CPU_CANDIDATE.json").read_bytes())["rows"]
    hist = ROOT.parent.parent / "Research_Diagnosis_20261108/ThreeTarget_FourCell_Replication_20261108/R02_Runtime"
    source_root = hist / "ALL18_QUALIFICATION_PREPARATION_V2/COLLECTED_20261108T033352Z/run/output-5196127/result"
    targets = hist / "TARGET_CACHE_PREPARATION_V1/COLLECTED_20261108T040745Z/run/output-5196457/result"
    tnp = ROOT.parent.parent / "Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V3/collected_job_5187833/output-5187833/result"
    rows = []
    for entry in inspection:
        identity = entry["id"]
        old = next(r for r in parent if r["id"] == identity)
        assert old["sha256_expected"] == entry["bundle_sha256"]
        if identity in ROUTES:
            source_index = {"CAS9_STRP1_Spencer_2017_positive": "01",
                            "HSP82_YEAST_Flynn_2019": "05", "RCRO_LAMBD_Tsuboyama_2023_1ORC": "14"}[identity]
            span_file = source_root / f"sources/SOURCE_{source_index}/FULL_SPAN_EVIDENCE.json"
        elif identity == "TnpB":
            # No historical FULL_SPAN file was collected for this old pilot. Check actual tensors anew.
            span_file = control / "TnpB_EXPECTED_SPAN.json"
            span_file.write_bytes(enc({"TnpB": {
                "WT_length": 408, "normalization_universe": 19 * 408, "truncation": False,
                "window_rule": "single-full-WT-forward-no-window",
                "comparison_mode": "CURRENT_CPU_EXACT_TENSOR_SPAN",
                "members": {str(k): {"h11_layer_index": 11} for k in (20,128,512,1024,2048,4096)}}}))
        else:
            span_file = (tnp if identity == "TnpB" else targets) / "FULL_SPAN_EVIDENCE.json"
        span_doc = json.loads(span_file.read_bytes())
        assert identity in span_doc
        row = {"id": identity, "role": old["role"], "cache": {"path": old["path"], "sha256": old["sha256_expected"]},
               "inspection": entry, "span": put(span_file, f"span/{identity}.json")}
        if identity in ROUTES:
            row["target"] = ROUTES[identity]
            wrapper = {"schema": "EXACT_THREE_SOURCE_POOL_ADMISSION_V1", "source_id": identity,
                       "target_route": ROUTES[identity], "parent_cache": row["cache"], "inspection": entry,
                       "original_asset_role": "SOURCE_POOL", "new_asset_role": "SOURCE", "banks": {},
                       "fixed_pair_sha256": {}, "numeric_bank_and_pair_stream_mounted": False}
            for bank in ("small594", "full_train"):
                record = next(r for r in banks if (r["source_id"], r["bank_rule"]) == (identity, bank))
                original = record["original_admission"]
                deployed = record["relocated_admission_local"]
                idx = record["leaves"]["index"]["local"]
                specs = {}
                for name, source in (("original_admission", original), ("deployed_admission", deployed), ("index", idx)):
                    p = Path(source["path"])
                    assert sha(p) == source["sha256"]
                    specs[name] = put(p, f"admissions/{identity}/{bank}/{name}.json")
                wrapper["banks"][bank] = specs
                wrapper["fixed_pair_sha256"][bank] = record["leaves"]["pairs"]["local"]["sha256"]
            path = control / "wrappers" / (identity + ".json")
            path.parent.mkdir(exist_ok=True)
            path.write_bytes(enc(wrapper))
            row["wrapper"] = put(path, "wrappers/" + identity + ".json")
        rows.append(row)
    grant = ROOT / "CONTROLLER_PHASE1_FORMAL_SOURCE_DERIVATION_ADMISSION.json"
    assert sha(grant) == "aa26eef533d4635de96a3c16607eca104e8e359faad6e6933b657a89b1eb765b"
    contract = {"schema": "PHASE1_SOURCE_DERIVATION_CONTRACT_V1", "rows": rows, "native_lock": native,
                "controller_admission": put(grant, "CONTROLLER_SOURCE_ADMISSION.json"),
                "actual_inspection": put(actual, "ACTUAL_CPU_INSPECTION.jsonl")}
    (control/"CONTRACT.json").write_bytes(enc(contract))
    index["/control/CONTRACT.json"] = {"local": str(control/"CONTRACT.json"), "sha256": sha(control/"CONTRACT.json"),
                                      "bytes": (control/"CONTRACT.json").stat().st_size}
    release = {"schema": "PHASE1_EXACT_SOURCE_BUNDLE_DERIVATION_RELEASE_V1", "status": "NOT_RELEASED",
               "controller": "01a1c09c-f9e6-70f1-b9e8-b988b89c755f", "expected_sources": ROUTES,
               "contract_sha256": sha(control/"CONTRACT.json"), "script_sha256": sha(HERE/"derive_sources_cpu.py"),
               "native_lock_sha256": native["sha256"],
               "wrapper_sha256": {r["id"]: r["wrapper"]["sha256"] for r in rows if r["id"] in ROUTES},
               "output": "/out/admitted", "gpu": 0, "optimizer_updates": 0, "model_loads": 0}
    (HERE/"RELEASE_NOT_RELEASED.json").write_bytes(enc(release))
    (HERE/"PAYLOAD_MANIFEST.json").write_bytes(enc({"files": index, "script": {
        "path": str(HERE/"derive_sources_cpu.py"), "sha256": sha(HERE/"derive_sources_cpu.py")},
        "resources": {"cpu": 4, "memory_gib": 32, "seconds": 900, "gpu": 0},
        "remote_root": "/public/home/s20223010065/RFduffision/Original_Project_Implementation_20261109/production_source_admission_v1",
        "deployments": 0, "source_references": len(ROUTES), "cache_references": 6}))


if __name__ == "__main__":
    main()
