"""Exercise exact source authorization and real admission metadata without torch."""
import ast
import copy
import json
from pathlib import Path
import tempfile
import subprocess
import unittest
import zipfile
from prepare import HERE


class ScopeChecks(unittest.TestCase):
    def setUp(self):
        tree=ast.parse((HERE/"derive_sources_cpu.py").read_bytes())
        tree.body=[node for node in tree.body if isinstance(node,ast.Assign) or
                   isinstance(node,ast.FunctionDef) and node.name in {"authorize_scope","source_metadata"}]
        self.plan=json.loads((HERE/"payload/control/CONTRACT.json").read_bytes())
        self.release=json.loads((HERE/"RELEASE_NOT_RELEASED.json").read_bytes()) | {"status":"RELEASED"}
        self.files=json.loads((HERE/"PAYLOAD_MANIFEST.json").read_bytes())["files"]
        def read(ref):
            row=self.files[ref["path"]]
            assert row["sha256"]==ref["sha256"]
            return json.loads(Path(row["local"]).read_bytes())
        self.read=read
        self.ns={"read":read}
        exec(compile(tree,"<exact guard functions>","exec"),self.ns)

    def test_actual_wrappers_and_two_banks(self):
        self.ns["authorize_scope"](self.plan,self.release,self.release["contract_sha256"])
        for row in self.plan["rows"]:
            if row["role"]=="SOURCE_H11":
                self.ns["source_metadata"](self.read(row["wrapper"]),row)

    def test_no_target_or_route_override(self):
        for bad in ("id","target","role"):
            plan=copy.deepcopy(self.plan)
            row=plan["rows"][0]
            row[bad]={"id":"TnpB","target":"SpCas9","role":"TARGET_H11"}[bad]
            with self.subTest(bad=bad),self.assertRaises(AssertionError):
                self.ns["authorize_scope"](plan,self.release,self.release["contract_sha256"])

    def test_unreleased_and_wrong_limits_rejected(self):
        for edits in ({"status":"NOT_RELEASED"},{"gpu":1},{"model_loads":1},{"optimizer_updates":1}):
            with self.subTest(edits=edits),self.assertRaises(AssertionError):
                self.ns["authorize_scope"](self.plan,self.release|edits,self.release["contract_sha256"])

    def test_wrapper_mismatches_rejected(self):
        row=next(r for r in self.plan["rows"] if r["role"]=="SOURCE_H11")
        wrapper=self.read(row["wrapper"])
        for field,value in (("original_asset_role","TARGET"),("target_route","TnpB"),("new_asset_role","SOURCE_POOL")):
            with self.subTest(field=field),self.assertRaises(AssertionError):
                self.ns["source_metadata"](wrapper|{field:value},row)

    def test_bash_receipts_and_payload_boundary(self):
        script=(HERE/"source_admission.sbatch").read_text()
        line=next(l for l in script.splitlines() if l.startswith("trap "))
        with tempfile.TemporaryDirectory() as d:
            result=subprocess.run(["F:/programming language/Git/bin/bash.exe","-c",
                                   'OUT="$1"\n'+line+'\nexit 19',"_",d])
            self.assertEqual(result.returncode,19)
            self.assertEqual(json.loads((Path(d)/"EXIT.json").read_bytes()),{"exit_code":19})
        with zipfile.ZipFile(HERE/"SOURCE_ADMISSION_CPU_UNSIGNED.zip") as z:
            self.assertIsNone(z.testzip())
            for n in z.namelist():
                self.assertNotIn("train_bank",n)
                self.assertNotIn("pairs_2000",n)
                self.assertFalse(n.endswith(".pt"))
        for p in self.files.values():
            if "/admissions/" in p["local"]:
                self.assertTrue(p["local"].endswith(("/index.json","/original_admission.json","/deployed_admission.json")))


if __name__=="__main__":
    unittest.main(verbosity=2)
