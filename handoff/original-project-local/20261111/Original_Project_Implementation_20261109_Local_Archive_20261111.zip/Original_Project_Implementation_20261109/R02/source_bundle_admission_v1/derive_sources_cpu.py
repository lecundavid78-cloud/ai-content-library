"""Exact three-source CPU admission. No model construction or functional-value inputs."""
import argparse
from dataclasses import asdict, is_dataclass
import hashlib
import json
from pathlib import Path

import torch
from pilot.contracts import digest
from pilot.storage import load_bundle
from r05_internal.reference.contracts import natural_sha256, tensor_sha256

ROUTES = {"CAS9_STRP1_Spencer_2017_positive": "AsCas12f",
          "HSP82_YEAST_Flynn_2019": "SpCas9", "RCRO_LAMBD_Tsuboyama_2023_1ORC": "TnpB"}
KS = {20, 128, 512, 1024, 2048, 4096}
NATIVE = "49e8719821c42f359ebbe489879c1094858ffebbd57f83dd557b58c6a04eea38"


def hash_file(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def bound(spec):
    path = Path(spec["path"])
    assert path.is_absolute() and hash_file(path) == spec["sha256"], "exact file binding"
    return path


def read(spec):
    return json.loads(bound(spec).read_bytes())


def emit(path, obj):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(obj, stream, indent=2, allow_nan=False)
        stream.write("\n")


def fingerprint(value):
    """Include every tensor's bytes, shape and dtype, plus all non-tensor values."""
    if isinstance(value, torch.Tensor):
        return {"tensor": tensor_sha256(value), "shape": list(value.shape), "dtype": str(value.dtype)}
    if is_dataclass(value):
        return fingerprint(asdict(value))
    if isinstance(value, dict):
        return {k: fingerprint(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [fingerprint(v) for v in value]
    assert value is None or isinstance(value, (str, int, float, bool)), type(value)
    return value


def span_and_identity(bundle, native, original_span, row):
    natural = bundle["natural"]
    length = len(natural.wt_sequence)
    observed = row["inspection"]
    assert natural.protein_id == row["id"] and natural.wt_sha256 == observed["wt_sha256"]
    assert natural_sha256(natural) == observed["natural_input_sha256"]
    assert bundle["provenance"]["structure_asset_sha256"] == observed["structure_asset_sha256"]
    assert bundle["provenance"]["native_lock_sha256"] == NATIVE
    assert digest({str(k): asdict(v) for k, v in bundle["members"].items()}) == observed["member_identity_sha256"]
    assert original_span["WT_length"] == length and original_span["truncation"] is False
    assert original_span["normalization_universe"] == 19 * length
    assert original_span["window_rule"] == "single-full-WT-forward-no-window"
    assert set(bundle["members"]) == KS and set(original_span["members"]) == {str(k) for k in KS}
    assert bundle["original_all19l"].shape == (19 * length,) and torch.isfinite(bundle["original_all19l"]).all()
    actual = {}
    for spec in native["members"]:
        k = spec["K"]
        m, c = bundle["members"][k], bundle["caches"][k]
        c.validate(m, natural)
        assert (m.weights_sha256, m.source_sha256, m.tokenizer_sha256, m.cls_sha256) == (
            spec["weights_sha256"], spec["modeling_source_sha256"], spec["tokenizer_sha256"], spec["head_sha256"])
        assert c.identity.structure_asset_sha256 == observed["structure_asset_sha256"]
        assert c.canonical_index.numel() == length
        old = original_span["members"][str(k)]
        assert old["h11_layer_index"] == 11
        if original_span.get("comparison_mode") == "CURRENT_CPU_EXACT_TENSOR_SPAN":
            assert c.h11.shape == (1, c.input_ids.shape[1], 768)
            assert c.expanded_mask.shape == (1, 1, c.h11.shape[1], c.h11.shape[1])
            assert c.relative_pos.shape == (1, c.h11.shape[1], c.h11.shape[1])
        else:
            assert list(c.h11.shape) == old["h11_shape"]
            assert list(c.expanded_mask.shape) == old["expanded_mask_shape"]
            assert list(c.relative_pos.shape) == old["relative_pos_shape"]
        assert c.h11.shape == bundle["h12"][k].shape
        assert torch.isfinite(c.h11).all() and torch.isfinite(bundle["h12"][k]).all()
        field = next(f for f in bundle["original_fields"] if f.member.structure_codebook_size == k)
        assert field.logits25.shape == (length, 25) and torch.isfinite(field.logits25).all()
        msa = natural.native_msa_by_member[m.name]
        assert msa.logp25 is not None
        if original_span.get("comparison_mode") != "CURRENT_CPU_EXACT_TENSOR_SPAN":
            assert [msa.aln_start, msa.aln_end] == old["native_MSA_span"]
            assert msa.logp25.shape[0] == old["native_MSA_rows"]
        assert c.relative_pos.min().item() == 1 - c.h11.shape[1] and c.relative_pos.max().item() == c.h11.shape[1] - 1
        actual[str(k)] = {"h11_shape": list(c.h11.shape), "h12_shape": list(bundle["h12"][k].shape),
                          "cache_digest": c.digest(), "canonical_count": c.canonical_index.numel()}
    return actual


def authorize_scope(plan, release, controller_sha):
    assert release["schema"] == "PHASE1_EXACT_SOURCE_BUNDLE_DERIVATION_RELEASE_V1"
    assert release["status"] == "RELEASED" and release["controller"] == "01a1c09c-f9e6-70f1-b9e8-b988b89c755f"
    assert release["gpu"] == release["optimizer_updates"] == release["model_loads"] == 0
    assert release["expected_sources"] == ROUTES and release["native_lock_sha256"] == NATIVE
    assert release["contract_sha256"] == controller_sha
    assert {r["id"] for r in plan["rows"] if r["role"] == "SOURCE_H11"} == set(ROUTES)
    assert {r["id"] for r in plan["rows"] if r["role"] == "TARGET_H11"} == set(ROUTES.values())
    assert len(plan["rows"]) == 6 and len({r["id"] for r in plan["rows"]}) == 6
    for row in plan["rows"]:
        if row["role"] == "SOURCE_H11":
            assert row["target"] == ROUTES[row["id"]]
            assert row["inspection"]["role"] == "SOURCE_POOL"
        else:
            assert row["role"] == "TARGET_H11" and row["inspection"]["role"] == "TARGET"


def source_metadata(wrapper, row):
    assert wrapper["source_id"] == row["id"] and wrapper["target_route"] == ROUTES[row["id"]]
    assert wrapper["parent_cache"] == row["cache"]
    assert wrapper["inspection"] == row["inspection"] and wrapper["original_asset_role"] == "SOURCE_POOL"
    assert wrapper["new_asset_role"] == "SOURCE" and set(wrapper["banks"]) == {"small594", "full_train"}
    for bank, references in wrapper["banks"].items():
        original, deployed = read(references["original_admission"]), read(references["deployed_admission"])
        assert original["source_id"] == row["id"] and original["bank_rule"] == bank
        assert original["role"] == "SOURCE_TRAIN_ONLY" and original["seed"] == 11 and original["steps"] == 2000
        assert set(original) == set(deployed)
        for key in original:
            if key in ("bank", "index", "pairs"):
                assert {k: v for k, v in original[key].items() if k != "path"} == {
                    k: v for k, v in deployed[key].items() if k != "path"}
            else:
                assert original[key] == deployed[key]
        index = read(references["index"])
        assert index["source_id"] == row["id"] and index["wt_sha256"] == row["inspection"]["wt_sha256"]
        assert references["index"]["sha256"] == original["index"]["sha256"]
        # Bind the authorized stream identity in admission metadata, without mounting pairs or numeric bank.
        assert wrapper["fixed_pair_sha256"][bank] == original["pairs"]["sha256"]
    return wrapper


def run(contract_path, release_path, release_sha, output):
    assert hash_file(release_path) == release_sha
    release = json.loads(release_path.read_bytes())
    assert release["script_sha256"] == hash_file(Path(__file__))
    plan = json.loads(contract_path.read_bytes())
    authorize_scope(plan, release, hash_file(contract_path))
    assert str(output) == release["output"] and not output.exists()
    native = read(plan["native_lock"])
    admission = read(plan["controller_admission"])
    assert admission["schema"] == "PHASE1_FORMAL_SOURCE_DERIVATION_ADMISSION_V1"
    assert {s["source_id"] for s in admission["sources"]} == set(ROUTES)
    for row in plan["rows"]:
        if row["role"] == "SOURCE_H11":
            grant = next(s for s in admission["sources"] if s["source_id"] == row["id"])
            assert grant["target_route"] == ROUTES[row["id"]] and grant["parent_cache"]["sha256_expected"] == row["cache"]["sha256"]
            assert grant["checked_cache_metadata"] == row["inspection"]
    assert plan["native_lock"]["sha256"] == NATIVE
    # Verify the actual CPU inspection output used to formulate every row.
    actual_inspection = [json.loads(line) for line in bound(plan["actual_inspection"]).read_text().splitlines()]
    assert {r["id"]: r for r in actual_inspection} == {r["id"]: r["inspection"] for r in plan["rows"]}
    wrappers = {}
    for row in plan["rows"]:
        assert row["cache"]["sha256"] == row["inspection"]["bundle_sha256"]
        bound(row["cache"])
        read(row["span"])
        if row["role"] == "SOURCE_H11":
            assert release["wrapper_sha256"][row["id"]] == row["wrapper"]["sha256"]
            wrappers[row["id"]] = source_metadata(read(row["wrapper"]), row)
    assert set(wrappers) == set(ROUTES)
    output.mkdir()
    for row in plan["rows"]:
        directory = output / row["id"]
        directory.mkdir()
        try:
            bundle = load_bundle(bound(row["cache"]), "cpu")
            expected_role = "SOURCE_POOL" if row["role"] == "SOURCE_H11" else "TARGET"
            assert bundle["asset_role"] == expected_role, "reject role override"
            span = read(row["span"])[row["id"]]
            actual = span_and_identity(bundle, native, span, row)
            digest_before = digest(fingerprint(bundle))
            final_sha = row["cache"]["sha256"]
            if row["role"] == "SOURCE_H11":
                raw = torch.load(bound(row["cache"]), map_location="cpu", weights_only=True)
                assert raw["asset_role"] == "SOURCE_POOL"
                prior_provenance = dict(raw["provenance"])
                additions = {"original_asset_role": "SOURCE_POOL", "parent_cache_sha256": final_sha,
                             "controller_admission_sha256": plan["controller_admission"]["sha256"],
                             "derivation_execution_release_sha256": release_sha, "wrapper_sha256": row["wrapper"]["sha256"]}
                assert not set(additions).intersection(prior_provenance)
                raw["asset_role"] = "SOURCE"
                raw["provenance"] = prior_provenance | additions
                path = directory / "SOURCE.pt"
                with path.open("xb") as stream:
                    torch.save(raw, stream)
                derived = load_bundle(path, "cpu")
                assert derived["asset_role"] == "SOURCE" and derived["provenance"] == prior_provenance | additions
                comparison = dict(derived, asset_role="SOURCE_POOL", provenance=prior_provenance)
                assert digest(fingerprint(comparison)) == digest_before, "derived tensors or natural identity changed"
                span_and_identity(derived, native, span, row)
                final_sha = hash_file(path)
                del raw, derived, comparison
            assert hash_file(Path(row["cache"]["path"])) == row["cache"]["sha256"], "parent changed"
            report = {k: row["inspection"][k] for k in ("wt_sha256", "native_lock_sha256",
                       "natural_input_sha256", "structure_asset_sha256", "member_identity_sha256")}
            report.update(status="EXACT_FULLWT_BUNDLE_ADMITTED", id=row["id"],
                          role="SOURCE" if row["role"] == "SOURCE_H11" else "TARGET",
                          bundle_sha256=final_sha, cache_schema="FOURCELL_PREPARED_V1", prefix_layer=11,
                          window_rule=span["window_rule"], full_wt_h11_h12_validated=True,
                          all_six_member_identities_match=True, functional_values_present=False,
                          parent_cache_sha256=row["cache"]["sha256"],
                          controller_admission_sha256=plan["controller_admission"]["sha256"],
                          derivation_execution_release_sha256=release_sha,
                          full_tree_identity_sha256=digest_before, actual_span=actual,
                          quantizer_sha256_by_k={str(m["K"]): m["quantizer_sha256"] for m in native["members"]},
                          source_wrapper_sha256=row.get("wrapper", {}).get("sha256"))
            emit(directory / "ADMISSION.json", report)
            print(json.dumps({"id": row["id"], "status": report["status"], "bundle_sha256": final_sha}), flush=True)
            del bundle
        except BaseException as exc:
            emit(directory / "FAILURE.json", {"id": row["id"], "error": repr(exc)})
            raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("contract", type=Path)
    parser.add_argument("release", type=Path)
    parser.add_argument("release_sha256")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    run(args.contract, args.release, args.release_sha256, args.output)
