import base64
from datetime import datetime,timezone
import hashlib
import io
import json
import os
from pathlib import Path,PurePosixPath
import pwd
import re
import subprocess
import zipfile

root=Path(PLAN["root"])
slurm="/public/gridview_20250224/slurm/bin/"
name="OriginalProject_SourceAdmission_CPU"
assert pwd.getpwuid(os.geteuid()).pw_name=="s20223010065"


def command(a):
    p=subprocess.run(a,capture_output=True,text=True,timeout=40)
    assert p.returncode==0,p.stderr
    return p.stdout


def emit(o):
    print(json.dumps(o),flush=True)


def file_sha(path):
    with path.open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


if PLAN["action"]=="submit":
    assert not root.exists() and not root.is_symlink(),"existing root; reconcile"
    history=command([slurm+"sacct","-X","-n","-P","-S","2026-11-10","-u","s20223010065",
                     "--name",name,"--format=JobIDRaw,JobName%100,State,ExitCode"])
    queue=command([slurm+"squeue","-h","-u","s20223010065","-n",name,"-o","%i|%j|%T"])
    assert not history.strip() and not queue.strip(),"already accepted; reconcile"
    blob=base64.b64decode(PLAN["archive"],validate=True)
    assert hashlib.sha256(blob).hexdigest()==PLAN["archive_sha256"]
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        assert len(z.namelist())==65 and set(z.namelist())==set(PLAN["files"]) and z.testzip() is None
        for n,h in PLAN["files"].items():
            p=PurePosixPath(n)
            assert not p.is_absolute() and ".." not in p.parts and "\\" not in n
            assert hashlib.sha256(z.read(n)).hexdigest()==h
        os.umask(0o077)
        root.mkdir(exist_ok=False)
        for n,h in PLAN["files"].items():
            p=root/n
            p.parent.mkdir(exist_ok=True,parents=True)
            with p.open("xb") as f:
                f.write(z.read(n))
            assert file_sha(p)==h
    (root/"logs").mkdir()
    args=[slurm+"sbatch","--parsable","--chdir="+str(root),
          "--output="+str(root/"logs/admit-%j.out"),"--error="+str(root/"logs/admit-%j.err"),
          "--export=ALL,R02_SOURCE_ADMISSION_RELEASE_SHA="+PLAN["inner_sha256"],str(root/"source_admission.sbatch")]
    intent={"root":str(root),"command":args,"archive_sha256":PLAN["archive_sha256"],"release_sha256":PLAN["release_sha256"]}
    with (root/".submit_intent").open("x",encoding="utf8") as f:
        json.dump(intent,f)
    emit(intent|{"status":"SUBMIT_STARTED"})
    proc=subprocess.run(args,capture_output=True,text=True,timeout=40)
    match=re.fullmatch(r"([0-9]+)(?:;[^\s;]+)?",proc.stdout.strip())
    accepted=proc.returncode==0 and match is not None
    event=intent|{"status":"SLURM_ACCEPTED" if accepted else "SUBMIT_FAILED_OR_AMBIGUOUS",
                 "job_id":match[1] if accepted else None,"returncode":proc.returncode,"stdout":proc.stdout,"stderr":proc.stderr}
    with (root/"SUBMISSION_RECEIPT.json").open("x",encoding="utf8") as f:
        json.dump(event,f)
    emit(event)
    assert accepted,"no retry; reconcile"
else:
    job=PLAN["job"]
    assert job.isdigit()
    account=command([slurm+"sacct","-X","-n","-P","-j",job,
        "--format=JobIDRaw,JobName%100,State%40,ExitCode,ElapsedRaw,AllocTRES%150,WorkDir%300,Start,End"])
    rows=[l.split("|") for l in account.splitlines()]
    assert len(rows)==1 and rows[0][0]==job and rows[0][1]==name and rows[0][6]==str(root)
    row=rows[0]
    terminal=row[2].split()[0] in {"COMPLETED","FAILED","TIMEOUT","CANCELLED","OUT_OF_MEMORY","NODE_FAIL"}
    event={"utc":datetime.now(timezone.utc).isoformat(),"job_id":job,"state":row[2],"exit_code":row[3],
           "elapsed_seconds":int(row[4]),"sacct":account,"terminal":terminal,"artifacts":[]}
    if terminal:
        event["deployment_unchanged"]=all(file_sha(root/n)==h for n,h in PLAN["files"].items())
        out=root/("output-"+job)
        selected=list((root/"logs").glob("*"+job+"*"))
        selected += [p for p in out.rglob("*") if p.is_file() and p.suffix in {".json",".stdout",".stderr",".pt"}
                     and not any(x in p.relative_to(out).parts for x in ("hf","hf_modules","tmp","home",".cache"))]
        total=0
        for p in selected:
            assert p.resolve().is_relative_to(root)
            size=p.stat().st_size
            item={"relative":p.relative_to(root).as_posix(),"remote_path":str(p),"sha256":file_sha(p),"bytes":size}
            if p.suffix!=".pt" and size<16*1024**2:
                total+=size
                assert total<64*1024**2
                item["payload"]=base64.b64encode(p.read_bytes()).decode()
            else:
                continue
            event["artifacts"].append(item)
        event["source_outputs"]=[{"path":str(p),"sha256":file_sha(p),"bytes":p.stat().st_size} for p in out.glob("admitted/*/SOURCE.pt")]
    else:
        event["queue"]=command([slurm+"squeue","-h","-j",job,"-o","%i|%j|%T|%R"])
    emit(event)
