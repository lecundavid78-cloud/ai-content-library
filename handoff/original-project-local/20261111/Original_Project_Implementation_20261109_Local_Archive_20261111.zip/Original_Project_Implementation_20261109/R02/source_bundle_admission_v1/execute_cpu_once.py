"""Exact signed source admission submission and read-only terminal collection."""
import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SHA = "f4f910d24c2f8a773eb4c843c7eb09353bf9fb07df16af74c083551ec5691963"


def digest(b):
    return hashlib.sha256(b).hexdigest()


def read(p):
    return json.loads(p.read_bytes())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("check","submit","collect"))
    parser.add_argument("--job")
    args = parser.parse_args()
    release = ROOT/"CONTROLLER_PHASE1_SOURCE_ADMISSION_CPU_EXECUTION_RELEASE.json"
    assert digest(release.read_bytes()) == SHA
    r = read(release)
    assert r["status"]=="RELEASED" and r["max_new_submissions"]==1 and not r["formal_training_release"]
    assert r["resources"]=={"CPU":4,"memory_GiB":32,"Slurm_seconds":1800,"internal_seconds":1700,"GPU":0}
    assert digest(Path(r["inner_release"]["path"]).read_bytes())==r["inner_release"]["sha256"]
    data = Path(r["archive"]["path"]).read_bytes()
    assert digest(data)==r["archive"]["sha256"] and len(data)==r["archive"]["bytes"]
    with zipfile.ZipFile(r["archive"]["path"]) as z:
        assert len(z.namelist())==len(r["files"])==65 and z.testzip() is None
        assert set(z.namelist())==set(r["files"])
        assert all(digest(z.read(n))==h for n,h in r["files"].items())
        assert digest(z.read("control/EXECUTION_RELEASE.json"))==r["inner_release"]["sha256"]
        assert b"--time=00:30:00" in z.read("source_admission.sbatch")
        assert b" 1700 " in z.read("source_admission.sbatch")
    plan={"root":r["remote_root"],"files":r["files"],"release_sha256":SHA,
          "inner_sha256":r["inner_release"]["sha256"],"archive":base64.b64encode(data).decode(),
          "archive_sha256":r["archive"]["sha256"],"action":args.action,"job":args.job}
    remote=(HERE/"execution_remote.py").read_bytes()
    compile(remote,"<remote>","exec")
    if args.action=="check":
        print("PASS signed 65-file package and resource/release bindings")
        return
    folder=HERE/"actual_execution_v1"
    folder.mkdir(exist_ok=True)
    if args.action=="submit":
        with (folder/".submit_intent").open("x",encoding="utf8") as f:
            json.dump({"root":r["remote_root"],"archive_sha256":r["archive"]["sha256"],"release_sha256":SHA},f)
    else:
        assert args.job and args.job.isdecimal()
    transport=ROOT.parent.parent/"Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2"
    sys.path.insert(0,str(transport))
    from remote_qualification import SSH,PYTHON
    stamp=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    rc=None
    try:
        proc=subprocess.run(SSH+[PYTHON],input=("PLAN="+repr(plan)+"\n").encode()+remote,
                            capture_output=True,timeout=240)
        rc,out,err=proc.returncode,proc.stdout,proc.stderr
    except subprocess.TimeoutExpired as e:
        out,err=e.stdout or b"",e.stderr or b""
    except OSError as e:
        out,err=b"",str(e).encode()
    (folder/(stamp+".stderr")).write_bytes(err)
    events=[]
    for line in out.splitlines():
        try:
            event=json.loads(line)
        except ValueError:
            continue
        for item in event.get("artifacts",[]):
            b=base64.b64decode(item.pop("payload"))
            assert digest(b)==item["sha256"]
            rel=Path(item["relative"])
            assert not rel.is_absolute() and ".." not in rel.parts
            dest=folder/"run"/rel
            dest.parent.mkdir(exist_ok=True,parents=True)
            if dest.exists():
                assert digest(dest.read_bytes())==item["sha256"]
            else:
                dest.write_bytes(b)
            item["local_path"]=str(dest)
        events.append(event)
    receipt={"utc":datetime.now(timezone.utc).isoformat(),"action":args.action,"returncode":rc,"events":events,
             "raw_stderr_sha256":digest(err),"release_sha256":SHA}
    path=folder/(stamp+"_RECEIPT.json")
    path.write_text(json.dumps(receipt,indent=2)+"\n",encoding="utf8")
    if args.action=="submit":
        (folder/(stamp+".stdout")).write_bytes(out)
    print(json.dumps({"receipt":str(path),"sha256":digest(path.read_bytes()),"returncode":rc,
                      "events":[{k:v for k,v in e.items() if k!="artifacts"} for e in events]}))


if __name__=="__main__":
    main()
