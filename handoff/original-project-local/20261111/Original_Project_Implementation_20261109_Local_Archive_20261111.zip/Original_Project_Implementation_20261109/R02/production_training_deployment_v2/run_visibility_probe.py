"""One exact zero-GPU probe after controller release."""
import argparse
import base64
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

from prepare_v2 import HERE, ROOT, enc, read, sha

REMOTE = '''
import base64,hashlib,io,json,os,pwd,subprocess,zipfile
from pathlib import Path,PurePosixPath
assert pwd.getpwuid(os.geteuid()).pw_name=="s20223010065"
os.umask(0o077)
root=Path(REQUEST["remote_root"])
assert not root.exists() and not root.is_symlink()
for row in REQUEST["identity"]:
    with Path(row["path"]).open("rb") as stream:
        assert hashlib.file_digest(stream,"sha256").hexdigest()==row["sha256"]
blob=base64.b64decode(ARCHIVE,validate=True)
assert hashlib.sha256(blob).hexdigest()==REQUEST["archive_sha256"]
with zipfile.ZipFile(io.BytesIO(blob)) as z:
    assert len(z.namelist())==len(REQUEST["files"]) and set(z.namelist())==set(REQUEST["files"])
    assert z.testzip() is None
    for name,h in REQUEST["files"].items():
        p=PurePosixPath(name)
        assert not p.is_absolute() and ".." not in p.parts
        assert hashlib.sha256(z.read(name)).hexdigest()==h
    root.mkdir()
    with (root/".probe_claim").open("x") as f: f.write(RELEASE_SHA)
    for name,h in REQUEST["files"].items():
        p=root/name
        p.parent.mkdir(parents=True,exist_ok=True)
        with p.open("xb") as f: f.write(z.read(name))
        assert hashlib.sha256(p.read_bytes()).hexdigest()==h
for directory in REQUEST["directory_setup"]:
    p=Path(directory)
    assert p.is_relative_to(root)
    p.mkdir()
env=os.environ.copy()
for name in ("SINGULARITY_BIND","SINGULARITY_BINDPATH","APPTAINER_BIND","APPTAINER_BINDPATH"):
    env.pop(name,None)
env["CUDA_VISIBLE_DEVICES"]=""
try:
    run=subprocess.run(REQUEST["argv"],cwd=root,env=env,capture_output=True,text=True,
                       timeout=REQUEST["timeout_seconds"])
    result={"returncode":run.returncode,"stdout":run.stdout,"stderr":run.stderr}
except subprocess.TimeoutExpired:
    result={"returncode":None,"status":"TIMEOUT"}
with (root/"PROBE_RECEIPT.json").open("x") as f: json.dump(result,f)
print(json.dumps(result),flush=True)
'''


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action",choices=("check","run"))
    p.add_argument("--release",type=Path)
    p.add_argument("--release-sha256")
    a=p.parse_args()
    folder=HERE/"visibility_probe_v1"
    request_path=folder/"PROBE_REQUEST_NOT_RELEASED.json"
    request=read(request_path)
    blob=Path(request["archive_path"]).read_bytes()
    assert sha(blob)==request["archive_sha256"]
    assert request["GPU"]==request["sbatch"]==request["model_loads"]==0
    assert request["max_connections"]==request["max_container_launches"]==1
    assert "--nv" not in request["argv"]
    compile(REMOTE,"<remote probe>","exec")
    if a.action=="check":
        print("PASS probe bytes and remote program compilation")
        return
    assert a.release and sha(a.release.read_bytes())==a.release_sha256
    release=read(a.release)
    assert release["status"]=="RELEASED"
    assert release["controller"]=="01a1c09c-f9e6-70f1-b9e8-b988b89c755f"
    assert release["candidate_sha256"]==sha(request_path.read_bytes())
    assert release["expected_visible_rows"]==92
    assert all(release[key]==value for key,value in request.items() if key!="status")
    with (folder/".probe_claim").open("xb") as f:
        f.write(enc({"release_sha256":a.release_sha256,"root":request["remote_root"]}))
    sys.path.insert(0,str(ROOT.parent.parent/"Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2"))
    from remote_qualification import SSH,PYTHON
    payload=f"REQUEST={request!r}\nARCHIVE={base64.b64encode(blob).decode()!r}\nRELEASE_SHA={a.release_sha256!r}\n"+REMOTE
    try:
        result=subprocess.run(SSH+[PYTHON],input=payload.encode(),capture_output=True,timeout=240)
        out,err,rc=result.stdout,result.stderr,result.returncode
    except subprocess.TimeoutExpired as exc:
        out,err,rc=exc.stdout or b"",exc.stderr or b"",None
    (folder/"PROBE_ACTUAL.stdout").write_bytes(out)
    (folder/"PROBE_ACTUAL.stderr").write_bytes(err)
    try:
        actual=json.loads(out)
    except ValueError:
        actual=None
    receipt={"utc":datetime.now(timezone.utc).isoformat(),"ssh_returncode":rc,"container":actual,
             "stdout_sha256":sha(out),"stderr_sha256":sha(err),"release_sha256":a.release_sha256}
    (folder/"PROBE_ACTUAL_RECEIPT.json").write_bytes(enc(receipt))
    print(json.dumps(receipt))


if __name__=="__main__":
    main()
