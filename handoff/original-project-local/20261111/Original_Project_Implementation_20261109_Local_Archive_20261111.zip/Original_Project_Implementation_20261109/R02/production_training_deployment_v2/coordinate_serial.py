"""Drive the approved nodes through the frozen serial driver without retries."""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
RELEASE = ROOT / "CONTROLLER_PHASE1_TWELVE_TRAIN_V2_EXECUTION_RELEASE.json"
SHA = "b80b5acf957a11239c53feb015c00a4ba22e7f60e1fec8a2f1a8a224e9773ae3"


def read(path):
    return json.loads(path.read_bytes())


def call(action, index):
    proc = subprocess.run([sys.executable, "-B", str(HERE / "serial_driver.py"), action,
                           "--release", str(RELEASE), "--release-sha256", SHA, "--index", str(index)],
                          capture_output=True, text=True, timeout=330)
    if proc.returncode:
        raise RuntimeError(proc.stderr.strip())
    receipt = json.loads(proc.stdout)
    if receipt["returncode"] != 0 or receipt["release_sha256"] != SHA or not receipt["events"]:
        raise RuntimeError(f"Ambiguous driver receipt at node {index}: {receipt}")
    return receipt["events"][-1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--minutes", type=int, choices=(15, 60, 240), default=60)
    args = parser.parse_args()
    from serial_driver import verify
    release = verify(RELEASE, SHA)
    deadline = time.monotonic() + 60 * args.minutes
    for index, node in enumerate(release["nodes"]):
        folder = HERE / "nodes" / node["track_id"] / "actual"
        acceptance = folder / "ACCEPTANCE.json"
        submission = folder / "SUBMISSION.json"
        if acceptance.exists():
            result = read(acceptance)
            assert result["status"] == "PASS_ACTUAL_TRAIN_2000"
            assert result["track_id"] == node["track_id"] and result["job_sha256"] == node["job_sha256"]
            continue
        if time.monotonic() >= deadline:
            break
        if not submission.exists():
            assert index > 0, "First node was already submitted. Reconcile its receipt."
            assert not Path(node["local_claim"]).exists(), "Existing unresolved claim; reconcile"
            result = call("submit", index)
            assert result["status"] == "SLURM_ACCEPTED"
            assert result["track_id"] == node["track_id"] and result["job_sha256"] == node["job_sha256"]
            print(json.dumps({"index": index, **result}), flush=True)
        submitted = read(submission)
        assert submitted["status"] == "SLURM_ACCEPTED" and submitted["job_sha256"] == node["job_sha256"]
        last_state = None
        while time.monotonic() < deadline:
            result = call("collect", index)
            assert result["job_id"] == submitted["job_id"] and result["track_id"] == node["track_id"]
            if result["status"] == "PASS_ACTUAL_TRAIN_2000":
                assert result["job_sha256"] == node["job_sha256"]
                print(json.dumps({"index": index, **result}), flush=True)
                break
            state = result.get("state")
            if state != last_state:
                print(json.dumps({"index": index, **result}), flush=True)
                last_state = state
            if state not in {"PENDING", "RUNNING", "CONFIGURING", "COMPLETING"}:
                raise RuntimeError(f"Stopped on unaccepted terminal state: {state}")
            time.sleep(90)
        else:
            break
    print("Serial coordination window ended. See per-node receipts.", flush=True)


if __name__ == "__main__":
    main()
