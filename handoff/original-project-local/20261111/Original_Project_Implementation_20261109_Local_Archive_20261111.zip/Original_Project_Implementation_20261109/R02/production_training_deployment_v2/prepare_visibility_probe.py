"""An unexecuted CPU container-visibility check with the corrected bind ordering."""
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import zipfile
from prepare_v2 import HERE,ROOT,read,enc,sha,bindings


def main():
    template=read(HERE/"TRAINING_RELEASE_NOT_RELEASED.json")
    node=template["nodes"][0]
    folder=HERE/"visibility_probe_v1"
    folder.mkdir(exist_ok=True)
    with zipfile.ZipFile(node["archive"]["path"]) as z:
        manifest=json.loads(z.read("MANIFEST.json"))
        control={n:z.read(n) for n in z.namelist() if n.startswith("control/")}
    original_root=node["remote_root"]
    probe_root=original_root.rsplit("/",1)[0]+"/production_train_v2_visibility_probe"
    manifest["mounts"]={dst:host.replace(original_root,probe_root) for dst,host in manifest["mounts"].items()}
    checked=[{"path":r["path"],"bytes":r["bytes"]} for r in manifest["actual_mounted_files"]]
    code="""import json,os,sys
from pathlib import Path
assert os.environ.get("CUDA_VISIBLE_DEVICES") == ""
spec=json.loads(Path("/runcontrol/VISIBILITY_FILES.json").read_bytes())
results=[]
for row in spec:
    p=Path(row["path"])
    actual=p.stat()
    assert p.is_file() and actual.st_size==row["bytes"] and os.access(p,os.R_OK),str(p)
    results.append({"path":str(p),"bytes":actual.st_size,"readable":True})
print(json.dumps({"status":"INTERPRETER_AND_BIND_VISIBILITY_PASS","python":sys.executable,"rows":results,
                  "model_imports":0,"functional_file_contents_read":False,"gpu":0}))
"""
    script=read(ROOT/"R02/qualification_v1/EXACT_RUNTIME_ENV_V3.json")["env"]
    runtime,base=script["R02_RUNTIME_ENV"],script["R02_BASE_ENV"]
    bind_list=[base+":"+base+":ro",runtime+":"+runtime+":ro",probe_root+":/runcontrol:ro"]
    bind_list.extend(host+":"+dst+":ro" for dst,host in sorted(manifest["mounts"].items()))
    # Match the training allocation's writable output mapping without exposing user directories.
    bind_list.append(probe_root+"/output:/out")
    argv=[script["R02_SINGULARITY"],"exec","--cleanenv","--containall","--no-home",
          "--bind",",".join(bind_list),"--pwd","/out",
          "--env","CUDA_VISIBLE_DEVICES=","--env","NVIDIA_VISIBLE_DEVICES=none",
          "--env","PYTHONNOUSERSITE=1","--env","PYTHONDONTWRITEBYTECODE=1","--env","PYTHONPATH=/code",
          "--env","HOME=/out/home","--env","TMPDIR=/out/tmp",
          script["R02_SIF"],runtime+"/bin/python","-B","/runcontrol/probe_visibility.py"]
    files=control|{"probe_visibility.py":code.encode(),"VISIBILITY_FILES.json":enc(checked)}
    with zipfile.ZipFile(folder/"VISIBILITY_INPUT_UNSIGNED.zip","w") as z:
        for n,b in sorted(files.items()):
            z.writestr(zipfile.ZipInfo(n,(2026,11,10,0,0,0)),b,compress_type=zipfile.ZIP_DEFLATED)
    request={"status":"NOT_RELEASED","remote_root":probe_root,"archive_sha256":sha((folder/"VISIBILITY_INPUT_UNSIGNED.zip").read_bytes()),
             "archive_path":str(folder/"VISIBILITY_INPUT_UNSIGNED.zip"),"files":{n:sha(b) for n,b in files.items()},
             "argv":argv,"timeout_seconds":120,"max_connections":1,"max_container_launches":1,
             "GPU":0,"sbatch":0,"model_loads":0,"functional_file_contents_read":False,
             "directory_setup":[probe_root+"/output",probe_root+"/output/home",probe_root+"/output/tmp"],
             "expected_source_training_root":original_root,"identity":[
                {"path":script["R02_SIF"],"sha256":"d90e1feeb54ed85c324ae738a08a8e9217fa0c6b1d8d2347ce7651b452fbcd7f"},
                {"path":script["R02_SINGULARITY"],"sha256":"fe405436816dc345002f141e4437805be380e91ddb96e7630c7f647f9cc9a3a9"}]}
    (folder/"PROBE_REQUEST_NOT_RELEASED.json").write_bytes(enc(request))
    print(json.dumps({"request_sha256":sha((folder/"PROBE_REQUEST_NOT_RELEASED.json").read_bytes()),"file_count":len(checked)}))


if __name__=="__main__":
    main()
