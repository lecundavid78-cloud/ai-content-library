"""Exact mount-order replacement preserving original scientific and inner-release bytes."""
import difflib
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import zipfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OLD=HERE.parent/"production_training_deployment_v1"


def sha(b):
    return hashlib.sha256(b).hexdigest()


def enc(o):
    return (json.dumps(o,indent=2)+"\n").encode()


def read(p):
    return json.loads(p.read_bytes())


def bindings(batch):
    argv=shlex.split(batch.replace("\\\n"," "))
    assert argv.count("--bind")==1
    return argv[argv.index("--bind")+1].split(",")


def main():
    old_release=ROOT/"CONTROLLER_PHASE1_TWELVE_TRAIN_EXECUTION_RELEASE.json"
    assert sha(old_release.read_bytes())=="cb90cfd0756a7e3eaf747332582960dd9c85e586ce5e2431d59ae4dfc8db2df1"
    release=read(old_release)
    template=read(OLD/"TRAINING_RELEASE_NOT_RELEASED.json")
    changes=[]
    nodes=[]
    for number,(old,prior) in enumerate(zip(release["nodes"],template["nodes"])):
        assert old["track_id"]==prior["track_id"]
        archive=Path(old["signed_archive"]["path"])
        assert sha(archive.read_bytes())==old["signed_archive"]["sha256"]
        with zipfile.ZipFile(archive) as z:
            files={n:z.read(n) for n in prior["unsigned_files"]}
            files["ROOT_RELEASE.json"]=z.read("ROOT_RELEASE.json")
        assert sha(files["ROOT_RELEASE.json"])==old["inner_sha256"]
        key=old["track_id"]
        old_root=old["remote_root"]
        new_root=old_root.replace("/production_train_","/production_train_v2_")
        assert new_root!=old_root
        supersedes="5222146" if number==0 else None
        manifest=json.loads(files["MANIFEST.json"])
        manifest["remote_root"]=new_root
        manifest["supersedes_job"]=supersedes
        for dst,host in manifest["mounts"].items():
            if host.startswith(old_root+"/"):
                assert dst.startswith("/control/")
                manifest["mounts"][dst]=new_root+host.removeprefix(old_root)
        files["MANIFEST.json"]=enc(manifest)
        outer=json.loads(files["OUTER_NOT_RELEASED.json"])
        outer.update(manifest_sha256=sha(files["MANIFEST.json"]),supersedes_job=supersedes)
        files["OUTER_NOT_RELEASED.json"]=enc(outer)
        batch=files["train.sbatch"].decode()
        new_batch=batch.replace(old_root,new_root).replace(old["job_name"],old["job_name"]+"_v2")
        leaf_first=' --bind "$RUN:/runcontrol:ro,'
        assert new_batch.count(leaf_first)==1
        tail=',$R02_RUNTIME_ENV:$R02_RUNTIME_ENV:ro,$R02_BASE_ENV:$R02_BASE_ENV:ro,$OUT:/out"'
        assert new_batch.count(tail)==1
        new_batch=new_batch.replace(leaf_first,
            ' --bind "$R02_BASE_ENV:$R02_BASE_ENV:ro,$R02_RUNTIME_ENV:$R02_RUNTIME_ENV:ro,$RUN:/runcontrol:ro,')
        new_batch=new_batch.replace(tail,',$OUT:/out"')
        before=bindings(batch)
        after=bindings(new_batch)
        translated=[b.replace(old_root,new_root) for b in before]
        assert set(translated)==set(after) and len(translated)==len(after)==len(set(after))
        assert after[:2]==["$R02_BASE_ENV:$R02_BASE_ENV:ro","$R02_RUNTIME_ENV:$R02_RUNTIME_ENV:ro"]
        for b in after[2:]:
            if "/production_init_" in b:
                assert b in before,"existing code/INIT host changed"
        files["train.sbatch"]=new_batch.encode()
        for n,h in prior["unsigned_files"].items():
            if n not in ("MANIFEST.json","OUTER_NOT_RELEASED.json","train.sbatch"):
                assert sha(files[n])==h,n
        folder=HERE/"nodes"/key
        folder.mkdir(parents=True,exist_ok=True)
        for n,b in files.items():
            p=folder/n
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(b)
        subprocess.run(["F:/programming language/Git/bin/bash.exe","-n",str(folder/"train.sbatch")],check=True)
        output=folder/"TRAIN_V2_UNSIGNED.zip"
        with zipfile.ZipFile(output,"w") as z:
            for n,b in sorted(files.items()):
                z.writestr(zipfile.ZipInfo(n,(2026,11,10,0,0,0)),b,compress_type=zipfile.ZIP_DEFLATED)
        node=prior|{"remote_root":new_root,"job_name":old["job_name"]+"_v2","supersedes_job":supersedes,
                    "archive":{"path":str(output),"sha256":sha(output.read_bytes()),"bytes":output.stat().st_size},
                    "unsigned_files":{n:sha(b) for n,b in files.items()},"sbatch_sha256":sha(files["train.sbatch"]),
                    "local_claim":str(folder/".submit_intent"),"preserved_inner_sha256":old["inner_sha256"]}
        nodes.append(node)
        changes.extend(difflib.unified_diff(batch.splitlines(True),new_batch.splitlines(True),
                                            "v1/"+key+"/train.sbatch","v2/"+key+"/train.sbatch"))
    result=template|{"nodes":nodes,"init_actual_gpu_seconds":231,"failed_original_training_gpu_seconds":24,
                     "superseded_execution_release_sha256":sha(old_release.read_bytes()),
                     "prior_formal_gpu_billed_seconds":255,"remaining_formal_gpu_budget_seconds":59145}
    (HERE/"TRAINING_RELEASE_NOT_RELEASED.json").write_bytes(enc(result))
    (HERE/"BATCH_ONLY_DIFF.patch").write_text("".join(changes),encoding="utf8")
    for name in ("training_launcher.py","serial_driver.py","serial_remote.py"):
        (HERE/name).write_bytes((OLD/name).read_bytes())
    assert len(nodes)==12
    print(json.dumps({"nodes":12,"template_sha256":sha((HERE/"TRAINING_RELEASE_NOT_RELEASED.json").read_bytes()),
                      "first_archive":nodes[0]["archive"]}))


if __name__=="__main__":
    main()
