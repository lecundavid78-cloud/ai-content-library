import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import queue_predecessor_gate as gate


class PredecessorGateTest(unittest.TestCase):
    def test_accounting_waits_only_for_transient_states(self):
        previous = {"job_id": "123", "job_name": "prior", "root": "/remote/prior"}
        completed = "123|prior|COMPLETED|0:0|42|gres/gpu=1|/remote/prior"
        running = completed.replace("COMPLETED", "RUNNING")
        with (patch.object(gate.subprocess, "check_output", side_effect=["", running, completed]) as sacct,
              patch.object(gate.time, "sleep") as wait):
            assert gate.wait_for_accounting(previous)[0] == completed
            assert sacct.call_count == 3
            assert wait.call_count == 2
        failed = completed.replace("COMPLETED|0:0", "FAILED|1:0")
        wrong = running.replace("/remote/prior", "/remote/other")
        for row in (failed, wrong):
            with (patch.object(gate.subprocess, "check_output", return_value=row) as sacct,
                  patch.object(gate.time, "sleep") as wait):
                with self.assertRaises(AssertionError):
                    gate.wait_for_accounting(previous)
                sacct.assert_called_once()
                wait.assert_not_called()

    def test_acceptance_and_fail_closed(self):
        def write(path, record):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(record), encoding="utf-8")
            return gate.sha(path)

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            prev = root / "previous"
            out = prev / "output-123"
            batch = write(root / "train.sbatch", {})
            outer = write(root / "OUTER_RELEASE.json", {})
            job = write(prev / "JOB.json", {"output": "/out/train-track"})
            inner = write(prev / "ROOT_RELEASE.json", {})
            prev_outer = write(prev / "OUTER_RELEASE.json", {})
            write(out / "LOGICAL_EXIT.json", {"returncode": 0, "job_sha256": job, "slurm_job_id": "123"})
            write(out / "train-track/RUNTIME_RECEIPT.json",
                  {"status": "COMPLETE_UNEVALUATED", "stage": "train", "job_sha256": job, "release_sha256": inner})
            checkpoints = []
            for step in (500, 1000, 2000):
                name = f"STEP_{step}.pt"
                digest = write(out / "train-track/train" / name, {"step": step})
                checkpoints.append({"step": step, "sha256": digest, "path": f"/out/train-track/train/{name}"})
            receipt_path = out / "train-track/train/TRAIN_RECEIPT.json"
            receipt = {"status": "COMPLETE_UNEVALUATED", "completed_updates": 2000, "attempts": 2000,
                       "resume_checkpoint": None, "training_id": "test", "checkpoints": checkpoints}
            write(receipt_path, receipt)
            binding = write(root / "QUEUE_BINDING.json", {
                "gate_sha256": gate.sha(Path(gate.__file__)), "batch_sha256": batch, "outer_sha256": outer,
                "predecessor": {"job_id": "123", "job_name": "prior", "root": str(prev),
                                "job_sha256": job, "inner_sha256": inner, "outer_sha256": prev_outer},
            })
            env = {"R02_QUEUE_BINDING_SHA": binding, "R02_TRAINING_OUTER_SHA": outer, "SLURM_JOB_ID": "124"}
            account = f"123|prior|COMPLETED|0:0|42|gres/gpu=1|{prev}"
            with (patch.dict(gate.os.environ, env), patch.object(gate.Path, "cwd", return_value=root),
                  patch.object(gate.subprocess, "check_output", return_value=account) as sacct,
                  patch.object(gate.os, "execv") as launch):
                gate.main()
                launch.assert_called_once_with("/bin/bash", ["/bin/bash", str(root / "train.sbatch")])
                launch.reset_mock()
                sacct.return_value = account.replace("COMPLETED|0:0", "FAILED|1:0")
                with self.assertRaises(AssertionError):
                    gate.main()
                sacct.return_value = account
                write(receipt_path, receipt | {"completed_updates": 1999})
                with self.assertRaises(AssertionError):
                    gate.main()
                write(receipt_path, receipt)
                write(out / "train-track/train/STEP_1000.pt", {"changed": True})
                with self.assertRaises(AssertionError):
                    gate.main()
                launch.assert_not_called()


if __name__ == "__main__":
    unittest.main()
