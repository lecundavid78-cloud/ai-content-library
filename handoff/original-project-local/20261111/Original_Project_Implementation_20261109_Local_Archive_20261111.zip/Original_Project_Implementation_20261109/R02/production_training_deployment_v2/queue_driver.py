"""Prepare an exact dependency-chain candidate and submit only its reviewed bytes."""
import argparse
import base64
import datetime
import json
from pathlib import Path
import subprocess
import sys

from serial_driver import HERE, ROOT, enc, sha, verify


TRAIN_RELEASE = ROOT / "CONTROLLER_PHASE1_TWELVE_TRAIN_V2_EXECUTION_RELEASE.json"
TRAIN_SHA = "b80b5acf957a11239c53feb015c00a4ba22e7f60e1fec8a2f1a8a224e9773ae3"
CANDIDATE = HERE / "QUEUE_CANDIDATE.json"


def exclusive(path, value):
    with path.open("xb") as stream:
        stream.write(enc(value))


def read(path):
    return json.loads(path.read_bytes())


def actual(node):
    return HERE / "nodes" / node["track_id"] / "actual"


def prepare():
    nodes = verify(TRAIN_RELEASE, TRAIN_SHA)["nodes"]
    submitted = [read(actual(node) / "SUBMISSION.json") for node in nodes[:4]]
    ids = ["5222686", "5222736", "5222749", "5222795"]
    for node, receipt, jid in zip(nodes[:4], submitted, ids, strict=True):
        assert receipt["status"] == "SLURM_ACCEPTED" and receipt["job_id"] == jid
        assert receipt["job_sha256"] == node["job_sha256"] and receipt["root"] == node["remote_root"]
    for node, jid in zip(nodes[:3], ids[:3], strict=True):
        receipt = read(actual(node) / "ACCEPTANCE.json")
        assert receipt["status"] == "PASS_ACTUAL_TRAIN_2000" and receipt["job_id"] == jid
    for node in nodes[4:]:
        assert not Path(node["local_claim"]).exists()
        assert not (actual(node) / "SUBMISSION.json").exists()
    tail = {key: nodes[3][key] for key in ("job_name", "job_sha256", "inner_sha256", "outer_sha256")}
    tail.update(root=nodes[3]["remote_root"], job_id=ids[3])
    scripts = {n: (HERE / n).read_bytes() for n in ("queue_driver.py", "queue_remote.py", "queue_predecessor_gate.py")}
    for n, source in scripts.items():
        compile(source, n, "exec")
    assert all(node["allocated_gpu_seconds"] == 1800 for node in nodes)
    assert 231 + 24 + sum(node["allocated_gpu_seconds"] for node in nodes) <= 59400
    candidate = {
        "status": "LOCAL_CANDIDATE_REQUIRES_CONTROLLER_REVIEW",
        "user_message_id": "01a1c5b6-3023-7ad1-9e05-e7286d2cf7db",
        "training_release_sha256": TRAIN_SHA,
        "scripts": {n: sha(source) for n, source in scripts.items()},
        "accepted_ids": ids,
        "tail": tail,
        "nodes": nodes[4:],
        "serial_dependency": "afterok",
        "maximum_project_GPU_seconds": 59400,
        "new_GPU_allocation_seconds_cap": 8 * 1800,
        "prediction": False,
    }
    return candidate, scripts


def submit(candidate, scripts, release_path, release_sha):
    assert sha(release_path.read_bytes()) == release_sha
    assert read(release_path) == {
        "status": "RELEASED",
        "candidate_sha256": sha(CANDIDATE.read_bytes()),
        "user_message_id": candidate["user_message_id"],
        "additional_jobs": 8,
        "afterok_only": True,
        "prediction": False,
    }
    assert read(CANDIDATE) == candidate
    nodes = candidate["nodes"]
    plan = dict(candidate)
    plan["release_sha256"] = release_sha
    gate = scripts["queue_predecessor_gate.py"]
    plan["gate"] = base64.b64encode(gate).decode("ascii")
    plan["gate_sha256"] = sha(gate)
    plan["archives"] = [base64.b64encode(Path(n["signed_archive"]["path"]).read_bytes()).decode("ascii") for n in nodes]
    transport = ROOT.parent.parent / "Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2"
    sys.path.insert(0, str(transport))
    from remote_qualification import SSH, PYTHON

    exclusive(HERE / "QUEUE_SUBMISSION_CLAIM.json", {"release_sha256": release_sha})
    for node in nodes:
        exclusive(Path(node["local_claim"]), {"queue_release_sha256": release_sha, "archive": node["signed_archive"]})
    rc = None
    try:
        p = subprocess.run(SSH + [PYTHON], input=("PLAN=" + repr(plan) + "\n").encode() + scripts["queue_remote.py"],
                           capture_output=True, timeout=900)
        rc, out, err = p.returncode, p.stdout, p.stderr
    except subprocess.TimeoutExpired as exc:
        out, err = exc.stdout or b"", exc.stderr or b""
    except OSError as exc:
        out, err = b"", str(exc).encode()
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    (HERE / (stamp + "_QUEUE.stdout")).write_bytes(out)
    (HERE / (stamp + "_QUEUE.stderr")).write_bytes(err)
    observed = {}
    predecessor = candidate["tail"]["job_id"]
    for line in out.splitlines():
        try:
            event = json.loads(line)
        except ValueError:
            continue
        if event.get("status") != "SLURM_ACCEPTED":
            continue
        node = nodes[len(observed)]
        assert event["dependency"] == predecessor and event["track_id"] == node["track_id"]
        assert event["job_sha256"] == node["job_sha256"] and event["root"] == node["remote_root"]
        predecessor = event["job_id"]
        assert predecessor.isdecimal() and predecessor not in set(observed.values()) | set(candidate["accepted_ids"])
        actual(node).mkdir(exist_ok=True)
        exclusive(actual(node) / "SUBMISSION.json", event)
        observed[node["track_id"]] = predecessor
    complete = rc == 0 and len(observed) == 8
    receipt = {"status": "ALL_QUEUED" if complete else "STOP_RECONCILE_NO_RETRY",
               "returncode": rc, "accepted": observed, "queue_release_sha256": release_sha,
               "stdout": stamp + "_QUEUE.stdout", "stderr": stamp + "_QUEUE.stderr"}
    exclusive(HERE / "QUEUE_SUBMISSION_RESULT.json", receipt)
    print(json.dumps(receipt))
    return 0 if complete else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("check", "submit"))
    parser.add_argument("--release", type=Path)
    parser.add_argument("--release-sha256")
    args = parser.parse_args()
    candidate, scripts = prepare()
    if args.action == "check":
        if CANDIDATE.exists():
            assert read(CANDIDATE) == candidate
        else:
            exclusive(CANDIDATE, candidate)
        print(json.dumps({"candidate": str(CANDIDATE), "sha256": sha(CANDIDATE.read_bytes())}))
        return 0
    return submit(candidate, scripts, args.release, args.release_sha256)


if __name__ == "__main__":
    sys.exit(main())
