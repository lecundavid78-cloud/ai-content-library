import json
from pathlib import Path
import shlex
import unittest
import zipfile
from prepare_v2 import HERE,OLD,read,sha,bindings


class BindChecks(unittest.TestCase):
    def test_all_twelve_same_bind_set_parent_directories_first(self):
        old=read(OLD/"TRAINING_RELEASE_NOT_RELEASED.json")
        new=read(HERE/"TRAINING_RELEASE_NOT_RELEASED.json")
        self.assertEqual(len(new["nodes"]),12)
        for a,b in zip(old["nodes"],new["nodes"]):
            before=(OLD/"nodes"/a["track_id"]/"train.sbatch").read_text()
            after=(HERE/"nodes"/b["track_id"]/"train.sbatch").read_text()
            actual=bindings(after)
            expected=[v.replace(a["remote_root"],b["remote_root"]) for v in bindings(before)]
            self.assertEqual(set(actual),set(expected))
            self.assertEqual(len(actual),len(set(actual)))
            self.assertTrue(actual[0].startswith("$R02_BASE_ENV:"))
            self.assertTrue(actual[1].startswith("$R02_RUNTIME_ENV:"))
            for v in actual[2:]:
                if "/production_init_" in v:
                    self.assertIn(v,bindings(before))

    def test_original_scientific_bytes_and_inner_releases(self):
        import sys
        sys.path.insert(0,str(HERE.parents[1]/"R05/phase1_v2"))
        old=read(OLD/"TRAINING_RELEASE_NOT_RELEASED.json")
        new=read(HERE/"TRAINING_RELEASE_NOT_RELEASED.json")
        for a,b in zip(old["nodes"],new["nodes"]):
            with zipfile.ZipFile(b["archive"]["path"]) as z:
                self.assertEqual(sha(z.read("ROOT_RELEASE.json")),b["preserved_inner_sha256"])
                for n,h in a["unsigned_files"].items():
                    if n not in ("MANIFEST.json","OUTER_NOT_RELEASED.json","train.sbatch"):
                        self.assertEqual(sha(z.read(n)),h,n)
        self.assertEqual(new["prior_formal_gpu_billed_seconds"],255)
        self.assertEqual(new["remaining_formal_gpu_budget_seconds"],59400-255)

    def test_visibility_probe_no_gpu_same_normalized_binds(self):
        request=read(HERE/"visibility_probe_v1/PROBE_REQUEST_NOT_RELEASED.json")
        node=read(HERE/"TRAINING_RELEASE_NOT_RELEASED.json")["nodes"][0]
        env=read(HERE.parents[1]/"R02/qualification_v1/EXACT_RUNTIME_ENV_V3.json")["env"]
        batch=(HERE/"nodes"/node["track_id"]/"train.sbatch").read_text()
        expanded=bindings(batch)
        variables={"RUN":request["remote_root"],"OUT":request["remote_root"]+"/output",
                   "R02_BASE_ENV":env["R02_BASE_ENV"],"R02_RUNTIME_ENV":env["R02_RUNTIME_ENV"]}
        expected=[]
        for b in expanded:
            for k,v in variables.items():b=b.replace("$"+k,v)
            b=b.replace(node["remote_root"],request["remote_root"])
            expected.append(b)
        args=request["argv"]
        actual=args[args.index("--bind")+1].split(",")
        self.assertEqual(set(actual),set(expected))
        self.assertEqual(actual[:2],expected[:2])
        self.assertNotIn("--nv",args)
        self.assertIn("CUDA_VISIBLE_DEVICES=",args)
        self.assertEqual(request["GPU"],0)
        with zipfile.ZipFile(request["archive_path"]) as z:
            for name in z.namelist():
                self.assertFalse(name.endswith(".pt"))
                self.assertNotIn("train_bank",name)


if __name__=="__main__":
    unittest.main(verbosity=2)
