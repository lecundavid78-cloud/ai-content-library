"""Validate the immediate predecessor before executing the unchanged batch."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


def read(p):
    return json.loads(p.read_bytes())


def sha(p):
    with p.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def wait_for_accounting(previous):
    jid = previous["job_id"]
    deadline = time.monotonic() + 30
    while (remaining := deadline - time.monotonic()) > 0:
        raw = subprocess.check_output(
            ["/public/gridview_20250224/slurm/bin/sacct", "-X", "-n", "-P", "-j", jid,
             "--format=JobIDRaw,JobName%100,State,ExitCode,ElapsedRaw,AllocTRES%150,WorkDir%300"],
            text=True, timeout=remaining).strip()
        if raw:
            assert len(raw.splitlines()) == 1, raw
            row = raw.split("|")
            assert len(row) >= 7 and row[:2] == [jid, previous["job_name"]] and row[6] == previous["root"], raw
            if row[2] not in {"PENDING", "RUNNING", "COMPLETING"}:
                assert row[2:4] == ["COMPLETED", "0:0"], raw
                return raw, row
        time.sleep(min(3, max(0, deadline - time.monotonic())))
    raise RuntimeError(f"Slurm accounting did not show a terminal result for {jid} within 30 seconds")


def main():
    root = Path.cwd()
    binding_path = root / "QUEUE_BINDING.json"
    assert sha(binding_path) == os.environ["R02_QUEUE_BINDING_SHA"]
    b = read(binding_path)
    assert sha(Path(__file__)) == b["gate_sha256"]
    assert sha(root / "train.sbatch") == b["batch_sha256"]
    assert sha(root / "OUTER_RELEASE.json") == b["outer_sha256"] == os.environ["R02_TRAINING_OUTER_SHA"]
    previous = b["predecessor"]
    jid = previous["job_id"]
    assert jid.isdecimal()
    pre = Path(previous["root"])
    raw, row = wait_for_accounting(previous)
    assert 0 < int(row[4]) <= 1800 and "gres/gpu=1" in row[5].split(",")
    assert sha(pre/"JOB.json") == previous["job_sha256"]
    assert sha(pre/"ROOT_RELEASE.json") == previous["inner_sha256"]
    assert sha(pre/"OUTER_RELEASE.json") == previous["outer_sha256"]
    job = read(pre/"JOB.json")
    out = pre/("output-"+jid)
    logical = read(out/"LOGICAL_EXIT.json")
    assert logical["returncode"] == 0 and logical["job_sha256"] == previous["job_sha256"]
    assert logical["slurm_job_id"] == jid
    result = out / Path(job["output"]).relative_to("/out")
    runtime = read(result/"RUNTIME_RECEIPT.json")
    assert runtime["status"] == "COMPLETE_UNEVALUATED" and runtime["stage"] == "train"
    assert runtime["job_sha256"] == previous["job_sha256"] and runtime["release_sha256"] == previous["inner_sha256"]
    tr = read(result/"train/TRAIN_RECEIPT.json")
    assert tr["status"] == "COMPLETE_UNEVALUATED" and tr["completed_updates"] == 2000
    assert tr["attempts"] >= 2000
    assert tr["resume_checkpoint"] is None and sorted(x["step"] for x in tr["checkpoints"]) == [500,1000,2000]
    for cp in tr["checkpoints"]:
        p = result/"train"/f'STEP_{cp["step"]}.pt'
        assert cp["path"] == job["output"]+f'/train/{p.name}' and sha(p) == cp["sha256"]
    print(json.dumps({"status":"PREDECESSOR_2000_AND_CHECKPOINTS_VERIFIED","predecessor_job_id":jid,
                      "slurm_job_id":os.environ["SLURM_JOB_ID"],"training_id":tr["training_id"],
                      "checkpoints":tr["checkpoints"],"sacct":raw}), flush=True)
    os.execv("/bin/bash", ["/bin/bash", str(root/"train.sbatch")])


if __name__ == "__main__":
    main()
