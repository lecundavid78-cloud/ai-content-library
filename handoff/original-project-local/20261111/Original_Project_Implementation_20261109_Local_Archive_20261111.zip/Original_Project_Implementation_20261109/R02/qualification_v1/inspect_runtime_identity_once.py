"""One exact-release readonly runtime identity inspection. No upload/write/model calls."""
from pathlib import Path
import sys,json,hashlib,subprocess,datetime
E=Path(__file__).resolve().parents[2];D=Path(__file__).resolve().parent
sys.path.insert(0,'F:/novoR2/Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2')
from remote_qualification import SSH,PYTHON
rp=E/'CONTROLLER_RUNTIME_IDENTITY_INSPECTION_RELEASE.json';release=json.loads(rp.read_bytes())
assert release['schema']=='ORIGINAL_PROJECT_READONLY_IDENTITY_INSPECTION_V1' and release['status']=='RELEASED' and release['controller']=='01a1c09c-f9e6-70f1-b9e8-b988b89c755f' and release['connections_max']==1
assert all(release[k] is False for k in ('upload','remote_mutation','sbatch','model_load_forward_backward','target_or_source_functional_values'))
ready=json.loads((E/'R01/qualification_material_v1/READY.json').read_bytes());sources={sid:v['natural_arrays_binding']['sha256'] for sid,v in ready['sources'].items()};assert len(sources)==3
payload={'sources':sources}
code=r'''
from pathlib import Path
import json,hashlib,subprocess,os,datetime,socket
RF=Path('/public/home/s20223010065/RFduffision');ENV=RF/'ZERO_SHOT_MODELS_P2R_20261024_v1/env_prosst';BASE=Path('/public/home/s20223010065/software/miniconda3/envs/prosst');SIF=RF/'RF3/cuda.sif';SING=Path('/public/software/singularity/3.9.2/bin/singularity')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def meta(p,expected=None,hash_file=False):
 p=Path(p);v={'path':str(p),'exists':p.exists(),'readable':os.access(p,os.R_OK),'bytes':p.stat().st_size if p.is_file() else None,'resolved':str(p.resolve())}
 if hash_file and p.is_file():v['sha256']=sha(p)
 if expected is not None:
  v['expected_sha256']=expected
  v['sha256_match']=(v.get('sha256')==expected) if hash_file else 'NOT_REHASHED_METADATA_ONLY'
 return v
p=subprocess.run(['id','-un'],capture_output=True,text=True,timeout=10);assert p.returncode==0 and p.stdout.strip()=='s20223010065'
lockpath=RF/'ThreeTarget_FourCell_Replication_20261108/all18_qualification_v2/job/NATIVE_LOCK.json';assert sha(lockpath)=='49e8719821c42f359ebbe489879c1094858ffebbd57f83dd557b58c6a04eea38';lock=json.loads(lockpath.read_bytes());native=[]
for m in lock['members']:
 root=RF/'ProSST-main/prosst2048' if m['K']==2048 else RF/'Research_VenusREM2_Execution_20261101/R02_Runtime/model_cache'/('ProSST-'+str(m['K']))
 for name,h in m['files_sha256'].items():native.append(dict(K=m['K'],**meta(root/name,h,False)))
arrays=[meta(RF/'ThreeTarget_FourCell_Replication_20261108/all18_qualification_v2/job/natural'/(sid+'.npz'),h,True) for sid,h in PLAN['sources'].items()];assert all(z['sha256_match'] for z in arrays)
# Actual library imports only; never native model construction or weight deserialization.
inspect_code="""import sys,json,inspect,hashlib,importlib,os
import torch,numpy,transformers
names=('torch','numpy','transformers','transformers.dynamic_module_utils')
files={}
for name in names:
 m=importlib.import_module(name);p=__import__('pathlib').Path(inspect.getfile(m)).resolve();files[name]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'torch_version':str(torch.__version__),'numpy_version':numpy.__version__,'transformers_version':transformers.__version__,'python_version':sys.version.split()[0],'files':files}))
"""
site=ENV/'lib/python3.11/site-packages';ld=':'.join([str(site/'torch/lib'),str(BASE/'lib')]+[str(p) for p in site.glob('nvidia/*/lib') if p.is_dir()])
args=[str(SING),'exec','--cleanenv','--containall','--no-home','--bind',str(ENV)+':'+str(ENV)+':ro,'+str(BASE)+':'+str(BASE)+':ro','--pwd','/tmp','--env','CUDA_VISIBLE_DEVICES=','--env','PYTHONDONTWRITEBYTECODE=1','--env','PYTHONNOUSERSITE=1','--env','HF_HUB_OFFLINE=1','--env','TRANSFORMERS_OFFLINE=1','--env','OMP_NUM_THREADS=1','--env','OPENBLAS_NUM_THREADS=1','--env','LD_LIBRARY_PATH='+ld,str(SIF),str(ENV/'bin/python'),'-B','-c',inspect_code]
p=subprocess.run(args,capture_output=True,text=True,timeout=100)
x={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'hostname':socket.gethostname(),'user':'s20223010065','source_arrays':arrays,'native_files_metadata':native,'native_lock':meta(lockpath,'49e8719821c42f359ebbe489879c1094858ffebbd57f83dd557b58c6a04eea38',True),'runtime_paths':[meta(z) for z in (ENV,BASE,SIF,SING)],'library_command':args,'library_returncode':p.returncode,'library_stdout':p.stdout,'library_stderr':p.stderr,'remote_file_writes_requested':0,'model_load_or_forward_calls':0,'GPU_allocation':0,'sbatch':0,'functional_values_read':False}
if p.returncode==0:
 x['import_lock']=json.loads(p.stdout);x['status']='READONLY_IMPORT_IDENTITIES_AND_ARRAY_METADATA_INSPECTED'
else:x['status']='IMPORT_INSPECTION_FAILED_NO_RETRY'
print(json.dumps(x))
'''
intent=D/'LOCAL_RUNTIME_IDENTITY_INSPECTION_INTENT.json'
with intent.open('x') as f:json.dump({'release_sha256':hashlib.sha256(rp.read_bytes()).hexdigest(),'max_connections':1,'prior_history_search':'No historical complete module-file import lock found in existing R02 relevant artifacts; actual four-file identities missing.'},f)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');p=subprocess.run(SSH+[PYTHON],input=('PLAN='+repr(payload)+'\n'+code).encode(),capture_output=True,timeout=180);(D/(stamp+'_IDENTITY.stdout')).write_bytes(p.stdout);(D/(stamp+'_IDENTITY.stderr')).write_bytes(p.stderr)
assert p.returncode==0,p.stderr.decode(errors='replace')[-1800:];x=json.loads(p.stdout);out=D/'ACTUAL_RUNTIME_IDENTITY_INSPECTION.json';assert not out.exists();out.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
if 'import_lock' in x:(D/'ACTUAL_IMPORT_LOCK.json').write_text(json.dumps(x['import_lock'],indent=2)+'\n',encoding='utf-8')
print(json.dumps({'receipt':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'status':x['status'],'library_returncode':x['library_returncode'],'import_lock':x.get('import_lock'),'source_arrays_verified':len(x['source_arrays']),'native_files_metadata':len(x['native_files_metadata']),'new_GPU_or_sbatch':0},indent=2))
