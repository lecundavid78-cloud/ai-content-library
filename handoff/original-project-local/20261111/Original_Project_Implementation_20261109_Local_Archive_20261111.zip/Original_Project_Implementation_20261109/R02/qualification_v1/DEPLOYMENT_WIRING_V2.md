# 确切最小CPU载荷接线 v2

实际包：CPU_QUALIFICATION_PAYLOAD_STAGED_V2.zip，内有三来源21个允许文件、36个R05 Python代码快照及control动作清单、路径重定位JOB草案/模型锁。包内没有功能数值TSV、完整2000批pair流、模型权重；权重只列原有只读绑定候选。没有SSH、上传或sbatch。

## 已解决并实际检查

R01 READY/PAYLOAD_ALLOWLIST全部21个文件SHA核对通过。三个ADMITTED_SOURCE wrapper的原始角色保留；三份原天然doc仍SOURCE_POOL。使用R05原role_bridge的纯consume函数（仅本地路径适配，无模型import）逐来源通过：bank594、两步、每步各128有向pairs、WT/父流slice/split/原numeric准入hash吻合，heldout位点不在支持内。每来源512有向pair出现。并非新生成pairs。

天然doc/数组、原numeric/index/derived admission/pair slice均原字节复制；wrapper和MATERIAL_LOCK只替换文件引用为/inputs位置并更新相应引用hash，角色/数值/顺序/父流hash不变，详PAYLOAD_RELOCATION_RECEIPT_V2.json。天然npz相对文件名沿用原doc，不改概率或mask。原记录中未被消费者打开的历史功能表路径只是元信息，不复制或挂载其指向文件。

## 两动作明确分开

- preflight：/code/runtime_cli.py preflight --job /control/JOB.json --report /out/ALL_FILE_PREFLIGHT.json。原入口只做全文件/角色/自然输入/原native文件hash核对，不加载权重；actual imports身份仍不得声称已运行通过。
- execute：/code/runtime_cli.py execute --job /control/JOB.json --release /control/R05_ROOT_RELEASE.json。这会真实CPU加载六native模型、构造h11、验证梯度/更新/保存恢复/导出，是单独许可事项。外层CPU_ACTION_RELEASE须显式native_load_forward_allowed=true，内层R05资格release须stagequalify/devicecpu/max_updates2，绝不能用preflight放行偷换execute。

实际cpu_qualification_v2.sbatch和cpu_action_launcher.py已写好；无--nv/GPU、2CPU16GB30min、外层1740/入口1680、无提前TERM。wrapper/root/action/hash都必须显式。旧无模型launcher单独保留、不当新版使用。真实native CPU负荷的内存/时长尚未测得，必须由R05与根确认最小可行工作量，不能凭Bash检查宣称16GB足够。

## 当前包的确切未完成依赖

只剩R05不可变READY/code manifest与实际import lock（torch/numpy/transformers/dynamic-module-utils的Linux绝对路径和SHA/版本），以及根的确切CPU动作release。JOB_NOT_READY的importSHA为null，故主动不可执行；没有伪造服务器import hash。R05正在编辑的runtime快照已经固定包SHA，最终READY若字节不同需新版本重打包，不覆盖本候选。

根选定action并验真实code/import后，生成control/JOB.json、EXECUTABLE_FILE_SHA256.json和CPU_ACTION_RELEASE；execute再需R05_ROOT_RELEASE。最终zip、脚本、实际输入、导入路径、环境候选值、远端root全部锁定后才提交。唯一local/remote intent、原endpoint/known_hosts、真实sbatchID及含糊先对账规则沿用SUBMISSION_INTENT_TEMPLATE；本阶段无任何训练release。

## 工作量记账

逻辑恢复深度2与真实计算更新次数分开。现R05快照qualification为first暂停1后second恢复到2，梯度update hook应共2次；另有无更新的新scorerrestore/RAW复核。若后续补连续2步参考，必须按2+1+1=4真实更新/单source架构计账，而不能写逻辑深度2便称只算2。最终以R05不可变版本实际operation ledger为准，尚未执行，当前实际模型/optimizer更新均0。

已执行的本地检查：21允许文件SHA、三桥接纯逻辑/两步pair/支持隔离、全部代码AST、Bash -n、ZIP逐成员SHA。无真模型CPU/服务器资格结论。原数据/角色和他人代码均未修改。
