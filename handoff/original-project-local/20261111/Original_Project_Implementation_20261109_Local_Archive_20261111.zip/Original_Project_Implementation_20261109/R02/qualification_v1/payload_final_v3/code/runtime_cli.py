"""Only R02 exact-release Slurm model entry; local preflight performs no model calls."""
import argparse
import os
from pathlib import Path
import signal
import time
import traceback
from production_loop import original_kernels,file_sha,write_new
from single_source import need


def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=('preflight','execute'));p.add_argument('--job',required=True)
    p.add_argument('--release');p.add_argument('--report');a=p.parse_args();root=Path(__file__).resolve().parent
    # Load only pinned original function definitions, not native weights.
    original_kernels(root/'legacy_v2')
    from runtime_contract import preflight,actual_imports,authorize,read,bound
    job,imp,checked=preflight(a.job,root)
    if a.action=='preflight':
        need(a.report is not None,'explicit preflight report file')
        write_new(a.report,{'status':'ALL_FILE_PREFLIGHT_PASS_NO_MODEL','job_sha256':file_sha(a.job),'case_count':len(checked),
            'actual_import_checked':False,'model_calls':0,'not_execution_release':True});return
    need(a.release is not None,'exact release file required')
    r=authorize(a.job,a.release,job)
    if job['device']=='cpu':
        import torch
        need(not torch.cuda.is_initialized(),'CPU qualification must not inherit initialized CUDA')
        os.environ['CUDA_VISIBLE_DEVICES']='' # Original engine.sync must never synchronize an incidental visible GPU.
    # All inputs and purpose gate pass before model construction.
    actual_imports(imp)
    out=Path(job['output']);out.mkdir(parents=True)
    started=time.perf_counter();record={'status':'RUNNING','job_sha256':file_sha(a.job),'release_sha256':file_sha(a.release),
        'stage':job['stage'],'purpose':job['purpose'],'device':job['device'],'actual_native_loads':0}
    def timeout(*_):raise TimeoutError('finite runtime wall exhausted')
    if hasattr(signal,'SIGALRM'):signal.signal(signal.SIGALRM,timeout);signal.alarm(r['wall_seconds'])
    try:
        os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HOME=str(out/'hf_local'),HF_MODULES_CACHE=str(out/'hf_modules'))
        import torch
        torch.set_num_threads(int(os.environ.get('SLURM_CPUS_PER_TASK','1')));torch.manual_seed(11)
        torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cudnn.benchmark=False
        torch.use_deterministic_algorithms(True)
        if job['device']=='cuda':need(torch.cuda.is_available() and torch.cuda.device_count()==1,'exact one allocated CUDA GPU')
        from native_loader import load_members
        models,tokens,members,quantizers,loads=load_members(bound(job['native_lock']),job['device'])
        record['actual_native_loads']=1;write_new(out/'NATIVE_LOAD.json',loads)
        from native_runtime import Factory,fresh_init,qualification
        factory=Factory(models,members)
        if job['stage']=='qualify':qualification(job,imp,checked,models,tokens,members,quantizers,out)
        elif job['stage']=='init':
            c=checked[0];init=out/'INIT.pt';h=fresh_init(factory,c['architecture'],c['seed'],job['native_lock']['sha256'],init)
            write_new(out/'INIT_RECEIPT.json',{'status':'CLEAN_NATIVE_INIT_ONLY','sha256':h,'architecture':c['architecture'],'seed':c['seed'],'trained_checkpoint_loaded':False});factory.clean()
        else:
            c,config,schedule=checked[0]
            from pilot.storage import load_bundle
            b=load_bundle(bound(c['bundle']),job['device'])
            if job['stage']=='train':
                from production_loop import train
                from pilot.engine import update
                train(config,schedule,bound(c['init']),{c['source_id']:b},out/'train',scorer_factory=factory,update_fn=update,
                    resume_path=bound(c['checkpoint']) if c['checkpoint'] else None,prior_attempts=c['prior_attempts'])
            else:
                from production_loop import predict_node
                from pilot.engine import export_prediction
                predict_node(config,schedule,bound(c['checkpoint']),b,out/'predict',scorer_factory=factory,export_fn=export_prediction)
            factory.clean()
        record['status']='COMPLETE_UNEVALUATED'
    except BaseException as exc:
        record.update(status='TECHNICAL_FAILURE_NO_RETRY',error_type=type(exc).__name__,error=str(exc))
        (out/'FAILURE.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
    finally:
        if hasattr(signal,'SIGALRM'):signal.alarm(0)
        record['elapsed_seconds']=time.perf_counter()-started;write_new(out/'RUNTIME_RECEIPT.json',record)


if __name__=='__main__':main()
