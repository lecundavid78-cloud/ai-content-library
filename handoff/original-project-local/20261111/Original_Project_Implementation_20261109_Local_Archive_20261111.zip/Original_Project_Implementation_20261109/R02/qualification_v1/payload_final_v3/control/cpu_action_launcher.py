"""Exact outer CPU action gate; preflight never implies native execute permission."""
from pathlib import Path
import json,hashlib,sys,subprocess,os

def require(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def main():
 c=Path('/control');r=read(c/'CPU_ACTION_RELEASE.json')
 require(r['schema']=='R02_EXACT_CPU_ACTION_RELEASE_V2' and r['status']=='RELEASED' and r['controller']=='01a1c09c-f9e6-70f1-b9e8-b988b89c755f','exact current CPU action release absent')
 require(r['GPU_count']==0 and r['CPU']==8 and r['memory_GiB']==64 and r['wall_seconds']==1800,'resource scope')
 require(r['training'] is False and r['functional_labels'] is False,'training/labels forbidden')
 require(r['action'] in ('preflight','execute'),'unknown CPU action')
 require(r['native_load_forward_allowed']==(r['action']=='execute'),'preflight and native qualification permissions cannot be conflated')
 require(os.environ.get('CUDA_VISIBLE_DEVICES')=='' and os.environ.get('SLURM_JOB_ID','').isdigit(),'CPU Slurm allocation required')
 require(r['launcher_sha256']==sha(__file__) and r['job_sha256']==sha(c/'JOB.json') and r['manifest_sha256']==sha(c/'EXECUTABLE_FILE_SHA256.json'),'outer identities')
 m=read(c/'EXECUTABLE_FILE_SHA256.json')
 for f in m['files']:
  p=Path(f['path']).resolve();require(any(p.is_relative_to(Path(root)) for root in ('/code','/inputs','/control')) and p.is_file() and sha(p)==f['sha256'],'exact mounted payload identity')
 job=read(c/'JOB.json');require(job['device']=='cpu' and job['stage']=='qualify' and job['purpose']=='QUALIFICATION_ONLY_MAX2','CPU qualification job only')
 require(not Path(job['output']).exists(),'fresh output needed')
 argv=[sys.executable,'-B','/code/runtime_cli.py',r['action'],'--job','/control/JOB.json']
 if r['action']=='preflight':argv+=['--report','/out/ALL_FILE_PREFLIGHT.json']
 else:
  require(r['R05_release_sha256']==sha(c/'R05_ROOT_RELEASE.json'),'exact native qualification release')
  argv+=['--release','/control/R05_ROOT_RELEASE.json']
 out=Path('/out');out.mkdir(exist_ok=True)
 with (out/'CPU_ACTION.stdout').open('wb') as stdout,(out/'CPU_ACTION.stderr').open('wb') as stderr:p=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=1680)
 (out/'CPU_ACTION_RECEIPT.json').write_text(json.dumps({'status':'ACTION_EXITED_REQUIRES_OUTPUT_ACCEPTANCE','returncode':p.returncode,'argv':argv,'outer_release_sha256':sha(c/'CPU_ACTION_RELEASE.json'),'native_permission':r['native_load_forward_allowed'],'GPU':0,'new_training_admission':False},indent=2)+'\n',encoding='utf-8')
 require(p.returncode==0,'CPU action failed; no retry')
if __name__=='__main__':main()
