"""Explicit device wiring around unchanged native capture, Scorer, FullVRH and export."""
from pathlib import Path
import time
import torch
from production_loop import file_sha,write_new
from single_source import need


def prepare(models,tokens,members,quantizers,doc,natural,codes,device,native_sha,admission=None):
    from pilot.provider import capture_member
    from r05_internal.reference.contracts import REQUIRED_K,MemberField
    from r05_internal.reference.vrh import FullVRH
    role=doc['role']
    if admission is not None:
        # Re-consume explicit wrapper; do not accept a generic boolean/source-promotion flag.
        from role_bridge import consume
        w,original,_,_,_=consume(admission['wrapper'],admission['record'])
        need(original==doc and w['source_id']==doc['asset_id'],'new bundle admission differs from original natural')
        role='SOURCE'


    fields=[];caches={};h12={};vectors={};t=time.perf_counter()
    for k in REQUIRED_K:
        need(doc['quantizer_sha256_by_k'][str(k)]==quantizers[k],'native quantizer changed')
        c,h,logits=capture_member(models[k],tokens[k],members[k],natural,codes[k],doc['structure_asset_sha256'],device=device)
        caches[k]=c;h12[k]=h;fields.append(MemberField(members[k],logits))
        pooled=h[0].index_select(0,c.canonical_index).mean(0);need(torch.isfinite(pooled).all().item() and pooled.norm()>0,'original pool finite')
        vectors[k]=(pooled/pooled.norm()).detach().cpu()
    result=FullVRH().score_all19l(fields,natural,statistics_gradient='full',normalization_universe='complete19L')
    provenance={'reference_kind':'fresh_full_original_forward','asset_id':doc['asset_id'],
        'natural_input_sha256':__import__('r05_internal.reference.contracts',fromlist=['natural_sha256']).natural_sha256(natural),
        'structure_asset_sha256':doc['structure_asset_sha256'],'native_lock_sha256':native_sha,'prepare_seconds':time.perf_counter()-t}
    if admission is not None:
        provenance.update(original_natural_role=doc['role'],qualification_wrapper_sha256=admission['wrapper']['sha256'],
            role_basis='explicit controller ADMITTED_SOURCE wrapper; original natural bytes unchanged')
    return {'members':members,'caches':caches,'h12':h12,'natural':natural,'original_fields':tuple(fields),
        'original_all19l':result.score_all19l.detach(),'vectors':vectors,'asset_role':role,
        'provenance':provenance}


class Factory:
    def __init__(self,models,members):self.models=models;self.members=members;self.current=None;self.score_calls=0;self.instances=0
    def clean(self):
        from pilot.scorer import uninstall_lora
        if self.current is not None:
            self.current.verify_frozen()
            if self.current.architecture=='L':uninstall_lora(self.models)
            if 'score' in self.current.__dict__:del self.current.score
            self.current=None
    def __call__(self,architecture,seed):
        from pilot.scorer import Scorer
        self.clean();self.current=Scorer(self.models,self.members,architecture,seed)
        self.instances+=1
        original_score=self.current.score
        def counted_score(*args,**kwargs):
            self.score_calls+=1;return original_score(*args,**kwargs)
        self.current.score=counted_score
        return self.current


def fresh_init(factory,architecture,seed,native_sha,path):
    scorer=factory(architecture,seed);scorer.verify_frozen()
    state={'schema':'SINGLE_SOURCE_INIT_V1','architecture':architecture,'seed':seed,'native_sha256':native_sha,
        'frozen_sha256':scorer.base_hash,'parameters':{n:p.detach().cpu().clone() for n,p in scorer.params.items()}}
    # Generated solely from clean original base, never any old trained checkpoint.
    need(not Path(path).exists(),'fresh initial state file')
    with Path(path).open('xb') as f:torch.save(state,f)
    return file_sha(path)


def qualification(job,imp,checked,models,tokens,members,quantizers,out):
    from runtime_contract import qualification_config
    from pilot.storage import dump_bundle
    from pilot.scorer import frozen_digest
    from pilot.engine import update,export_prediction
    from production_loop import train
    from resume_state import load,restore
    from production_loop import optimizer_for
    from long_sequence import full_span_evidence
    import inspect
    need(Path(inspect.getfile(full_span_evidence)).resolve()==Path(__file__).parent/'legacy_v2/long_sequence.py','span helper import shadow')
    baseline=frozen_digest(models);summaries=[]
    for c,doc,natural,codes,a,schedule in checked:
        case_out=out/c['source_id'];case_out.mkdir()
        bundle=prepare(models,tokens,members,quantizers,doc,natural,codes,job['device'],job['native_lock']['sha256'],
            {'wrapper':c['material'],'record':c['material_record']})
        # Span helper records actual config/full h11/masks/partial-MSA rows.
        write_new(case_out/'FULL_SPAN.json',full_span_evidence(models,bundle))
        dump_bundle(case_out/'SOURCE.pt',bundle);bundle_sha=file_sha(case_out/'SOURCE.pt')
        factory=Factory(models,members)
        for arch in ('S','L'):
            started=time.perf_counter();score_start=factory.score_calls;instance_start=factory.instances
            arch_out=case_out/arch;arch_out.mkdir();init=arch_out/'INIT.pt'
            init_sha=fresh_init(factory,arch,11,job['native_lock']['sha256'],init)
            config=qualification_config(job,imp,c,doc,a,arch,init_sha,bundle_sha)
            write_new(arch_out/'CONFIG.json',config);write_new(arch_out/'SCHEDULE.json',schedule)
            # Verify exact original zero-increment raw and full19L, no source update yet.
            with torch.no_grad():zero_fields,zero=factory.current.score(bundle)
            for f,g in zip(zero_fields,bundle['original_fields']):
                need(torch.allclose(f.logits25,g.logits25,atol=2e-5,rtol=2e-4),'zero raw mismatch')
            need(torch.allclose(zero.score_all19l,bundle['original_all19l'],atol=2e-5,rtol=2e-4),'zero VRH mismatch')
            gradient_evidence=[]
            def checked_update(scorer,b,cross,within,optimizer):
                captures={};hooks=[]
                def hook_for(k):
                    def hook(module,args):
                        need(args[0].requires_grad,'original head lost input autograd');args[0].retain_grad();captures[k]=args[0]
                    return hook
                for k,m in models.items():hooks.append(m.cls.register_forward_pre_hook(hook_for(k)))
                try:rec=update(scorer,b,cross,within,optimizer)
                finally:
                    for h in hooks:h.remove()
                norms={str(k):float(h.grad.norm()) if h.grad is not None else 0. for k,h in captures.items()}
                need(len(norms)==6 and all(x>0 for x in norms.values()),'six head input gradients required')
                for n,v in rec['gradient_norms'].items():
                    active=(len(gradient_evidence)>0 or (arch=='L' and n.endswith('.B')) or (arch=='S' and n.startswith('up.')))
                    if arch=='S' and n=='context.0.weight' and not natural.context().any():active=False
                    if active:need(v>0,'active adapter branch gradient zero: '+n)
                gradient_evidence.append({'head_input_gradient_norms':norms,'parameter_gradient_norms':rec['gradient_norms']})
                return rec
            train(config,schedule,init,{c['source_id']:bundle},arch_out/'first',scorer_factory=factory,update_fn=checked_update,pause_after=1)
            with torch.no_grad():before_fields,before=factory.current.score(bundle)
            # A new adapter instance restores moments/RNG/cursor, with no extra optimizer update.
            resumed=factory(arch,11);opt=optimizer_for(resumed,config);opt.zero_grad(set_to_none=True)
            restore(load(arch_out/'first/STEP_1.pt'),config,schedule,resumed.params,opt,frozen_sha256=resumed.base_hash)
            with torch.no_grad():after_fields,after=resumed.score(bundle)
            need(torch.equal(before.score_all19l,after.score_all19l),'new instance complete resume score mismatch')
            for f,g in zip(before_fields,after_fields):need(torch.equal(f.logits25,g.logits25),'new instance raw reload mismatch')
            receipt=train(config,schedule,init,{c['source_id']:bundle},arch_out/'second',scorer_factory=factory,update_fn=checked_update,
                resume_path=arch_out/'first/STEP_1.pt',prior_attempts=1)
            need(receipt['completed_updates']==2 and len(gradient_evidence)==2,'qualification exactly2 actual updates')
            with torch.no_grad():fields,result=factory.current.score(bundle)
            need(not torch.equal(result.score_all19l,zero.score_all19l),'qualification produced no score change')
            raw_out=arch_out/'RAW_SOURCE_QUALIFICATION';raw_out.mkdir()
            export_prediction(raw_out,bundle,fields,result,{'qualification_only':True,'steps_completed':2,'active_adaptation':True,'seed':11,'architecture':arch})
            need(result.score_all19l.numel()==19*len(natural.wt_sequence),'full19L export span')
            factory.current.verify_frozen();factory.clean()
            need(frozen_digest(models)==baseline,'base changed across qualification cells')
            record={'status':'REAL_SOURCE_ARCH_QUALIFICATION_PASS_NOT_TRAINING_ADMISSION','source_id':c['source_id'],'architecture':arch,
                'actual_updates':2,'training_id':receipt['training_id'],'gradients':gradient_evidence,'resume_new_instance_exact':True,
                'frozen_bytes_unchanged':True,'raw_export_sha256':file_sha(raw_out/'RAW.npz'),'checkpoint_sha256':file_sha(arch_out/'second/STEP_2.pt'),
                'elapsed_seconds':time.perf_counter()-started,'actual_scorer_calls':factory.score_calls-score_start,
                'actual_member_head_calls':6*(factory.score_calls-score_start),'actual_new_scorer_instances':factory.instances-instance_start,
                'new_instance_restore_validation_extra_scorer_calls':2}
            write_new(arch_out/'QUALIFICATION.json',record);summaries.append(record)
            del resumed,opt,zero_fields,zero,before_fields,before,after_fields,after,fields,result
        del bundle
        import gc
        gc.collect()
        if job['device']=='cuda':torch.cuda.empty_cache()
    write_new(out/'QUALIFICATION_SUMMARY.json',{'status':'THREE_SOURCE_SIX_CELL_PASS_NOT_FORMAL_TRAINING','cells':summaries,'updates_per_cell':2,
        'actual_native_prefix_full_forwards':18,'actual_total_optimizer_updates':sum(x['actual_updates'] for x in summaries),
        'extra_validation_forwards_disclosed':True,'formal2000_training':False})
