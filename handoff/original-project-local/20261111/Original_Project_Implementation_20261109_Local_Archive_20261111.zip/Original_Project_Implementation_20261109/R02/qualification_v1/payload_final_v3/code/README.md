# runtime_v1：可提交资格的真实入口代码包

**代码READY；不是资格通过或提交release。** 本包完成单来源真实CLI、严格文件预检、显式CPU/CUDA native构造、三来源六格资格控制与任意预锁节点推理。实际模型仍未加载；R02需填本机native/import/output绝对路径并由新总控签确切JOB，才可唯一sbatch。无自动重试、无隐式角色提升、无目标/源heldout值。

## 精确入口

在解包根运行（不是含父R05目录的开发根）：

```bash
python -B runtime_cli.py preflight --job /job/JOB.json --report /out/INPUT_PREFLIGHT.json
python -B runtime_cli.py execute --job /job/JOB.json --release /job/ROOT_RELEASE.json
```

preflight不构造模型：检查全部Python文件SHA、原六native文件清单、实际import锁所列文件、三来源全部wrapper/父元信息/天然数组/量化码身份及pair端点/heldout隔离。三份输入全部通过才返回。execute另要求SLURM_JOB_ID、新总控exact release、显式device、wall<=1800及max_updates_per_case；在构造模型前核实际torch/numpy/transformers版本与模块__file__路径/SHA。未release、旧总控release、旧双源格式、缺字段或错导入立即停止。外层Slurm硬wall应覆盖预检/包核验/失败导出开销，Python alarm从执行段开始。

## 原科学文件与实际导入

legacy_v2包含原manifest列明的全部Python副本，逐字节核对；没有权重。production_loop.original_kernels仍锁原manifest SHA4b0afe0a…及所有已加载pilot/r05_internal模块来源，不只查engine。native_loader.py只复制原load_members函数，加device参数并把model.cuda()换为model.to(device)，详NATIVE_LOADER_MINIMAL.diff；原权重/源码/config/vocab/head/hash/loading_info/FP32检查都保留。不改Transformer/head/Scorer/FullVRH数学。原prepare_input的CUDA硬编码不能用于CPU，因此native_runtime.prepare只接显式device，复用原capture_member、MemberField及FullVRH；原向量计算无新公式。

IMPORT_LOCK.json精确字段：torch_version、transformers_version、numpy_version、python_version、files；files恰含torch、numpy、transformers、transformers.dynamic_module_utils，每项{path,sha256}来自R02实际解释器inspect.getfile，不凭dist metadata猜测。前三级版本必须与原native lock一致；actual_imports再核真正已import模块。原动态模型与config代码还由原loader检查实际源码SHA。QUALIFICATION_JOB_NOT_RELEASED.json的runtime_code_sha256已列本包全部py，模型锁和import锁仍是显式待R02绑定项，不是可执行release。

## 真实R01材料接线

资格JOB的cases恰三项{source_id,material:{path,sha256}}，source分别RCRO_LAMBD_Tsuboyama_2023_1ORC、CAS9_STRP1_Spencer_2017_positive、HSP82_YEAST_Flynn_2019；material_lock绑定R01 qualification_material_v1/READY.json。消费者已实际读这三份wrapper、派生admission、small594索引、2行slice和原天然数组，通过记录见ACTUAL_MATERIAL_COMPATIBILITY.json，未加载模型。

role_bridge.consume按新总控QUALIFICATION_SOURCE_ROLE_CONTRACT：原天然doc必须SOURCE_POOL或SOURCE、functional_labels_included=false，TARGET永拒；必须显式ADMITTED_SOURCE wrapper且原numeric admission/WT/length/split/bank/hash一致。两行slice是**实际列表**，无虚构schema嵌套；严格step0/1、source和128+128端点；父2000流hash、slice_steps及slice文件SHA由wrapper与被JOB锁定的R01 READY交叉核对。真正parent[:2]相等性由R01/root原始材料审核提供，资格进程不挂载或打开完整parent流、train TSV或heldout目录。

新资格bundle由该明确准入创建，asset_role=SOURCE，同时provenance永久保留original_natural_role、qualification_wrapper_sha256和role_basis；原天然doc字节/role不改。无wrapper时SOURCE_POOL绝不自动提升。正式train/predict仍硬验实际bundle的SOURCE/TARGET角色，不从资格桥自动扩大到正式训练准入。

搬到学校服务器时F:/引用不能直接运行。R02须制作**纯路径重绑定副本**（wrapper、READY、JOB及自然JSON中的数组引用），重新核叶文件/数组字节不变，记录前后映射/hash并让根验收最终JOB；不能将未验证路径字符串替换当完成。import/native路径同理绑定原学校实际文件。预检禁止相对/不存在的绑定，也不下载缺权重。

## 资格计算上限与完整恢复

stage=qualify，purpose=QUALIFICATION_ONLY_MAX2，seed11/lr1e-4，三个small594来源×S/L，配置steps2、checkpoints[1,2]、两类各128。资格runtime身份含专用purpose及真实wrapper/code/import/init/bundle，绝不能当正式2000轨迹、不能从step2接成正式2000。

六模型只加载一次。每来源：原完整WT前向制六成员h11/h12/AA25/full19L，记录实际mask/relative/config/MSA跨度并保存portable SOURCE.pt。每架构：从干净原Scorer构造SINGLE_SOURCE_INIT_V1（从不加载旧训练权重）；零增量raw/head/VRH相符；执行第1步并原子完整保存；新Scorer实例恢复参数/AdamW/RNG/游标，恢复前后RAW及19L逐值相等；再新实例从step1继续第2步，至此每格**总共2个真实源更新**。不额外跑一个连续2步基准（上阶段toy已验）。两次原head输入梯度、首步输出分支/第二步活跃参数梯度、原冻结byte、分数变化和RAW完整导出都需通过。

12次optimizer update总上限；完整WT native prefix共18成员前向。恢复一致性还需要额外no_grad scorer评估，不能从账单扣掉。每格记录actual_scorer_calls、6成员head调用量、新实例数、额外恢复评估2次及耗时；S评估使用cached h12+adapter/head，L才重放末块。最终完整RAW_SOURCE_QUALIFICATION仅源预测分数、无功能值，不评价指标。失败只保留实际文件/FAILURE及RUNTIME_RECEIPT，停止后续格，不称六格PASS；SIGKILL由Slurm对账，不能推断完成。

## CPU规格及单卡备选（均待根release）

首选资格规格候选：一个CPU Slurm allocation、8 CPU、64GiB RAM、1800秒hard wall、单进程六模型一次加载；无GPU、无付费、只上述三来源六格。尚无本机CPU全长步时，不能保证30分钟内完成或外推历史GPU时长。若R02依据本校硬件/实际观测预计超1800秒，应停在已成功格并给根计时；**不自动换卡/重投**。供根裁决的备选为同一完全相同JOB语义device=cuda、恰1张既有卡、8CPU/64GiB、上限1200 GPU allocated秒、串行一次加载/12更新，重签device/job SHA/release；不是本包批准提交或扩GPU配额。原失败attempt/预检/hash/加载/导出/恢复forward开销全计。

## 正式入口已接，当前不放行

stage=init：单case {source_id,architecture,seed11}，从干净Scorer构造新init，绑定native，零训练。stage=train/predict：单case精确含source_id/admission/config/schedule/init/bundle/checkpoint/prior_attempts；其中config/schedule/init/bundle/checkpoint均文件绑定，admission为R01 TRAINONLY_ADMISSION。formal config必须当前CONTINUATION_02的2000、lr1e-4、seed11、nodes500/1000/2000、每类128，small594/full_train实际index/heldout/流SHA贯通；不得用资格身份或旧adapter-only文件。推理选checkpoint实际completed节点，原export输出RAW AA25/完整19L；Original保持原独立精确复用。此CLI具备接线，但未获本任务的正式训练/模型运行授权。

## 验证层级

TEST_EXECUTION.json为7项新检查：真实三wrapper消费、无wrapper/TARGET/错WT/父流不符拒绝；原loader仅device变更及所有legacy字节相同；小CPU toy在新pause/resume路径仅2次更新。STATIC_CHECKS确认全部py AST。未重复旧16项宽套件。这里“完整包/代码READY”仅供R02绑定和根签资格，不表示CPU/GPU/真实模型资格通过；精确动态import路径、native文件可见性、校内fsync/hardlink、真实S/LoRA梯度/RAW和资源占用仍待唯一sbatch实证。
