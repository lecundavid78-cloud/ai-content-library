# CPU资格部署候选 v1

已给出实际CPU sbatch和fail-closed launcher，尚未生成可提交包：R05真实CPU入口/argv与R01新train-only bank/pair文件均未READY，不能拿旧250批或toy测试冒充这次完整资格。

资源建议：单节点2CPU、16GB、30分钟、0GPU；外层1740秒，入口1680秒。本轮仅本地准备，不SSH/上传/sbatch、不训练。实际CPU检查用小模型恢复和线性校验pair/支持，禁止平方级pairs。若R05的CPU脚本要求本地反复加载六原生模型，本CPU协议应拒绝而非扩大内存/GPU。

## 已有文件如何接线

- cpu_qualification.sbatch：无GPU申请、无--nv、无提前TERM预告。2CPU16GB30min明确。CPU环境通过精确获准的R02_RUN_ROOT/RUNTIME_ENV/BASE_ENV/SIF/SINGULARITY传入；缺任一参数立即停止。它调用/control/cpu_gate_launcher.py。
- cpu_gate_launcher.py：只stdlib，实际bindings与自身SHA必须匹配RELEASED根回执；拒NOT_READY、错误控制人/预算/模型/标签权限、空入口/输入/输出。入口只能在/code，全部code和inputs逐hash/role核验；随后以R05明确argv执行其CPU入口。不猜R05尚不存在的CLI。输出保留stdout/stderr及CPU_LAUNCH_RECEIPT，不称真实模型通过。
- BINDINGS_NOT_READY.json、MOUNT_PLAN_NOT_READY.json：当前缺项按null/空清单记录，不生成伪造hash。CPU可以消费获准SOURCE train-only材料，禁止目标、source-heldout、原功能表、权重或其他项目目录挂载。
- PAYLOAD_CANDIDATE_MANIFEST.json：实际本地候选文件、上游schema/status快照及冻结payload需要的布局。所有上游快照只读，R05/R01后续变化须重新绑定，当前hash不是声称它们已经就绪。
- SUBMISSION_INTENT_TEMPLATE.json：不是受理证据。未来精确唯一任务名/root、release/package/脚本/实际import hash全部冻结后，先查本意图/同名任务历史，不干扰其他工作。唯一local+remote intent先于sbatch；解析真实ID，含糊则停止只读对账，不拆分/换人/盲重投。

## 后续根放行前必须完成

1. 收到R05 READY CPU入口/代码/argv/output合同与R01六个来源bank组合（3来源×small594/full_train）的train-only支持/pairs身份；原3来源元信息可复用，但旧250batches不是新2000日程。
2. 按真实schema填写容器路径和完整文件SHA清单，确认无额外源/目标/留出labels、无weights，固定外部历史科学模块实际import清单。
3. 新独立remote root/准确任务名及existing CPU Singularity/Python路径/hash由根验收；runtime当前可用性本轮未远端核。优先复用历史可用torch环境，不安装/下载。
4. 将所有binds解析为确切路径，固定sbatch需要的6个runtime环境值、代码和payload SHA，再生成zip与不可变manifest。根签唯一CPU资格release后，原R02才可短SSH对账/上传/单次sbatch；现在没有训练release。
5. 资格输出只能给CPU工程验收：schema/direction/训练支持隔离/日程/初始化拒旧/full optimizer+RNG+cursor连续对照/恢复守卫；不声称真ProSST/CUDA/h11/fullWT forward通过。CPU后真模型资格另需精确资源和release。

当前脚本是可执行但主动拒绝缺绑定的部署候选，未部署未运行真实R05入口。所有新增文件仅此R02目录，不改历史或其他角色。凭据不会进入载荷。
