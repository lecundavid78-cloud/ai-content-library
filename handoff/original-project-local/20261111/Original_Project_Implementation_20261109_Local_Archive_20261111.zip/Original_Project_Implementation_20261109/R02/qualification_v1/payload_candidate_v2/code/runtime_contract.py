"""All-file preflight and exact stage authorization, before any native model construction."""
import json
from pathlib import Path
from production_loop import file_sha
from single_source import need,keys,digest,validate

CONTROLLER='01a1c09c-f9e6-70f1-b9e8-b988b89c755f'
SOURCES={'RCRO_LAMBD_Tsuboyama_2023_1ORC','CAS9_STRP1_Spencer_2017_positive','HSP82_YEAST_Flynn_2019'}


def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def bound(spec):
    keys(spec,('path','sha256'));p=Path(spec['path'])
    need(p.is_absolute() and p.is_file() and file_sha(p)==spec['sha256'],'exact absolute file binding: '+str(p))
    return p


def runtime_identity(lock):
    return digest(lock)


def r01_admission(path,source_id,schedule_spec):
    """Consume R01's real train-only manifest/index, never parse bank score columns."""
    d=read(path)
    need(d['source_id']==source_id and d['role']=='SOURCE_TRAIN_ONLY' and d['bank_rule'] in ('small594','full_train')
        and d['seed']==11 and d['steps']==2000 and d['pairs_each_class_per_step']==128 and d['same_bank_and_stream_for_S_and_LoRA'] is True,'R01 train-only admission')
    ref=lambda r:{'path':r['path'],'sha256':r['sha256']}
    index=read(bound(ref(d['index'])))
    bound(ref(d['bank'])) # File integrity only, no functional value parsing.
    need(schedule_spec==ref(d['pairs']),'exact R01 locked pair stream')
    need(index['source_id']==source_id and index['bank_rule']==d['bank_rule'] and index['count']==d['count']==len(index['bank_indices']),'R01 bank index identity/count')
    return {'role':'SOURCE','wt_sha256':index['wt_sha256'],'training_indices':index['bank_indices'],
        'heldout_positions':index['heldout_positions'],'admission_sha256':file_sha(path)}


def preflight(job_path,code_root):
    job=read(job_path)
    keys(job,('schema','stage','purpose','device','output','native_lock','import_lock','material_lock','cases','runtime_code_sha256'))
    need(job['schema']=='SINGLE_SOURCE_RUNTIME_JOB_V1' and job['stage'] in ('qualify','init','train','predict'),'explicit runtime stage')
    need(job['device'] in ('cpu','cuda'),'explicit device')
    need(job['purpose']==('QUALIFICATION_ONLY_MAX2' if job['stage']=='qualify' else 'EXACT_SINGLE_SOURCE_'+job['stage'].upper()),'stage purpose namespace')
    root=Path(code_root).resolve()
    actual={p.relative_to(root).as_posix() for p in root.rglob('*.py')}
    need(set(job['runtime_code_sha256'])==actual,'bind every actual Python file, including legacy copy')
    for n,h in job['runtime_code_sha256'].items():need(file_sha(root/n)==h,'runtime Python bytes changed: '+n)
    import sys
    for name in ('single_source','resume_state','production_loop','runtime_contract','runtime_cli','native_loader','native_runtime'):
        module=sys.modules.get(name)
        if module is not None:
            need(Path(module.__file__).resolve()==root/(name+'.py'),'runtime module shadow: '+name)
    native=bound(job['native_lock']);lock=read(native)
    # Check the complete original native inventory before loading any model.
    need(lock['schema']=='FOURCELL_NATIVE_MEMBERS_V1' and len(lock['members'])==6 and {x['K'] for x in lock['members']}=={20,128,512,1024,2048,4096},'six original member lock')
    for m in lock['members']:
        for rel,h in m['files_sha256'].items():
            p=Path(m['root'])/rel
            need(not Path(rel).is_absolute() and '..' not in Path(rel).parts and p.resolve().is_relative_to(Path(m['root']).resolve()) and file_sha(p)==h,'native inventory bytes')
    imp=read(bound(job['import_lock']))
    keys(imp,('torch_version','transformers_version','numpy_version','python_version','files'))
    need(imp['torch_version']==lock['torch_version'] and imp['transformers_version']==lock['transformers_version'] and imp['numpy_version']==lock['numpy_version'],'import/native runtime agreement')
    need(set(imp['files'])=={'torch','numpy','transformers','transformers.dynamic_module_utils'},'exact actual library import inventory')
    for spec in imp['files'].values():bound(spec)
    cases=job['cases'];need(isinstance(cases,list) and cases,'explicit cases')
    if job['stage']=='qualify':
        need(len(cases)==3 and {c['source_id'] for c in cases}==SOURCES,'three admitted sources exactly once; both architectures run internally')
        materials=read(bound(job['material_lock']))
        need(materials['schema']=='QUALIFICATION_SOURCE_MATERIAL_READY_V1' and set(materials['sources'])==SOURCES,'exact admitted material manifest')
    else:need(len(cases)==1,'one formal model or init per job')
    checked=[]
    for c in cases:
        if job['stage']=='init':
            keys(c,('source_id','architecture','seed'))
            need(c['source_id'] in SOURCES and c['architecture'] in ('S','L') and c['seed']==11,'one admitted clean initialization')
            checked.append(c);continue
        if job['stage']=='qualify':
            keys(c,('source_id','material'))
            from role_bridge import consume
            record=materials['sources'][c['source_id']]
            w,doc,a,schedule,paths=consume(c['material'],record)
            c=dict(c,material_record=record)
            need(c['source_id']==w['source_id'],'case/wrapper source mismatch')
            arrays=dict(doc['arrays']);ap=Path(arrays['path']);arrays['path']=str(ap if ap.is_absolute() else paths['original_natural'].parent/ap);bound(arrays)
            from pilot.contracts import natural_asset
            _,natural,codes=natural_asset(paths['original_natural'])
            need(doc['quantizer_sha256_by_k']=={str(m['K']):m['quantizer_sha256'] for m in lock['members']},'all natural/native quantizer identities before models')
            for architecture in ('S','L'):
                validate(qualification_config(job,imp,c,doc,a,architecture,'0'*64,'0'*64),schedule)
            checked.append((c,doc,natural,codes,a,schedule))
        else:
            keys(c,('source_id','admission','config','schedule','init','bundle','checkpoint','prior_attempts'))
            config=read(bound(c['config']));schedule=read(bound(c['schedule']));validate(config,schedule)
            a=r01_admission(bound(c['admission']),c['source_id'],c['schedule'])
            need(config['source']['bank_sha256']==c['admission']['sha256'] and config['source']['bank_indices']==a['training_indices']
                and config['source']['heldout_positions']==a['heldout_positions'] and config['source']['wt_sha256']==a['wt_sha256'],'formal config exact admitted bank/support/split')
            need(config['source']['id']==c['source_id'] and c['source_id'] in SOURCES,'config admitted single source identity')
            need(config['steps']==2000 and config['seed']==11 and config['lr']==1e-4 and config['checkpoints']==[500,1000,2000] and config['pairs_per_class']==128,'current continuation formal scope; qualification has separate identity')
            bound(c['init']);bound(c['bundle'])
            need(config['init_sha256']==c['init']['sha256'] and config['native_sha256']==job['native_lock']['sha256'],'exact config native/init binding')
            if job['stage']!='predict':need(config['source']['bundle_sha256']==c['bundle']['sha256'],'source bundle identity')
            if c['checkpoint'] is not None:bound(c['checkpoint'])
            from resume_state import load
            init=load(bound(c['init']))
            need(init.get('schema')=='SINGLE_SOURCE_INIT_V1' and init.get('architecture')==config['architecture'] and init.get('seed')==11 and init.get('native_sha256')==config['native_sha256'],'fresh new init schema before models; reject old trained weights')
            if c['checkpoint'] is not None:
                ck=load(bound(c['checkpoint']))
                from single_source import training_identity
                need(ck.get('schema')=='SINGLE_SOURCE_RESUME_V1' and ck.get('training_id')==training_identity(config,schedule)[0],'exact new resume identity before models')
            from pilot.storage import load_bundle
            b=load_bundle(bound(c['bundle']),'cpu')
            if job['stage']=='train':
                need(b['asset_role']=='SOURCE' and b['natural'].protein_id==c['source_id'] and b['natural'].wt_sha256==config['source']['wt_sha256'],'original SOURCE bundle metadata before native models')
            else:
                need(b['asset_role']=='TARGET' and b['natural'].wt_sha256!=config['source']['wt_sha256'],'original nonself TARGET metadata before models')
                need(c['checkpoint'] is not None,'prediction checkpoint required')
            need(b['provenance']['native_lock_sha256']==job['native_lock']['sha256'],'prepared bundle native identity')
            del b
            need(config['code_sha256']==digest(job['runtime_code_sha256']) and config['runtime_sha256']==runtime_identity(imp),'config actual code/runtime identity')
            checked.append((c,config,schedule))
    out=Path(job['output']);need(out.is_absolute() and not out.exists() and not out.resolve().is_relative_to(root),'fresh output outside code')
    return job,imp,checked


def qualification_config(job,imp,c,doc,a,architecture,init_sha,bundle_sha):
    return {'schema':'SINGLE_SOURCE_CONFIG_V1','source':{'id':c['source_id'],'wt_sha256':doc['wt_sha256'],
        'length':len(doc['wt_sequence']),'bank_indices':a['training_indices'],'heldout_positions':a['heldout_positions'],
        'bank_sha256':c['material']['sha256'],'bundle_sha256':bundle_sha},'architecture':architecture,'seed':11,
        'steps':2,'lr':1e-4,'checkpoints':[1,2],'pairs_per_class':128,'loss':'phaseA-pair-v2-nonempty',
        'optimizer':{'name':'AdamW','betas':[.9,.999],'eps':1e-8,'weight_decay':0.,'clip_norm':1.,'dtype':'float32','scheduler':None,'scaler':None},
        'native_sha256':job['native_lock']['sha256'],'init_sha256':init_sha,'code_sha256':digest(job['runtime_code_sha256']),
        'runtime_sha256':digest({'import_lock':imp,'purpose':'QUALIFICATION_ONLY_MAX2'})}


def actual_imports(imp):
    import importlib,sys,inspect
    import torch,numpy,transformers
    need(str(torch.__version__)==imp['torch_version'] and numpy.__version__==imp['numpy_version'] and transformers.__version__==imp['transformers_version'] and sys.version.split()[0]==imp['python_version'],'actual runtime versions')
    for name,spec in imp['files'].items():
        module=importlib.import_module(name);path=Path(inspect.getfile(module)).resolve()
        need(path==Path(spec['path']).resolve() and file_sha(path)==spec['sha256'],'actual import origin mismatch: '+name)


def authorize(job_path,release_path,job):
    import os
    r=read(release_path)
    keys(r,('schema','controller','status','stage','job_sha256','wall_seconds','device','max_updates_per_case'))
    need(r['schema']=='SINGLE_SOURCE_RUNTIME_RELEASE_V1' and r['controller']==CONTROLLER and r['status']=='RELEASED' and r['stage']==job['stage'] and r['job_sha256']==file_sha(job_path) and r['device']==job['device'],'exact new controller release')
    need(type(r['wall_seconds']) is int and 0<r['wall_seconds']<=1800,'bounded qualification/runtime wall <=1800 seconds')
    need(os.environ.get('SLURM_JOB_ID','').isdigit(),'R02 sole real Slurm entry; local model mode absent')
    need(r['max_updates_per_case']==(2 if job['stage']=='qualify' else 0 if job['stage'] in ('init','predict') else read(bound(job['cases'][0]['config']))['steps']),'stage update cap')
    return r
