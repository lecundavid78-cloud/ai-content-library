"""Released, label-free native qualification. Never called by local test runner."""
from pathlib import Path
import time
import torch
from r05_internal.reference.contracts import REQUIRED_K,MemberField,require
from r05_internal.reference.vrh import FullVRH
from .provider import inputs
from .scorer import Scorer,uninstall_lora
from .engine import update,optimizer_for,sync
from .contracts import write,sha,OPTIMIZER

# Existing prior FP32 numerical policy; controller binds these exact values in release.
NUMERICS={"atol":2e-5,"rtol":2e-4,"model_dtype":"float32","tf32":False,"batch_size":1,"padding_probe_batch":2}

def close(a,b):
    require(a.shape==b.shape and torch.isfinite(a).all() and torch.isfinite(b).all(),"numeric shape/finite")
    require(torch.allclose(a,b,atol=NUMERICS["atol"],rtol=NUMERICS["rtol"]),"numerical qualification mismatch")
    return float((a-b).abs().max())

def padding_probe(models,tokenizers,bundle,codes):
    errors={}
    natural=bundle["natural"]
    for k in REQUIRED_K:
        m=models[k];args,idx=inputs(tokenizers[k],natural.wt_sequence,codes[k],k,"cuda")
        padded={}
        for name,x in args.items():
            pad=tokenizers[k].pad_token_id if name=="input_ids" else 0
            x=torch.nn.functional.pad(x,(0,2),value=pad)
            padded[name]=x.repeat(2,1)
        with torch.no_grad():
            out=m(**padded,return_dict=True,output_hidden_states=False,output_attentions=False).logits
        expected=next(f.logits25 for f in bundle["original_fields"] if f.member.structure_codebook_size==k)
        errors[str(k)]=[close(out[row].index_select(0,idx),expected) for row in range(2)]
    return errors

def qualify(models,tokenizers,members,bundle,codes,output,seed=11):
    output=Path(output);started=time.perf_counter()
    require(len(bundle["natural"].wt_sequence)>=4,"qualification probe requires >=4 residues")
    report={"schema":"FOURCELL_QUALIFICATION_V1","status":"RUNNING","numerics":NUMERICS,
            "seed":seed,"optimizer":OPTIMIZER,"probe_pairs":"fixed indices; synthetic ordering, no functional values",
            "probe_updates_per_architecture":2,"probe_pair_counts_per_step":{"within_site":128,"cross_site":128},"architecture":{}}
    report["padding_batch_errors"]=padding_probe(models,tokenizers,bundle,codes)
    fields64=tuple(MemberField(f.member,f.logits25.double()) for f in bundle["original_fields"])
    score64=FullVRH().score_all19l(fields64,bundle["natural"]).score_all19l
    report["FP64_readout_vs_FP32_raw_max_abs"]=close(score64,bundle["original_all19l"])
    for architecture in ("S","L"):
        scorer=Scorer(models,members,architecture,seed)
        if architecture=="L":
            with torch.no_grad():
                replay={}
                for k in REQUIRED_K:
                    c=bundle["caches"][k]
                    h=models[k].prosst.encoder.layer[11](c.h11,c.expanded_mask,query_states=None,
                        relative_pos=c.relative_pos,rel_embeddings=c.rel_embeddings,
                        output_attentions=False,ss_hidden_states=c.ss_hidden_states)
                    replay[str(k)]=close(h,bundle["h12"][k])
            report["h11_to_h12_replay_max_abs"]=replay
        with torch.no_grad():zero_fields,zero=scorer.score(bundle)
        raw={f.member.name:close(f.logits25,g.logits25) for f,g in zip(zero_fields,bundle["original_fields"])}
        score_error=close(zero.score_all19l,bundle["original_all19l"])
        init=scorer.state(0);init_path=output/f"INIT_{architecture}.pt";torch.save(init,init_path)
        optimizer=optimizer_for(scorer);steps=[];head_inputs={};hooks=[]
        def hook_for(k):
            def hook(module,args):
                require(args[0].requires_grad,"frozen original head input lost autograd")
                args[0].retain_grad();head_inputs[k]=args[0]
            return hook
        for k in REQUIRED_K:hooks.append(models[k].cls.register_forward_pre_hook(hook_for(k)))
        try:
            for i in range(2):
                rec=update(scorer,bundle,[[0,19],[38,57]]*64,[[1,2],[20,21]]*64,optimizer)
                rec["head_input_gradient_norms"]={str(k):float(h.grad.norm()) for k,h in head_inputs.items()
                    if h.grad is not None}
                require(len(rec["head_input_gradient_norms"])==6 and
                        all(v>0 for v in rec["head_input_gradient_norms"].values()),"head path must transmit gradient")
                steps.append(rec);head_inputs.clear()
        finally:
            for h in hooks:h.remove()
        for n,v in steps[0]["gradient_norms"].items():
            if (architecture=="L" and n.endswith(".B")) or (architecture=="S" and n.startswith("up.")):
                require(v>0,"first-step output branch gradient missing")
        for n,v in steps[1]["gradient_norms"].items():
            # Exact-zero context input can legitimately leave its first weight gradient zero.
            if not (architecture=="S" and n=="context.0.weight" and not bundle["natural"].context().any()):
                require(v>0,"second-step active parameter gradient missing: "+n)
        with torch.no_grad():trained=scorer.score(bundle)[1].score_all19l.detach().clone()
        require(not torch.equal(trained,zero.score_all19l),"probe produced no output update")
        save_path=output/f"PROBE_{architecture}_NOT_TRAINED.pt";torch.save(scorer.state(2),save_path)
        scorer.restore(init,0)
        scorer.restore(torch.load(save_path,map_location="cpu",weights_only=True),2)
        with torch.no_grad():reloaded=scorer.score(bundle)[1].score_all19l
        require(torch.equal(trained,reloaded),"save/reload exact replay")
        scorer.verify_frozen()
        scorer.restore(torch.load(init_path,map_location="cpu",weights_only=True),0)
        report["architecture"][architecture]={"raw_zero_max_abs":raw,"score_zero_max_abs":score_error,
            "trainable_parameters":sum(p.numel() for p in scorer.params.values()),"steps":steps,
            "head_autograd":True,"frozen_bytes_unchanged":True,"reload_exact":True,
            "init_file":init_path.name,"init_sha256":sha(init_path),"base_frozen_sha256":scorer.base_hash}
        if architecture=="L":uninstall_lora(models)
        del scorer,optimizer,zero_fields,zero
    sync()
    report.update(status="REAL_QUALIFICATION_PASS_NOT_TRAINING_ADMISSION",
        qualification_seconds=time.perf_counter()-started,
        max_cuda_memory_allocated_bytes=torch.cuda.max_memory_allocated(),
        max_cuda_memory_reserved_bytes=torch.cuda.max_memory_reserved())
    write(output/"QUALIFICATION_RECEIPT.json",report)
    return report
