"""Finite pilot metadata, identity and pair-schedule contracts. No model loading."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from r05_internal.reference.contracts import AA20, REQUIRED_K, require, NativeMSA, NaturalInput, sequence_sha256

PROTOCOL_SHA = "c944fe00233c0fd02e05ce642588911387e4d2c88c203d0fd15a02f9ccf9af1b"
OPTIMIZER = {"name":"AdamW","lr":1e-4,"betas":[0.9,0.999],"eps":1e-8,"weight_decay":0.0,"clip_norm":1.0}
STEPS = 500
CELLS = {"A1":("C","S"),"A2":("C","L"),"A3":("R","S"),"A4":("R","L")}

def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda:stream.read(1024*1024),b""):h.update(block)
    return h.hexdigest()

def digest(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(",",":"),allow_nan=False).encode()).hexdigest()

def legacy_tensor_sha(x):
    x=x.detach().cpu().contiguous()
    return digest({"dtype":str(x.dtype),"shape":list(x.shape),
                   "bytes_sha256":hashlib.sha256(x.numpy().tobytes()).hexdigest()})

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def write(path,x):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False)+"\n",encoding="utf-8")

def bound(spec, base):
    require(set(spec)=={"path","sha256"},"file binding must contain path and sha256 only")
    path=Path(spec["path"])
    path=path if path.is_absolute() else Path(base)/path
    require(path.is_file() and sha(path)==spec["sha256"],"bound file identity: "+str(path))
    return path

def exact_keys(doc,keys):
    require(set(doc)==set(keys),"unexpected/missing manifest fields: "+str(set(doc)^set(keys)))

def natural_asset(path):
    """Only admitted label-free numeric arrays; no arbitrary pickle or DMS parser."""
    path=Path(path);doc=read(path)
    exact_keys(doc,("schema","asset_id","role","wt_sequence","wt_sha256","arrays","structure_asset_sha256",
                    "quantizer_sha256_by_k","msa_span_by_k","provenance","functional_labels_included"))
    require(doc["schema"]=="FOURCELL_NATURAL_V1" and doc["functional_labels_included"] is False,"natural schema/labels")
    require(doc["role"] in ("QUALIFICATION_ONLY","SOURCE_POOL","SOURCE","TARGET"),"natural role")
    seq=doc["wt_sequence"];L=len(seq)
    require(L and set(seq)<=set(AA20) and sequence_sha256(seq)==doc["wt_sha256"],"WT identity")
    required={"adapter_msa_profile","foldseek_mapped_profile","context_mask","context_quality"}
    required|={f"structure_codes_{k}" for k in REQUIRED_K}|{f"msa_logp25_{k}" for k in REQUIRED_K}
    with np.load(bound(doc["arrays"],path.parent),allow_pickle=False) as archive:
        require(required<=set(archive.files)<=required|{"rsa_weights","plddt_weights"},"natural array whitelist")
        arrays={key:torch.from_numpy(archive[key].copy()) for key in archive.files}
    codes={}
    for k in REQUIRED_K:
        x=arrays[f"structure_codes_{k}"]
        require(x.dtype==torch.long and x.shape==(L,) and ((x>=0)&(x<k)).all(),"complete canonical structure codes")
        codes[k]=x.tolist()
    require(set(doc["quantizer_sha256_by_k"])=={str(k) for k in REQUIRED_K},"six quantizer identities")
    native={}
    for k in REQUIRED_K:
        start,end=doc["msa_span_by_k"][str(k)]
        native[f"ProSST-{k}"]=NativeMSA(arrays[f"msa_logp25_{k}"],start,end,"admitted label-free source")
    natural=NaturalInput(doc["asset_id"],seq,doc["wt_sha256"],native,
        arrays["adapter_msa_profile"],arrays["foldseek_mapped_profile"],arrays["context_mask"],
        arrays["context_quality"],arrays.get("rsa_weights"),arrays.get("plddt_weights"),doc["provenance"])
    natural.validate()
    require(not natural.foldseek_mapped_profile.any() and not natural.context_mask[:,1].any()
            and not natural.context_quality[:,2:].any(),"extra FS profile remains absent in both arms")
    return doc,natural,codes

def validate_schedule(doc, *, source_ids, natural_by_id, seed):
    exact_keys(doc,("schema","protocol_sha256","init_seed","steps",
                    "source_admissions","schedule"))
    require(doc["schema"]=="THREE_TARGET_PAIR_SCHEDULE_V1" and doc["protocol_sha256"]==PROTOCOL_SHA,"schedule identity")
    require(doc["init_seed"]==seed and seed in (11,23,47) and doc["steps"]==STEPS,"fixed pilot schedule")
    require(len(source_ids)==2 and len(set(source_ids))==2 and
            set(doc["source_admissions"])==set(source_ids),"two source admissions")
    support={}
    counts={s:0 for s in source_ids}
    for sid,a in doc["source_admissions"].items():
        exact_keys(a,("role","wt_sha256","training_indices","heldout_positions","admission_sha256"))
        require(a["role"]=="SOURCE" and a["wt_sha256"]==natural_by_id[sid].wt_sha256,"source natural identity")
        idx=a["training_indices"]
        require(all(type(i) is int for i in idx) and len(idx)==len(set(idx)),"training support duplicates")
        B=len(idx)
        require(4<=B<=2048,"common B in [4,2048]; support-pair pretraining decision, no power-of-two restriction")
        require(all(0<=i<19*len(natural_by_id[sid].wt_sequence) for i in idx),"source support out of 19L")
        held=set(a["heldout_positions"])
        require(all(type(i) is int and 0<=i<len(natural_by_id[sid].wt_sequence) for i in held),"heldout positions")
        require(not ({i//19 for i in idx}&held),"source heldout site in train support")
        from collections import Counter
        require(sum(n>=2 for n in Counter(i//19 for i in idx).values())>=2,"two multi-variant train sites required by support compatibility decision")
        support[sid]=set(idx)
    require(len({len(x) for x in support.values()})==1,"source budget mismatch")
    require(len(doc["schedule"])==STEPS,"500 updates required")
    for step,row in enumerate(doc["schedule"]):
        exact_keys(row,("step","source_id","cross_pairs","within_pairs"))
        sid=row["source_id"]
        require(row["step"]==step and sid==sorted(source_ids)[step%2],"ascending two-source alternation")
        counts[sid]+=1
        for kind in ("cross_pairs","within_pairs"):
            pairs=row[kind]
            require(isinstance(pairs,list) and len(pairs)==128,"both pair classes require exactly 128 nonempty pairs")
            for pair in pairs:
                require(isinstance(pair,list) and len(pair)==2 and
                        all(type(i) is int and i in support[sid] for i in pair),"pair outside admitted source support")
                require(pair[0]!=pair[1],"self pair")
                require((pair[0]//19==pair[1]//19)==(kind=="within_pairs"),"pair site class mismatch")
    require(set(counts.values())=={250},"two sources exactly 250 updates each")
    return doc
