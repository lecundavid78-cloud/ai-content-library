"""Metadata-only single-source protocol. No labels, model loaders, or training."""
import hashlib
import json
import math


def need(ok,message):
    if not ok:raise ValueError(message)


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def keys(doc,names):need(isinstance(doc,dict) and set(doc)==set(names),'exact schema fields: '+str(names))
def integer(x):return type(x) is int
def hash64(x):return isinstance(x,str) and len(x)==64 and all(c in '0123456789abcdef' for c in x)


def validate(config,schedule):
    keys(config,('schema','source','architecture','seed','steps','lr','checkpoints','pairs_per_class',
                 'loss','optimizer','native_sha256','init_sha256','code_sha256','runtime_sha256'))
    need(config['schema']=='SINGLE_SOURCE_CONFIG_V1','single-source configuration only; legacy unsupported')
    src=config['source'];keys(src,('id','wt_sha256','length','bank_indices','heldout_positions','bank_sha256','bundle_sha256'))
    need(isinstance(src['id'],str) and src['id'] and integer(src['length']) and src['length']>0,'one named full WT source')
    for h in (src['wt_sha256'],src['bank_sha256'],src['bundle_sha256'],config['native_sha256'],config['init_sha256'],config['code_sha256'],config['runtime_sha256']):need(hash64(h),'exact lowercase SHA256 identity')
    bank=src['bank_indices'];held=src['heldout_positions'];L=src['length']
    need(isinstance(bank,list) and bank and all(integer(i) and 0<=i<19*L for i in bank) and len(set(bank))==len(bank),'unique train-only19L bank')
    need(isinstance(held,list) and all(integer(p) and 0<=p<L for p in held) and len(set(held))==len(held),'heldout whole-site positions')
    need(not ({i//19 for i in bank}&set(held)),'heldout endpoint in training bank')
    need(config['architecture'] in ('S','L'),'Original is prediction-only; S/L trainable')
    need(integer(config['seed']) and 0<=config['seed']<2**32,'explicit seed, never select best target seed')
    T=config['steps'];need(integer(T) and T>0,'explicit positive update budget')
    lr=config['lr'];need(type(lr) in (int,float) and math.isfinite(lr) and lr>0,'explicit finite positive learning rate')
    cps=config['checkpoints'];need(isinstance(cps,list) and cps==sorted(set(cps)) and all(integer(x) and 0<x<=T for x in cps) and T in cps,'ordered checkpoint steps including final')
    need(integer(config['pairs_per_class']) and config['pairs_per_class']>0,'explicit pair counts')
    need(config['loss']=='phaseA-pair-v2-nonempty','unchanged pairwise formula; no unapproved objective')
    need(config['optimizer']=={'name':'AdamW','betas':[0.9,0.999],'eps':1e-8,'weight_decay':0.0,'clip_norm':1.0,'dtype':'float32','scheduler':None,'scaler':None},'inherited FP32 optimizer; scheduler/scaler unsupported')
    need(isinstance(schedule,list) and len(schedule)==T,'schedule length must equal update budget')
    support=set(bank);count=config['pairs_per_class']
    for step,row in enumerate(schedule):
        keys(row,('step','source_id','within_pairs','cross_pairs'))
        need(row['step']==step and integer(row['step']) and row['source_id']==src['id'],'single source schedule only')
        for kind in ('within_pairs','cross_pairs'):
            pairs=row[kind];need(isinstance(pairs,list) and len(pairs)==count,'fixed nonempty pair class budget')
            for pair in pairs:
                need(isinstance(pair,list) and len(pair)==2 and all(integer(i) and i in support for i in pair) and pair[0]!=pair[1],'pair endpoint not in train-only support')
                need((pair[0]//19==pair[1]//19)==(kind=='within_pairs'),'pair class mismatch')
    return config


def assemble(config,batches):
    """Consume prelocked ordered pairs, no label parsing/resampling or implicit epochs."""
    need(isinstance(batches,list),'prelocked batches required')
    schedule=[{'step':i,'source_id':config['source']['id'],'within_pairs':b['within_pairs'],'cross_pairs':b['cross_pairs']} for i,b in enumerate(batches)]
    # Copies prevent upstream alias mutation after schedule creation.
    schedule=json.loads(json.dumps(schedule))
    validate(config,schedule)
    return schedule


def training_identity(config,schedule):
    validate(config,schedule)
    doc={'schema':'SINGLE_SOURCE_IDENTITY_V1','config':config,'schedule_sha256':digest(schedule),
         'normalization':'complete19L','statistics_gradient':'full','window_rule':'single-full-WT-forward-no-window',
         'canonical_train_bank_sha256':digest(sorted(config['source']['bank_indices']))}
    return digest(doc),json.loads(json.dumps(doc))


def coverage(config,schedule,*,attempts,completed_updates):
    validate(config,schedule);T=config['steps']
    need(integer(attempts) and integer(completed_updates) and 0<=completed_updates<=T and attempts>=completed_updates,'attempted versus completed update counters')
    # Only successful prefix counts as consumed supervision, never failed attempt pairs.
    observed=schedule[:completed_updates];bank=set(config['source']['bank_indices']);endpoints=set();sites=set();counts={}
    for kind in ('within_pairs','cross_pairs'):
        pairs=[tuple(pair) for row in observed for pair in row[kind]]
        for a,b in pairs:endpoints.update((a,b));sites.update((a//19,b//19))
        counts[kind]={'appearances':len(pairs),'unique_ordered_pairs':len(set(pairs)),'repeats':len(pairs)-len(set(pairs))}
    return {'schema':'SINGLE_SOURCE_COVERAGE_V1','source_id':config['source']['id'],'attempted_updates':attempts,
            'completed_updates':completed_updates,'eligible_variants':len(bank),'observed_variants':len(endpoints),
            'eligible_sites':len({i//19 for i in bank}),'observed_sites':len(sites),
            'variant_coverage':len(endpoints)/len(bank),'unseen_bank_indices':sorted(bank-endpoints),
            'pair_counts':counts,'all_train_bank_observed':endpoints==bank,'full19L_labels_implied':False}
