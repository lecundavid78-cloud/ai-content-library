"""Six-member live suffix -> unchanged AA25/full-19L readout. No model loader."""
from __future__ import annotations
import torch
from .lora import assert_runtime_mode
from .reference.contracts import REQUIRED_K, MemberField, require, validate_members
from .reference.vrh import FullVRH

def canonical_fields(models, members, caches, natural):
    require(set(models) == set(members) == set(caches) == set(REQUIRED_K), "six members required")
    validate_members(tuple(members[k] for k in REQUIRED_K), "full")
    assert_runtime_mode(models)
    fields = []
    for k in REQUIRED_K:
        member, cache, model = members[k], caches[k], models[k]
        require(member.structure_codebook_size == k, "K/key mismatch")
        cache.validate(member, natural)
        block = model.get_submodule("prosst.encoder.layer.11")
        parameter = next(block.parameters())
        require(parameter.dtype == cache.h11.dtype and parameter.device == cache.h11.device,
                "no implicit cache/block precision or device conversion")
        # Never no_grad/detach here: frozen suffix/head must transmit gradients to A/B.
        h12 = block(cache.h11, attention_mask=cache.expanded_mask,
                    query_states=None, relative_pos=cache.relative_pos,
                    rel_embeddings=cache.rel_embeddings, ss_hidden_states=cache.ss_hidden_states,
                    output_attentions=False)
        require(isinstance(h12, torch.Tensor) and h12.shape == cache.h11.shape, "unexpected last-block return")
        logits = model.cls(h12)
        require(logits.shape == (1, cache.h11.shape[1], 25), "complete original head must return AA25")
        canonical = logits[0].index_select(0, cache.canonical_index)
        # FP32 cast retains autograd; FP64 synthetic checks may remain FP64.
        canonical = canonical if canonical.dtype == torch.float64 else canonical.float()
        fields.append(MemberField(member, canonical))
    return tuple(fields)

def score_full19l(models, members, caches, natural):
    fields = canonical_fields(models, members, caches, natural)
    result = FullVRH().score_all19l(fields, natural,
        statistics_gradient="full", normalization_universe="complete19L")
    require(result.score_all19l.shape == (19 * len(natural.wt_sequence),), "incomplete support")
    return result

PAIR_INTERFACE_VERSION = "phaseA-pair-v2-nonempty"

def original_pair_risk(scores, cross_pairs, within_pairs):
    """Original nonempty-class formula; phase A rejects either empty class."""
    losses = []
    for name, pairs in (("cross", cross_pairs), ("within", within_pairs)):
        require(pairs.dtype == torch.long and pairs.ndim == 2 and pairs.shape[1] == 2, "pair shape")
        require(pairs.shape[0] > 0, f"{name} pair class must be nonempty")
        require(((pairs >= 0) & (pairs < scores.numel())).all(), "pair outside full support")
        losses.append(torch.nn.functional.softplus(-(scores[pairs[:, 0]] - scores[pairs[:, 1]])).mean())
    return (losses[0] + losses[1]) / 2
