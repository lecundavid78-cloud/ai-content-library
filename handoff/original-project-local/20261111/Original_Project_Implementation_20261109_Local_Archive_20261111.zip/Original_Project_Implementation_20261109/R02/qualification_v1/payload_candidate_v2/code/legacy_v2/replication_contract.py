"""Only new source-only training identity and target scoring-edge checks."""
from pathlib import Path
from pilot.contracts import PROTOCOL_SHA,OPTIMIZER,bound,read,sha,digest,exact_keys
from pilot.qualification import NUMERICS
from r05_internal.reference.contracts import require

SEEDS=(11,23,47)
CONTROLLER='01a1868c-f2f5-7472-b24f-b4a9ac5ee794'
STAGES={'qualify':'QUALIFICATION_RELEASE','qualify_batch':'QUALIFICATION_RELEASE','cache':'QUALIFICATION_RELEASE','init':'QUALIFICATION_RELEASE',
        'train':'TRAINING_ADMISSION','predict':'PREDICTION_RELEASE'}


def seed_value(seed):
    require(type(seed) is int and seed in SEEDS,'seed must be 11/23/47')
    return seed


def role_meta(meta):
    exact_keys(meta,('id','group_id','wt_sha256','length'))
    require(isinstance(meta['id'],str) and meta['id'] and isinstance(meta['group_id'],str) and meta['group_id'],'reference/group IDs required')
    h=meta['wt_sha256'];require(isinstance(h,str) and len(h)==64 and all(c in '0123456789abcdef' for c in h),'reference WT SHA')
    require(type(meta['length']) is int and meta['length']>0,'full WT length')
    return meta


def source_roles(sources):
    require(isinstance(sources,list) and len(sources)==2,'exact two source metadata rows')
    for m in sources:role_meta(m)
    require(len({s['id'] for s in sources})==len({s['group_id'] for s in sources})==len({s['wt_sha256'] for s in sources})==2,'two independent groups and different WT sources')
    return sources


def scoring_edge(sources,target):
    source_roles(sources);role_meta(target)
    require(target['id'] in ('TnpB','AsCas12f','SpCas9'),'fixed prediction target')
    require(all(s['id']!=target['id'] and s['wt_sha256']!=target['wt_sha256'] and s['group_id']!=target['group_id'] for s in sources),'source-target ID/WT/group isolation')
    # Separate assay naming must not disguise the protected SpCas9 WT.
    if target['id']=='SpCas9':
        require(not any(s['id'].startswith('CAS9_STRP1') or s['id']=='SpCas9' for s in sources),'SpCas9-source model cannot score SpCas9')
    return True


def training_key(*,sources,bundles,schedule_sha256,init_sha256,architecture,seed,native_sha256,code_manifest_sha256):
    source_roles(sources);seed_value(seed)
    require(architecture in ('S','L') and set(bundles)=={s['id'] for s in sources},'architecture/source bindings')
    identity={'schema':'THREE_TARGET_TRAINING_IDENTITY_V1','protocol_sha256':PROTOCOL_SHA,
        'sources':sorted(sources,key=lambda s:s['id']),
        'bundle_sha256':{s:bundles[s]['sha256'] for s in sorted(bundles)},
        'schedule_sha256':schedule_sha256,'init_sha256':init_sha256,'architecture':architecture,
        'seed':seed,'native_lock_sha256':native_sha256,'code_manifest_sha256':code_manifest_sha256,
        'optimizer':OPTIMIZER,'steps':500,'normalization':'complete19L','statistics_gradient':'full',
        'window_rule':'single-full-WT-forward-no-window'}
    return digest(identity),identity


def verify(job_path,release_path,code_root,allocation):
    job_path=Path(job_path);job=read(job_path);r=read(release_path)
    exact_keys(job,('schema','stage','protocol_sha256','code_ready','native_lock','output','config'))
    require(job['schema']=='THREE_TARGET_JOB_V1' and job['protocol_sha256']==PROTOCOL_SHA and job['stage'] in STAGES,'new exact job/protocol/stage')
    exact_keys(r,('schema','controller_chat','status','kind','protocol_sha256','job_sha256','code_ready_sha256','optimizer','numerics','wall_seconds'))
    require(r['schema']=='THREE_TARGET_EXACT_RELEASE_V1' and r['controller_chat']==CONTROLLER and r['status']=='RELEASED'
        and r['kind']==STAGES[job['stage']] and r['protocol_sha256']==PROTOCOL_SHA and r['job_sha256']==sha(job_path),'exact controller stage release')
    require(r['optimizer']==OPTIMIZER and r['numerics']==NUMERICS,'inherited scientific settings')
    require(type(r['wall_seconds']) is int and 0<r['wall_seconds']<=86400,'finite deadline')
    ready_path=bound(job['code_ready'],job_path.parent);ready=read(ready_path)
    require(sha(ready_path)==r['code_ready_sha256'] and ready['status']=='CODE_READY_FOR_R02_REAL_QUALIFICATION'
        and ready['protocol_sha256']==PROTOCOL_SHA,'released ready')
    mp=bound(ready['code_manifest'],ready_path.parent);manifest=read(mp);names=set()
    for item in manifest['files']:
        rel=Path(item['path']);require(not rel.is_absolute() and '..' not in rel.parts,'relative code file')
        require(sha(Path(code_root)/rel)==item['sha256'],'code identity '+str(rel));names.add(rel.as_posix())
    require({f.relative_to(code_root).as_posix() for f in Path(code_root).rglob('*.py')}=={n for n in names if n.endswith('.py')},'unmanifested Python')
    require(str(allocation).isdigit(),'real entry requires R02 Slurm allocation')
    output=Path(job['output'])
    require(output.is_absolute() and not output.exists() and not output.resolve().is_relative_to(Path(code_root).resolve()),'fresh absolute output outside immutable code package')
    native=bound(job['native_lock'],job_path.parent)
    return job,r,native,sha(mp)
