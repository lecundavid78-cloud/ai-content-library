"""18 independent source qualifications, one native load, one live bundle at a time."""
from pathlib import Path
import time
import torch
from pilot.contracts import natural_asset,bound,write,sha
from pilot.provider import prepare_input
from pilot.storage import dump_bundle
from pilot.qualification import qualify
from pilot.scorer import frozen_items,stamps,frozen_digest
from r05_internal.lora import UnmergedLoRALinear
from r05_internal.reference.contracts import require
from long_sequence import full_span_evidence


def clean_base(models):
    require(not any(isinstance(m,UnmergedLoRALinear) for model in models.values() for m in model.modules()),'previous source LoRA was not uninstalled')
    require(not any(p.requires_grad or p.grad is not None for model in models.values() for p in model.parameters()),'previous source trainable/base gradients leaked')
    return stamps(frozen_items(models))


def qualify_batch(models,tokens,members,quantizers,assets,source_ids,seed,output,base,native_sha,code_sha):
    require(len(source_ids)==18 and len(set(source_ids))==18 and len(assets)==18,'exact18 independently qualified selected sources')
    require(seed in (11,23,47),'fixed initialization seed')
    out=Path(output);index={'schema':'THREE_TARGET_BATCH_QUALIFICATION_V1','status':'RUNNING',
        'native_lock_sha256':native_sha,'code_manifest_sha256':code_sha,'seed':seed,
        'expected_source_ids':list(source_ids),'sources':{},'pending_source_ids':list(source_ids),
        'native_loader_calls':1,'qualification_calls':0,'completed_source_qualifications':0}
    baseline_stamp=clean_base(models);baseline_bytes=frozen_digest(models)
    index['base_frozen_sha256']=baseline_bytes
    write(out/'BATCH_QUALIFICATION_INDEX.json',index)
    started=time.perf_counter();seen=set()
    for i,spec in enumerate(assets):
        work=out/'sources'/f'SOURCE_{i:02d}';work.mkdir(parents=True,exist_ok=False)
        sid=None;phase='asset_validation';t=time.perf_counter()
        try:
            asset=bound(spec,base);doc,natural,codes=natural_asset(asset);sid=doc['asset_id']
            require(sid in source_ids and sid not in seen and doc['role'] in ('SOURCE','SOURCE_POOL'),'exact selected source role/identity; no target probe substitution')
            seen.add(sid)
            require(clean_base(models)==baseline_stamp,'cross-source base changed before preparation')
            torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats()
            phase='full_WT_cache_preparation'
            bundle=prepare_input(models,tokens,members,quantizers,doc,natural,codes)
            bundle['provenance']['native_lock_sha256']=native_sha
            evidence={sid:full_span_evidence(models,bundle)};write(work/'FULL_SPAN_EVIDENCE.json',evidence)
            dump_bundle(work/'CACHE.pt',bundle)
            prepare_seconds=time.perf_counter()-t;phase='independent_S_and_L_gradient_qualification'
            index['qualification_calls']+=1
            q=qualify(models,tokens,members,bundle,codes,work,seed)
            require(q['status']=='REAL_QUALIFICATION_PASS_NOT_TRAINING_ADMISSION' and set(q['architecture'])=={'S','L'},'both independent architecture gradient qualifications must pass')
            # qualify restores S/L step0 and removes all LoRA wrappers before returning.
            require(clean_base(models)==baseline_stamp and frozen_digest(models)==baseline_bytes,'cross-source reset/uninstall/frozen-byte proof failed')
            q.update(probe_asset_id=sid,native_lock_sha256=native_sha,code_manifest_sha256=code_sha,
                full_WT_length=len(natural.wt_sequence),wt_sha256=natural.wt_sha256,
                natural_input_sha256=bundle['provenance']['natural_input_sha256'],
                structure_asset_sha256=bundle['provenance']['structure_asset_sha256'],
                full_span_evidence_sha256=sha(work/'FULL_SPAN_EVIDENCE.json'),
                cross_source_base_reset_verified=True,base_frozen_sha256=baseline_bytes)
            write(work/'QUALIFICATION_RECEIPT.json',q)
            index['sources'][sid]={'status':'REAL_QUALIFICATION_PASS_NOT_TRAINING_ADMISSION',
                'qualification':{'path':str((work/'QUALIFICATION_RECEIPT.json').resolve()),'sha256':sha(work/'QUALIFICATION_RECEIPT.json')},
                'bundle':{'path':str((work/'CACHE.pt').resolve()),'sha256':sha(work/'CACHE.pt')},
                'natural_asset_sha256':sha(asset),'preparation_and_dump_seconds':prepare_seconds,
                'qualification_seconds':q['qualification_seconds'],'source_total_seconds':time.perf_counter()-t,
                'peak_allocated_bytes':torch.cuda.max_memory_allocated(),'peak_reserved_bytes':torch.cuda.max_memory_reserved()}
            index['pending_source_ids']=[s for s in source_ids if s not in index['sources']]
            index['completed_source_qualifications']=len(index['sources'])
            index['batch_peak_allocated_bytes']=max(r['peak_allocated_bytes'] for r in index['sources'].values())
            index['batch_peak_reserved_bytes']=max(r['peak_reserved_bytes'] for r in index['sources'].values())
            index['elapsed_seconds']=time.perf_counter()-started
            write(out/'BATCH_QUALIFICATION_INDEX.json',index)
            del bundle,natural,codes,q,evidence
            # Native models stay resident; only per-source temporary/cached allocation is released.
            torch.cuda.empty_cache()
        except BaseException as exc:
            failure={'status':'TECHNICAL_FAILURE_NO_RETRY','source_id':sid,'asset_binding':spec,'phase':phase,
                'error_type':type(exc).__name__,'error':str(exc),'seconds':time.perf_counter()-t,
                'peak_allocated_bytes':torch.cuda.max_memory_allocated(),'peak_reserved_bytes':torch.cuda.max_memory_reserved()}
            write(work/'SOURCE_FAILURE.json',failure)
            index.update(status='BATCH_TECHNICAL_FAILURE_NOT_ALL_SOURCES_QUALIFIED',failure=failure,
                elapsed_seconds=time.perf_counter()-started)
            write(out/'BATCH_QUALIFICATION_INDEX.json',index)
            raise # Do not run another source on a possibly partially adapted model.
    require(seen==set(source_ids) and len(index['sources'])==18,'all18 actual gradient qualifications required')
    index.update(status='ALL18_REAL_QUALIFICATION_PASS_NOT_TRAINING_ADMISSION',elapsed_seconds=time.perf_counter()-started)
    write(out/'BATCH_QUALIFICATION_INDEX.json',index)
    return index
