"""Fixed LoRA-A initialization, including PyTorch 2.1's Tensor-level API."""
import math
import torch
from .reference.contracts import require


def kaiming_uniform_a_sqrt5_(tensor, *, generator):
    """Preserve native fan_in/leaky_relu arithmetic and the supplied RNG."""
    require(tensor.ndim == 2 and all(n > 0 for n in tensor.shape),
            "LoRA initialization requires a nonempty two-dimensional weight")
    fan_in = tensor.size(1)
    negative_slope = math.sqrt(5)
    gain = math.sqrt(2.0 / (1 + negative_slope ** 2))
    std = gain / math.sqrt(fan_in)
    bound = math.sqrt(3.0) * std
    with torch.no_grad():
        return tensor.uniform_(-bound, bound, generator=generator)
