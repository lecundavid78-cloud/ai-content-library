"""Unmerged, finite Q/V updates. No loaders, downloads, training loop or I/O."""
from __future__ import annotations
import hashlib
from collections.abc import Mapping
import torch
from torch import nn
from .initialization import kaiming_uniform_a_sqrt5_
from .reference.contracts import REQUIRED_K, require, tensor_sha256

PATHS = tuple(f"prosst.encoder.layer.11.attention.self.{p}" for p in ("query", "value"))
RANK = ALPHA = 32
PARAMETER_COUNT = 589824

class UnmergedLoRALinear(nn.Module):
    def __init__(self, base: nn.Linear, *, seed: int, rank: int = RANK, alpha: int = ALPHA):
        super().__init__()
        require(type(base) is nn.Linear, "plain original nn.Linear required")
        require(rank > 0 and alpha > 0, "invalid low-rank configuration")
        self.base = base.requires_grad_(False)
        self.rank, self.alpha = rank, alpha
        self.merge_weights = self.merged = False
        self.A = nn.Parameter(torch.empty(rank, base.in_features, device=base.weight.device, dtype=base.weight.dtype))
        self.B = nn.Parameter(torch.zeros(base.out_features, rank, device=base.weight.device, dtype=base.weight.dtype))
        generator = torch.Generator(device=base.weight.device).manual_seed(seed)
        kaiming_uniform_a_sqrt5_(self.A, generator=generator)
        self.base.eval()

    def train(self, mode: bool = True):
        super().train(mode)
        self.base.eval()
        return self

    def merge(self):
        raise RuntimeError("merge is forbidden; effective updates must remain differentiable")

    def forward(self, x):
        require(not self.merged and not self.merge_weights, "merged path is forbidden")
        return self.base(x) + (self.alpha / self.rank) * torch.nn.functional.linear(
            torch.nn.functional.linear(x, self.A), self.B)

def _models(models: Mapping[int, nn.Module]):
    require(set(models) == set(REQUIRED_K), "exact six K members required")
    require(len({id(m) for m in models.values()}) == 6, "members cannot share model objects")

def _seed(seed: int, k: int, path: str) -> int:
    return int(hashlib.sha256(f"{seed}:{k}:{path}".encode()).hexdigest()[:15], 16)

def expected_names():
    return {f"{k}/{path}.{ab}" for k in REQUIRED_K for path in PATHS for ab in ("A", "B")}

def adapter_parameters(models):
    return {f"{k}/{name}": p for k in REQUIRED_K for name, p in models[k].named_parameters()
            if p.requires_grad}

def assert_whitelist(models):
    _models(models)
    params = adapter_parameters(models)
    require(set(params) == expected_names(), "trainable parameter whitelist mismatch")
    require(sum(p.numel() for p in params.values()) == PARAMETER_COUNT, "parameter count mismatch")
    require(len({id(p) for p in params.values()}) == 24, "adapter tensors must be independent")
    for k in REQUIRED_K:
        for path in PATHS:
            module = models[k].get_submodule(path)
            require(type(module) is UnmergedLoRALinear, "unexpected projection implementation")
            require(module.rank == module.alpha == 32, "rank/scale identity mismatch")
            require(module.A.shape == (32, 768) and module.B.shape == (768, 32), "adapter shape mismatch")
            require(not module.merged and not module.merge_weights, "merge forbidden")
    return params

def install_last_qv(models, *, seed: int):
    """Preflight every member before any replacement; does not execute any model."""
    _models(models)
    targets = []
    for k in REQUIRED_K:
        model = models[k]
        require(len(model.prosst.encoder.layer) == 12, "exact 12-block encoder required")
        require(not any(isinstance(x, UnmergedLoRALinear) for x in model.modules()), "already installed")
        for path in PATHS:
            base = model.get_submodule(path)
            require(type(base) is nn.Linear and base.in_features == base.out_features == 768,
                    "original Q/V must be plain 768x768 Linear")
            targets.append((k, path, base))
    require(len({id(base.weight) for _, _, base in targets}) == 12, "Q/V weights must be independent")
    for model in models.values():
        model.requires_grad_(False)
        model.eval()
        model.prosst.encoder.gradient_checkpointing = False
    for k, path, base in targets:
        parent, child = path.rsplit(".", 1)
        setattr(models[k].get_submodule(parent), child, UnmergedLoRALinear(base, seed=_seed(seed, k, path)))
    return assert_whitelist(models)

def assert_runtime_mode(models):
    assert_whitelist(models)
    for model in models.values():
        require(not model.prosst.encoder.gradient_checkpointing, "checkpoint wrapper not admitted")
        for module in model.modules():
            if isinstance(module, nn.Dropout):
                require(not module.training, "original dropout must be disabled")

def frozen_fingerprint(models):
    """Called on installed models; includes all frozen parameters and buffers."""
    assert_whitelist(models)
    dig = hashlib.sha256()
    for k in REQUIRED_K:
        tensors = [(n, p) for n, p in models[k].named_parameters() if not p.requires_grad]
        tensors += [("buffer:" + n, b) for n, b in models[k].named_buffers()]
        for name, tensor in sorted(tensors):
            dig.update(f"{k}/{name}:{tensor_sha256(tensor)}\n".encode())
    return dig.hexdigest()

def export_adapter_state(models):
    params = assert_whitelist(models)
    return {"schema": "r05-qv32-unmerged-v1", "rank": 32, "alpha": 32,
            "frozen_fingerprint": frozen_fingerprint(models),
            "tensors": {n: p.detach().cpu().clone() for n, p in params.items()}}

def load_adapter_state(models, payload):
    params = assert_whitelist(models)
    require(set(payload) == {"schema", "rank", "alpha", "frozen_fingerprint", "tensors"}, "state fields mismatch")
    require(payload["schema"] == "r05-qv32-unmerged-v1" and payload["rank"] == payload["alpha"] == 32,
            "state configuration mismatch")
    require(payload["frozen_fingerprint"] == frozen_fingerprint(models), "wrong frozen model identity")
    require(set(payload["tensors"]) == set(params), "state whitelist mismatch")
    for name, tensor in payload["tensors"].items():
        require(isinstance(tensor, torch.Tensor) and tensor.shape == params[name].shape,
                "state tensor shape mismatch")
        require(tensor.dtype == params[name].dtype and torch.isfinite(tensor).all(), "state dtype/nonfinite")
    with torch.no_grad():
        for name, tensor in payload["tensors"].items():
            params[name].copy_(tensor.to(device=params[name].device))
