"""Isolated local preparation; importing does not load a protein model."""
