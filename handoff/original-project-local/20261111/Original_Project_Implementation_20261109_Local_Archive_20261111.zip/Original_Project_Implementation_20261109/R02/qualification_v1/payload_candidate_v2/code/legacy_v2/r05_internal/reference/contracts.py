"""Strict, label-free natural inputs and explicit per-member cache contracts."""
from __future__ import annotations

from dataclasses import dataclass, fields
import hashlib
import json
from typing import Mapping, Sequence

import torch

AA20 = "ACDEFGHIKLMNPQRSTVWY"
REQUIRED_K = (20, 128, 512, 1024, 2048, 4096)


class ContractError(ValueError):
    pass


class IncompleteEnsembleError(ContractError):
    pass


def sequence_sha256(sequence: str) -> str:
    return hashlib.sha256(sequence.encode("ascii")).hexdigest()


def tensor_sha256(tensor: torch.Tensor) -> str:
    x = tensor.detach().cpu().contiguous()
    header = json.dumps({"dtype": str(x.dtype), "shape": list(x.shape)}, sort_keys=True).encode()
    return hashlib.sha256(header + b"\0" + x.numpy().tobytes()).hexdigest()


def json_sha256(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()


def require(condition, message: str) -> None:
    if not bool(condition):
        raise ContractError(message)


def constant_tensor(x: torch.Tensor, name: str) -> None:
    require(isinstance(x, torch.Tensor), f"{name}: expected Tensor")
    require(not x.requires_grad and x.grad_fn is None, f"{name}: natural/cache input must be detached")
    require(torch.isfinite(x).all(), f"{name}: nonfinite")


@dataclass(frozen=True)
class MemberIdentity:
    name: str
    structure_codebook_size: int
    structure_vocab_size: int
    hidden_width: int
    vocab: tuple[str, ...]
    weights_sha256: str
    source_sha256: str
    tokenizer_sha256: str
    cls_sha256: str
    layer_norm_eps: float = 1e-7

    def __post_init__(self):
        require(self.name and "." not in self.name, "member name must be nonempty and contain no dots")
        require(len(self.vocab) == 25 and len(set(self.vocab)) == 25, "AA25 vocabulary required")
        require(all(aa in self.vocab for aa in AA20), "vocab must contain every AA20")
        require(self.hidden_width > 0 and self.structure_vocab_size > 0 and self.layer_norm_eps > 0, "invalid member dimensions")
        for value in (self.weights_sha256, self.source_sha256, self.tokenizer_sha256, self.cls_sha256):
            require(len(value) == 64 and all(c in "0123456789abcdef" for c in value), "member identity requires lowercase SHA256")

    @property
    def aa20_ids(self) -> tuple[int, ...]:
        return tuple(self.vocab.index(aa) for aa in AA20)

    @property
    def vocab_size(self) -> int:
        return len(self.vocab)


def validate_members(members: Sequence[MemberIdentity], ensemble_mode: str) -> None:
    require(ensemble_mode in ("full", "partial_technical"), "unknown ensemble mode")
    require(len(members) > 0 and len({m.name for m in members}) == len(members), "members empty or duplicated")
    codes = [m.structure_codebook_size for m in members]
    require(len(set(codes)) == len(codes) and set(codes).issubset(REQUIRED_K), "invalid member K")
    if ensemble_mode == "full" and set(codes) != set(REQUIRED_K):
        raise IncompleteEnsembleError("Full VenusREM2 requires all six K; partial_technical must be explicit")


@dataclass(frozen=True)
class NativeMSA:
    logp25: torch.Tensor | None
    aln_start: int = 0
    aln_end: int = 0
    provenance: str = ""


@dataclass(frozen=True)
class NaturalInput:
    protein_id: str
    wt_sequence: str
    wt_sha256: str
    native_msa_by_member: Mapping[str, NativeMSA]
    adapter_msa_profile: torch.Tensor
    foldseek_mapped_profile: torch.Tensor
    context_mask: torch.Tensor
    context_quality: torch.Tensor
    rsa_weights: torch.Tensor | None = None
    plddt_weights: torch.Tensor | None = None
    provenance: Mapping[str, str] | None = None

    @classmethod
    def from_mapping(cls, mapping: Mapping) -> "NaturalInput":
        unknown = set(mapping) - {f.name for f in fields(cls)}
        require(not unknown, f"Unknown/label fields in NaturalInput: {sorted(unknown)}")
        result = cls(**mapping)
        result.validate()
        return result

    def validate(self) -> None:
        L = len(self.wt_sequence)
        require(L > 0 and not (set(self.wt_sequence) - set(AA20)), "WT must be nonempty canonical AA20")
        require(sequence_sha256(self.wt_sequence) == self.wt_sha256, "WT hash mismatch")
        require(self.context_mask.shape == (L, 2) and self.context_mask.dtype == torch.bool, "context_mask must be bool [L,2]")
        require(self.context_quality.shape == (L, 4), "quality order is coverage_msa,entropy_msa,coverage_fs,entropy_fs")
        for x, label in ((self.adapter_msa_profile, "MSA profile"), (self.foldseek_mapped_profile, "FS profile"), (self.context_mask, "context mask"), (self.context_quality, "context quality")):
            constant_tensor(x, label)
        require(((self.context_quality >= 0) & (self.context_quality <= 1)).all(), "quality outside [0,1]")
        for i, x in enumerate((self.adapter_msa_profile, self.foldseek_mapped_profile)):
            require(x.shape == (L, 20), "adapter profile must be [L,20], not native AA25")
            require((x >= 0).all(), "profile negative")
            present = self.context_mask[:, i]
            require(torch.allclose(x[present].sum(-1), torch.ones_like(x[present].sum(-1)), atol=2e-6, rtol=2e-6), "present profile must sum to 1")
            require((x[~present] == 0).all() and (self.context_quality[~present, 2*i:2*i+2] == 0).all(), "missing profile and quality must be zero")
        for name, msa in self.native_msa_by_member.items():
            require(isinstance(msa, NativeMSA), f"{name}: NativeMSA required")
            if msa.logp25 is not None:
                constant_tensor(msa.logp25, "native MSA")
                require(msa.logp25.ndim == 2 and msa.logp25.shape[1] == 25, "native MSA must have 25 vocabulary columns")
                require(0 <= msa.aln_start < msa.aln_end <= L, "invalid native alignment span")
                require(msa.logp25.shape[0] == msa.aln_end - msa.aln_start, "native alignment rows/span mismatch")
                require(torch.allclose(msa.logp25.logsumexp(-1), torch.zeros_like(msa.logp25[:, 0]), atol=2e-5, rtol=0), "native MSA must be normalized logp25, not AA20 frequencies")
        for x, name in ((self.rsa_weights, "RSA"), (self.plddt_weights, "pLDDT")):
            if x is not None:
                constant_tensor(x, name)
                require(x.shape in ((L,), (L, 1)), f"{name}: expected [L] or [L,1]")
        if self.provenance:
            banned = {"label", "labels", "fitness", "dms_score", "target_score", "functional_score"}
            require(not any(str(k).lower() in banned for k in self.provenance), "functional label in provenance")
            require(all(isinstance(k, str) and isinstance(v, str) for k, v in self.provenance.items()), "provenance only strings")

    def context(self, mode: str = "full") -> torch.Tensor:
        require(mode in ("full", "null"), "context mode must be full/null")
        # All columns zero for null; the same adapter, biases and native MSA remain.
        c = torch.cat((self.adapter_msa_profile, self.foldseek_mapped_profile, self.context_mask.to(self.adapter_msa_profile.dtype), self.context_quality), -1)
        return torch.zeros_like(c) if mode == "null" else c


def natural_sha256(natural: NaturalInput) -> str:
    record = {"protein_id": natural.protein_id, "wt_sha256": natural.wt_sha256, "provenance": dict(natural.provenance or {})}
    for name in ("adapter_msa_profile", "foldseek_mapped_profile", "context_mask", "context_quality", "rsa_weights", "plddt_weights"):
        value = getattr(natural, name)
        record[name] = tensor_sha256(value) if value is not None else None
    record["native_msa"] = {name: {"sha256": tensor_sha256(x.logp25) if x.logp25 is not None else None, "span": [x.aln_start, x.aln_end], "provenance": x.provenance} for name, x in natural.native_msa_by_member.items()}
    return json_sha256(record)


@dataclass(frozen=True)
class MaskPlan:
    protein_id: str
    wt_sha256: str
    canonical_positions: tuple[int, ...]
    seed: int
    plan_sha256: str


@dataclass(frozen=True)
class HiddenCacheKey:
    member_name: str
    protein_id: str
    role: str
    natural_input_sha256: str
    input_ids_sha256: str
    structure_tokens_sha256: str
    attention_mask_sha256: str
    canonical_index_sha256: str
    mask_plan_sha256: str | None
    dtype: str
    truncation_policy: str
    forward_flags_sha256: str
    weights_sha256: str
    source_sha256: str
    tokenizer_sha256: str
    cls_sha256: str
    encoder_mode: str = "eval"


@dataclass(frozen=True)
class HiddenCache:
    key: HiddenCacheKey
    hidden: torch.Tensor
    canonical_index: torch.Tensor
    attention_mask: torch.Tensor
    input_ids: torch.Tensor
    structure_tokens: torch.Tensor


def make_cache_key(member, natural, *, role, input_ids, structure_tokens, attention_mask, canonical_index, mask_plan, hidden, forward_flags, truncation_policy):
    require(role in ("wt", "masked"), "unknown cache role")
    require((role == "masked") == (mask_plan is not None), "mask plan required exactly for masked role")
    flags = {"flags": dict(forward_flags), "role": role, "mask_plan": mask_plan.plan_sha256 if mask_plan else None, "encoder_mode": "eval", "dtype": str(hidden.dtype)}
    return HiddenCacheKey(member.name, natural.protein_id, role, natural_sha256(natural), tensor_sha256(input_ids), tensor_sha256(structure_tokens), tensor_sha256(attention_mask), tensor_sha256(canonical_index), mask_plan.plan_sha256 if mask_plan else None, str(hidden.dtype), truncation_policy, json_sha256(flags), member.weights_sha256, member.source_sha256, member.tokenizer_sha256, member.cls_sha256)


@dataclass(frozen=True)
class PairPlan:
    protein_id: str
    wt_sha256: str
    step: int
    cross_pairs: torch.Tensor
    within_pairs: torch.Tensor
    plan_sha256: str


@dataclass(frozen=True)
class SourceTask:
    natural: NaturalInput
    wt_cache: Mapping[str, HiddenCache]
    masked_cache: Mapping[str, HiddenCache]
    mask_plan: MaskPlan
    source_protein_id: str
    target_protein_id: str

    def validate_role(self):
        require(self.source_protein_id == self.natural.protein_id, "wrong source role")
        require(self.source_protein_id != self.target_protein_id, "source and target must differ")


@dataclass(frozen=True)
class MemberField:
    member: MemberIdentity
    logits25: torch.Tensor

    @property
    def logp25(self):
        return self.logits25.log_softmax(-1)


@dataclass(frozen=True)
class VRHConfig:
    alpha_spec: str | float = "entropy"
    background_spec: str | float = "one_minus_alpha"
    disable_adaptive_ccd: bool = False
    use_rsa_decay: bool = True
    rsa_decay_mode: str = "above_mean"
    use_plddt_decay: bool = True
    plddt_decay_mode: str = "above_mean"
    task_type: str = "default"


@dataclass(frozen=True)
class VRHResult:
    score_all19l: torch.Tensor
    member_scores: torch.Tensor
    member_zscores: torch.Tensor
    variant_ids: tuple[str, ...]
    member_names: tuple[str, ...]
    diagnostics: Mapping[str, object]


def variant_ids(sequence: str) -> tuple[str, ...]:
    require(sequence and not set(sequence) - set(AA20), "noncanonical WT")
    return tuple(f"{wt}{i+1}{aa}" for i, wt in enumerate(sequence) for aa in AA20 if aa != wt)
