"""Tensor-only portable bundles, loaded with weights_only=True."""
from dataclasses import asdict,fields,is_dataclass,replace
from pathlib import Path
import torch
from r05_internal.cache import H11Cache,PrefixIdentity
from r05_internal.reference.contracts import MemberIdentity,MemberField,NaturalInput,NativeMSA,require,REQUIRED_K

def tree(x,device):
    if isinstance(x,torch.Tensor):return x.detach().to(device)
    if is_dataclass(x):return type(x)(**{f.name:tree(getattr(x,f.name),device) for f in fields(x)})
    if isinstance(x,dict):return {k:tree(v,device) for k,v in x.items()}
    if isinstance(x,tuple):return tuple(tree(v,device) for v in x)
    if isinstance(x,list):return [tree(v,device) for v in x]
    return x

def dump_bundle(path,bundle):
    b=tree(bundle,"cpu")
    out={"schema":"FOURCELL_PREPARED_V1",
         "members":{k:asdict(m) for k,m in b["members"].items()},
         "caches":{k:asdict(c) for k,c in b["caches"].items()},
         "natural":asdict(b["natural"]),"h12":b["h12"],
         "original_logits":{f.member.structure_codebook_size:f.logits25 for f in b["original_fields"]},
         **{n:b[n] for n in ("original_all19l","vectors","asset_role","provenance")}}
    require(not Path(path).exists(),"cache output must be new")
    torch.save(out,path)

def load_bundle(path,device="cpu"):
    p=torch.load(path,map_location="cpu",weights_only=True)
    require(set(p)=={"schema","members","caches","natural","h12","original_logits","original_all19l","vectors",
                     "asset_role","provenance"} and p["schema"]=="FOURCELL_PREPARED_V1","bundle schema")
    members={k:MemberIdentity(**dict(m,vocab=tuple(m["vocab"]))) for k,m in p["members"].items()}
    natural=dict(p["natural"])
    natural["native_msa_by_member"]={n:NativeMSA(**v) for n,v in natural["native_msa_by_member"].items()}
    natural=NaturalInput.from_mapping(natural)
    caches={k:H11Cache(**dict(c,identity=PrefixIdentity(**c["identity"]))) for k,c in p["caches"].items()}
    require(set(members)==set(caches)==set(p["h12"])==set(p["original_logits"])==set(REQUIRED_K),"six cache members")
    for k,c in caches.items():c.validate(members[k],natural)
    b={"members":members,"caches":caches,"natural":natural,
       "original_fields":tuple(MemberField(members[k],p["original_logits"][k]) for k in REQUIRED_K),
       **{n:p[n] for n in ("h12","original_all19l","vectors","asset_role","provenance")}}
    return tree(b,device)
