"""Offline native six-member loader and fresh full-forward prefix provider."""
from __future__ import annotations
from dataclasses import asdict
import inspect
from pathlib import Path
import time
import torch
from r05_internal.cache import PrefixIdentity,H11Cache
from r05_internal.reference.contracts import (
    AA20,REQUIRED_K,MemberIdentity,MemberField,natural_sha256,require,
)
from r05_internal.reference.vrh import FullVRH
from .contracts import read,bound,sha,digest,legacy_tensor_sha,exact_keys

def load_members(lock_path):
    """Called only by released Slurm CLI; never by the local synthetic suite."""
    lock_path=Path(lock_path);lock=read(lock_path)
    exact_keys(lock,("schema","members","torch_version","transformers_version","numpy_version"))
    require(lock["schema"]=="FOURCELL_NATIVE_MEMBERS_V1","member lock schema")
    from transformers import AutoModelForMaskedLM,AutoTokenizer
    import transformers
    import numpy as np
    require(torch.__version__==lock["torch_version"] and transformers.__version__==lock["transformers_version"] and
            np.__version__==lock["numpy_version"],
            "runtime dependency versions must match released lock")
    models={};tokenizers={};members={};receipts={};quantizers={}
    require({int(x["K"]) for x in lock["members"]}==set(REQUIRED_K) and len(lock["members"])==6,"six native members")
    for spec in sorted(lock["members"],key=lambda x:int(x["K"])):
        identity_started=time.perf_counter()
        k=int(spec["K"]);root=Path(spec["root"])
        require(root.is_dir(),"native root missing")
        require({"config.json","modeling_prosst.py","configuration_prosst.py","vocab.txt",
                 "tokenizer_config.json","special_tokens_map.json"}<=set(spec["files_sha256"]),"incomplete native lock")
        for relative,h in spec["files_sha256"].items():
            require(not Path(relative).is_absolute() and ".." not in Path(relative).parts,"relative model file required")
            require(sha(root/relative)==h,"native file SHA "+relative)
        weight_files=spec["weight_files"]
        require(weight_files==["model.safetensors"] and set(weight_files)<=set(spec["files_sha256"]),
                "finite pilot requires the registered single model.safetensors file")
        require(not any(p.name in ("adapter_config.json","adapter_model.safetensors") for p in root.iterdir()),
                "base root must not auto-load an existing adapter")
        weight_sha=spec["files_sha256"][weight_files[0]] if len(weight_files)==1 else digest(
            {name:spec["files_sha256"][name] for name in sorted(weight_files)})
        require(weight_sha==spec["weights_sha256"],"weights identity convention mismatch")
        started=time.perf_counter()
        tokenizer=AutoTokenizer.from_pretrained(root,local_files_only=True,trust_remote_code=True)
        model,loading=AutoModelForMaskedLM.from_pretrained(root,local_files_only=True,trust_remote_code=True,
            output_loading_info=True,torch_dtype=torch.float32,use_safetensors=True)
        require(not any(loading.get(n) for n in ("missing_keys","unexpected_keys","mismatched_keys","error_msgs")),
                "native loading key mismatch")
        actual=Path(inspect.getfile(type(model)))
        require(sha(actual)==spec["modeling_source_sha256"],"actual model source")
        require(sha(Path(inspect.getfile(type(model.config))))==spec["configuration_source_sha256"],"actual config source")
        cfg=model.config
        require(cfg.hidden_size==768 and cfg.num_hidden_layers==12 and cfg.vocab_size==25 and
                cfg.ss_vocab_size==k+3 and cfg.position_embedding_type=="relative" and cfg.relative_attention,
                "registered native dimensions/relative attention")
        model=model.cuda().float().eval().requires_grad_(False)
        vocab=tokenizer.get_vocab()
        require(len(vocab)==25 and set(vocab.values())==set(range(25)) and set(AA20)<=set(vocab),"AA25 vocabulary")
        require(digest(vocab)==spec["tokenizer_sha256"],"vocabulary identity")
        head_sha=digest({n:legacy_tensor_sha(t) for n,t in model.cls.state_dict().items()})
        require(head_sha==spec["head_sha256"],"original full head identity")
        member=MemberIdentity(f"ProSST-{k}",k,k+3,768,tuple(sorted(vocab,key=vocab.get)),
            weight_sha,sha(actual),digest(vocab),head_sha,float(cfg.layer_norm_eps))
        require(all(p.dtype==torch.float32 for p in model.parameters()),"native FP32 only")
        model.prosst.encoder.gradient_checkpointing=False
        models[k]=model;tokenizers[k]=tokenizer;members[k]=member
        quantizers[k]=spec["quantizer_sha256"]
        receipts[k]={"load_seconds":time.perf_counter()-started,"file_identity_seconds":started-identity_started,
                     "identity_and_load_seconds":time.perf_counter()-identity_started,"actual_model_source":str(actual),
                     "member":asdict(member),"loading_info":loading,"config_sha256":sha(root/"config.json"),
                     "tokenizer_class":type(tokenizer).__name__,
                     "head_decoder_tied_to_AA_embeddings":model.cls.predictions.decoder.weight.data_ptr()==model.prosst.embeddings.word_embeddings.weight.data_ptr()}
    return models,tokenizers,members,quantizers,receipts

def inputs(tokenizer,sequence,codes,k,device):
    raw=tokenizer(sequence,return_tensors="pt",return_special_tokens_mask=True,truncation=False)
    ids=raw["input_ids"];special=raw["special_tokens_mask"][0].tolist()
    vocab=tokenizer.get_vocab()
    canonical=[i for i,flag in enumerate(special) if not flag]
    require(len(canonical)==len(sequence) and ids[0,canonical].tolist()==[vocab[a] for a in sequence],"canonical WT tokenization")
    require(len(codes)==len(sequence) and all(type(c) is int and 0<=c<k for c in codes),"complete structure codes")
    ss=torch.full_like(ids,-1)
    ss[0,canonical]=torch.tensor(codes,dtype=torch.long)+3
    mapping={tokenizer.cls_token_id:1,tokenizer.eos_token_id:2,tokenizer.pad_token_id:0}
    for i,flag in enumerate(special):
        if flag:
            require(int(ids[0,i]) in mapping,"unexpected special AA")
            ss[0,i]=mapping[int(ids[0,i])]
    require((ss>=0).all(),"unmapped structure token")
    return {"input_ids":ids.to(device),"ss_input_ids":ss.to(device),
            "attention_mask":raw["attention_mask"].to(device=device,dtype=torch.bool)},torch.tensor(canonical,device=device,dtype=torch.long)

def capture_member(model,tokenizer,member,natural,codes,structure_sha,*,device):
    """Fresh native full forward; exact last-block positional/keyword inputs."""
    args,idx=inputs(tokenizer,natural.wt_sequence,codes,member.structure_codebook_size,device)
    captures=[];heads=[]
    def capture(block,pos,kw):
        require(len(pos)==2,"native last-block positional signature changed")
        expected={"query_states","relative_pos","rel_embeddings","output_attentions","ss_hidden_states"}
        require(set(kw)==expected and kw["query_states"] is None and kw["output_attentions"] is False,"last-block keywords changed")
        captures.append({"h11":pos[0].detach().clone(),"expanded_mask":pos[1].detach().clone(),
            **{n:kw[n].detach().clone() for n in ("relative_pos","rel_embeddings","ss_hidden_states")}})
    hook=model.prosst.encoder.layer[11].register_forward_pre_hook(capture,with_kwargs=True)
    head_hook=model.cls.register_forward_pre_hook(lambda module,pos:heads.append(pos[0].detach().clone()))
    try:
        with torch.no_grad():
            direct=model(**args,return_dict=True,output_hidden_states=False,output_attentions=False).logits.detach()
    finally:
        hook.remove();head_hook.remove()
    require(len(captures)==len(heads)==1,"exact one native capture")
    cap=captures[0]
    ident=PrefixIdentity(member.name,member.weights_sha256,member.source_sha256,member.tokenizer_sha256,
        member.cls_sha256,natural.wt_sha256,natural_sha256(natural),structure_sha,member.structure_codebook_size)
    cache=H11Cache(ident,cap["h11"],args["input_ids"],args["ss_input_ids"],args["attention_mask"],idx,
        cap["expanded_mask"],cap["relative_pos"],cap["rel_embeddings"],cap["ss_hidden_states"]).sealed()
    cache.validate(member,natural)
    return cache,heads[0],direct[0].index_select(0,idx)

def prepare_input(models,tokenizers,members,quantizers,doc,natural,codes):
    require(all(doc["quantizer_sha256_by_k"][str(k)]==quantizers[k] for k in REQUIRED_K),"structure quantizer identity")
    fields=[];cache={};h12={};vectors={}
    started=time.perf_counter()
    for k in REQUIRED_K:
        c,h,logits=capture_member(models[k],tokenizers[k],members[k],natural,codes[k],doc["structure_asset_sha256"],device="cuda")
        cache[k]=c;h12[k]=h;fields.append(MemberField(members[k],logits))
        pooled=h[0].index_select(0,c.canonical_index).mean(0)
        require(torch.isfinite(pooled).all() and pooled.norm()>0,"invalid original pooling norm")
        vectors[k]=(pooled/pooled.norm()).detach().cpu()
    result=FullVRH().score_all19l(tuple(fields),natural,statistics_gradient="full",normalization_universe="complete19L")
    torch.cuda.synchronize()
    return {"members":members,"caches":cache,"h12":h12,"natural":natural,"original_fields":tuple(fields),
            "original_all19l":result.score_all19l.detach(),"vectors":vectors,"asset_role":doc["role"],
            "provenance":{"reference_kind":"fresh_full_original_forward","asset_id":doc["asset_id"],
                "natural_input_sha256":natural_sha256(natural),"structure_asset_sha256":doc["structure_asset_sha256"],
                "prepare_seconds":time.perf_counter()-started}}
