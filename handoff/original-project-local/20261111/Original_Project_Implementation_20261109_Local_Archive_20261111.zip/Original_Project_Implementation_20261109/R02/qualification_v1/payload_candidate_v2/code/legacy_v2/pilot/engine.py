"""Fixed 500-update F-only runner and complete RAW exports; no label evaluator."""
from dataclasses import asdict
from pathlib import Path
import time
import numpy as np
import torch
from r05_internal.suffix import original_pair_risk,PAIR_INTERFACE_VERSION
from r05_internal.reference.contracts import REQUIRED_K,require
from r05_internal.reference.vrh import FullVRH
from .contracts import OPTIMIZER,write,sha,digest,validate_schedule
from .scorer import Scorer

def sync():
    if torch.cuda.is_available():torch.cuda.synchronize()

def optimizer_for(scorer):
    return torch.optim.AdamW(scorer.params.values(),lr=OPTIMIZER["lr"],
        betas=tuple(OPTIMIZER["betas"]),eps=OPTIMIZER["eps"],weight_decay=OPTIMIZER["weight_decay"])

def update(scorer,bundle,cross,within,optimizer):
    sync();started=time.perf_counter();optimizer.zero_grad(set_to_none=True)
    _,result=scorer.score(bundle);device=result.score_all19l.device
    loss=original_pair_risk(result.score_all19l,torch.tensor(cross,device=device,dtype=torch.long),
                            torch.tensor(within,device=device,dtype=torch.long))
    require(torch.isfinite(loss),"nonfinite F loss");sync();forward_end=time.perf_counter()
    loss.backward();sync();backward_end=time.perf_counter()
    norms={}
    for n,p in scorer.params.items():
        require(p.grad is not None and torch.isfinite(p.grad).all(),"missing/nonfinite gradient: "+n)
        norms[n]=float(p.grad.detach().norm())
    norm=torch.nn.utils.clip_grad_norm_(list(scorer.params.values()),OPTIMIZER["clip_norm"],error_if_nonfinite=True)
    optimizer.step();scorer.guard();sync()
    return {"loss":float(loss.detach()),"unclipped_gradient_norm":float(norm),
            "seconds":time.perf_counter()-started,"forward_and_full_vrh_seconds":forward_end-started,
            "backward_seconds":backward_end-forward_end,"gradient_check_and_optimizer_seconds":time.perf_counter()-backward_end,
            "gradient_norms":norms}

def train(models,members,bundles,schedule,init_path,output,*,architecture,seed,training_identity):
    require(all(b["asset_role"]=="SOURCE" for b in bundles.values()),"train accepts SOURCE bundles only")
    validate_schedule(schedule,source_ids=list(bundles),natural_by_id={s:b["natural"] for s,b in bundles.items()},
                      seed=seed)
    scorer=Scorer(models,members,architecture,seed)
    initial_state=torch.load(init_path,map_location="cpu",weights_only=True)
    scorer.restore(initial_state,0)
    optimizer=optimizer_for(scorer);started=time.perf_counter()
    output=Path(output);rows=[]
    for row in schedule["schedule"]:
        rec=update(scorer,bundles[row["source_id"]],row["cross_pairs"],row["within_pairs"],optimizer)
        rec.update(step=row["step"]+1,source_id=row["source_id"])
        rows.append(rec)
        with (output/"updates.jsonl").open("a",encoding="utf-8") as log:
            import json
            log.write(json.dumps(rec,allow_nan=False)+"\n")
    frozen_proof=scorer.verify_frozen()
    torch.save(scorer.state(500),output/"FINAL_500.pt")
    with torch.no_grad():before={s:scorer.score(b)[1].score_all19l.detach().clone() for s,b in bundles.items()}
    final_state=torch.load(output/"FINAL_500.pt",map_location="cpu",weights_only=True)
    scorer.restore(final_state,500)
    from .update_receipt import parameter_update_receipt
    movement=parameter_update_receipt(initial_state,final_state,init_path=init_path,checkpoint_path=output/"FINAL_500.pt",
        frozen_proof=frozen_proof,steps_observed=len(rows))
    movement.update(source_ids=list(bundles),training_identity=training_identity)
    write(output/"PARAMETER_UPDATE_RECEIPT.json",movement)
    with torch.no_grad():
        for s,b in bundles.items():require(torch.equal(before[s],scorer.score(b)[1].score_all19l),"last-state reload mismatch")
    receipt={"schema":"FOURCELL_TRAIN_RECEIPT_V1","status":"TRAIN_COMPLETE_UNEVALUATED",
        "architecture":architecture,"source_ids":list(bundles),"training_identity":training_identity,
        "steps_completed":500,"updates_per_source":{s:sum(r["source_id"]==s for r in rows) for s in bundles},
        "seed":seed,"optimizer":OPTIMIZER,"loss_interface":PAIR_INTERFACE_VERSION,"natural_adaptation_updates":0,
        "normalization":"complete19L","statistics_gradient":"full","init_sha256":sha(init_path),
        "schedule_digest":digest(schedule),"checkpoint_sha256":sha(output/"FINAL_500.pt"),
        "frozen_sha256":scorer.base_hash,"frozen_byte_check_passed":True,"reload_exact":True,
        "parameter_update_receipt_sha256":sha(output/"PARAMETER_UPDATE_RECEIPT.json"),
        "changed_elements":movement["changed_elements"],"all_trainable_tensors_changed":movement["all_trainable_tensors_changed"],
        "elapsed_seconds":time.perf_counter()-started}
    write(output/"TRAIN_RECEIPT.json",receipt)
    return receipt

def export_prediction(output,bundle,fields,result,metadata):
    output=Path(output);arrays={}
    for f in fields:
        k=f.member.structure_codebook_size;c=bundle["caches"][k]
        arrays[f"logits_{k}"]=f.logits25.detach().cpu().numpy()
        arrays[f"logp_{k}"]=f.logp25.detach().cpu().numpy()
        for name in ("input_ids","structure_tokens","token_mask","canonical_index"):
            arrays[f"{name}_{k}"]=getattr(c,name).detach().cpu().numpy()
        arrays[f"special_mask_{k}"]=np.ones(c.input_ids.shape,dtype=bool)
        arrays[f"special_mask_{k}"][0,c.canonical_index.cpu().numpy()]=False
        arrays[f"raw_row_index_{k}"]=np.arange(len(bundle["natural"].wt_sequence),dtype=np.int64)
    natural=bundle["natural"]
    for k in REQUIRED_K:
        msa=natural.native_msa_by_member[bundle["members"][k].name]
        arrays[f"msa_logp25_{k}"]=msa.logp25.detach().cpu().numpy()
        arrays[f"msa_span_{k}"]=np.asarray([msa.aln_start,msa.aln_end],dtype=np.int64)
        arrays[f"structure_code_valid_{k}"]=np.ones(len(natural.wt_sequence),dtype=bool)
    for name in ("adapter_msa_profile","foldseek_mapped_profile","context_mask","context_quality","rsa_weights","plddt_weights"):
        x=getattr(natural,name)
        if x is not None:arrays[name]=x.detach().cpu().numpy()
    arrays.update(member_scores=result.member_scores.detach().cpu().numpy(),
                  member_zscores=result.member_zscores.detach().cpu().numpy(),
                  ensemble=result.score_all19l.detach().cpu().numpy(),
                  variant_ids=np.asarray(result.variant_ids,dtype=str))
    require(all(np.isfinite(a).all() for a in arrays.values() if a.dtype.kind=="f"),"nonfinite export")
    np.savez_compressed(output/"RAW.npz",**arrays)
    with (output/"PREDICTIONS.csv").open("w",encoding="utf-8",newline="") as stream:
        import csv
        writer=csv.writer(stream);writer.writerow(["variant_id","score"])
        writer.writerows(zip(result.variant_ids,arrays["ensemble"].tolist()))
    receipt={"schema":"FOURCELL_PREDICTION_V1","status":"RAW_COMPLETE_UNEVALUATED",
        "protein_id":bundle["natural"].protein_id,"wt_sha256":bundle["natural"].wt_sha256,
        "members":{str(k):asdict(bundle["members"][k]) for k in REQUIRED_K},
        "natural_provenance":bundle["provenance"],
        "structure_quality_fields":{"rsa_weights":natural.rsa_weights is not None,"plddt_weights":natural.plddt_weights is not None,
                                    "encoded_all_canonical_sites":True,"absent_quality_is_not_assumed_high":True},
        "vrh_config":asdict(FullVRH().config),"raw_layout":"canonical [L,25]; input mapping separate",
        "variant_order_digest":digest(list(result.variant_ids)),"score_direction":"higher",
        "coverage":1.0,"n_full19l":len(result.variant_ids),
        "normalization":"complete19L","statistics_gradient":"full","no_functional_labels":True,
        "raw_sha256":sha(output/"RAW.npz"),"csv_sha256":sha(output/"PREDICTIONS.csv"),**metadata}
    write(output/"PREDICTION_RECORD.json",receipt)
    return receipt
