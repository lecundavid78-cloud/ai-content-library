"""Full FP32 AdamW boundary snapshots, not an engine or legacy checkpoint converter."""
import copy
import hashlib
import os
import random
import tempfile
from pathlib import Path
import numpy as np
import torch
from single_source import need,keys,hash64,training_identity,coverage


def content_hash(x):
    h=hashlib.sha256()
    def visit(v):
        if isinstance(v,torch.Tensor):
            t=v.detach().cpu().contiguous();h.update(str((str(t.dtype),tuple(t.shape))).encode());h.update(t.numpy().tobytes())
        elif isinstance(v,dict):
            h.update(b'{')
            for k in sorted(v,key=lambda y:(type(y).__name__,str(y))):visit(k);visit(v[k])
            h.update(b'}')
        elif isinstance(v,(tuple,list)):
            h.update(type(v).__name__.encode())
            for a in v:visit(a)
            h.update(b']')
        else:h.update((type(v).__name__+':'+repr(v)+';').encode())
    visit(x);return h.hexdigest()


def cpu_tree(x):
    if isinstance(x,torch.Tensor):return x.detach().cpu().clone()
    if isinstance(x,dict):return {k:cpu_tree(v) for k,v in x.items()}
    if isinstance(x,list):return [cpu_tree(v) for v in x]
    if isinstance(x,tuple):return tuple(cpu_tree(v) for v in x)
    return copy.deepcopy(x)


def optimizer_layout(params,optimizer,config):
    need(type(optimizer) is torch.optim.AdamW,'only original AdamW supported')
    need(params and all(isinstance(p,torch.nn.Parameter) and p.requires_grad and p.dtype==torch.float32 for p in params.values()),'explicit FP32 trainable whitelist')
    need(len({id(p) for p in params.values()})==len(params),'unique trainable parameters')
    need(all(p.grad is None for p in params.values()),'snapshot boundary requires zero_grad(set_to_none=True)')
    ids={id(p):n for n,p in params.items()};flat=[p for g in optimizer.param_groups for p in g['params']]
    need(len(flat)==len(params) and {id(p) for p in flat}==set(ids),'optimizer must contain exactly trainable whitelist')
    groups=[]
    for g in optimizer.param_groups:
        need(g['lr']==config['lr'] and list(g['betas'])==[.9,.999] and g['eps']==1e-8 and g['weight_decay']==0 and not g.get('amsgrad',False)
             and not g.get('maximize',False) and not g.get('capturable',False) and not g.get('differentiable',False),'optimizer configuration mismatch')
        groups.append([ids[id(p)] for p in g['params']])
    return groups


def capture_rng():
    n=np.random.get_state()
    return {'python':random.getstate(),'numpy':{'kind':n[0],'keys':n[1].tolist(),'position':n[2],'has_gauss':n[3],'cached_gaussian':n[4]},
            'torch_cpu':torch.get_rng_state(),'cuda':torch.cuda.get_rng_state_all() if torch.cuda.is_initialized() else []}


def set_rng(rng):
    random.setstate(rng['python']);n=rng['numpy']
    np.random.set_state((n['kind'],np.asarray(n['keys'],dtype=np.uint32),n['position'],n['has_gauss'],n['cached_gaussian']))
    torch.set_rng_state(rng['torch_cpu'])
    if rng['cuda']:torch.cuda.set_rng_state_all(rng['cuda'])


def validate_optimizer_state(state,params,layout,config,completed):
    need(set(state)=={'state','param_groups'} and len(state['param_groups'])==len(layout),'optimizer snapshot schema')
    allids=[]
    for g,names in zip(state['param_groups'],layout):
        need(len(g['params'])==len(names) and g['lr']==config['lr'] and list(g['betas'])==[.9,.999] and g['eps']==1e-8 and g['weight_decay']==0,'saved optimizer group configuration')
        need(not any(g.get(k,False) for k in ('amsgrad','maximize','capturable','differentiable')),'unsupported saved optimizer flags')
        allids.extend(g['params'])
        for pid,name in zip(g['params'],names):
            if completed==0:
                need(pid not in state['state'],'step0 AdamW must have fresh state');continue
            s=state['state'].get(pid);need(isinstance(s,dict) and set(s)=={'step','exp_avg','exp_avg_sq'},'complete AdamW moments required')
            need(isinstance(s['step'],torch.Tensor) and s['step'].numel()==1 and float(s['step'])==completed,'AdamW counter differs from completed updates')
            for key in ('exp_avg','exp_avg_sq'):
                x=s[key];p=params[name]
                need(isinstance(x,torch.Tensor) and x.shape==p.shape and x.dtype==p.dtype and torch.isfinite(x).all().item(),'invalid AdamW moments')
            need((s['exp_avg_sq']>=0).all().item(),'negative second moment')
    need(len(set(allids))==len(allids) and set(state['state'])==(set(allids) if completed else set()),'unexpected optimizer state entries')


def capture(config,schedule,params,optimizer,*,frozen_sha256,attempts,completed_updates):
    tid,identity=training_identity(config,schedule);need(hash64(frozen_sha256),'frozen base fingerprint required from original scorer.verify_frozen')
    cov=coverage(config,schedule,attempts=attempts,completed_updates=completed_updates)
    layout=optimizer_layout(params,optimizer,config);opt=cpu_tree(optimizer.state_dict())
    validate_optimizer_state(opt,params,layout,config,completed_updates)
    tensors={n:p.detach().cpu().clone() for n,p in params.items()}
    need(all(torch.isfinite(t).all().item() for t in tensors.values()),'nonfinite trainable parameters')
    result={'schema':'SINGLE_SOURCE_RESUME_V1','training_id':tid,'identity':identity,'frozen_sha256':frozen_sha256,
            'parameters':tensors,'optimizer':opt,'optimizer_layout':layout,'rng':capture_rng(),
            'completed_updates':completed_updates,'attempts':attempts,'next_schedule_index':completed_updates,
            'coverage':cov,'scheduler':None,'scaler':None,
            'environment':{'torch':str(torch.__version__),'numpy':str(np.__version__)}}
    result['content_sha256']=content_hash(result);return result


def restore(state,config,schedule,params,optimizer,*,frozen_sha256):
    keys(state,('schema','training_id','identity','frozen_sha256','parameters','optimizer','optimizer_layout','rng',
                'completed_updates','attempts','next_schedule_index','coverage','scheduler','scaler','environment','content_sha256'))
    need(state['schema']=='SINGLE_SOURCE_RESUME_V1','reject dual-source/adapter-only legacy checkpoints')
    need(content_hash({k:v for k,v in state.items() if k!='content_sha256'})==state['content_sha256'],'resume content digest mismatch')
    tid,identity=training_identity(config,schedule)
    need(state['training_id']==tid and state['identity']==identity,'source/config/schedule/runtime identity mismatch')
    need(state['frozen_sha256']==frozen_sha256 and hash64(frozen_sha256),'frozen base mismatch')
    need(state['scheduler'] is None and state['scaler'] is None,'FP32 no scheduler/scaler contract')
    need(state['environment']=={'torch':str(torch.__version__),'numpy':str(np.__version__)},'runtime versions changed')
    done=state['completed_updates']
    need(state['coverage']==coverage(config,schedule,attempts=state['attempts'],completed_updates=done) and state['next_schedule_index']==done,'coverage/cursor mismatch')
    layout=optimizer_layout(params,optimizer,config)
    need(layout==state['optimizer_layout'] and set(params)==set(state['parameters']),'trainable whitelist/order mismatch')
    for n,p in params.items():
        x=state['parameters'][n];need(isinstance(x,torch.Tensor) and x.shape==p.shape and x.dtype==p.dtype and torch.isfinite(x).all().item(),'invalid resume trainable tensor')
    validate_optimizer_state(state['optimizer'],params,layout,config,done)
    # Validate RNG without perturbing the live streams, before parameter mutations.
    rng=state['rng'];keys(rng,('python','numpy','torch_cpu','cuda'))
    random.Random().setstate(rng['python']);n=rng['numpy']
    np.random.RandomState().set_state((n['kind'],np.asarray(n['keys'],dtype=np.uint32),n['position'],n['has_gauss'],n['cached_gaussian']))
    torch.Generator(device='cpu').set_state(rng['torch_cpu'])
    need(not rng['cuda'] or (torch.cuda.is_initialized() and len(rng['cuda'])==torch.cuda.device_count()),'CUDA RNG device inventory mismatch')
    # Caller must fail closed if runtime loading errors: never continue a partial restore.
    with torch.no_grad():
        for n,p in params.items():p.copy_(state['parameters'][n].to(p.device))
    optimizer.load_state_dict(copy.deepcopy(state['optimizer']));set_rng(rng)
    return {'training_id':tid,'next_schedule_index':done,'attempts':state['attempts'],'completed_updates':done}


def save_new(path,state):
    """Publish only fully written/fsynced bytes, atomically without replacing any file."""
    path=Path(path);need(not path.exists(),'never overwrite checkpoint')
    need(content_hash({k:v for k,v in state.items() if k!='content_sha256'})==state['content_sha256'],'refuse corrupt state')
    descriptor,tmp=tempfile.mkstemp(prefix='.'+path.name+'.',suffix='.incomplete',dir=path.parent)
    tmp=Path(tmp)
    try:
        with os.fdopen(descriptor,'wb') as f:
            torch.save(state,f);f.flush();os.fsync(f.fileno())
        # Same-directory hard link is an atomic, no-replace publication on the required filesystem.
        # No copy/replace fallback: unsupported filesystems fail closed, leaving final path absent.
        os.link(tmp,path)
        directory_synced=False
        if os.name=='posix':
            directory=os.open(path.parent,os.O_RDONLY)
            try:os.fsync(directory);directory_synced=True
            finally:os.close(directory)
        return {'published':True,'file_fsync':True,'directory_fsync':directory_synced,
                'publication':'same_directory_hard_link_no_replace'}
    finally:
        tmp.unlink(missing_ok=True)


def load(path):return torch.load(path,map_location='cpu',weights_only=True)
