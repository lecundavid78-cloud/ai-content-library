"""Mocked orchestration only; no native model or CUDA operation is executed."""
import json
from pathlib import Path
from types import SimpleNamespace
import tempfile
import unittest
from unittest.mock import patch
import torch
from torch import nn
import batch_qualification as bq
from pilot.contracts import sha,read
from r05_internal.reference.contracts import ContractError,REQUIRED_K


class BatchQualificationTests(unittest.TestCase):
    def run_batch(self,root,fail_at=None,mutate_at=None):
        ids=['source_%02d'%i for i in range(18)];assets=[]
        for sid in ids:
            f=root/(sid+'.json');f.write_text(json.dumps({'asset_id':sid}));assets.append({'path':str(f),'sha256':sha(f)})
        out=root/'out';out.mkdir();models={k:nn.Linear(2,2).requires_grad_(False).eval() for k in REQUIRED_K};calls=[]
        def asset(path):
            sid=read(path)['asset_id']
            return {'asset_id':sid,'role':'SOURCE_POOL'},SimpleNamespace(wt_sequence='ACDE',wt_sha256='a'*64),{20:[0]*4}
        def prepare(models,tokens,members,quantizers,doc,natural,codes):
            return {'sid':doc['asset_id'],'provenance':{'natural_input_sha256':'b'*64,'structure_asset_sha256':'c'*64}}
        def qualify(models,tokens,members,bundle,codes,work,seed):
            self.assertFalse(any(p.requires_grad or p.grad is not None for m in models.values() for p in m.parameters()))
            calls.append(bundle['sid'])
            if len(calls)==fail_at:raise RuntimeError('synthetic source gradient failure')
            if len(calls)==mutate_at:
                with torch.no_grad():next(models[20].parameters()).add_(1)
            return {'status':'REAL_QUALIFICATION_PASS_NOT_TRAINING_ADMISSION','architecture':{'S':{},'L':{}},'qualification_seconds':.25}
        patches=[patch.object(bq,'natural_asset',side_effect=asset),patch.object(bq,'prepare_input',side_effect=prepare),
            patch.object(bq,'full_span_evidence',return_value={'WT_length':4}),
            patch.object(bq,'dump_bundle',side_effect=lambda f,b:f.write_bytes(b'fake-bundle')),
            patch.object(bq,'qualify',side_effect=qualify)]
        for name in ('synchronize','reset_peak_memory_stats','empty_cache'):
            patches.append(patch.object(torch.cuda,name,return_value=None))
        for name in ('max_memory_allocated','max_memory_reserved'):
            patches.append(patch.object(torch.cuda,name,return_value=0))
        from contextlib import ExitStack
        with ExitStack() as stack:
            for p in patches:stack.enter_context(p)
            if fail_at or mutate_at:
                with self.assertRaises((RuntimeError,ContractError)):
                    bq.qualify_batch(models,{}, {},{},assets,ids,11,out,root,'d'*64,'e'*64)
                result=read(out/'BATCH_QUALIFICATION_INDEX.json')
            else:result=bq.qualify_batch(models,{}, {},{},assets,ids,11,out,root,'d'*64,'e'*64)
        return result,calls,out

    def test_all18_distinct_real_qualification_calls_and_receipt_bindings(self):
        with tempfile.TemporaryDirectory() as tmp:
            result,calls,out=self.run_batch(Path(tmp))
            self.assertEqual(len(calls),18);self.assertEqual(len(set(calls)),18)
            self.assertEqual(result['completed_source_qualifications'],18);self.assertEqual(result['qualification_calls'],18)
            self.assertEqual(result['status'],'ALL18_REAL_QUALIFICATION_PASS_NOT_TRAINING_ADMISSION')
            self.assertEqual(result['pending_source_ids'],[])
            for sid,row in result['sources'].items():
                q=read(row['qualification']['path']);self.assertEqual(q['probe_asset_id'],sid)
                self.assertEqual(row['qualification']['sha256'],sha(row['qualification']['path']))
                self.assertEqual(q['native_lock_sha256'],'d'*64);self.assertTrue(q['cross_source_base_reset_verified'])

    def test_source_failure_preserves_two_passes_and_stops_not18cache_claim(self):
        with tempfile.TemporaryDirectory() as tmp:
            result,calls,out=self.run_batch(Path(tmp),fail_at=3)
            self.assertEqual(len(calls),3);self.assertEqual(len(result['sources']),2)
            self.assertEqual(result['completed_source_qualifications'],2);self.assertEqual(len(result['pending_source_ids']),16)
            self.assertEqual(result['failure']['phase'],'independent_S_and_L_gradient_qualification')
            self.assertEqual(result['status'],'BATCH_TECHNICAL_FAILURE_NOT_ALL_SOURCES_QUALIFIED')
            self.assertTrue((out/'sources/SOURCE_02/SOURCE_FAILURE.json').is_file())

    def test_mutated_base_stops_before_next_source_and_no_false_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            result,calls,out=self.run_batch(Path(tmp),mutate_at=1)
            self.assertEqual(len(calls),1);self.assertEqual(result['sources'],{})
            self.assertEqual(result['failure']['error_type'],'ContractError')

    def test_incomplete18_rejected_and_live_LoRA_rejected(self):
        with self.assertRaises(ContractError):bq.qualify_batch({}, {},{},{},[],['x'],11,Path('.'),Path('.'),'d'*64,'e'*64)
        from r05_internal.lora import UnmergedLoRALinear
        model=nn.Sequential(UnmergedLoRALinear(nn.Linear(2,2),seed=11,rank=1,alpha=1))
        with self.assertRaisesRegex(ContractError,'LoRA was not uninstalled'):bq.clean_base({20:model})


if __name__=='__main__':unittest.main()
