"""CPU-only synthetic checks. Never imports or constructs a real protein model."""
import copy
from dataclasses import replace
import hashlib
import io
import json
from pathlib import Path
import unittest
import torch
from torch import nn
from r05_internal.lora import (
    UnmergedLoRALinear, install_last_qv, assert_whitelist, frozen_fingerprint,
    export_adapter_state, load_adapter_state, PARAMETER_COUNT, PATHS,
)
from r05_internal.cache import PrefixIdentity, H11Cache
from r05_internal.suffix import score_full19l, original_pair_risk, PAIR_INTERFACE_VERSION
from r05_internal.reference.contracts import (
    AA20, REQUIRED_K, ContractError, MemberIdentity, NativeMSA, NaturalInput,
    MemberField, sequence_sha256, natural_sha256,
)
from r05_internal.reference.vrh import FullVRH

EVIDENCE = {}
def sha(text): return hashlib.sha256(text.encode()).hexdigest()

class ToySelfAttention(nn.Module):
    def __init__(self):
        super().__init__()
        self.query, self.key, self.value = (nn.Linear(768, 768) for _ in range(3))
    def forward(self, x, mask, ss):
        q, k, v = self.query(x), self.key(x), self.value(x)
        logits = (q @ k.transpose(-1, -2) + q @ ss.transpose(-1, -2)) / (768 ** 0.5)
        weights = logits.masked_fill(~mask[:, 0], float("-inf")).softmax(-1)
        weights = weights.masked_fill(~mask[:, 0], 0)
        return weights @ v

class ToyBlock(nn.Module):
    """Signature fixture only; NOT the original ProSST block or its replica."""
    def __init__(self):
        super().__init__()
        self.attention = nn.Module()
        self.attention.self = ToySelfAttention()
        self.output = nn.Linear(768, 768)
    def forward(self, hidden_states, attention_mask, query_states=None, relative_pos=None,
                rel_embeddings=None, output_attentions=False, ss_hidden_states=None):
        assert query_states is None and output_attentions is False
        return hidden_states + .2 * torch.tanh(self.output(
            self.attention.self(hidden_states, attention_mask, ss_hidden_states)))

class ToyMember(nn.Module):
    def __init__(self):
        super().__init__()
        self.prosst = nn.Module()
        self.prosst.encoder = nn.Module()
        self.prosst.encoder.layer = nn.ModuleList([nn.Identity() for _ in range(11)] + [ToyBlock()])
        self.prosst.encoder.gradient_checkpointing = False
        self.cls = nn.Sequential(nn.Linear(768, 64), nn.GELU(), nn.LayerNorm(64), nn.Linear(64, 25))

def fixture():
    torch.manual_seed(41)
    sequence = "ACDEFGH"  # deliberately tiny synthetic alphabet string, no protein asset
    vocab = ("<pad>", "<cls>", "<eos>", "<unk>", "<mask>") + tuple(AA20)
    models = {k: ToyMember().cpu().eval() for k in REQUIRED_K}
    members = {k: MemberIdentity("synthetic_" + str(k), k, k+3, 768, vocab,
        sha(f"synthetic-weights-{k}"), sha("synthetic-source"), sha("synthetic-vocab"),
        sha(f"synthetic-head-{k}")) for k in REQUIRED_K}
    L, T = len(sequence), len(sequence)+2
    native_msa = {m.name: NativeMSA(torch.randn(L,25).log_softmax(-1), 0, L, "synthetic")
                  for m in members.values()}
    natural = NaturalInput("synthetic_only", sequence, sequence_sha256(sequence), native_msa,
        torch.zeros(L,20), torch.zeros(L,20), torch.zeros(L,2,dtype=torch.bool),
        torch.zeros(L,4), torch.linspace(.1,.9,L), torch.linspace(.65,.95,L),
        {"origin":"synthetic-generated-no-real-assets"})
    caches = {}
    for k in REQUIRED_K:
        m = members[k]
        ident = PrefixIdentity(m.name,m.weights_sha256,m.source_sha256,m.tokenizer_sha256,m.cls_sha256,
            natural.wt_sha256,natural_sha256(natural),sha(f"synthetic-structure-{k}"),k)
        ids = torch.tensor([[vocab.index("<cls>")] + [vocab.index(a) for a in sequence] + [vocab.index("<eos>")]])
        structure = torch.tensor([[1] + [3+(i % k) for i in range(L)] + [2]])
        idx = torch.arange(1,L+1)
        token_mask = torch.ones(1,T,dtype=torch.bool)
        offsets = torch.arange(T)
        caches[k] = H11Cache(ident, torch.randn(1,T,768), ids, structure, token_mask, idx,
            token_mask[:,None,:,None] & token_mask[:,None,None,:],
            (offsets[:,None]-offsets[None,:])[None], torch.randn(32,768),
            torch.randn(1,T,768)).sealed()
    return models, members, caches, natural

def original_scores(models, members, caches, natural):
    fields = []
    for k in REQUIRED_K:
        c, model = caches[k], models[k]
        h = model.prosst.encoder.layer[11](c.h11, attention_mask=c.expanded_mask,
            query_states=None, relative_pos=c.relative_pos, rel_embeddings=c.rel_embeddings,
            output_attentions=False, ss_hidden_states=c.ss_hidden_states)
        fields.append(MemberField(members[k], model.cls(h)[0].index_select(0,c.canonical_index)))
    return FullVRH().score_all19l(fields,natural).score_all19l

def synthetic_loss(scores):
    cross = torch.tensor([[0,22],[39,60],[81,100],[110,125]],dtype=torch.long)
    within = torch.tensor([[1,7],[24,30],[44,50]],dtype=torch.long)
    return original_pair_risk(scores,cross,within)
