"""Finite four-cell production wiring; real entry points require released Slurm jobs."""
