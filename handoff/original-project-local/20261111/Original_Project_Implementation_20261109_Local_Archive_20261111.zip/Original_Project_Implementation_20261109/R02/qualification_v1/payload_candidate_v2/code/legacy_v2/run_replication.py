"""Finite stage entry using original native/provider/scorer; no SSH or submitter."""
from pathlib import Path
import argparse
import os
import signal
import time
import traceback
import torch
from pilot.contracts import bound,read,write,sha,digest,natural_asset,exact_keys,validate_schedule
from pilot.storage import load_bundle,dump_bundle,tree
from r05_internal.reference.contracts import require
from replication_contract import verify,seed_value,source_roles,scoring_edge,training_key


def admit_bundle(b,meta,native_sha):
    require(b['natural'].protein_id==meta['id'] and b['natural'].wt_sha256==meta['wt_sha256']
        and len(b['natural'].wt_sequence)==meta['length'],'exact bundle reference identity')
    require(b['provenance'].get('native_lock_sha256')==native_sha,'original native lock identity')


def main():
    p=argparse.ArgumentParser();p.add_argument('--job',required=True);p.add_argument('--release',required=True);a=p.parse_args()
    root=Path(__file__).resolve().parent
    job,r,native,code_sha=verify(a.job,a.release,root,os.environ.get('SLURM_JOB_ID',''))
    base=Path(a.job).resolve().parent;out=Path(job['output']);out.mkdir(parents=True)
    started=time.perf_counter();stage=job['stage'];conf=job['config'];native_sha=sha(native)
    identity={'job_sha256':sha(a.job),'release_sha256':sha(a.release),'code_ready_sha256':job['code_ready']['sha256'],
        'code_manifest_sha256':code_sha,'native_lock_sha256':native_sha,'stage':stage,'slurm_job_id':os.environ['SLURM_JOB_ID'],'status':'RUNNING'}
    write(out/'JOB_RECEIPT.json',identity)
    if hasattr(signal,'SIGALRM'):
        signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('controller wall budget exhausted')));signal.alarm(r['wall_seconds'])
    try:
        os.environ.update(HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HOME=str(out/'hf_local'),HF_MODULES_CACHE=str(out/'hf_modules'))
        require(torch.cuda.is_available() and torch.cuda.device_count()==1,'exact one allocated CUDA GPU')
        torch.set_num_threads(int(os.environ.get('SLURM_CPUS_PER_TASK','1')))
        torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cudnn.benchmark=False
        torch.use_deterministic_algorithms(True);torch.cuda.reset_peak_memory_stats()
        from pilot.provider import load_members,prepare_input
        from pilot.scorer import Scorer,uninstall_lora
        if stage=='qualify_batch':
            exact_keys(conf,('assets','source_ids','seed'))
            models,tokens,members,quantizers,loads=load_members(native);write(out/'NATIVE_LOAD_RECEIPT.json',loads)
            from batch_qualification import qualify_batch
            qualify_batch(models,tokens,members,quantizers,conf['assets'],conf['source_ids'],seed_value(conf['seed']),
                out,base,native_sha,code_sha)
        elif stage in ('qualify','cache'):
            exact_keys(conf,('assets','probe_asset_id','seed') if stage=='qualify' else ('assets',))
            models,tokens,members,quantizers,loads=load_members(native);write(out/'NATIVE_LOAD_RECEIPT.json',loads)
            require(conf['assets'],'nonempty natural assets');index={};evidence={};probe=None;probe_codes=None
            from long_sequence import full_span_evidence
            for i,spec in enumerate(conf['assets']):
                asset=bound(spec,base);doc,natural,codes=natural_asset(asset);sid=doc['asset_id']
                require(sid not in index,'unique natural entity')
                b=prepare_input(models,tokens,members,quantizers,doc,natural,codes)
                b['provenance']['native_lock_sha256']=native_sha
                evidence[sid]=full_span_evidence(models,b)
                name=f'CACHE_{i:03d}.pt';dump_bundle(out/name,b)
                index[sid]={'path':name,'sha256':sha(out/name),'asset_sha256':sha(asset),'prepare_seconds':b['provenance']['prepare_seconds']}
                if stage=='qualify' and sid==conf['probe_asset_id']:probe=b;probe_codes=codes
                else:del b
            write(out/'CACHE_INDEX.json',index);write(out/'FULL_SPAN_EVIDENCE.json',evidence)
            if stage=='qualify':
                require(probe is not None,'exact qualification probe')
                from pilot.qualification import qualify
                q=qualify(models,tokens,members,probe,probe_codes,out,seed_value(conf['seed']))
                q.update(probe_asset_id=conf['probe_asset_id'],native_lock_sha256=native_sha,code_manifest_sha256=code_sha,
                    full_WT_length=len(probe['natural'].wt_sequence),wt_sha256=probe['natural'].wt_sha256,
                    natural_input_sha256=probe['provenance']['natural_input_sha256'],
                    structure_asset_sha256=probe['provenance']['structure_asset_sha256'],
                    full_span_evidence_sha256=sha(out/'FULL_SPAN_EVIDENCE.json'))
                write(out/'QUALIFICATION_RECEIPT.json',q)
        elif stage=='init':
            exact_keys(conf,('seeds',));require(conf['seeds']==[11,23,47],'all three fixed initializations')
            models,tokens,members,quantizers,loads=load_members(native);write(out/'NATIVE_LOAD_RECEIPT.json',loads);index={}
            for seed in conf['seeds']:
                for architecture in ('S','L'):
                    scorer=Scorer(models,members,architecture,seed);name=f'INIT_{architecture}_{seed}.pt'
                    torch.save(scorer.state(0),out/name);scorer.verify_frozen()
                    index[f'{architecture}:{seed}']={'path':name,'sha256':sha(out/name),'seed':seed,'architecture':architecture,'step':0}
                    if architecture=='L':uninstall_lora(models)
                    del scorer
            write(out/'INIT_INDEX.json',index)
        elif stage=='train':
            exact_keys(conf,('sources','architecture','seed','schedule','init','bundles','qualifications'))
            sources=source_roles(conf['sources']);seed=seed_value(conf['seed']);arch=conf['architecture']
            sp=bound(conf['schedule'],base);schedule=read(sp);init=bound(conf['init'],base)
            require(set(conf['bundles'])=={s['id'] for s in sources},'source-only bundle mounts')
            bundles={}
            for meta in sources:
                sid=meta['id'];b=load_bundle(bound(conf['bundles'][sid],base),'cuda');admit_bundle(b,meta,native_sha)
                require(b['asset_role'] in ('SOURCE','SOURCE_POOL'),'only source role bundles in training')
                bundles[sid]=dict(b,asset_role='SOURCE')
            validate_schedule(schedule,source_ids=list(bundles),natural_by_id={s:b['natural'] for s,b in bundles.items()},seed=seed)
            require(set(conf['qualifications'])==set(bundles),'each source needs actual span/gradient qualification')
            qualification_hashes={}
            for sid,spec in conf['qualifications'].items():
                qp=bound(spec,base);q=read(qp)
                require(q['status']=='REAL_QUALIFICATION_PASS_NOT_TRAINING_ADMISSION' and q['probe_asset_id']==sid
                    and q['native_lock_sha256']==native_sha and q['code_manifest_sha256']==code_sha
                    and q['full_WT_length']==len(bundles[sid]['natural'].wt_sequence)
                    and q['wt_sha256']==bundles[sid]['natural'].wt_sha256
                    and q['natural_input_sha256']==bundles[sid]['provenance']['natural_input_sha256']
                    and q['structure_asset_sha256']==bundles[sid]['provenance']['structure_asset_sha256'],'exact source real qualification')
                qualification_hashes[sid]=sha(qp)
            key,training_identity=training_key(sources=sources,bundles=conf['bundles'],schedule_sha256=sha(sp),init_sha256=sha(init),
                architecture=arch,seed=seed,native_sha256=native_sha,code_manifest_sha256=code_sha)
            write(out/'TRAINING_IDENTITY.json',dict(training_identity,training_id=key))
            models,tokens,members,quantizers,loads=load_members(native);write(out/'NATIVE_LOAD_RECEIPT.json',loads)
            from pilot.engine import train
            receipt=train(models,members,bundles,schedule,init,out,architecture=arch,seed=seed,training_identity=training_identity)
            receipt.update(training_id=key,source_metadata=sources,schedule_sha256=sha(sp),native_lock_sha256=native_sha,
                code_manifest_sha256=code_sha,qualification_sha256_by_source=qualification_hashes)
            write(out/'TRAIN_RECEIPT.json',receipt)
        elif stage=='predict':
            exact_keys(conf,('condition','target','bundle','checkpoint','train_receipt'))
            from replication_contract import role_meta
            meta=role_meta(conf['target']);require(meta['id'] in ('TnpB','AsCas12f','SpCas9'),'three targets only')
            bp=bound(conf['bundle'],base);b=load_bundle(bp,'cuda');admit_bundle(b,meta,native_sha)
            require(b['asset_role']=='TARGET','prediction only target-role bundle')
            from pilot.engine import export_prediction
            from r05_internal.reference.vrh import FullVRH
            metadata={**identity,'condition':conf['condition'],'target_id':meta['id'],'target_metadata':meta,
                'prepared_bundle_sha256':sha(bp)};metadata.pop('status')
            if conf['condition']=='Original':
                require(conf['checkpoint'] is None and conf['train_receipt'] is None,'Original has no checkpoint')
                fields=b['original_fields'];result=FullVRH().score_all19l(fields,b['natural'])
                require(torch.equal(result.score_all19l,b['original_all19l']),'exact Original replay')
                metadata.update(active_adaptation=False,seed=None,steps_completed=0)
            else:
                trp=bound(conf['train_receipt'],base);tr=read(trp);ck=bound(conf['checkpoint'],base)
                require(tr['status']=='TRAIN_COMPLETE_UNEVALUATED' and tr['steps_completed']==500 and tr['checkpoint_sha256']==sha(ck)
                    and tr['native_lock_sha256']==native_sha and tr['code_manifest_sha256']==code_sha,'successful exact final state')
                ti=tr['training_identity']
                require(tr['training_id']==digest(ti) and sorted(tr['source_metadata'],key=lambda s:s['id'])==ti['sources']
                    and tr['architecture']==ti['architecture'] and tr['seed']==ti['seed'],'complete training identity consistency')
                scoring_edge(tr['source_metadata'],meta)
                require(conf['condition'] in ('A1','A2','A3','A4') and tr['architecture']==('S' if conf['condition'] in ('A1','A3') else 'L'),'scoring cell architecture')
                models,tokens,members,quantizers,loads=load_members(native);write(out/'NATIVE_LOAD_RECEIPT.json',loads)
                scorer=Scorer(models,members,tr['architecture'],seed_value(tr['seed']))
                scorer.restore(torch.load(ck,map_location='cpu',weights_only=True),500)
                with torch.no_grad():fields,result=scorer.score(b)
                scorer.verify_frozen()
                metadata.update(active_adaptation=True,architecture=tr['architecture'],seed=tr['seed'],training_id=tr['training_id'],
                    train_receipt_sha256=sha(trp),checkpoint_sha256=sha(ck),training=tr)
            export_prediction(out,b,fields,result,metadata)
        identity['status']='COMPLETED_UNEVALUATED'
    except BaseException as exc:
        identity.update(status='TECHNICAL_FAILURE',error_type=type(exc).__name__,error=str(exc))
        (out/'FAILURE.txt').write_text(traceback.format_exc(),encoding='utf-8');raise
    finally:
        if hasattr(signal,'SIGALRM'):signal.alarm(0)
        identity['wall_seconds']=time.perf_counter()-started
        if torch.cuda.is_available():
            identity['peak_allocated_bytes']=torch.cuda.max_memory_allocated();identity['peak_reserved_bytes']=torch.cuda.max_memory_reserved()
        write(out/'JOB_RECEIPT.json',identity)


if __name__=='__main__':main()
