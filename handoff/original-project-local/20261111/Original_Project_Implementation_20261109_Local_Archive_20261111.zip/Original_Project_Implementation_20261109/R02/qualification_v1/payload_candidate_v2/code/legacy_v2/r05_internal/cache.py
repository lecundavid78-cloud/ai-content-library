"""h11 input contract, intentionally incompatible with old h12 cache containers."""
from __future__ import annotations
from dataclasses import asdict, dataclass, replace
import hashlib
import json
import torch
from .reference.contracts import (
    AA20, MemberIdentity, NaturalInput, constant_tensor, natural_sha256,
    require, tensor_sha256,
)

@dataclass(frozen=True)
class PrefixIdentity:
    member_name: str
    weights_sha256: str
    source_sha256: str
    tokenizer_sha256: str
    head_sha256: str
    sequence_sha256: str
    natural_input_sha256: str
    structure_asset_sha256: str
    structure_codebook_size: int
    role: str = "wt"
    layer_index: int = 11
    encoder_mode: str = "eval"
    schema: str = "r05-h11-input-v1"
    mask_plan_sha256: str | None = None

@dataclass(frozen=True)
class H11Cache:
    identity: PrefixIdentity
    h11: torch.Tensor
    input_ids: torch.Tensor
    structure_tokens: torch.Tensor
    token_mask: torch.Tensor
    canonical_index: torch.Tensor
    expanded_mask: torch.Tensor
    relative_pos: torch.Tensor
    rel_embeddings: torch.Tensor
    ss_hidden_states: torch.Tensor
    content_sha256: str = ""
    query_states: None = None

    def digest(self):
        meta = json.dumps(asdict(self.identity), sort_keys=True, separators=(",", ":"))
        dig = hashlib.sha256(meta.encode())
        for name in ("h11", "input_ids", "structure_tokens", "token_mask", "canonical_index",
                     "expanded_mask", "relative_pos", "rel_embeddings", "ss_hidden_states"):
            dig.update(f"{name}:{tensor_sha256(getattr(self, name))}\n".encode())
        return dig.hexdigest()

    def sealed(self):
        return replace(self, content_sha256=self.digest())

    def validate(self, member: MemberIdentity, natural: NaturalInput):
        """First phase admits WT caches only; no implicit natural/masked pipeline."""
        natural.validate()
        ident = self.identity
        require(ident.schema == "r05-h11-input-v1" and ident.layer_index == 11, "not a last-block input cache")
        require(ident.encoder_mode == "eval" and ident.role == "wt" and ident.mask_plan_sha256 is None,
                "phase A requires unmasked WT/eval cache")
        require(self.query_states is None, "nonstandard query_states not admitted")
        require(ident.member_name == member.name and ident.structure_codebook_size == member.structure_codebook_size,
                "member identity mismatch")
        for field, expected in (
            ("weights_sha256", member.weights_sha256), ("source_sha256", member.source_sha256),
            ("tokenizer_sha256", member.tokenizer_sha256), ("head_sha256", member.cls_sha256),
            ("sequence_sha256", natural.wt_sha256), ("natural_input_sha256", natural_sha256(natural))):
            require(getattr(ident, field) == expected, f"{field} mismatch")
        require(len(ident.structure_asset_sha256) == 64 and
                all(c in "0123456789abcdef" for c in ident.structure_asset_sha256), "structure hash required")
        for name in ("h11", "input_ids", "structure_tokens", "token_mask", "canonical_index",
                     "expanded_mask", "relative_pos", "rel_embeddings", "ss_hidden_states"):
            constant_tensor(getattr(self, name), name)
        h = self.h11
        require(h.ndim == 3 and h.shape[0] == 1 and h.shape[2] == 768, "h11 must be [1,T,768]")
        require(h.dtype in (torch.float32, torch.float64), "initial cache supports FP32/64 only")
        T, L = h.shape[1], len(natural.wt_sequence)
        for name in ("input_ids", "structure_tokens"):
            x = getattr(self, name)
            require(x.shape == (1, T) and x.dtype == torch.long, f"{name}: [1,T] int64 required")
        require(self.token_mask.shape == (1, T) and self.token_mask.dtype == torch.bool, "bad token mask")
        require(self.expanded_mask.shape == (1, 1, T, T) and self.expanded_mask.dtype == torch.bool,
                "expanded mask must be [1,1,T,T] bool")
        outer = self.token_mask[:, None, :, None] & self.token_mask[:, None, None, :]
        require(torch.equal(outer, self.expanded_mask), "expanded mask differs from encoder rule")
        idx = self.canonical_index
        require(idx.dtype == torch.long and idx.shape == (L,) and idx.unique().numel() == L,
                "invalid canonical mapping")
        require(((idx >= 0) & (idx < T)).all() and self.token_mask[0, idx].all(), "canonical padding/out of range")
        aa = torch.tensor([member.vocab.index(a) for a in natural.wt_sequence], device=idx.device)
        require(torch.equal(self.input_ids[0, idx], aa), "WT-AA or token mapping mismatch")
        require(((self.input_ids >= 0) & (self.input_ids < 25)).all(), "AA token out of vocabulary")
        structure = self.structure_tokens[0, idx]
        require(((structure >= 3) & (structure < member.structure_vocab_size)).all(), "missing/invalid canonical structure token")
        require(((self.structure_tokens >= 0) & (self.structure_tokens < member.structure_vocab_size)).all(), "structure token out of vocabulary")
        special = torch.ones(T, dtype=torch.bool, device=idx.device)
        special[idx] = False
        aa_ids = torch.tensor(member.aa20_ids, device=idx.device)
        require(not torch.isin(self.input_ids[0, special], aa_ids).any(), "canonical mapping omitted AA")
        require(all(token in member.vocab for token in ("<cls>", "<eos>", "<pad>")), "special vocabulary required")
        special_map = {member.vocab.index("<cls>"): 1, member.vocab.index("<eos>"): 2, member.vocab.index("<pad>"): 0}
        for position in torch.nonzero(special, as_tuple=False).flatten().tolist():
            token = int(self.input_ids[0, position])
            require(token in special_map and int(self.structure_tokens[0, position]) == special_map[token],
                    "special AA/structure token mapping mismatch")
        require(torch.equal(self.token_mask, self.input_ids != member.vocab.index("<pad>")), "padding mask mismatch")
        require(self.relative_pos.shape == (1, T, T) and self.relative_pos.dtype == torch.long, "bad relative positions")
        offsets = torch.arange(T, device=self.relative_pos.device)
        require(torch.equal(self.relative_pos, (offsets[:, None] - offsets[None, :])[None]), "relative positions mismatch")
        require(self.ss_hidden_states.shape == h.shape and self.ss_hidden_states.dtype == h.dtype, "bad structure hidden")
        require(self.rel_embeddings.ndim == 2 and self.rel_embeddings.shape[1] == 768 and
                self.rel_embeddings.dtype == h.dtype, "bad relative embeddings")
        require(all(getattr(self, name).device == h.device for name in (
            "input_ids", "structure_tokens", "token_mask", "canonical_index", "expanded_mask",
            "relative_pos", "rel_embeddings", "ss_hidden_states")), "cache devices differ")
        require(self.content_sha256 == self.digest(), "cache content mutated or not sealed")
        return self
