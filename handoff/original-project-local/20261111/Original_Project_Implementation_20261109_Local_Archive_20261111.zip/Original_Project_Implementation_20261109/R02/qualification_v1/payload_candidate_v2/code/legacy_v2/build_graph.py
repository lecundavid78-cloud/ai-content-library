"""Metadata-only graph compiler. Targets are scoring edges, never training keys."""
import argparse
from pathlib import Path
from types import SimpleNamespace
from pilot.contracts import read,write,bound,sha,digest,validate_schedule,exact_keys
from replication_contract import training_key,scoring_edge,source_roles
from r05_internal.reference.contracts import require


def compile_requests(requests,base,code_manifest_sha256):
    nodes={};edges=[];budgets=set();shared_support={};shared_schedules={};shared_initial={}
    for request in requests:
        exact_keys(request,('sources','bundles','schedule','init','architecture','seed','native_lock','edges'))
        source_roles(request['sources'])
        for spec in request['bundles'].values():bound(spec,base)
        sp=bound(request['schedule'],base);schedule=read(sp)
        natural={s['id']:SimpleNamespace(wt_sha256=s['wt_sha256'],wt_sequence='A'*s['length']) for s in request['sources']}
        validate_schedule(schedule,source_ids=list(natural),natural_by_id=natural,seed=request['seed'])
        budgets.update(len(a['training_indices']) for a in schedule['source_admissions'].values())
        for sid,admission in schedule['source_admissions'].items():
            signature=digest(admission)
            require(sid not in shared_support or shared_support[sid]==signature,'same source support must be shared across pairs/architectures/seeds')
            shared_support[sid]=signature
        pair=tuple(sorted(natural));body=digest(schedule['schedule'])
        require(pair not in shared_schedules or shared_schedules[pair]==body,'same pair schedule must be shared across architectures/seeds')
        shared_schedules[pair]=body
        init_sha=sha(bound(request['init'],base));native_sha=sha(bound(request['native_lock'],base))
        init_group=(request['architecture'],request['seed'],native_sha)
        require(init_group not in shared_initial or shared_initial[init_group]==init_sha,'one locked initial state per architecture/seed/native identity')
        shared_initial[init_group]=init_sha
        key,ident=training_key(sources=request['sources'],bundles=request['bundles'],schedule_sha256=sha(sp),
            init_sha256=init_sha,architecture=request['architecture'],seed=request['seed'],
            native_sha256=native_sha,code_manifest_sha256=code_manifest_sha256)
        if key in nodes:require(nodes[key]['identity']==ident,'training hash collision')
        else:nodes[key]={'training_id':key,'identity':ident,'request':{k:v for k,v in request.items() if k!='edges'}}
        for edge in request['edges']:
            exact_keys(edge,('target','cell','retrieval','random_pair_index'))
            scoring_edge(request['sources'],edge['target'])
            require(edge['cell'] in ('A1','A2','A3','A4') and request['architecture']==('S' if edge['cell'] in ('A1','A3') else 'L'),'edge architecture')
            require(edge['retrieval'] in ('ESM2','VESM','ProSST'),'fixed retrieval reference')
            require((edge['random_pair_index'] in (1,2,3)) if edge['cell'] in ('A1','A2') else edge['random_pair_index'] is None,'random three-pair reporting reference')
            row=dict(edge,training_id=key,seed=request['seed'])
            if row not in edges:edges.append(row)
    require(len(budgets)==1,'one common B across all selected sources')
    require(0<len(nodes)<=84,'finite unique training count <=84')
    return {'schema':'THREE_TARGET_EXECUTION_GRAPH_V1','common_B':budgets.pop(),
        'nodes':sorted(nodes.values(),key=lambda n:(n['identity']['seed'],n['training_id'])),'scoring_edges':edges,
        'unique_trainings':len(nodes),'execution_release':False,'training_target_labels':False,
        'scope':'deduplication and edge validity; root/R03 separately verify complete expected four-cell matrix'}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--requests',required=True);p.add_argument('--code-manifest',required=True);p.add_argument('--output',required=True);a=p.parse_args()
    result=compile_requests(read(a.requests),Path(a.requests).resolve().parent,sha(a.code_manifest))
    result['request_sha256']=sha(a.requests);result['code_manifest_sha256']=sha(a.code_manifest);write(a.output,result)
