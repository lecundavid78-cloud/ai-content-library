"""One full-AA25/full-19L scorer. S and L differ only in their adaptation."""
from dataclasses import asdict,fields,is_dataclass
import hashlib
import torch
from r05_internal.reference.adapter import ContextAdapter
from r05_internal.reference.contracts import REQUIRED_K,MemberField,require,tensor_sha256
from r05_internal.reference.vrh import FullVRH
from r05_internal.lora import install_last_qv,assert_runtime_mode,PATHS,UnmergedLoRALinear
from .contracts import digest

def tensors(x,prefix=""):
    if isinstance(x,torch.Tensor):yield prefix,x
    elif is_dataclass(x):
        for f in fields(x):yield from tensors(getattr(x,f.name),prefix+"/"+f.name)
    elif isinstance(x,dict):
        for k,v in x.items():yield from tensors(v,prefix+"/"+str(k))
    elif isinstance(x,(list,tuple)):
        for k,v in enumerate(x):yield from tensors(v,prefix+"/"+str(k))

def stamps(items):
    return {n:(id(p),p.data_ptr(),p._version,p.dtype,str(p.device),tuple(p.shape),p.requires_grad)
            for n,p in items}

def frozen_items(models):
    for k in REQUIRED_K:
        for n,p in models[k].named_parameters():
            if not p.requires_grad:yield str(k)+"/"+n,p
        for n,p in models[k].named_buffers():yield str(k)+"/buffer:"+n,p

def frozen_digest(models):
    h=hashlib.sha256()
    for n,p in frozen_items(models):h.update((n+":"+tensor_sha256(p)+"\n").encode())
    return h.hexdigest()

def uninstall_lora(models):
    for model in models.values():
        for path in PATHS:
            module=model.get_submodule(path)
            require(type(module) is UnmergedLoRALinear,"expected installed LoRA")
            parent,child=path.rsplit(".",1)
            setattr(model.get_submodule(parent),child,module.base)

def head_digests(models):
    return {str(k):digest({n:tensor_sha256(t) for n,t in models[k].cls.state_dict().items()}) for k in REQUIRED_K}

class Scorer:
    def __init__(self,models,members,architecture,seed=11):
        require(architecture in ("S","L"),"architecture")
        require(set(models)==set(members)==set(REQUIRED_K),"six members")
        require(type(seed) is int and seed in (11,23,47),"three frozen seeds")
        self.seed=seed
        self.models,self.members,self.architecture=models,members,architecture
        self.validated={}
        for model in models.values():
            model.requires_grad_(False).eval()
            model.prosst.encoder.gradient_checkpointing=False
        first=next(models[REQUIRED_K[0]].parameters())
        if architecture=="S":
            with torch.random.fork_rng(devices=[]):
                torch.manual_seed(seed)
                self.adapter=ContextAdapter([members[k] for k in REQUIRED_K],64).to(first.device,first.dtype)
            self.params=dict(self.adapter.named_parameters())
        else:
            self.adapter=None
            self.params=install_last_qv(models,seed=seed)
        expected=597376 if architecture=="S" else 589824
        require(sum(p.numel() for p in self.params.values())==expected,"exact trainable count")
        self.base_stamp=stamps(frozen_items(models))
        self.base_hash=frozen_digest(models)
        self.head_initial_sha256=head_digests(models)
        self.identity=digest({str(k):asdict(members[k]) for k in REQUIRED_K})

    def guard(self):
        require(stamps(frozen_items(self.models))==self.base_stamp,"frozen tensor changed or was replaced")
        if self.architecture=="L":assert_runtime_mode(self.models)
        else:require(not any(p.requires_grad for m in self.models.values() for p in m.parameters()),"S base unfrozen")
        for m in self.models.values():
            require(not m.prosst.encoder.gradient_checkpointing,"checkpointing disabled")
            require(all(not d.training for d in m.modules() if isinstance(d,torch.nn.Dropout)),"base dropout active")

    def admit(self,b):
        require(b["members"]==self.members,"cache/native identity")
        require(b["provenance"]["reference_kind"]=="fresh_full_original_forward","fresh Original reference required")
        for k in REQUIRED_K:
            c=b["caches"][k];c.validate(self.members[k],b["natural"])
            p=next(self.models[k].parameters())
            require(c.h11.device==p.device and c.h11.dtype==p.dtype,"cache precision/device")
            h=b["h12"][k]
            require(h.shape==c.h11.shape and h.dtype==c.h11.dtype and h.device==c.h11.device and
                    not h.requires_grad and torch.isfinite(h).all(),"detached h12")
        self.validated[id(b)]=(b,stamps(tensors(b)))

    def fields(self,b):
        self.guard()
        if id(b) not in self.validated:self.admit(b)
        require(stamps(tensors(b))==self.validated[id(b)][1],"prepared tensor mutation")
        out=[]
        for k in REQUIRED_K:
            c,m=b["caches"][k],self.models[k]
            if self.architecture=="L":
                h=m.prosst.encoder.layer[11](c.h11,c.expanded_mask,query_states=None,
                    relative_pos=c.relative_pos,rel_embeddings=c.rel_embeddings,
                    output_attentions=False,ss_hidden_states=c.ss_hidden_states)
            else:
                h=b["h12"][k]
                context=torch.zeros((*h.shape[:2],46),device=h.device,dtype=h.dtype)
                context[0,c.canonical_index]=b["natural"].context().to(h.device,h.dtype)
                mask=torch.zeros(h.shape[:2],device=h.device,dtype=torch.bool)
                mask[0,c.canonical_index]=True
                h=h+self.adapter(h,context,mask,self.members[k])
            logits=m.cls(h)[0].index_select(0,c.canonical_index)
            require(logits.shape==(len(b["natural"].wt_sequence),25),"raw AA25 shape")
            out.append(MemberField(self.members[k],logits if logits.dtype==torch.float64 else logits.float()))
        return tuple(out)

    def score(self,b):
        f=self.fields(b)
        return f,FullVRH().score_all19l(f,b["natural"],statistics_gradient="full",normalization_universe="complete19L")

    def state(self,step):
        self.guard()
        return {"schema":"FOURCELL_ADAPTER_V1","architecture":self.architecture,"seed":self.seed,"step":step,
                "member_identity":self.identity,"frozen_sha256":self.base_hash,
                "tensors":{n:p.detach().cpu().clone() for n,p in self.params.items()}}

    def restore(self,state,expected_step):
        require(set(state)=={"schema","architecture","seed","step","member_identity","frozen_sha256","tensors"} and
                state["schema"]=="FOURCELL_ADAPTER_V1" and state["architecture"]==self.architecture and
                state["seed"]==self.seed and state["step"]==expected_step and state["member_identity"]==self.identity and
                state["frozen_sha256"]==self.base_hash,"checkpoint identity")
        require(set(state["tensors"])==set(self.params),"checkpoint whitelist")
        for n,p in self.params.items():
            x=state["tensors"][n]
            require(x.shape==p.shape and x.dtype==p.dtype and torch.isfinite(x).all(),"checkpoint tensor")
        with torch.no_grad():
            for n,p in self.params.items():p.copy_(state["tensors"][n].to(p.device))
        self.guard()

    def verify_frozen(self):
        self.guard()
        current=frozen_digest(self.models)
        require(current==self.base_hash,"frozen byte fingerprint changed")
        heads=head_digests(self.models)
        require(heads==self.head_initial_sha256,"complete head byte fingerprint changed")
        n_grad=sum(p.requires_grad for m in self.models.values() for p in m.cls.parameters())
        require(n_grad==0,"complete original head unfrozen")
        return {"frozen_initial_sha256":self.base_hash,"frozen_current_sha256":current,"frozen_bytes_unchanged":True,
                "head_initial_sha256":self.head_initial_sha256,"head_current_sha256":heads,"head_requires_grad_count":n_grad}
