"""Explicit controller-admitted qualification source material; never mutate old roles."""
from runtime_contract import read,bound,SOURCES,CONTROLLER
from single_source import need,keys
from production_loop import file_sha


def reference(d):
    need(set(d) in ({'path','sha256'},{'path','sha256','bytes'}),'exact material file reference')
    p=bound({'path':d['path'],'sha256':d['sha256']})
    if 'bytes' in d:need(p.stat().st_size==d['bytes'],'material byte size')
    return p


def consume(wrapper_spec,material_record):
    wp=reference(wrapper_spec);w=read(wp)
    keys(w,('schema','controller','stage','role','source_id','wt_sha256','original_natural','original_numeric_admission',
        'bank_index','derived_admission','pair_slice','parent_pair_stream_sha256','parent_pair_count','slice_steps'))
    need(w['schema']=='SINGLE_SOURCE_QUALIFICATION_MATERIAL_V1' and w['controller']==CONTROLLER
        and w['stage']=='CPU_QUALIFICATION_ONLY' and w['role']=='ADMITTED_SOURCE' and w['source_id'] in SOURCES,'explicit admitted three-source qualification wrapper required')
    need(w['parent_pair_count']==2000 and w['slice_steps']==[0,1],'exact first2 of locked2000 parent stream')
    need(wrapper_spec==material_record['wrapper'] and w['parent_pair_stream_sha256']==material_record['parent_pair_stream']['sha256']
        and w['pair_slice']==material_record['pair_slice'] and material_record['pair_slice_steps']==2,'parent stream/slice/locked material record mismatch')
    for k in ('original_natural','original_numeric_admission','bank_index','derived_admission'):
        need(w[k]==material_record[k],'wrapper material differs from locked manifest: '+k)
    paths={k:reference(w[k]) for k in ('original_natural','original_numeric_admission','bank_index','derived_admission','pair_slice')}
    doc=read(paths['original_natural']);numeric=read(paths['original_numeric_admission']);index=read(paths['bank_index']);a=read(paths['derived_admission']);s=read(paths['pair_slice'])
    need(doc['schema']=='FOURCELL_NATURAL_V1' and doc['role'] in ('SOURCE_POOL','SOURCE') and doc['functional_labels_included'] is False,'TARGET or unlabeled-role conversion forbidden')
    need(doc['asset_id']==w['source_id']==numeric['source_id']==index['source_id'],'original source identity')
    need(doc['wt_sha256']==w['wt_sha256']==numeric['WT_sha256']==index['wt_sha256']==a['wt_sha256'],'original/numeric/index/derived WT mismatch')
    need(numeric['length']==index['length']==len(doc['wt_sequence']),'full WT length')
    keys(a,('role','wt_sha256','training_indices','heldout_positions','admission_sha256'))
    need(a['role']=='SOURCE' and a['admission_sha256']==file_sha(paths['original_numeric_admission']),'derived SOURCE must bind original numeric admission')
    need(index['bank_rule']=='small594' and index['count']==len(index['bank_indices'])==len(a['training_indices'])==594
        and index['bank_indices']==a['training_indices'] and index['heldout_positions']==a['heldout_positions'],'exact small594 support/split bridge')
    # Slice document must declare the exact parent; no full parent stream or score table is opened here.
    need(isinstance(s,list) and len(s)==2,'exact two-row R01 slice')
    for i,row in enumerate(s):need(row['step']==i and row['source_id']==w['source_id'],'exact original slice row identity')
    return w,doc,a,s,paths
