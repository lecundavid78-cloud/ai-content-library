"""Runtime evidence of the inherited full-WT path; never invent a new window."""
from r05_internal.reference.contracts import REQUIRED_K,require


def full_span_evidence(models,bundle):
    natural=bundle['natural'];L=len(natural.wt_sequence);rows={}
    require(bundle['original_all19l'].shape==(19*L,),'complete19L Original output')
    for k in REQUIRED_K:
        c=bundle['caches'][k];c.validate(bundle['members'][k],natural)
        T=c.h11.shape[1];cfg=models[k].config
        require(c.canonical_index.numel()==L and c.expanded_mask.shape==(1,1,T,T) and c.relative_pos.shape==(1,T,T),'full length h11/mask/relative positions')
        require(bundle['h12'][k].shape==c.h11.shape,'true h12 cache span')
        f=next(f for f in bundle['original_fields'] if f.member.structure_codebook_size==k)
        require(f.logits25.shape==(L,25),'all canonical AA25 rows')
        msa=natural.native_msa_by_member[bundle['members'][k].name]
        require(msa.logp25 is not None,'existing native MSA required; no artificial counts')
        rows[str(k)]={'WT_length':L,'token_count':T,'h11_shape':list(c.h11.shape),
            'expanded_mask_shape':list(c.expanded_mask.shape),'relative_pos_shape':list(c.relative_pos.shape),
            'relative_pos_min':int(c.relative_pos.min()),'relative_pos_max':int(c.relative_pos.max()),
            'actual_config':{n:getattr(cfg,n,None) for n in ('max_position_embeddings','position_embedding_type','relative_attention','max_relative_positions','position_buckets')},
            'native_MSA_span':[msa.aln_start,msa.aln_end],'native_MSA_rows':int(msa.logp25.shape[0]),
            'native_MSA_covers_full_WT':msa.aln_start==0 and msa.aln_end==L,
            'h11_layer_index':c.identity.layer_index,'canonical_structure_rows':L}
    return {'WT_length':L,'window_rule':'single-full-WT-forward-no-window','truncation':False,
        'mask_rule':'unmasked-WT-eval-exact-canonical-mapping','normalization_universe':19*L,
        'members':rows,'note':'max_position_embeddings is recorded, not presumed a hard limit for relative attention; native full forward and all span checks must actually pass'}
