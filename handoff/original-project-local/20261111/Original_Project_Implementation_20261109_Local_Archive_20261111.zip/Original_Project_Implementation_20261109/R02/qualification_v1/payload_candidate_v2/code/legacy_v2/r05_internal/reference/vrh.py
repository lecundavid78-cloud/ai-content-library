"""Differentiable, complete-19L VenusREM2 calibrated-margin scorer.

Forward arithmetic follows VRH 80781b9a86a6b90db33c4c4103f29b374ae74028.
Only detached branch predicates are permitted; continuous statistics retain
their graph in ``full`` mode.  No protein labels, model loader or I/O lives here.
"""
from __future__ import annotations

import math
from typing import Sequence

import torch

from .contracts import (
    AA20, MemberField, NativeMSA, NaturalInput, VRHConfig, VRHResult,
    require, validate_members, variant_ids,
)


def _positive(value: torch.Tensor, threshold: float = 0.0) -> bool:
    """A branch decision, never a replacement value in the differentiable path."""
    return bool((value.detach() > threshold).item())


def _stat(value: torch.Tensor, mode: str) -> torch.Tensor:
    return value if mode == "full" else value.detach()


def _sample_std(values: torch.Tensor) -> torch.Tensor:
    # torch.std has a singular second derivative at exact zero variance.  The
    # upstream zero branches select a constant; make that choice explicit.
    if values.numel() < 2:
        return values.new_full((), float("nan"))
    centered = values - values.mean()
    if not _positive((centered * centered).sum()):
        return values.sum() * 0.0
    return values.std(unbiased=True)


def _clamped_norm(square_sum: torch.Tensor, minimum: float) -> torch.Tensor:
    # Algebraically sqrt(x).clamp_min(minimum), as upstream, but avoids the
    # undefined sqrt'(0)*0 produced by backprop through an inactive clamp.
    return square_sum.clamp_min(minimum * minimum).sqrt()


def _raw_alpha(rho, scale_plm, scale_msa):
    rho = rho.clamp(0.0, 1.0)
    numerator = rho * scale_plm
    denominator = numerator + (1.0 - rho) * scale_msa
    if not _positive(denominator):
        raise ValueError("non-positive scale-mapping denominator")
    return (numerator / denominator).clamp(0.0, 1.0)


def native_preference_features(raw_logp25, msa: NativeMSA, sequence, aa_ids):
    """Tensor form of entropy_alpha.native_preference_features.

    The AA20 normalization is intentionally independent of raw AA25 softmax.
    Sample (ddof=1) margin scales and float64 statistics match upstream.
    """
    if msa.logp25 is None:
        raise ValueError("entropy α requires an MSA count matrix")
    start, end = msa.aln_start, msa.aln_end
    n = min(max(0, end - start), msa.logp25.shape[0], max(0, raw_logp25.shape[0] - start))
    if n <= 0:
        raise ValueError("empty aligned span")
    ids = torch.as_tensor(aa_ids, dtype=torch.long, device=raw_logp25.device)
    raw_aa = raw_logp25[start:start+n].index_select(1, ids).double()
    count_aa = msa.logp25[:n].to(raw_logp25.device).index_select(1, ids).double()
    wt = torch.tensor([AA20.index(aa) for aa in sequence[start:start+n]], device=raw_aa.device)
    rows = torch.arange(n, device=raw_aa.device)
    pref = raw_aa.softmax(1)
    pll = pref[rows, wt].clamp_min(1e-12).log().mean()
    x = raw_aa - raw_aa[rows, wt, None]
    y = count_aa - count_aa[rows, wt, None]
    non_wt = torch.arange(20, device=wt.device)[None, :] != wt[:, None]
    scale_plm = _sample_std(x[non_wt])
    scale_msa = _sample_std(y[non_wt])
    if not bool(torch.isfinite(scale_plm.detach()) & torch.isfinite(scale_msa.detach())) or not _positive(scale_msa):
        raise ValueError("invalid native-margin score scale")
    rho_pi = (-pll / math.log(20)).clamp(0.0, 1.0)
    logp20 = raw_aa.log_softmax(1)
    hbar = (-(logp20.exp() * logp20).sum(1).mean() / math.log(20)).clamp(0.0, 1.0)
    xc = raw_aa - raw_aa.mean(1, keepdim=True)
    yc = count_aa - count_aa.mean(1, keepdim=True)
    denominator = _clamped_norm((xc * xc).sum(1) * (yc * yc).sum(1), 1e-12)
    corr = torch.nan_to_num((xc * yc).sum(1) / denominator, nan=0.0, posinf=0.0, neginf=0.0).mean()
    rho_rot = 0.5 * (1.0 - corr)
    rho = ((1.0 - hbar) * rho_pi + hbar * rho_rot).clamp(0.0, 1.0)
    return {
        "n": n, "n_native_sites": n, "pll_plm": pll,
        "rho_pi": rho_pi, "hbar": hbar, "corr_rm": corr,
        "rho_rot": rho_rot, "rho": rho, "scale_plm": scale_plm,
        "scale_msa": scale_msa, "alpha_pi": _raw_alpha(rho_pi, scale_plm, scale_msa),
        "alpha": _raw_alpha(rho, scale_plm, scale_msa),
    }


def _resolve(raw, msa, sequence, aa_ids, config, statistics_gradient):
    spec = config.alpha_spec
    features = {}
    if spec is None or str(spec).lower() in {"entropy", "auto", "adaptive"}:
        if msa is None:
            raise ValueError("entropy α requires an MSA count matrix")
        features = native_preference_features(raw, msa, sequence, aa_ids)
        alpha = features["alpha"]
    else:
        alpha = raw.new_tensor(float(spec), dtype=torch.float64)
    alpha = _stat(alpha, statistics_gradient)
    beta_spec = config.background_spec
    if beta_spec is None or str(beta_spec).lower() in {"one_minus_alpha", "1-alpha", "auto", "dynamic"}:
        beta = 1.0 - alpha
    else:
        beta = raw.new_tensor(float(beta_spec), dtype=torch.float64)
    require(torch.isfinite(alpha.detach()) & torch.isfinite(beta.detach()), "nonfinite alpha/background weight")
    features = {k: _stat(v, statistics_gradient) if isinstance(v, torch.Tensor) else v for k, v in features.items()}
    features.update(alpha=alpha, background_weight=beta)
    return alpha, beta, features


def calibration_terms(raw, sequence, aa_ids, *, disable_adaptive_ccd=False, statistics_gradient="full"):
    """Raw AA25 background; AA20 sample std and sitewise correlation."""
    ids = torch.as_tensor(aa_ids, device=raw.device, dtype=torch.long)
    background = raw.logsumexp(0) - math.log(raw.shape[0])
    bg_aa = background.index_select(0, ids)
    bg_std = _sample_std(bg_aa)
    if _positive(bg_std, 1e-8):
        bg_z20 = (bg_aa - bg_aa.mean()) / bg_std
    else:
        bg_z20 = bg_aa * 0.0
    background_z = torch.zeros_like(background).index_copy(0, ids, bg_z20)
    local = raw.index_select(1, ids).double()
    bg64 = bg_aa.double()
    bg_centered = bg64 - bg64.mean()
    bg_square = bg_centered.square().sum()
    if _positive(bg_square, 1e-24):
        bg_den = bg_square.sqrt()
        local_c = local - local.mean(1, keepdim=True)
        local_den = _clamped_norm(local_c.square().sum(1), 1e-12)
        corr = (local_c * bg_centered[None, :]).sum(1) / (local_den * bg_den)
        consistency = torch.nan_to_num(corr, nan=0.0, posinf=0.0, neginf=0.0).mean()
    else:
        consistency = bg64.sum() * 0.0
    kappa = consistency.new_ones(()) if disable_adaptive_ccd else consistency.clamp_min(0.0)
    wt = torch.tensor([aa_ids[AA20.index(aa)] for aa in sequence], device=raw.device)
    wt_logp = raw[torch.arange(len(sequence), device=raw.device), wt]
    wt_std = _sample_std(wt_logp)
    wt_z = (wt_logp - wt_logp.mean()) / wt_std if _positive(wt_std, 1e-8) else wt_logp * 0.0
    terms = {
        "background": background, "background_z": background_z,
        "background_std": bg_std, "bg_consistency": consistency,
        "bg_scale": kappa, "kappa": kappa,
        "entropy": -(raw.exp() * raw).sum(-1),
        "wt_log_probability": wt_logp, "wt_confidence": wt_z.sigmoid(),
        "calibrated_on_raw": True,
    }
    return {k: _stat(v, statistics_gradient) if isinstance(v, torch.Tensor) else v for k, v in terms.items()}


def _structure_factor(raw, natural, config):
    """Input-constant structure decay, including official nonzero means."""
    factor = raw.new_ones(raw.shape[0])
    diagnostics = {}
    if natural.rsa_weights is not None:
        rsa = natural.rsa_weights.to(device=raw.device, dtype=raw.dtype).reshape(-1).clamp(0.0, 1.0)
        valid = rsa[rsa > 0]
        mean = valid.mean() if valid.numel() else rsa.new_zeros(())
        std = valid.std(unbiased=True) if valid.numel() > 1 else rsa.new_zeros(())
        diagnostics.update(rsa=rsa, rsa_mean=mean, rsa_std=std)
        if config.use_rsa_decay:
            if config.rsa_decay_mode == "above_mean":
                decay = (rsa - mean).clamp_min(0)
            elif config.rsa_decay_mode == "std_scaled":
                decay = std * (rsa - mean).clamp_min(0)
            elif config.rsa_decay_mode == "adaptive":
                decay = (1.0 - 2.0 * mean).clamp_min(0) * rsa
            else:  # historical raw/other path
                decay = rsa
            factor = factor * (1.0 + decay if config.task_type == "surface" else 1.0 - decay)
    if natural.plddt_weights is not None:
        confidence = natural.plddt_weights.to(device=raw.device, dtype=raw.dtype).reshape(-1).clamp(0.0, 1.0)
        valid = confidence[confidence > 0]
        mean = valid.mean() if valid.numel() else confidence.new_zeros(())
        disorder = 1.0 - valid if valid.numel() else confidence
        std = disorder.std(unbiased=True) if disorder.numel() > 1 else confidence.new_zeros(())
        diagnostics.update(plddt=confidence, plddt_mean=mean, plddt_disorder_std=std)
        if config.use_plddt_decay:
            q = ((1.0 - confidence) - (1.0 - mean)).clamp_min(0)
            if config.plddt_decay_mode == "std_scaled":
                q = q * std
            factor = factor * (1.0 - q)
    diagnostics["structure_factor"] = factor
    return factor, diagnostics


def zmean_members(member_scores: torch.Tensor, statistics_gradient: str = "full"):
    """Exact complete-column NumPy nanstd(ddof=0)/nanmean semantics.

    Upstream converts member columns to NumPy float (float64). Float64 is
    retained here; this is a statistic precision, not mixed model precision.
    """
    require(statistics_gradient in {"full", "stopgrad"}, "unknown statistics gradient")
    require(member_scores.ndim == 2 and member_scores.shape[1] > 0, "empty normalization universe")
    rows, means, scales = [], [], []
    for scores in member_scores.double().unbind(0):
        valid = scores[~scores.isnan()]
        if valid.numel():
            mean = valid.mean()
            scale = valid.std(unbiased=False)
        else:
            mean = scores.new_full((), float("nan"))
            scale = scores.new_full((), float("nan"))
        if _positive(scale):
            mean, scale = _stat(mean, statistics_gradient), _stat(scale, statistics_gradient)
            z = (scores - mean) / scale
        else:
            # Zero/all-NaN/nonfinite-scale original columns map to zeros.
            z = torch.nan_to_num(scores, nan=0.0, posinf=0.0, neginf=0.0) * 0.0
        rows.append(z)
        means.append(mean)
        scales.append(scale)
    standardized = torch.stack(rows)
    return standardized.nanmean(0), standardized, torch.stack(means), torch.stack(scales)


class FullVRH:
    def __init__(self, config: VRHConfig | None = None, ensemble_mode: str = "full"):
        self.config = config or VRHConfig()
        self.ensemble_mode = ensemble_mode

    def score_all19l(
        self, fields: Sequence[MemberField], natural: NaturalInput, *,
        statistics_gradient: str = "full", normalization_universe: str = "complete19L",
    ) -> VRHResult:
        require(statistics_gradient in {"full", "stopgrad"}, "unknown statistics gradient")
        require(normalization_universe == "complete19L", "VRH requires complete19L before any pair/subset selection")
        natural.validate()
        members = [field.member for field in fields]
        validate_members(members, self.ensemble_mode)
        L = len(natural.wt_sequence)
        outputs, diagnostics = [], {}
        for field in fields:
            member, logits = field.member, field.logits25
            require(logits.shape == (L, 25) and logits.dtype in (torch.float32, torch.float64), "field must be full [L,25] FP32/FP64")
            require(torch.isfinite(logits.detach()).all(), "nonfinite member logits")
            raw = field.logp25
            msa = natural.native_msa_by_member.get(member.name)
            alpha, beta, terms = _resolve(raw, msa, natural.wt_sequence, member.aa20_ids, self.config, statistics_gradient)
            fused = raw
            if bool((alpha.detach() != 0).item()):
                if msa is None or msa.logp25 is None:
                    raise ValueError("nonzero alpha requires an MSA count matrix")
                start, end = msa.aln_start, msa.aln_end
                cm = msa.logp25.to(device=raw.device, dtype=raw.dtype)
                mixed = (1.0 - alpha).to(raw.dtype) * raw[start:end] + alpha.to(raw.dtype) * cm
                fused = torch.cat((raw[:start], mixed, raw[end:]), 0)
            elif msa is not None and msa.logp25 is not None:
                # alpha may be zero at a smooth point of a learned field. Keep
                # its derivative: an upstream Python scalar used no autograd.
                start, end = msa.aln_start, msa.aln_end
                cm = msa.logp25.to(device=raw.device, dtype=raw.dtype)
                mixed = (1.0 - alpha).to(raw.dtype) * raw[start:end] + alpha.to(raw.dtype) * cm
                fused = torch.cat((raw[:start], mixed, raw[end:]), 0)
            cal = calibration_terms(raw, natural.wt_sequence, member.aa20_ids, disable_adaptive_ccd=self.config.disable_adaptive_ccd, statistics_gradient=statistics_gradient)
            ids = torch.tensor(member.aa20_ids, device=raw.device)
            wt_col = torch.tensor([AA20.index(aa) for aa in natural.wt_sequence], device=raw.device)
            rows = torch.arange(L, device=raw.device)
            values = fused.index_select(1, ids)
            delta = values - values[rows, wt_col, None]
            bg = cal["background_z"].index_select(0, ids)
            bg_delta = bg[None, :] - bg[wt_col, None]
            penalty = (cal["bg_scale"] * beta).to(raw.dtype) * bg_delta
            factor, structure = _structure_factor(raw, natural, self.config)
            score20 = (delta - penalty) * factor[:, None]
            non_wt = torch.arange(20, device=raw.device)[None, :] != wt_col[:, None]
            scores = score20[non_wt]
            require(scores.numel() == 19 * L and torch.isfinite(scores.detach()).all(), "incomplete/nonfinite member score field")
            outputs.append(scores)
            diagnostics[member.name] = {**terms, **cal, **structure, "raw_logp25": raw, "fused_logp25": fused, "score20": score20}
        member_scores = torch.stack(outputs)
        ensemble, zscores, means, scales = zmean_members(member_scores, statistics_gradient)
        diagnostics["ensemble"] = {"means": means, "population_std": scales, "statistics_gradient": statistics_gradient, "normalization_universe": "complete19L", "ensemble_mode": self.ensemble_mode, "runtime_identity_certified": False}
        return VRHResult(ensemble, member_scores, zscores, variant_ids(natural.wt_sequence), tuple(member.name for member in members), diagnostics)
