import copy
import inspect
import tempfile
from pathlib import Path
from types import SimpleNamespace
import unittest
import torch
from pilot.contracts import PROTOCOL_SHA,validate_schedule,sha
from pilot.scorer import Scorer,uninstall_lora
from pilot.engine import update,optimizer_for
from pilot.update_receipt import parameter_update_receipt
from replication_contract import training_key,scoring_edge,seed_value
from r05_internal.reference.contracts import ContractError,REQUIRED_K,MemberField
from r05_internal.reference.vrh import FullVRH
from tests.synthetic_fixture import fixture


def schedule(seed=11,B=5):
    n=SimpleNamespace(wt_sequence='A'*40,wt_sha256='a'*64)
    support=[0,1,19,20,38][:B]
    admission={'role':'SOURCE','wt_sha256':n.wt_sha256,'training_indices':support,'heldout_positions':[39],'admission_sha256':'b'*64}
    d={'schema':'THREE_TARGET_PAIR_SCHEDULE_V1','protocol_sha256':PROTOCOL_SHA,'init_seed':seed,'steps':500,
       'source_admissions':{s:copy.deepcopy(admission) for s in ('x','y')},
       'schedule':[{'step':i,'source_id':('x','y')[i%2],'cross_pairs':[[0,19]]*128,'within_pairs':[[0,1]]*128} for i in range(500)]}
    return d,dict(source_ids=['x','y'],natural_by_id={'x':n,'y':n},seed=seed)


def sources():return [{'id':'x','group_id':'gx','wt_sha256':'a'*64,'length':40},{'id':'y','group_id':'gy','wt_sha256':'b'*64,'length':50}]


def keyargs():
    return dict(sources=sources(),bundles={'x':{'path':'old1','sha256':'1'*64},'y':{'path':'old2','sha256':'2'*64}},
        schedule_sha256='3'*64,init_sha256='4'*64,architecture='S',seed=11,native_sha256='5'*64,code_manifest_sha256='6'*64)


def bundle(models,members,caches,natural):
    h12={};fields=[]
    with torch.no_grad():
        for k in REQUIRED_K:
            c=caches[k];h12[k]=models[k].prosst.encoder.layer[11](c.h11,c.expanded_mask,query_states=None,
                relative_pos=c.relative_pos,rel_embeddings=c.rel_embeddings,output_attentions=False,ss_hidden_states=c.ss_hidden_states)
            fields.append(MemberField(members[k],models[k].cls(h12[k])[0,c.canonical_index]))
        result=FullVRH().score_all19l(fields,natural)
    return dict(members=members,caches=caches,h12=h12,natural=natural,original_fields=fields,
        original_all19l=result.score_all19l,asset_role='SOURCE',provenance={'reference_kind':'fresh_full_original_forward'})


class ReplicationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(1)

    def test_small_non_power_two_B_and_three_seeds(self):
        for seed in (11,23,47):
            d,kw=schedule(seed);self.assertIs(validate_schedule(d,**kw),d)

    def test_schedule_rejects_empty_class_heldout_and_wrong_seed(self):
        d,kw=schedule();bad=copy.deepcopy(d);bad['schedule'][0]['within_pairs']=[]
        with self.assertRaises(ContractError):validate_schedule(bad,**kw)
        bad=copy.deepcopy(d);bad['source_admissions']['x']['heldout_positions']=[0]
        with self.assertRaises(ContractError):validate_schedule(bad,**kw)
        with self.assertRaises(ContractError):validate_schedule(d,**dict(kw,seed=23))
        for seed in (True,0,12):
            with self.assertRaises(ContractError):seed_value(seed)

    def test_R01_pair_assembly_preserves_all_500_rows_across_seed_and_arch(self):
        from build_schedule import assemble
        d,kw=schedule();fields=d['source_admissions'];batches={}
        for sid in fields:
            batches[sid]={'schema':'FOURCELL_SOURCE_BATCHES_V1','source_id':sid,'WT_sha256':'a'*64,'B':5,
                'batches':[{'cross_pairs':[[0,19]]*128,'within_pairs':[[0,1]]*128} for _ in range(250)]}
        a=assemble(fields,batches,11);b=assemble(fields,batches,23)
        self.assertEqual(a['schedule'],b['schedule']);self.assertEqual(a['schedule'],d['schedule'])
        validate_schedule(a,**kw)

    def test_graph_same_training_different_scoring_edges_deduplicated(self):
        from build_graph import compile_requests
        from pilot.contracts import write
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);d,kw=schedule();write(p/'schedule.json',d)
            for n in ('x','y','init','native'):(p/n).write_bytes(n.encode())
            bind=lambda n:{'path':str(p/n),'sha256':sha(p/n)}
            ss=sources();ss[1].update(wt_sha256='a'*64)
            # Different sources require different WT, make corresponding admission explicit.
            ss[1]['wt_sha256']='b'*64;d['source_admissions']['y']['wt_sha256']='b'*64;write(p/'schedule.json',d)
            request={'sources':ss,'bundles':{s:bind(s) for s in ('x','y')},'schedule':bind('schedule.json'),
                'init':bind('init'),'native_lock':bind('native'),'architecture':'S','seed':11,
                'edges':[{'target':{'id':'AsCas12f','group_id':'targetGroup','wt_sha256':'c'*64,'length':422},'cell':'A3','retrieval':'ESM2','random_pair_index':None}]}
            other=copy.deepcopy(request);other['edges'][0]['retrieval']='VESM'
            g=compile_requests([request,other],p,'d'*64)
            self.assertEqual(g['unique_trainings'],1);self.assertEqual(len(g['scoring_edges']),2)
            changed=copy.deepcopy(other);changed_schedule=copy.deepcopy(d)
            changed_schedule['schedule'][0]['cross_pairs'][0]=[1,20]
            write(p/'different_schedule.json',changed_schedule);changed['schedule']=bind('different_schedule.json')
            with self.assertRaisesRegex(ContractError,'schedule must be shared'):compile_requests([request,changed],p,'d'*64)
            (p/'different_init').write_bytes(b'different');changed=copy.deepcopy(other);changed['init']=bind('different_init')
            with self.assertRaisesRegex(ContractError,'one locked initial'):compile_requests([request,changed],p,'d'*64)
            other['edges'][0]['target']['wt_sha256']='a'*64
            with self.assertRaises(ContractError):compile_requests([other],p,'d'*64)

    def test_training_identity_target_free_path_independent_and_sensitive(self):
        args=keyargs();key,ident=training_key(**args)
        self.assertFalse(any('target' in k for k in ident))
        paths=copy.deepcopy(args);paths['bundles']['x']['path']='other_mount'
        self.assertEqual(key,training_key(**paths)[0])
        for k,v in [('architecture','L'),('seed',23),('schedule_sha256','7'*64),('init_sha256','8'*64),('native_sha256','9'*64),('code_manifest_sha256','0'*64)]:
            self.assertNotEqual(key,training_key(**dict(args,**{k:v}))[0])
        changed=copy.deepcopy(args);changed['bundles']['x']['sha256']='9'*64
        self.assertNotEqual(key,training_key(**changed)[0])

    def test_SpCas9_source_other_target_allowed_self_group_and_WT_rejected(self):
        ss=sources();ss[0]['id']='CAS9_STRP1_Spencer_2017_positive'
        target={'id':'TnpB','group_id':'gother','wt_sha256':'c'*64,'length':408}
        self.assertTrue(scoring_edge(ss,target))
        with self.assertRaises(ContractError):scoring_edge(ss,dict(target,id='SpCas9'))
        with self.assertRaises(ContractError):scoring_edge(ss,dict(target,wt_sha256=ss[0]['wt_sha256']))
        with self.assertRaises(ContractError):scoring_edge(ss,dict(target,group_id=ss[0]['group_id']))

    def test_seed_states_paired_different_seed_and_zero_readout(self):
        for arch in ('S','L'):
            models,members,caches,natural=fixture();b=bundle(models,members,caches,natural);saved={}
            for seed in (11,23,47):
                scorer=Scorer(models,members,arch,seed);state=scorer.state(0)
                self.assertEqual(state['seed'],seed)
                with torch.no_grad():self.assertTrue(torch.equal(scorer.score(b)[1].score_all19l,b['original_all19l']))
                saved[seed]=state
                if arch=='L':uninstall_lora(models)
            names=saved[11]['tensors']
            self.assertTrue(any(not torch.equal(names[n],saved[23]['tensors'][n]) for n in names))
            paired=Scorer(models,members,arch,23);paired_state=paired.state(0)
            self.assertTrue(all(torch.equal(saved[23]['tensors'][n],paired_state['tensors'][n]) for n in names))
            with self.assertRaises(ContractError):paired.restore(saved[11],0)
            paired.restore(saved[23],0)
            if arch=='L':uninstall_lora(models)

    def test_seed23_new_checkpoint_update_reload_frozen(self):
        for arch in ('S','L'):
            models,members,caches,natural=fixture();b=bundle(models,members,caches,natural)
            scorer=Scorer(models,members,arch,23);initial=scorer.state(0);opt=optimizer_for(scorer)
            for _ in range(2):update(scorer,b,[[0,19]],[[1,2]],opt)
            state=scorer.state(2)
            with torch.no_grad():expected=scorer.score(b)[1].score_all19l.detach().clone()
            scorer.restore(initial,0);scorer.restore(state,2)
            with torch.no_grad():self.assertTrue(torch.equal(expected,scorer.score(b)[1].score_all19l))
            self.assertFalse(torch.equal(expected,b['original_all19l']));self.assertTrue(scorer.verify_frozen()['frozen_bytes_unchanged'])

    def test_seed47_movement_receipt(self):
        from r05_internal.lora import expected_names
        a={'schema':'FOURCELL_ADAPTER_V1','architecture':'L','seed':47,'step':0,'member_identity':'1'*64,'frozen_sha256':'2'*64,
            'tensors':{n:torch.zeros((32,768) if n.endswith('.A') else (768,32)) for n in expected_names()}}
        b=copy.deepcopy(a);b['step']=500;b['tensors'][next(iter(b['tensors']))][0,0]=.125
        heads={str(k):'3'*64 for k in REQUIRED_K};proof={'frozen_current_sha256':'2'*64,'frozen_bytes_unchanged':True,
            'head_initial_sha256':heads,'head_current_sha256':heads,'head_requires_grad_count':0}
        with tempfile.TemporaryDirectory() as d:
            ip=Path(d)/'init.pt';cp=Path(d)/'last.pt';torch.save(a,ip);torch.save(b,cp)
            r=parameter_update_receipt(a,b,init_path=ip,checkpoint_path=cp,frozen_proof=proof,steps_observed=500)
            self.assertEqual(r['seed'],47);self.assertEqual(r['changed_elements'],1)

    def test_provider_truncation_and_long_span_not_retrieval_windows(self):
        from pilot.provider import inputs
        from long_sequence import full_span_evidence
        self.assertIn('truncation=False',inspect.getsource(inputs))
        self.assertIn('single-full-WT-forward-no-window',inspect.getsource(full_span_evidence))
        # A long tokenizer fixture must return the last canonical residue too.
        class Tok:
            cls_token_id=1;eos_token_id=2;pad_token_id=0
            def get_vocab(self):return {'A':5}
            def __call__(self,s,**kwargs):
                return {'input_ids':torch.tensor([[1]+[5]*len(s)+[2]]),'attention_mask':torch.ones(1,len(s)+2),
                    'special_tokens_mask':torch.tensor([[1]+[0]*len(s)+[1]])}
        for L in (1368,2185):
            args,idx=inputs(Tok(),'A'*L,[0]*L,20,'cpu')
            self.assertEqual(args['input_ids'].shape,(1,L+2));self.assertEqual(idx.tolist(),list(range(1,L+1)))

    def test_existing_partial_MSA_keeps_raw_outside_span_full19L_and_gradients(self):
        from dataclasses import replace
        from r05_internal.reference.contracts import NativeMSA
        models,members,caches,natural=fixture();b=bundle(models,members,caches,natural)
        partial={name:NativeMSA(msa.logp25[1:5].clone(),1,5,'synthetic existing partial span')
            for name,msa in natural.native_msa_by_member.items()}
        natural=replace(natural,native_msa_by_member=partial);natural.validate()
        fields=[MemberField(f.member,f.logits25.detach().clone().requires_grad_(True)) for f in b['original_fields']]
        result=FullVRH().score_all19l(fields,natural,statistics_gradient='full',normalization_universe='complete19L')
        self.assertEqual(result.score_all19l.numel(),19*len(natural.wt_sequence))
        for f in fields:
            diag=result.diagnostics[f.member.name]
            raw=diag['raw_logp25'];fused=diag['fused_logp25']
            self.assertTrue(torch.equal(raw[:1],fused[:1]));self.assertTrue(torch.equal(raw[5:],fused[5:]))
        (result.score_all19l[0]-result.score_all19l[-1]).backward()
        self.assertTrue(all(torch.isfinite(f.logits25.grad).all() and f.logits25.grad[-1].abs().sum()>0 for f in fields))


if __name__=='__main__':unittest.main()
