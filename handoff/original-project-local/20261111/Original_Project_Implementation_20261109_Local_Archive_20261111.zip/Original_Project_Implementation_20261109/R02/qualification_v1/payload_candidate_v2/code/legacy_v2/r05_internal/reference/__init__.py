"""Byte-pinned, parameter-free historical readout reference."""
