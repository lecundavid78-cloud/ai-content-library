"""Original strict native loader with explicit CPU/CUDA placement only; no model math changes."""
from pathlib import Path
from dataclasses import asdict
import inspect,time
import torch
from pilot.contracts import read,bound,sha,digest,legacy_tensor_sha,exact_keys
from r05_internal.reference.contracts import REQUIRED_K,AA20,MemberIdentity,MemberField,require
def load_members(lock_path,device):
    """Called only by released Slurm CLI; never by the local synthetic suite."""
    lock_path=Path(lock_path);lock=read(lock_path)
    exact_keys(lock,("schema","members","torch_version","transformers_version","numpy_version"))
    require(lock["schema"]=="FOURCELL_NATIVE_MEMBERS_V1","member lock schema")
    from transformers import AutoModelForMaskedLM,AutoTokenizer
    import transformers
    import numpy as np
    require(torch.__version__==lock["torch_version"] and transformers.__version__==lock["transformers_version"] and
            np.__version__==lock["numpy_version"],
            "runtime dependency versions must match released lock")
    models={};tokenizers={};members={};receipts={};quantizers={}
    require({int(x["K"]) for x in lock["members"]}==set(REQUIRED_K) and len(lock["members"])==6,"six native members")
    for spec in sorted(lock["members"],key=lambda x:int(x["K"])):
        identity_started=time.perf_counter()
        k=int(spec["K"]);root=Path(spec["root"])
        require(root.is_dir(),"native root missing")
        require({"config.json","modeling_prosst.py","configuration_prosst.py","vocab.txt",
                 "tokenizer_config.json","special_tokens_map.json"}<=set(spec["files_sha256"]),"incomplete native lock")
        for relative,h in spec["files_sha256"].items():
            require(not Path(relative).is_absolute() and ".." not in Path(relative).parts,"relative model file required")
            require(sha(root/relative)==h,"native file SHA "+relative)
        weight_files=spec["weight_files"]
        require(weight_files==["model.safetensors"] and set(weight_files)<=set(spec["files_sha256"]),
                "finite pilot requires the registered single model.safetensors file")
        require(not any(p.name in ("adapter_config.json","adapter_model.safetensors") for p in root.iterdir()),
                "base root must not auto-load an existing adapter")
        weight_sha=spec["files_sha256"][weight_files[0]] if len(weight_files)==1 else digest(
            {name:spec["files_sha256"][name] for name in sorted(weight_files)})
        require(weight_sha==spec["weights_sha256"],"weights identity convention mismatch")
        started=time.perf_counter()
        tokenizer=AutoTokenizer.from_pretrained(root,local_files_only=True,trust_remote_code=True)
        model,loading=AutoModelForMaskedLM.from_pretrained(root,local_files_only=True,trust_remote_code=True,
            output_loading_info=True,torch_dtype=torch.float32,use_safetensors=True)
        require(not any(loading.get(n) for n in ("missing_keys","unexpected_keys","mismatched_keys","error_msgs")),
                "native loading key mismatch")
        actual=Path(inspect.getfile(type(model)))
        require(sha(actual)==spec["modeling_source_sha256"],"actual model source")
        require(sha(Path(inspect.getfile(type(model.config))))==spec["configuration_source_sha256"],"actual config source")
        cfg=model.config
        require(cfg.hidden_size==768 and cfg.num_hidden_layers==12 and cfg.vocab_size==25 and
                cfg.ss_vocab_size==k+3 and cfg.position_embedding_type=="relative" and cfg.relative_attention,
                "registered native dimensions/relative attention")
        model=model.to(device).float().eval().requires_grad_(False)
        vocab=tokenizer.get_vocab()
        require(len(vocab)==25 and set(vocab.values())==set(range(25)) and set(AA20)<=set(vocab),"AA25 vocabulary")
        require(digest(vocab)==spec["tokenizer_sha256"],"vocabulary identity")
        head_sha=digest({n:legacy_tensor_sha(t) for n,t in model.cls.state_dict().items()})
        require(head_sha==spec["head_sha256"],"original full head identity")
        member=MemberIdentity(f"ProSST-{k}",k,k+3,768,tuple(sorted(vocab,key=vocab.get)),
            weight_sha,sha(actual),digest(vocab),head_sha,float(cfg.layer_norm_eps))
        require(all(p.dtype==torch.float32 for p in model.parameters()),"native FP32 only")
        model.prosst.encoder.gradient_checkpointing=False
        models[k]=model;tokenizers[k]=tokenizer;members[k]=member
        quantizers[k]=spec["quantizer_sha256"]
        receipts[k]={"load_seconds":time.perf_counter()-started,"file_identity_seconds":started-identity_started,
                     "identity_and_load_seconds":time.perf_counter()-identity_started,"actual_model_source":str(actual),
                     "member":asdict(member),"loading_info":loading,"config_sha256":sha(root/"config.json"),
                     "tokenizer_class":type(tokenizer).__name__,
                     "head_decoder_tied_to_AA_embeddings":model.cls.predictions.decoder.weight.data_ptr()==model.prosst.embeddings.word_embeddings.weight.data_ptr()}
    return models,tokenizers,members,quantizers,receipts
