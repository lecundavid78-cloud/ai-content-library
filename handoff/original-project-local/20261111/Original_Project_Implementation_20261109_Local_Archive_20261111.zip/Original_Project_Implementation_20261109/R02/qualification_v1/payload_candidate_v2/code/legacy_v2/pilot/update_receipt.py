"""Exact initial/final trainable-tensor comparison and frozen-byte proof."""
from pathlib import Path
import torch
from r05_internal.reference.contracts import require,tensor_sha256
from .contracts import sha

def parameter_update_receipt(initial,final,*,init_path,checkpoint_path,frozen_proof,steps_observed):
    require(initial["step"]==0 and final["step"]==500 and steps_observed==500,"exact observed step0 to step500")
    for key in ("schema","architecture","seed","member_identity","frozen_sha256"):
        require(initial[key]==final[key],"init/final identity: "+key)
    require(initial["schema"]=="FOURCELL_ADAPTER_V1" and initial["seed"] in (11,23,47),"adapter schema/seed")
    require(frozen_proof["frozen_current_sha256"]==initial["frozen_sha256"] and
            frozen_proof["frozen_bytes_unchanged"] is True,"frozen byte proof")
    require(frozen_proof["head_initial_sha256"]==frozen_proof["head_current_sha256"] and
            len(frozen_proof["head_initial_sha256"])==6 and frozen_proof["head_requires_grad_count"]==0,"frozen complete head proof")
    a,b=initial["tensors"],final["tensors"]
    require(set(a)==set(b) and a,"exact adapter tensor whitelist")
    expected={"S":(22,597376),"L":(24,589824)}[initial["architecture"]]
    require((len(a),sum(x.numel() for x in a.values()))==expected,"registered trainable tensor count/budget")
    rows=[];total=0
    for name in sorted(a):
        x,y=a[name].detach().cpu(),b[name].detach().cpu()
        require(x.shape==y.shape and x.dtype==y.dtype and x.is_floating_point(),"tensor shape/dtype")
        require(torch.isfinite(x).all() and torch.isfinite(y).all(),"nonfinite init/final tensor")
        changed=int(torch.count_nonzero(x!=y));total+=changed
        delta=y.double()-x.double()
        rows.append({"name":name,"shape":list(x.shape),"dtype":str(x.dtype),"numel":x.numel(),
            "init_tensor_sha256":tensor_sha256(x),"final_tensor_sha256":tensor_sha256(y),
            "changed_elements":changed,"max_abs_delta":float(delta.abs().max()),
            "l2_delta":float(delta.norm())})
    require(total>0,"no numerical adapter update despite checkpoint serialization")
    return {"schema":"FOURCELL_PARAMETER_UPDATE_RECEIPT_V1","status":"PARAMETER_CHANGE_AND_FROZEN_BYTES_PASS",
        "architecture":initial["architecture"],"seed":initial["seed"],"initial_step":0,"final_step":500,
        "steps_observed":steps_observed,"member_identity":initial["member_identity"],
        "init_sha256":sha(init_path),"checkpoint_sha256":sha(checkpoint_path),
        "trainable_tensor_count":len(rows),"trainable_parameter_count":sum(r["numel"] for r in rows),
        "changed_elements":total,"changed_tensors":sum(r["changed_elements"]>0 for r in rows),
        "all_trainable_tensors_changed":all(r["changed_elements"]>0 for r in rows),
        "unchanged_tensor_names":[r["name"] for r in rows if r["changed_elements"]==0],
        "per_tensor":rows,"frozen_proof":frozen_proof,
        "criterion":"aggregate exact changed_elements > 0; per-tensor unchanged entries explicitly retained",
        "scope":"parameter movement and frozen identity only; no functional benefit inference"}
