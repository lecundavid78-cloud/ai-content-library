"""Bound real metadata and narrow CPU toy checks; never load native model weights."""
import ast
import copy
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
import torch
from production_loop import original_kernels,file_sha,train
from runtime_contract import read,qualification_config
from role_bridge import consume
from single_source import validate
from resume_state import load

ROOT=Path(__file__).resolve().parent
MATERIAL=ROOT.parents[1]/'R01/qualification_material_v1/READY.json'


class Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        original_kernels(ROOT/'legacy_v2');torch.set_num_threads(1)

    def test_real_three_source_pool_wrappers_consume_without_role_mutation(self):
        from pilot.contracts import natural_asset
        ready=read(MATERIAL)
        for sid,record in ready['sources'].items():
            w,doc,a,s,paths=consume(record['wrapper'],record)
            _,natural,codes=natural_asset(paths['original_natural'])
            self.assertEqual(doc['role'],'SOURCE_POOL');self.assertEqual(len(codes),6)
            for arch in ('S','L'):
                c=qualification_config({'native_lock':{'sha256':'a'*64},'runtime_code_sha256':{}},{},
                    {'source_id':sid,'material':record['wrapper']},doc,a,arch,'b'*64,'c'*64)
                validate(c,s);self.assertEqual(c['steps'],2)

    def mutated(self,kind):
        record=copy.deepcopy(next(iter(read(MATERIAL)['sources'].values())));w=read(record['wrapper']['path'])
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            if kind in ('TARGET','WT'):
                doc=read(w['original_natural']['path'])
                if kind=='TARGET':doc['role']='TARGET'
                else:doc['wt_sha256']='9'*64
                f=p/'natural.json';f.write_text(json.dumps(doc));w['original_natural']={'path':str(f),'sha256':file_sha(f)};record['original_natural']=w['original_natural']
            else:w['parent_pair_stream_sha256']='9'*64
            f=p/'wrapper.json';f.write_text(json.dumps(w));record['wrapper']={'path':str(f),'sha256':file_sha(f)}
            with self.assertRaises(ValueError):consume(record['wrapper'],record)

    def test_target_rejected_even_with_new_wrapper_binding(self):self.mutated('TARGET')
    def test_wrong_WT_rejected(self):self.mutated('WT')
    def test_parent_stream_slice_mismatch_rejected(self):self.mutated('PARENT')

    def test_source_pool_natural_without_wrapper_rejected(self):
        record=next(iter(read(MATERIAL)['sources'].values()))
        with self.assertRaises(ValueError):consume(record['original_natural'],record)

    def test_loader_exact_device_only_diff_and_scientific_copy_bytes(self):
        from native_loader import load_members # Definitions only; function never called.
        src=(ROOT/'legacy_v2/pilot/provider.py').read_text()
        node=next(x for x in ast.parse(src).body if isinstance(x,ast.FunctionDef) and x.name=='load_members')
        original='\n'.join(src.splitlines()[node.lineno-1:node.end_lineno])
        import inspect
        actual=inspect.getsource(load_members).strip()
        self.assertEqual(actual,original.replace('def load_members(lock_path):','def load_members(lock_path,device):').replace('model=model.cuda().float().eval().requires_grad_(False)','model=model.to(device).float().eval().requires_grad_(False)'))
        for row in read(ROOT/'legacy_v2/CODE_MANIFEST.json')['files']:
            if row['path'].endswith('.py'):self.assertEqual(file_sha(ROOT/'legacy_v2'/row['path']),row['sha256'])

    def test_pause_one_then_new_instance_resume_exactly_two_updates(self):
        from pilot.engine import update
        class Toy:
            def __init__(self,*_):self.params={'p':torch.nn.Parameter(torch.tensor([.1,.2]))};self.base_hash='4'*64
            def guard(self):pass
            def verify_frozen(self):return {'frozen_bytes_unchanged':True,'frozen_current_sha256':self.base_hash}
            def score(self,b):
                x=torch.arange(76).float();p=self.params['p']
                return None,SimpleNamespace(score_all19l=p[0]*x/76+p[1]*torch.sin(x))
        from single_source import assemble
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);init=p/'init.pt';torch.save({'schema':'SINGLE_SOURCE_INIT_V1','architecture':'S','seed':11,'native_sha256':'a'*64,'frozen_sha256':'4'*64,'parameters':{'p':torch.tensor([.1,.2])}},init)
            doc={'wt_sequence':'AAAA','wt_sha256':'b'*64};a={'training_indices':[0,1,19,20],'heldout_positions':[3]}
            c=qualification_config({'native_lock':{'sha256':'a'*64},'runtime_code_sha256':{}},{},
                {'source_id':'synthetic','material':{'sha256':'c'*64}},doc,a,'S',file_sha(init),'d'*64)
            s=assemble(c,[{'within_pairs':[[0,1]]*128,'cross_pairs':[[0,19]]*128}]*2)
            bundle={'asset_role':'SOURCE','natural':SimpleNamespace(protein_id='synthetic',wt_sequence='AAAA',wt_sha256='b'*64)};calls=[]
            def checked(*args):calls.append(1);return update(*args)
            r=train(c,s,init,{'synthetic':bundle},p/'first',scorer_factory=Toy,update_fn=checked,pause_after=1)
            self.assertEqual(r['status'],'PAUSED_AT_PRELOCKED_NODE');self.assertFalse((p/'first/TRAIN_RECEIPT.json').exists())
            r=train(c,s,init,{'synthetic':bundle},p/'second',scorer_factory=Toy,update_fn=checked,
                resume_path=p/'first/STEP_1.pt',prior_attempts=1)
            self.assertEqual(len(calls),2);self.assertEqual(r['completed_updates'],2)
            self.assertEqual(load(p/'second/STEP_2.pt')['optimizer']['state'][0]['step'],2)


if __name__=='__main__':unittest.main()
