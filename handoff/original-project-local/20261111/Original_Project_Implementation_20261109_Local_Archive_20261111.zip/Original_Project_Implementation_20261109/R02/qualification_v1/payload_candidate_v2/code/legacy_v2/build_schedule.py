"""Assemble existing R01 pair batches; never read source scores or heldout values."""
import argparse
from pathlib import Path
from pilot.contracts import PROTOCOL_SHA,read,write,bound,sha,exact_keys
from replication_contract import seed_value
from r05_internal.reference.contracts import require


def assemble(source_fields,pair_batches,seed):
    seed_value(seed)
    require(len(source_fields)==2 and set(source_fields)==set(pair_batches),'two exact source fields and batches')
    admissions={};steps=[]
    ids=sorted(source_fields)
    for sid in ids:
        a=source_fields[sid];exact_keys(a,('role','wt_sha256','training_indices','heldout_positions','admission_sha256'))
        b=pair_batches[sid]
        require(b['schema']=='FOURCELL_SOURCE_BATCHES_V1' and b['source_id']==sid and b['WT_sha256']==a['wt_sha256']
            and len(b['batches'])==250 and b['B']==len(a['training_indices']),'R01 exact source batches')
        admissions[sid]=a
    for i in range(500):
        sid=ids[i%2];batch=pair_batches[sid]['batches'][i//2]
        steps.append({'step':i,'source_id':sid,'cross_pairs':batch['cross_pairs'],'within_pairs':batch['within_pairs']})
    return {'schema':'THREE_TARGET_PAIR_SCHEDULE_V1','protocol_sha256':PROTOCOL_SHA,'init_seed':seed,'steps':500,
        'source_admissions':admissions,'schedule':steps}


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--bindings',required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--output',required=True);a=p.parse_args()
    doc=read(a.bindings);base=Path(a.bindings).resolve().parent;fields={};batches={}
    for sid,spec in doc.items():
        exact_keys(spec,('source_fields','pair_batches'))
        fields[sid]=read(bound(spec['source_fields'],base));batches[sid]=read(bound(spec['pair_batches'],base))
    write(a.output,assemble(fields,batches,a.seed))
    write(a.output+'.ASSEMBLY.json',{'bindings':{'path':str(Path(a.bindings).resolve()),'sha256':sha(a.bindings)},'seed':a.seed,
        'schedule_sha256':sha(a.output),'pair_generation':False,'source_functional_or_heldout_tables_read':False})
