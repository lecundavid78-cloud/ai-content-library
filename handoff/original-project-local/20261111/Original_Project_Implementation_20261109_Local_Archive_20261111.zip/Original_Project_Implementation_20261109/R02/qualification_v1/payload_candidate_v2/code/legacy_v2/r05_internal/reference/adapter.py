"""Shared context encoder and member-specific terminal residuals."""
from __future__ import annotations

from typing import Mapping, Sequence

import torch
from torch import nn
from torch.nn import functional as F

from .contracts import MemberIdentity, require


class ContextAdapter(nn.Module):
    def __init__(self, members: Sequence[MemberIdentity], rank: int = 64):
        super().__init__()
        require(rank > 0, "rank must be positive")
        self.rank = rank
        self.context = nn.Sequential(nn.Linear(46, rank), nn.GELU(), nn.Linear(rank, rank))
        self.down = nn.ModuleDict({m.name: nn.Linear(m.hidden_width, rank, bias=True) for m in members})
        self.up = nn.ModuleDict({m.name: nn.Linear(rank, m.hidden_width, bias=False) for m in members})
        for layer in self.up.values():
            nn.init.zeros_(layer.weight)

    def forward(self, hidden, context, residue_mask, member: MemberIdentity):
        require(hidden.ndim == 3 and hidden.shape[-1] == member.hidden_width, "adapter hidden shape")
        require(context.shape == hidden.shape[:2] + (46,), "adapter context shape")
        require(residue_mask.shape == hidden.shape[:2] and residue_mask.dtype == torch.bool, "adapter residue mask")
        normed = F.layer_norm(hidden, (member.hidden_width,), weight=None, bias=None, eps=member.layer_norm_eps)
        g = self.context(context)
        delta = self.up[member.name](F.gelu(self.down[member.name](normed) + g))
        return delta * residue_mask.unsqueeze(-1)


def apply_adapter(adapter, params: Mapping[str, torch.Tensor], hidden, context, residue_mask, member):
    require(set(params) == set(dict(adapter.named_parameters())), "functional adapter parameter keys differ")
    delta = torch.func.functional_call(adapter, dict(params), (hidden, context, residue_mask, member), strict=True)
    return hidden + delta


class FrozenHead(nn.Module):
    """Freeze original complete cls parameters without detaching its inputs."""
    def __init__(self, head: nn.Module):
        super().__init__()
        self.head = head
        self.head.requires_grad_(False)
        self.head.eval()

    def train(self, mode: bool = True):
        super().train(False)
        self.head.eval()
        return self

    def forward(self, hidden):
        # Caller decides whether an inference-only no_grad scope is appropriate.
        # Training and inner adaptation must preserve normal input autograd.
        return self.head(hidden)
