# CPU资格候选：当前以 MINIMAL_PAYLOAD_BOUNDARY_V2.json 为准

资源仍建议2CPU/16GB/30分钟/0GPU，当前没有部署或训练release。

允许载荷仅三source small594索引/显式资格准入、R01从父流派生的前2批有向pairs（父流和切片均hash）、三天然输入以及原native权重只读绑定。不得上传功能数值TSV，包括train-only train_bank.tsv；不得上传六份2000批完整流。原权重不下载/复制。天然metadata不等于新SOURCE资格。

已实核三份历史天然doc均为SOURCE_POOL，R01当前manifest是SOURCE_TRAIN_ONLY，R05 runtime_contract却要求SOURCE natural和精确五字段SOURCE admission。这是实际接口缺口，等待显式新资格准入和对应schema；不能改角色/文件名规避。

R05当前native qualification入口会prepare/capture_member/构造scorer并更新，和本候选cpu_gate_launcher的“无native模型加载”权限不同。当前sbatch/launcher只是本地未部署候选，未擅自放宽权限：必须由R05/根明确CPU阶段实际工作量、内存可行性、入口argv/产物/权限后修订并重新hash，才能变READY。不得把toy guard通过写成真实native资格通过。

恢复对照需分开记录continuous/prefix/resume/retry的实际optimizer更新次数。举例连续2+前缀1+恢复1，共逻辑深度2但实际计算4次；这是记账示例，不是批准工作量。每source/架构及总量必须由真实操作ledger汇总。

已备文件：cpu_qualification.sbatch、cpu_gate_launcher.py、test_cpu_gate_launcher.py、绑定/挂载/唯一提交意图/release模板；旧草案单独保留。8项本地拒绝测试和Bash语法通过，不等于上游READY。先消费确切READY依赖并冻结actual imports/输入/runtime/payload哈希，根签唯一CPU资格release后才由原R02核本意图并提交。含糊受理先对账，不自动重投或干扰无关作业。没有训练release。
