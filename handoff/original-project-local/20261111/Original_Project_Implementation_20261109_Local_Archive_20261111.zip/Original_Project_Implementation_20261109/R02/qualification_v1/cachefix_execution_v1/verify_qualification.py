"""Verify downloaded receipts and fields for the one cachefix qualification."""
from collections import Counter
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
COLLECTION = ROOT / "CPU_JOB_5214122"
RUN = COLLECTION / "run"
OUT = RUN / "output-5214122"
QUAL = OUT / "qualification"
SOURCES = {
    "CAS9_STRP1_Spencer_2017_positive",
    "HSP82_YEAST_Flynn_2019",
    "RCRO_LAMBD_Tsuboyama_2023_1ORC",
}
MEMBERS = {"20", "128", "512", "1024", "2048", "4096"}


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    pointer = read(COLLECTION / "LATEST.json")
    collection_file = Path(pointer["path"])
    assert sha(collection_file) == pointer["sha256"]
    evidence = read(collection_file)
    assert evidence["job_id"] == "5214122" and evidence["terminal"]
    index = {f["path"]: f for f in evidence["all_output_file_metadata"]}
    for file in evidence["files"]:
        assert sha(RUN / file["path"]) == file["sha256"]
    assert evidence["GPU_seconds"] == 0 and "gres/gpu" not in evidence["AllocTRES"]

    receipt = read(QUAL / "RUNTIME_RECEIPT.json")
    assert receipt["status"] == "COMPLETE_UNEVALUATED"
    assert receipt["device"] == "cpu" and receipt["actual_native_loads"] == 1
    assert evidence["state"] == "COMPLETED" and evidence["exit_code"] == "0:0"
    assert read(OUT / "CPU_ACTION_RECEIPT.json")["returncode"] == 0
    loads = read(QUAL / "NATIVE_LOAD.json")
    assert set(loads) == MEMBERS
    native = read(ROOT.parent / "payload_final_v3/control/NATIVE_LOCK.json")
    for member in native["members"]:
        load = loads[str(member["K"])]
        actual = load["actual_model_source"]
        assert actual.startswith("/out/")
        path = Path(actual.removeprefix("/out/"))
        assert not path.is_absolute() and ".." not in path.parts
        assert sha(OUT / path) == member["modeling_source_sha256"]
        assert sha(OUT / path.with_name("configuration_prosst.py")) == member["configuration_source_sha256"]
        assert not any(load["loading_info"].get(k) for k in (
            "missing_keys", "unexpected_keys", "mismatched_keys", "error_msgs"
        ))

    summary = read(QUAL / "QUALIFICATION_SUMMARY.json")
    assert summary["status"] == "THREE_SOURCE_SIX_CELL_PASS_NOT_FORMAL_TRAINING"
    assert summary["actual_total_optimizer_updates"] == 12
    assert summary["actual_native_prefix_full_forwards"] == 18
    assert summary["formal2000_training"] is False
    expected = {(source, arch) for source in SOURCES for arch in ("S", "L")}
    assert Counter((x["source_id"], x["architecture"]) for x in summary["cells"]) == Counter(expected)

    cells = []
    for row in summary["cells"]:
        source, arch = row["source_id"], row["architecture"]
        base = QUAL / source / arch
        assert row == read(base / "QUALIFICATION.json")
        assert row["actual_updates"] == 2 and len(row["gradients"]) == 2
        assert row["resume_new_instance_exact"] and row["frozen_bytes_unchanged"]
        for step in row["gradients"]:
            norms = step["head_input_gradient_norms"]
            assert set(norms) == MEMBERS and all(np.isfinite(v) and v > 0 for v in norms.values())
        first = read(base / "first/PAUSE_RECEIPT.json")
        second = read(base / "second/TRAIN_RECEIPT.json")
        assert first["completed_updates"] == first["attempts"] == 1
        assert second["completed_updates"] == second["attempts"] == 2
        for subdir, step in (("first", 1), ("second", 2)):
            records = (base / subdir / "updates.jsonl").read_text().splitlines()
            assert len(records) == 1
            update = json.loads(records[0])
            assert update["completed_update"] == update["attempt"] == step
        assert second["resume_checkpoint"]["sha256"] == first["checkpoints"][0]["sha256"]
        checkpoint = (base / "second/STEP_2.pt").relative_to(RUN).as_posix()
        assert index[checkpoint]["sha256"] == row["checkpoint_sha256"]
        full = read(base.parent / "FULL_SPAN.json")
        length = full["WT_length"]
        natural = read(ROOT.parent / "payload_final_v3/inputs" / source / f"{source}.json")
        sequence = natural["wt_sequence"]
        assert length == len(sequence)
        assert full["truncation"] is False and set(full["members"]) == MEMBERS
        n = 19 * length
        assert full["normalization_universe"] == n
        raw = base / "RAW_SOURCE_QUALIFICATION"
        pred = read(raw / "PREDICTION_RECORD.json")
        assert pred["n_full19l"] == n and pred["no_functional_labels"] is True
        assert pred["wt_sha256"] == natural["wt_sha256"] and pred["protein_id"] == source
        assert sha(raw / "RAW.npz") == pred["raw_sha256"] == row["raw_export_sha256"]
        assert sha(raw / "PREDICTIONS.csv") == pred["csv_sha256"]
        with np.load(raw / "RAW.npz", allow_pickle=False) as data:
            assert data["ensemble"].shape == (n,) and np.isfinite(data["ensemble"]).all()
            ids = data["variant_ids"].tolist()
            assert ids == [
                f"{wt}{position}{alt}"
                for position, wt in enumerate(sequence, 1)
                for alt in "ACDEFGHIKLMNPQRSTVWY" if alt != wt
            ]
            for member in MEMBERS:
                assert data[f"logits_{member}"].shape == (length, 25)
                assert np.isfinite(data[f"logits_{member}"]).all()
            with (raw / "PREDICTIONS.csv").open(newline="") as stream:
                rows = list(csv.DictReader(stream))
            assert [x["variant_id"] for x in rows] == ids
            assert np.array_equal([float(x["score"]) for x in rows], data["ensemble"])
        cells.append({
            "source": source, "architecture": arch, "full_candidates": n,
            "elapsed_seconds": row["elapsed_seconds"], "actual_updates": row["actual_updates"],
            "actual_scorer_calls": row["actual_scorer_calls"],
            "actual_member_head_calls": row["actual_member_head_calls"],
        })

    elapsed = evidence["allocation_seconds"]
    report = {
        "status": "PASS_ACTUAL_CPU_QUALIFICATION_ONLY",
        "job_id": "5214122", "collection": pointer, "cells": cells,
        "actual_optimizer_updates": sum(c["actual_updates"] for c in cells),
        "actual_native_prefix_full_forwards": summary["actual_native_prefix_full_forwards"],
        "allocation_seconds": elapsed, "CPU_count": 8, "CPU_core_seconds": elapsed * 8,
        "including_parent_CPU_core_seconds": (185 + elapsed) * 8, "GPU_seconds": 0,
        "training_release": False, "target_evaluation_release": False,
    }
    with (ROOT / "QUALIFICATION_ACCEPTANCE_5214122.json").open("x", encoding="utf-8") as stream:
        json.dump(report, stream, indent=2)
        stream.write("\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

