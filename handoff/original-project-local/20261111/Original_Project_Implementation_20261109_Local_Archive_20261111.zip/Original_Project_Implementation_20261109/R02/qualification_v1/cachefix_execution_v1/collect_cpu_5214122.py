"""Read-only collection of the one accepted CPU qualification; never resubmit."""
from pathlib import Path
import sys,json,hashlib,base64,datetime,subprocess
D=Path(__file__).resolve().parent.parent
sys.path.insert(0,'F:/novoR2/Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2')
from remote_qualification import SSH,PYTHON
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
sub=json.loads((D/'cachefix_execution_v1/CPU_CACHEFIX_SUBMISSION_RECEIPT.json').read_bytes());assert sub['job_id']=='5214122'
payload={'root':sub['remote_root'],'job_id':sub['job_id'],'signed_file_index':json.loads((D/'cachefix_execution_v1/SIGNED_PACKAGE_CACHEFIX_V1.json').read_bytes())['files']}
code=r'''
from pathlib import Path
import subprocess,json,hashlib,base64,datetime,os
R=Path(PLAN['root']);jid=PLAN['job_id'];S='/public/gridview_20250224/slurm/bin/'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
p=subprocess.run([S+'sacct','-X','-n','-P','-j',jid,'--format=JobIDRaw,JobName%100,State%40,ExitCode,ElapsedRaw,AllocTRES%150,WorkDir%300,User,Start,End'],capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stderr;rows=[l.split('|') for l in p.stdout.splitlines() if l];assert len(rows)==1;row=rows[0]
assert row[0]==jid and row[1]=='OriginalProject_CPUqual_cachefix_20261109' and row[6]==str(R) and row[7]=='s20223010065';assert 'gres/gpu' not in row[5]
state=row[2].split()[0];out=R/('output-'+jid);terminal=state in ('COMPLETED','FAILED','TIMEOUT','CANCELLED','OUT_OF_MEMORY','NODE_FAIL');files=[];metadata=[]
if terminal:
 for name,v in PLAN['signed_file_index'].items():assert sha(R/name)==v['sha256'],'deployed input/code changed'
 selected=[R/'SUBMISSION_RECEIPT.json',R/'SUBMISSION_INTENT.json']+list((R/'logs').glob('*'+jid+'*'))
 if out.exists():selected+=sorted(f for f in out.rglob('*') if f.is_file())
 totalbytes=0
 for f in sorted(set(selected)):
  assert f.resolve().is_relative_to(R.resolve()),'unexpected escaped output link';n=f.relative_to(R).as_posix();h=sha(f);size=f.stat().st_size
  # Keep large torch states/cache at original school path; hash identities retained.
  download=f.suffix in ('.json','.jsonl','.txt','.log','.out','.err','.stdout','.stderr','.npz','.csv','.py') and size<=16*1024*1024
  metadata.append({'path':n,'bytes':size,'sha256':h,'downloaded':download,'remote_path':str(f)})
  if download:
   totalbytes+=size;assert totalbytes<=160*1024*1024,'bounded collection exceeded'
   files.append({'path':n,'sha256':h,'bytes':size,'payload_b64':base64.b64encode(f.read_bytes()).decode()})
summary=[]
if (out/'qualification').exists():summary=[str(f.relative_to(out)) for f in (out/'qualification').rglob('QUALIFICATION.json')]
print(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'job_id':jid,'state':state,'exit_code':row[3],'allocation_seconds':int(row[4]),'AllocTRES':row[5],'CPU_count':8,'GPU_seconds':0,'sacct':p.stdout,'terminal':terminal,'qualification_cell_receipts_present':summary,'files':files,'all_output_file_metadata':metadata,'new_submissions':0,'functional_values_read':False}))
'''
A=D/'cachefix_execution_v1/CPU_JOB_5214122';A.mkdir(exist_ok=True);stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');p=subprocess.run(SSH+[PYTHON],input=('PLAN='+repr(payload)+'\n'+code).encode(),capture_output=True,timeout=180);(A/(stamp+'.stderr')).write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode(errors='replace')[-1800:];x=json.loads(p.stdout)
for f in x['files']:
 b=base64.b64decode(f.pop('payload_b64'));assert hashlib.sha256(b).hexdigest()==f['sha256'];rel=Path(f['path']);assert not rel.is_absolute() and '..' not in rel.parts;dest=A/'run'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 if dest.exists():assert sha(dest)==f['sha256'],'immutable terminal output changed'
 else:dest.write_bytes(b)
out=A/(stamp+'_COLLECTION.json');out.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8');(A/'LATEST.json').write_text(json.dumps({'path':str(out),'sha256':sha(out)},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'receipt':str(out),'sha256':sha(out),'job_id':x['job_id'],'state':x['state'],'exit_code':x['exit_code'],'allocation_seconds':x['allocation_seconds'],'cells_present':len(x['qualification_cell_receipts_present']),'downloaded_files':len(x['files']),'GPU_seconds':0,'terminal':x['terminal']},indent=2))
