"""One exact CPU qualification deployment/submission; ambiguous acceptance never retries."""
from pathlib import Path
import json,hashlib,base64,subprocess,sys,datetime,argparse
D=Path(__file__).resolve().parent.parent;E=D.parents[1]
sys.path.insert(0,'F:/novoR2/Research_Diagnosis_20261106/FourCell_Pilot_20261106/R02_Runtime/QUALIFICATION_PREPARATION_V2')
from remote_qualification import SSH,PYTHON
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
a=argparse.ArgumentParser();a.add_argument('--check-only',action='store_true');args=a.parse_args()
info=read(D/'cachefix_execution_v1/SIGNED_PACKAGE_CACHEFIX_V1.json');release=read(info['outer_release']['path']);inner=read(info['inner_release']['path']);ready=read(D/'SUBMISSION_READY_V3.json');env=read(D/'EXACT_RUNTIME_ENV_V3.json')['env'];env['R02_RUN_ROOT']=release['exact_remote_root']
assert sha(info['archive']['path'])==info['archive']['sha256'] and sha(info['outer_release']['path'])==info['outer_release']['sha256'] and sha(info['inner_release']['path'])==release['R05_release_sha256']
assert release['status']=='RELEASED' and release['action']=='execute' and release['CPU']==8 and release['memory_GiB']==64 and release['GPU_count']==0 and release['max_new_sbatch']==1 and release['max_actual_optimizer_updates']==12
assert sha(ready['job']['path'])==release['job_sha256']==inner['job_sha256'] and sha(info['script_override']['path'])==release['batch_script_sha256']
assert release['unsigned_archive_sha256']==info['unsigned_parent']['sha256'] and sha(info['unsigned_parent']['path'])==release['unsigned_archive_sha256']
if args.check_only:print(json.dumps({'status':'EXACT_SIGNED_CPU_DEPLOYMENT_CHECK_PASS_NO_NETWORK','max_sbatch':1,'CPU':8,'RAM_GiB':64,'wall':1800,'GPU':0,'max_updates':12}));raise SystemExit(0)
payload={'root':env['R02_RUN_ROOT'],'env':env,'archive_b64':base64.b64encode(Path(info['archive']['path']).read_bytes()).decode(),'archive_sha256':info['archive']['sha256'],'files':info['files'],'release':release,'outer_release_sha256':info['outer_release']['sha256'],'inner_release_sha256':info['inner_release']['sha256']}
code=r'''
from pathlib import Path,PurePosixPath
import json,hashlib,subprocess,base64,zipfile,io,os,datetime,socket
R=Path(PLAN['root']);S='/public/gridview_20250224/slurm/bin/';name='OriginalProject_CPUqual_cachefix_20261109'
def cmd(a):
 p=subprocess.run(a,capture_output=True,text=True,timeout=40);assert p.returncode==0,repr((a,p.stderr));return p.stdout
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert cmd(['id','-un']).strip()=='s20223010065' and str(R)=='/public/home/s20223010065/RFduffision/Original_Project_Implementation_20261109/cpu_qualification_cachefix_v1'
assert not R.exists(),'existing root/intent must be reconciled, never overwrite or resubmit'
history=cmd([S+'sacct','-X','-n','-P','-S','2026-11-09','--name',name,'--format=JobIDRaw,JobName%100,State%40,ExitCode']);assert not history.strip(),'existing exact intent job history, stop'
queue=cmd([S+'squeue','-h','-u','s20223010065','-n',name,'-o','%i|%j|%T|%b']);assert not queue.strip(),'existing exact job pending/running, stop; unrelated jobs untouched'
for k in ('R02_RUNTIME_ENV','R02_BASE_ENV','R02_SIF','R02_SINGULARITY','R02_MODELROOT','R02_EXISTING2048'):assert Path(PLAN['env'][k]).exists() and os.access(PLAN['env'][k],os.R_OK),k
b=base64.b64decode(PLAN['archive_b64']);assert hashlib.sha256(b).hexdigest()==PLAN['archive_sha256'];z=zipfile.ZipFile(io.BytesIO(b));assert z.testzip() is None and set(z.namelist())==set(PLAN['files']) and len(z.namelist())==len(PLAN['files'])
for n in z.namelist():
 q=PurePosixPath(n);assert not q.is_absolute() and '..' not in q.parts and '\\' not in n
 assert hashlib.sha256(z.read(n)).hexdigest()==PLAN['files'][n]['sha256'] and len(z.read(n))==PLAN['files'][n]['bytes']
assert hashlib.sha256(z.read('control/CPU_ACTION_RELEASE.json')).hexdigest()==PLAN['outer_release_sha256'] and hashlib.sha256(z.read('control/R05_ROOT_RELEASE.json')).hexdigest()==PLAN['inner_release_sha256']
imp=json.loads(z.read('control/IMPORT_LOCK.json'))
for v in imp['files'].values():assert sha(v['path'])==v['sha256'],'actual existing import file changed'
assert hashlib.sha256(z.read('cpu_qualification.sbatch')).hexdigest()==PLAN['release']['batch_script_sha256']
R.mkdir(parents=True,exist_ok=False)
for n in z.namelist():p=R/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
for n,v in PLAN['files'].items():assert sha(R/n)==v['sha256']
(R/'logs').mkdir()
intent={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive_sha256':PLAN['archive_sha256'],'outer_release_sha256':PLAN['outer_release_sha256'],'root':str(R),'exact_job_name':name,'exact_prior_history':history,'exact_prior_queue':queue,'max_new_sbatch':1,'CPU':8,'RAM_GiB':64,'wall':1800,'GPU':0,'max_actual_optimizer_updates':12,'remote_file_hashes_verified':len(PLAN['files']),'unrelated_jobs_modified':False}
with (R/'SUBMISSION_INTENT.json').open('x') as f:json.dump(intent,f,indent=2)
export=dict(PLAN['env']);export['SINGULARITYENV_SLURM_CPUS_PER_TASK']='8';envspec='ALL,'+','.join(k+'='+v for k,v in sorted(export.items()));assert all(',' not in v and '\n' not in v for v in export.values())
a=[S+'sbatch','--parsable','--chdir='+str(R),'--output='+str(R/'logs/cpu-%j.out'),'--error='+str(R/'logs/cpu-%j.err'),'--export='+envspec,str(R/'cpu_qualification.sbatch')]
x={'status':'SUBMISSION_ATTEMPT_STARTED','remote_root':str(R),'archive_sha256':PLAN['archive_sha256'],'command':a,'outer_release_sha256':PLAN['outer_release_sha256'],'new_attempts':1,'max_new_sbatch':1,'GPU':0,'qualification_only':True,'formal_training':False,'unrelated_jobs_modified':False}
(R/'SUBMISSION_RECEIPT.json').write_text(json.dumps(x,indent=2)+'\n')
p=subprocess.run(a,cwd=R,capture_output=True,text=True,timeout=40);x.update(returncode=p.returncode,stdout=p.stdout,stderr=p.stderr);(R/'SUBMISSION_RECEIPT.json').write_text(json.dumps(x,indent=2)+'\n');assert p.returncode==0,p.stderr
jid=p.stdout.strip().split(';')[0];assert jid.isdigit(),'ambiguous sbatch acceptance, stop for readonly reconciliation'
x.update(status='EXACT_SINGLE_CPU_QUALIFICATION_SBATCH_ACCEPTED_NOT_PASS',job_id=jid,actual_account='s20223010065',hostname=socket.gethostname(),resources={'CPU':8,'RAM_GiB':64,'Slurm_seconds':1800,'GPU':0})
(R/'SUBMISSION_RECEIPT.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(x))
'''
with (D/'cachefix_execution_v1/LOCAL_CPU_CACHEFIX_SUBMISSION_INTENT.json').open('x') as f:json.dump({'archive_sha256':info['archive']['sha256'],'outer_release_sha256':info['outer_release']['sha256'],'max_sbatch':1,'automatic_retry':False},f)
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');p=subprocess.run(SSH+[PYTHON],input=('PLAN='+repr(payload)+'\n'+code).encode(),capture_output=True,timeout=240);(D/'cachefix_execution_v1'/(stamp+'_CPU_SUBMISSION.stdout')).write_bytes(p.stdout);(D/'cachefix_execution_v1'/(stamp+'_CPU_SUBMISSION.stderr')).write_bytes(p.stderr);assert p.returncode==0,p.stderr.decode(errors='replace')[-2200:];x=json.loads(p.stdout);out=D/'cachefix_execution_v1/CPU_CACHEFIX_SUBMISSION_RECEIPT.json';assert not out.exists();out.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8');print(json.dumps({'receipt':str(out),'sha256':sha(out),'status':x['status'],'job_id':x['job_id'],'resources':x['resources'],'new_sbatch':1},indent=2))
