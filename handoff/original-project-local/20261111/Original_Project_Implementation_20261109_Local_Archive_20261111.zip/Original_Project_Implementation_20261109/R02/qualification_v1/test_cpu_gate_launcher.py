"""CPU guards only; no producer entry/model/data files are executed."""
from pathlib import Path
import copy,importlib.util,json,tempfile,unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('cpu_gate_launcher',ROOT/'cpu_gate_launcher.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Guards(unittest.TestCase):
 def setUp(self):
  self.b=json.loads((ROOT/'BINDINGS_NOT_READY.json').read_text(encoding='utf-8'));self.r=json.loads((ROOT/'RELEASE_NOT_RELEASED.json').read_text(encoding='utf-8'))
 def ready_prefix(self):
  self.b['status']='READY';self.r.update(status='RELEASED',bindings_sha256='digest',launcher_sha256='digest')
 def invoke(self):
  with patch.object(m,'read',side_effect=[self.b,self.r]),patch.object(m,'sha',return_value='digest'):
   return m.verify('binding','release','launcher')
 def test_current_not_ready_rejected(self):
  with self.assertRaisesRegex(ValueError,'bindings not READY'):m.verify(ROOT/'BINDINGS_NOT_READY.json',ROOT/'RELEASE_NOT_RELEASED.json',ROOT/'cpu_gate_launcher.py')
 def test_unreleased_rejected(self):
  self.b['status']='READY'
  with self.assertRaisesRegex(ValueError,'no exact CPU release'):self.invoke()
 def test_controller_rejected(self):
  self.ready_prefix();self.r['controller']='old-controller'
  with self.assertRaisesRegex(ValueError,'controller identity'):self.invoke()
 def test_gpu_request_rejected(self):
  self.ready_prefix();self.r['GPU_count']=1
  with self.assertRaisesRegex(ValueError,'resource caps'):self.invoke()
 def test_training_permission_rejected(self):
  self.ready_prefix();self.r['training']=True
  with self.assertRaisesRegex(ValueError,'scope escalation'):self.invoke()
 def test_target_permission_rejected(self):
  self.ready_prefix();self.b['functional_target_labels_allowed']=True
  with self.assertRaisesRegex(ValueError,'scope'):self.invoke()
 def test_missing_entry_rejected(self):
  self.ready_prefix()
  with self.assertRaisesRegex(ValueError,'missing exact CPU entrypoint'):self.invoke()
 def test_altered_binding_rejected(self):
  self.ready_prefix();self.r['bindings_sha256']='wrong'
  with self.assertRaisesRegex(ValueError,'identities'):self.invoke()
if __name__=='__main__':unittest.main(verbosity=2)
