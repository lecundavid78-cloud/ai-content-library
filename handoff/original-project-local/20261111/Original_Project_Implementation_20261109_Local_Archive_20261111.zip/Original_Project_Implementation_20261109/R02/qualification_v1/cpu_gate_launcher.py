"""Fail-closed CPU qualification launcher. No network/model imports; exact release only."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys

def need(ok,msg):
 if not ok:raise ValueError(msg)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8'))
def verify(bindings,release,launcher_path):
 b=read(bindings);r=read(release)
 need(b['schema']=='R02_SINGLE_SOURCE_CPU_QUALIFICATION_BINDINGS_V1' and b['status']=='READY','bindings not READY')
 need(r['schema']=='R02_EXACT_CPU_QUALIFICATION_RELEASE_V1' and r['status']=='RELEASED','no exact CPU release')
 need(b['controller']==r['controller']=='01a1c09c-f9e6-70f1-b9e8-b988b89c755f','controller identity')
 need(r['bindings_sha256']==sha(bindings) and r['launcher_sha256']==sha(launcher_path),'actual bindings/launcher identities')
 need(r['GPU_count']==0 and r['CPU']==2 and r['memory_GiB']==16 and r['wall_seconds']==1800 and r['max_new_sbatch']==1,'exact resource caps')
 need(r['allowed_stage']=='CPU_QUALIFICATION_ONLY' and b['stage']=='CPU_QUALIFICATION_ONLY','stage')
 need(all(r[k] is False for k in ('native_model_load_or_forward','training','target_labels')),'scope escalation')
 need(b['model_load_or_forward_allowed'] is False and b['functional_target_labels_allowed'] is False and b['training_release'] is False,'scope')
 need(b['resource_caps']=={'CPU':2,'memory_GiB':16,'wall_seconds':1800,'external_seconds':1740},'binding caps')
 entry=b['entrypoint'];need(isinstance(entry,dict) and set(entry)=={'path','sha256','argv','cpu_only'} and entry['cpu_only'] is True,'missing exact CPU entrypoint')
 ep=Path(entry['path']).resolve();need(ep.is_relative_to(Path('/code')) and ep.is_file() and sha(ep)==entry['sha256'],'actual entry outside frozen code')
 need(isinstance(entry['argv'],list) and all(isinstance(x,str) for x in entry['argv']),'argv')
 need(b['code_files'] and b['input_files'] and b['required_output_receipts'],'no empty bindings/outputs')
 seen=set()
 for kind,root in [('code_files','/code'),('input_files','/inputs')]:
  for f in b[kind]:
   need(set(f)=={'path','sha256','role'},'file binding schema');p=Path(f['path']).resolve()
   need(p.is_relative_to(Path(root)) and p.is_file() and str(p) not in seen and sha(p)==f['sha256'],'file identity or path');seen.add(str(p))
   need(f['role'] in ('CPU_CODE','SOURCE_TRAIN_BANK','SOURCE_TRAIN_PAIRS','SOURCE_ADMISSION_METADATA','LABEL_FREE_METADATA'),'forbidden file role')
 need(str(ep) in seen,'entry not in code manifest')
 return b,r

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--bindings',required=True);ap.add_argument('--release',required=True);a=ap.parse_args()
 b,r=verify(a.bindings,a.release,__file__)
 need(os.environ.get('CUDA_VISIBLE_DEVICES')=='','CUDA not explicitly disabled')
 need(os.environ.get('SLURM_JOB_GPUS','')=='' and os.environ.get('SLURM_GPUS','') in ('','0'),'GPU allocation forbidden')
 out=Path('/out/result');out.mkdir(exist_ok=False)
 cmd=[sys.executable,'-B',b['entrypoint']['path'],*b['entrypoint']['argv']]
 with (out/'ENTRY.stdout').open('wb') as stdout,(out/'ENTRY.stderr').open('wb') as stderr:
  p=subprocess.run(cmd,cwd=out,stdout=stdout,stderr=stderr,timeout=1680)
 need(p.returncode==0,'CPU qualification entry failed')
 for name in b['required_output_receipts']:
  q=(out/name).resolve();need(q.is_relative_to(out) and q.is_file(),'missing receipt')
 receipt={'status':'CPU_ENTRY_COMPLETED_NOT_REAL_MODEL_QUALIFIED','command':cmd,'bindings_sha256':sha(a.bindings),'release_sha256':sha(a.release),'launcher_sha256':sha(__file__),'outputs':{n:sha(out/n) for n in b['required_output_receipts']},'GPU':0,'model_forward_verified':False,'training_admission':False}
 (out/'CPU_LAUNCH_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
if __name__=='__main__':main()
