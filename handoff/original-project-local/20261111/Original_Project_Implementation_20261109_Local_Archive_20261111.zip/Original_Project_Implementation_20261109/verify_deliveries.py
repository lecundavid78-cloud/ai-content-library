"""Controller receipt verification. Reads metadata/code/test receipts only."""
from pathlib import Path
import json, hashlib, datetime
D=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
for role in ('R01','R02','R03','R05'):
 p=D/role/'STATUS.json'
 if not p.exists():
  checks.append({'role':role,'status':'AWAITING_OWNER_RECEIPT'});continue
 doc=json.loads(p.read_text(encoding='utf-8-sig'))
 checks.append({'role':role,'owner_status':doc.get('status'),'status_sha256':sha(p)})
 if role=='R01':
  m=json.loads((D/role/'MANIFEST.json').read_text(encoding='utf-8-sig'))
  for x in m['files']:
   f=Path(x['path']);assert f.is_relative_to(D/role)
   assert sha(f)==x['sha256'] and f.stat().st_size==x['bytes'],str(f)
  checks[-1]['manifest_files_verified']=len(m['files'])
 if role=='R02':
  for x in doc['deliverables']:
   f=Path(x['path']);assert f.is_relative_to(D/role)
   assert sha(f)==x['sha256'] and f.stat().st_size==x['bytes']
  checks[-1]['deliverables_verified']=len(doc['deliverables'])
 if role=='R03':
  parent=Path(doc['metric_parent_path'])
  assert sha(parent)==doc['metric_parent_sha256']==sha(D/role/'metrics_reference.py')
  checks[-1]['inherited_metric_bytes_identical']=True
out={'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
     'checks':checks,'scope':'Metadata identities only; tests separately recorded; no model or raw functional values read',
     'new_server_jobs':0,'training_admission':False}
(D/'CONTROLLER_RECEIPT_VERIFICATION.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(out,ensure_ascii=False))
